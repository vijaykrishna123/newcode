#!/bin/ksh
 
# ------------------------------------------------------------------------
# Reports automation interface script
# ------------------------------------------------------------------------
 
CG_BUILD_SCRIPT_NAME=analyze.sh
BUILD_RC=0
 
echo ------------------------------------------------------------------------
echo Start Script: ${CG_BUILD_SCRIPT_NAME}
echo ------------------------------------------------------------------------
 
# ------------------------------------------------------------------------
# Environment specific settings should be read from env.sh
# ------------------------------------------------------------------------
. ./env.sh
 
# ------------------------------------------------------------------------
# CD out of the cgbuild directory (./cgbuild/interface/UNIX) for
# the rest of the relative paths within this script to work
# ------------------------------------------------------------------------
cd ../../..
 
# ------------------------------------------------------------------------
# Display parameters
# ------------------------------------------------------------------------
echo ------------------------------------------------------------------------
echo Parameters Passed to Script: ${CG_BUILD_SCRIPT_NAME}
echo ------------------------------------------------------------------------
echo Build Type                 : ${CG_BUILD_TYPE}
echo Build Number               : ${CG_BUILD_NUMBER}
echo Source Control Label Name  : ${CG_BUILD_LABEL}
echo Source Control last change : ${CG_SRC_LAST_CHANGE}
echo Application Name           : ${CG_APP_NAME}
echo Application Version        : ${CG_APP_VERSION}
echo Build Tools Home           : ${CG_TOOLS_HOME}
echo Running Analyze Step       :
echo ------------------------------------------------------------------------
 
# ------------------------------------------------------------------------
#  Insert code below
# ------------------------------------------------------------------------
if [ ${bamboo_buildprops_analyze} -eq 0 ]
then
    echo ------------------------------------------------------------------------
    echo Skipping Running Analyze Step
    echo ------------------------------------------------------------------------
    echo Finish script: ${CG_BUILD_SCRIPT_NAME}
    echo ------------------------------------------------------------------------
    exit 0
fi
 
# ----------------------------------------------------------------------------
# SonarQube Analysis via Bamboo
# ----------------------------------------------------------------------------
# To scan your source code and publish the results to SonarQube, simply execute
# our Python script that is available on the build agents.
#
# usage: Python code-scanner.py <version> <baseDir>
#
# * The Python is located in a sub folder in BuildTools.
# * code-scanner.py is located in a folder that is relative to BuildTools. 
# * Version is the version you want to display in your SonarQube project. We
#   recommend you use the App Version + Build Number (full app version).
# * BaseDir is the base directory of the source code that you want to scan.
#   Typically, the source code is in a folder at the same level as the CGBuild
#   folder that this analyze.bat is being executed from.
#
# NOTE: sonar.project.properties file is required in the baseDir path.
 
# - Change value if you prefer a different version
#version=${CG_APP_VERSION}.${CG_BUILD_NUMBER}
 
# - Change value to your source code. Note, add BUILD_PATH env var in your env.sh
## Absolute path to this script
#  SCRIPT=$(readlink -f "$0")
## Absolute path this script is in
#  BUILD_PATH=$(dirname "$SCRIPT")
#
#  export BUILD_PATH
#baseDir=${BUILD_PATH}/../../../src
 
# Executing Code Analysis
#${CG_TOOLS_HOME}/c/linux32/CGPython/bin/python ${CG_TOOLS_HOME}/../synced_repos/interface_scripts/analyze/code-scanner.py ${version} ${baseDir}
 
 
# ----------------------------------------------
# Maven Command for Running Sonar Scan
# ----------------------------------------------
BRANCH=`echo ${bamboo_planRepository_branch} | cut -c1-7`
KEY=${bamboo_buildprops_key}
 
echo "Running SonarScan"
echo "Running: ${M3_HOME}/bin/mvn sonar:sonar -Dsonar.projectKey=${KEY} -Dsonar.branch=${BRANCH}"
${M3_HOME}/bin/mvn sonar:sonar -Dsonar.projectKey=${KEY} -Dsonar.branch=${BRANCH}
 
BUILD_RC=$?
 
if [ ${BUILD_RC} -ne 0 ]
then
  echo Build step failed
  echo ------------------------------------------------------------------------
  echo Finish script: ${CG_BUILD_SCRIPT_NAME}  Result: ${BUILD_RC}
  echo ------------------------------------------------------------------------
  exit 1
fi
 
 
echo Build step completed
echo ------------------------------------------------------------------------
echo Finish script: ${CG_BUILD_SCRIPT_NAME}  Result: ${BUILD_RC}
echo ------------------------------------------------------------------------
 
exit $?
