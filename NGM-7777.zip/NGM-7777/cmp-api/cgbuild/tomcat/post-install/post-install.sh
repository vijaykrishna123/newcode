echo running-tomcat-post-install

#cd /users/cgc/cwb/{{environment}}/tomcat/tc-cwb1/bin
#mv /users/cgc/cwb/{{environment}}/app/cwb1/cmp-api*.war /users/cgc/cwb/{{environment}}/tomcat/tc-cwb1/webapps

date >> /tmp/post-install.log
chmod 644 /tmp/post-install.log
