// package com.capgroup.digital.ce.cmp.config;
//
// import static org.hamcrest.CoreMatchers.startsWith;
// import static org.junit.Assert.assertThat;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;
// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.core.Appender;
// import org.apache.logging.log4j.core.LogEvent;
// import org.apache.logging.log4j.core.Logger;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.mockito.ArgumentCaptor;
// import org.mockito.Captor;
// import org.mockito.Mock;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.core.io.Resource;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.test.util.ReflectionTestUtils;
//
// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// public class TaxonomyMappingConfigTest {
//
// @Autowired
// TaxonomyMappingConfig config;
// @Value("classpath:/taxonomy-mapping-invalid.json")
// private Resource jsonResource;
// @Mock
// private Appender mockAppender;
// @Captor
// private ArgumentCaptor<LogEvent> captorLoggingEvent;
// private Logger logger;
//
// @Before
// public void setup() {
// when(mockAppender.getName()).thenReturn("MockAppender");
// when(mockAppender.isStarted()).thenReturn(true);
// when(mockAppender.isStopped()).thenReturn(false);
// logger = (Logger) LogManager.getLogger(TaxonomyMappingConfig.class);
// logger.addAppender(mockAppender);
// }
//
// @Test
// public void testInvalidJsonLoad() {
//
// ReflectionTestUtils.setField(config, "jsonResource", jsonResource);
//
// config.loadMappingsJson();
//
// verify(mockAppender, times(1)).append(captorLoggingEvent.capture());
// assertThat(captorLoggingEvent.getValue()
// .getMessage()
// .getFormattedMessage(), startsWith("Error while loading taxonomy-mapping.json:"));
// }
//
// }
