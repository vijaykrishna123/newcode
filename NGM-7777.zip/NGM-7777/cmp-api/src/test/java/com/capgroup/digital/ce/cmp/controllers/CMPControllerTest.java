package com.capgroup.digital.ce.cmp.controllers;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.ArrayList;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import com.capgroup.digital.ce.cmp.dto.Post;
import com.capgroup.digital.ce.cmp.dto.PostData;
import com.capgroup.digital.ce.cmp.exceptions.PercolateException;
import com.capgroup.digital.ce.cmp.services.CMPService;

@RunWith(SpringRunner.class)
@WebMvcTest(CMPController.class)
@ActiveProfiles("test")
public class CMPControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private CMPService service;

  @Test
  public void addUrlShouldReturn201WhenThereIsNoException() throws Exception {

    doNothing().when(service)
        .addCWBUrl();

    this.mockMvc.perform(post("/v1/add-url"))
        .andExpect(status().isCreated());
  }

  @Test
  public void getContentShouldReturn201WhenThePostExists() throws Exception {

    final PostData content = new PostData();
    given(service.getContent("post:12345")).willReturn(content);

    this.mockMvc.perform(get("/v1/posts/post:12345"))
        .andExpect(status().isOk());
  }

  @Test
  public void getAssignmentsShouldReturn400WhenSearchParamIsMissing() throws Exception {

    this.mockMvc.perform(get("/v1/assignments"))
        .andExpect(status().isBadRequest());
  }

  @Test
  public void getAssignmentsShouldReturn401WhenUserDoesNotExist() throws Exception {

    given(service.getAssignments("abc")).willThrow(new PercolateException(""));
    this.mockMvc.perform(get("/v1/assignments?search=abc"))
        .andExpect(status().isNotFound());
  }

  @Test
  public void getAssignmentsShouldReturn200WhenUserExist() throws Exception {

    given(service.getAssignments("rbn")).willReturn(new ArrayList<Post>());
    this.mockMvc.perform(get("/v1/assignments?search=rbn"))
        .andExpect(status().isOk());
  }

  @Test
  public void getPostsShouldReturn401WhenPostDoesNotExist() throws Exception {

    given(service.getContent("post:123")).willThrow(new PercolateException(""));
    this.mockMvc.perform(get("/v1/posts/post:123"))
        .andExpect(status().isNotFound());
  }

  @Test
  public void getPostsShouldReturn200WhenPostExist() throws Exception {

    given(service.getContent("post:123")).willReturn(new PostData());
    this.mockMvc.perform(get("/v1/posts/post:123"))
        .andExpect(status().isOk());
  }
}
