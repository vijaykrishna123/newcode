package com.capgroup.digital.ce.cmp.repositories;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import com.capgroup.digital.ce.cmp.dto.TaxonomyMapping;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class TaxonomyRepositoryTest {

  @Autowired
  private TaxonomyRepository repository;

  @Test
  public void readTaxonomyMapping() throws Exception {
    final TaxonomyMapping mappings = repository.fetchAllMappings();
    assertThat(mappings.containsKey("Content Distribution Channel"), is(true));
    assertThat(mappings.get("Content Distribution Channel")
                       .containsKey("Advisor"), is(true));
  }

}
