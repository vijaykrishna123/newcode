package com.capgroup.digital.ce.cmp.services;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.util.ReflectionTestUtils;
import com.capgroup.digital.ce.cmp.dto.Post;
import com.capgroup.digital.ce.cmp.dto.PostData;
import com.capgroup.digital.ce.cmp.dto.TaxonomyMapping;
import com.capgroup.digital.ce.cmp.edam.EdamCsrfToken;
import com.capgroup.digital.ce.cmp.edam.EdamGateway;
import com.capgroup.digital.ce.cmp.exceptions.CMPException;
import com.capgroup.digital.ce.cmp.repositories.TaxonomyRepository;
import com.capgroup.digital.ce.cmp.util.TestDataReader;
import com.google.common.collect.ImmutableMap;
import com.percolate.sdk.api.request.license.LicenseV5Params;
import com.percolate.sdk.api.request.metadata.MetadataParams;
import com.percolate.sdk.api.request.post.PostListParams;
import com.percolate.sdk.api.request.schema.SchemasListParams;
import com.percolate.sdk.api.request.terms.TermsParams;
import com.percolate.sdk.api.request.users.UsersParams;
import com.percolate.sdk.dto.LicensesV5;
import com.percolate.sdk.dto.MetadataItem;
import com.percolate.sdk.dto.MetadataList;
import com.percolate.sdk.dto.PostV5;
import com.percolate.sdk.dto.PostV5Data;
import com.percolate.sdk.dto.PostsV5;
import com.percolate.sdk.dto.Schema;
import com.percolate.sdk.dto.SchemaField;
import com.percolate.sdk.dto.Schemas;
import com.percolate.sdk.dto.Term;
import com.percolate.sdk.dto.User;
import com.percolate.sdk.dto.WorkflowSteps;

@ActiveProfiles("test")
@RunWith(MockitoJUnitRunner.class)
public class CMPServiceTest {

  @Mock
  private PercolateGateway percolateGateway;
  @Mock
  private TaxonomyRepository taxonomyRepository;
  @InjectMocks
  private CMPServiceImpl cmpService;
  @Rule
  public ExpectedException exception = ExpectedException.none();

  @Mock
  private EdamGateway edamGateway;

  @Before
  public void setUp() {
    cmpService = Mockito.spy(this.cmpService);
  }

  @Test
  public void givenValidPostId_GetContent_ShouldReturnContent() throws IOException {
    final String postId = "post:41528859";
    final Map<String, Object> metadata = mockMetadata();

    // given
    given(percolateGateway.getPost(any())).willReturn(TestDataReader.readData("getpost_1.json", PostV5.class));
    ReflectionTestUtils.setField(cmpService, "workfrontJobId", "Workfront Job #");
    doReturn(metadata).when(cmpService)
                      .fetchMetaData(postId);
    doReturn(metadata).when(cmpService)
                      .getTaxonomyMappings(metadata);

    // when
    final PostData content = cmpService.getContent(postId);

    // then
    assertThat(content, notNullValue());
    assertThat(content.getMetaData()
                      .size(), is(6));
    assertThat(content.getMetaData()
                      .get("Workfront Job #"), is("123"));
  }

  @Test(expected = CMPException.class)
  public void givenSchemaDoesntExist_buildMetaData_ShouldThrowError() {
    final Schema schema = new Schema();
    schema.setFields(Arrays.asList());
    cmpService.buildMetaData(ImmutableMap.of("1", "metadata1", "2", "metadata2"), schema);
  }

  @Test
  public void givenValidSchema_getMetadataSchemaKey_ShouldReturnKey() {
    final Schema schema = new Schema();
    final SchemaField field1 = new SchemaField();
    field1.setLabel("testLabel");
    field1.setKey("1");
    final SchemaField field2 = new SchemaField();
    field2.setLabel("testLabel2");
    field2.setKey("11");
    schema.setFields(Arrays.asList(field1, field2));
    assertThat(cmpService.getMetadataSchemaKey(schema, "testLabel2"), is("11"));
  }

  @Test(expected = CMPException.class)
  public void givenFieldMissing_getMetadataSchemaKey_ShouldThrowError() {
    final Schema schema = new Schema();
    schema.setFields(Arrays.asList());
    cmpService.getMetadataSchemaKey(schema, "testLabel2");
  }

  @Test
  public void givenValidMetaData_GetTaxonomyMappings_ShouldReturnMapping() throws IOException {
    final Map<String, Object> metadata = mockMetadata();
    // given
    given(taxonomyRepository.fetchAllMappings()).willReturn(mockTaxonomyMapping());
    // when
    final Map<String, Set<String>> mappings = cmpService.getTaxonomyMappings(metadata);
    // then
    System.out.println(mappings);
    assertThat(mappings, notNullValue());
    assertThat(mappings.size(), is(2));
    assertThat(mappings.get("Channel")
                       .size(), is(1));
    assertThat(mappings.get("Channel")
                       .contains("web"), is(true));
    assertThat(mappings.get("Audience")
                       .size(), is(2));
    assertThat(mappings.get("Audience")
                       .contains("advisor"), is(true));
    assertThat(mappings.get("Audience")
                       .contains("investor"), is(true));
  }

  @Test
  public void givenValidSearchString_GetAssignments_ShouldReturnListOfPostsWithMinimalProperties() throws IOException {

    final PostsV5 posts = new PostsV5();
    posts.setData(Arrays.asList(getPostV5Data(), new PostV5Data()));

    // given
    doReturn("user:113911").when(cmpService)
                           .getUserId("conpask");
    given(percolateGateway.listPost(any(PostListParams.class))).willReturn(posts);

    // when
    final List<Post> postList = cmpService.getAssignments("conpask");

    // then
    assertThat(postList, notNullValue());
    assertThat(postList.size(), is(2));
    assertThat(postList.get(0)
                       .getTitle(), is("post1"));
    assertThat(postList.get(0)
                       .getId(), is("post:123"));
    assertThat(postList.get(0)
                       .getLiveAt(), is("2018"));
  }

  @Test
  public void givenNoassignmentInPercolate_GetAssignments_ShouldReturnEmptyList() throws IOException {
    // given
    doReturn("user:113911").when(cmpService)
                           .getUserId("conpask");
    given(percolateGateway.listPost(any(PostListParams.class))).willReturn(new PostsV5());

    // when
    final List<Post> postList = cmpService.getAssignments("conpask");

    // then
    assertThat(postList, notNullValue());
    assertThat(postList.size(), is(0));
  }

  @Test
  public void givenValidSearchString_GetAssignments_ShouldReturnListOfPosts() throws IOException {

    // given
    doReturn("user:113911").when(cmpService)
                           .getUserId("conpask");
    given(percolateGateway.listPost(any(PostListParams.class))).willReturn(TestDataReader.readData("listpost_1.json",
        PostsV5.class));
    given(percolateGateway.listLicenses(any(LicenseV5Params.class))).willReturn(TestDataReader.readData(
        "license_1.json", LicensesV5.class)
                                                                                              .getLicenses());
    doReturn(TestDataReader.readData("object_step_1.json", WorkflowSteps.class)
                           .getData()).when(cmpService)
                                      .getCurrentWorkflowSteps(anyListOf(String.class));

    // when
    final List<Post> postList = cmpService.getAssignments("conpask");

    // then
    assertThat(postList, notNullValue());
    assertThat(postList.size(), is(8));
    assertThat(postList.get(0)
                       .getId(), is("post:41571223"));
    assertThat(postList.get(0)
                       .getTitle(), is("Create FAQ For College America 529"));
    assertThat(postList.get(0)
                       .getCurrentStatus(), is("Design"));
    assertThat(postList.get(0)
                       .getLiveAt(), is("2018-08-01T18:22:00+00:00"));
    assertThat(postList.get(0)
                       .getChannel(), is("Web"));
    assertThat(postList.get(0)
                       .getTemplate(), is("Web Article"));
    assertThat(postList.get(0)
                       .getTeam(), is("ASRP"));
  }

  @Test
  public void givenValidSearchString_GetUserId_ShouldReturnUserId() throws IOException {

    final User user = new User();
    user.setId("user:123");

    given(percolateGateway.listUser(any(UsersParams.class))).willReturn(Arrays.asList(user));

    assertThat(cmpService.getUserId("conpask"), is("user:123"));
  }

  @Test
  public void whenNoUserExist_GetUserId_ShouldThrowException() throws IOException {

    given(percolateGateway.listUser(any(UsersParams.class))).willReturn(Collections.emptyList());

    exception.expect(CMPException.class);
    exception.expectMessage("No users found for: conpask");
    cmpService.getUserId("conpask");
  }

  @Test
  public void whenMultipleUserExist_GetUserId_ShouldThrowException() throws IOException {

    given(percolateGateway.listUser(any(UsersParams.class))).willReturn(Arrays.asList(new User(), new User()));

    exception.expect(CMPException.class);
    exception.expectMessage("2 users found for : conpask");
    cmpService.getUserId("conpask");
  }

  @Test
  public void whenLicenseDoesnotExistfilterTeamByIdShouldNotThrowException() throws IOException {
    assertThat(cmpService.filterTeamById(Collections.emptyList(), "license:123"), nullValue());
  }

  @Test
  public void whenSchemaIsValid_getFilteredContents_ShouldReturnPostData() {

    final PostsV5 posts = new PostsV5();
    posts.setData(Arrays.asList(getPostV5Data(), new PostV5Data()));

    doReturn("").when(cmpService)
                .getMetadataSchemaKey(any(), anyString());
    given(percolateGateway.listPost(any(PostListParams.class))).willReturn(posts);

    final List<PostV5Data> dataList = cmpService.getFilteredContents(new Schema());

    assertThat(dataList, notNullValue());
    assertThat(dataList.size(), is(2));
  }

  @Test
  public void addCWBUrl_test() throws IOException {

    final PostV5Data data = new PostV5Data();
    final PostData postData = new PostData();
    data.setId("post:123");
    final MetadataItem item1 = new MetadataItem();
    item1.setExt(new LinkedHashMap<>());
    final MetadataItem item2 = new MetadataItem();
    item2.setExt(new LinkedHashMap<>());

    // given
    ReflectionTestUtils.setField(cmpService, "customFieldFlag", "CWB Linked");
    ReflectionTestUtils.setField(cmpService, "customFieldCWBUrl", "CWB URL");
    // ReflectionTestUtils.setField(cmpService, "customFieldWIPUrl", "WIP URL");

    given(percolateGateway.listSchema(any(SchemasListParams.class))).willReturn(TestDataReader.readData("schema_1.json",
        Schemas.class)
                                                                                              .getData());
    doReturn(Arrays.asList(data)).when(cmpService)
                                 .getFilteredContents(any(Schema.class));
    doReturn(postData).when(cmpService)
                      .getContent(data.getId());

    given(percolateGateway.listMetadata(any(MetadataParams.class))).willReturn(Arrays.asList(item1, item2));

    given(edamGateway.fetchCsrfToken()).willReturn(new EdamCsrfToken());


    // when
    cmpService.addCWBUrl();
    // then
    verify(percolateGateway, times(1)).updateMetadata(item1);
    verify(percolateGateway, times(1)).updateMetadata(item2);
  }

  @Test
  public void whenValidPostId_fetchMetdata_ShouldReturnMetadata() {
    final MetadataItem item1 = new MetadataItem();
    item1.setSchemaId("schema:123");
    item1.setExt(new LinkedHashMap<>());
    final Schema schema = new Schema();
    schema.setId("schema:123");

    // given
    given(percolateGateway.listMetadata(any(MetadataParams.class))).willReturn(Arrays.asList(item1));
    given(percolateGateway.listSchema(any(SchemasListParams.class))).willReturn(Arrays.asList(schema));
    // when
    final Map<String, Object> map = cmpService.fetchMetaData("post:123");
    // then
    assertThat(map, notNullValue());
  }

  @Test
  public void whenValidTermIdsPassed_interpretTerms_ShouldReturnTerms() {

    final Term term1 = new Term();
    term1.setName("web");
    final Term term2 = new Term();
    term2.setName("advisor");

    // given
    given(percolateGateway.listTerm(any(TermsParams.class))).willReturn(Arrays.asList(term1, term2));
    // when
    final String terms = cmpService.interpretTerms(Arrays.asList("Term:123", "Term:345"));
    // then
    assertThat(terms, is("web,advisor"));
  }

  @Test
  public void whenValidPostIdsPassed_getCurrentWorkflowSteps_ShouldReturnNotThrowException() {

    given(percolateGateway.listWorkflowSteps(any())).willReturn(Collections.emptyList());
    cmpService.getCurrentWorkflowSteps(Arrays.asList("post1", "post2"));
  }

  @Test
  public void testFetchMetaData() throws Exception {
    // TODO
    // given
    given(percolateGateway.listMetadata(any(MetadataParams.class))).willReturn(TestDataReader.readData(
        "listmetadata_1.json", MetadataList.class)
                                                                                             .getData());
    given(percolateGateway.listSchema(any(SchemasListParams.class))).willReturn(TestDataReader.readData(
        "listschema_1.json", Schemas.class)
                                                                                              .getData());
    // when
    final Map<String, Object> medataDataMap = cmpService.fetchMetaData("post:41528859");
    // then
    assertThat(medataDataMap, is(notNullValue()));
  }

  private Map<String, Object> mockMetadata() {
    final Map<String, Object> metadata = new LinkedHashMap<>();
    metadata.put("Target Audience", "*All,Plan Participant,Investor");
    metadata.put("Pod", "ASRP");
    metadata.put("Content Origin", "Original");
    metadata.put("Content Distribution Channel", "Advisor");
    metadata.put("Subject", "Asset Classes,Markets & Economy");
    return metadata;
  }

  private TaxonomyMapping mockTaxonomyMapping() {

    final Map<String, Map<String, String>> channel = new LinkedHashMap<>();
    channel.put("Advisor", ImmutableMap.of("Channel", "web", "Audience", "advisor"));
    channel.put("Investor", ImmutableMap.of("Channel", "web", "Audience", "investor"));

    final Map<String, Map<String, String>> audience = new LinkedHashMap<>();
    audience.put("Advisor", ImmutableMap.of("Audience", "advisor"));
    audience.put("Investor", ImmutableMap.of("Audience", "investor"));

    final TaxonomyMapping mapping = new TaxonomyMapping();
    mapping.put("Content Distribution Channel", channel);
    mapping.put("Target Audience", audience);

    return mapping;
  }

  private PostV5Data getPostV5Data() {
    final PostV5Data data = new PostV5Data();
    data.setName("post1");
    data.setId("post:123");
    data.setLiveAt("2018");
    data.setChannelId("web");
    return data;
  }

}
