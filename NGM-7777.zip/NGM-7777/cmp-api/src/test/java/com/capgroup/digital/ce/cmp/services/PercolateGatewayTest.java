package com.capgroup.digital.ce.cmp.services;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import com.capgroup.digital.ce.cmp.exceptions.PercolateException;
import com.capgroup.digital.ce.cmp.exceptions.PercolateGatewayException;
import com.percolate.sdk.api.PercolateApi;
import com.percolate.sdk.api.request.license.LicenseRequest;
import com.percolate.sdk.api.request.license.LicenseV5Params;
import com.percolate.sdk.api.request.metadata.MetadataParams;
import com.percolate.sdk.api.request.metadata.MetadataRequest;
import com.percolate.sdk.api.request.post.PostGetParams;
import com.percolate.sdk.api.request.post.PostListParams;
import com.percolate.sdk.api.request.post.PostRequest;
import com.percolate.sdk.api.request.schema.SchemasListParams;
import com.percolate.sdk.api.request.schema.SchemasRequest;
import com.percolate.sdk.api.request.terms.TermsParams;
import com.percolate.sdk.api.request.terms.TermsRequest;
import com.percolate.sdk.api.request.users.UsersParams;
import com.percolate.sdk.api.request.users.UsersRequest;
import com.percolate.sdk.api.request.workflow.WorkflowStepsParams;
import com.percolate.sdk.api.request.workflow.WorkflowStepsRequest;
import com.percolate.sdk.dto.LicenseV5;
import com.percolate.sdk.dto.LicensesV5;
import com.percolate.sdk.dto.MetadataItem;
import com.percolate.sdk.dto.MetadataList;
import com.percolate.sdk.dto.PostV5;
import com.percolate.sdk.dto.PostV5Data;
import com.percolate.sdk.dto.PostsV5;
import com.percolate.sdk.dto.Schema;
import com.percolate.sdk.dto.Schemas;
import com.percolate.sdk.dto.SingleMetadataItem;
import com.percolate.sdk.dto.Term;
import com.percolate.sdk.dto.Terms;
import com.percolate.sdk.dto.User;
import com.percolate.sdk.dto.Users;
import com.percolate.sdk.dto.WorkflowStepData;
import com.percolate.sdk.dto.WorkflowSteps;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

@RunWith(MockitoJUnitRunner.class)
public class PercolateGatewayTest {

  @Mock
  private PercolateApi percolateApi;
  @InjectMocks
  private PercolateGateway percolateGateway;
  @Rule
  public ExpectedException exception = ExpectedException.none();
  Call call;

  @Before
  public void init() {
    call = Mockito.mock(Call.class);
  }

  @Test
  public void givenPercolateResponseBodyIsNull_listPost_ShouldThrowPercolateException() throws IOException {

    final Response<PostsV5> response = Response.error(400, ResponseBody.create(null, "errString"));
    final PostRequest postRequest = Mockito.mock(PostRequest.class);

    // given
    given(percolateApi.post()).willReturn(postRequest);
    given(postRequest.list(any(PostListParams.class))).willReturn(call);
    given(call.execute()).willReturn(response);

    exception.expect(PercolateException.class);
    exception.expectMessage("HTTP code:400, errString");

    // when
    percolateGateway.listPost(new PostListParams());
  }

  @Test
  public void givenValidParams_listPost_ShouldReturnPosts() throws IOException {

    final PostsV5 posts = new PostsV5();
    posts.setData(Arrays.asList(new PostV5Data()));
    final Response<PostsV5> response = Response.success(posts);
    final PostRequest postRequest = Mockito.mock(PostRequest.class);

    // given
    given(percolateApi.post()).willReturn(postRequest);
    given(postRequest.list(any(PostListParams.class))).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    final PostsV5 post = percolateGateway.listPost(new PostListParams());
    assertThat(post, notNullValue());
    assertThat(post.getData(), notNullValue());
    assertThat(post.getData()
                   .size(), is(1));
  }

  @Test
  public void givenValidParams_listUser_ShouldReturnUsers() throws IOException {

    final Users users = new Users();
    users.setData(Arrays.asList(new User(), new User()));
    final Response<Users> response = Response.success(users);
    final UsersRequest request = Mockito.mock(UsersRequest.class);

    // given
    given(percolateApi.users()).willReturn(request);
    given(request.get(any(UsersParams.class))).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    final List<User> userList = percolateGateway.listUser(new UsersParams());
    assertThat(userList, notNullValue());
    assertThat(userList.size(), is(2));
  }

  @Test
  public void givenValidParams_listSchema_ShouldReturnSchema() throws IOException {

    final Schemas schemas = new Schemas();
    schemas.setData(Arrays.asList(new Schema(), new Schema()));
    final Response<Schemas> response = Response.success(schemas);
    final SchemasRequest request = Mockito.mock(SchemasRequest.class);

    // given
    given(percolateApi.schemas()).willReturn(request);
    given(request.list(any(SchemasListParams.class))).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    final List<Schema> userList = percolateGateway.listSchema(new SchemasListParams());
    assertThat(userList, notNullValue());
    assertThat(userList.size(), is(2));
  }

  @Test
  public void givenValidParams_listMetadata_ShouldReturnMetadata() throws IOException {

    final MetadataList metadataList = new MetadataList();
    metadataList.setData(Arrays.asList(new MetadataItem(), new MetadataItem()));
    final Response<MetadataList> response = Response.success(metadataList);
    final MetadataRequest request = Mockito.mock(MetadataRequest.class);

    // given
    given(percolateApi.metadata()).willReturn(request);
    given(request.list(any(MetadataParams.class))).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    final List<MetadataItem> userList = percolateGateway.listMetadata(new MetadataParams());
    assertThat(userList, notNullValue());
    assertThat(userList.size(), is(2));
  }

  @Test
  public void givenPostV5DataIsNull_getPost_ShouldNotThrowException() throws IOException {

    final Response<PostV5> response = Response.success(new PostV5());
    final PostRequest request = Mockito.mock(PostRequest.class);

    // given
    given(percolateApi.post()).willReturn(request);
    given(request.get(any(PostGetParams.class))).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    final PostV5 postV5 = percolateGateway.getPost(new PostGetParams("post:123"));
    assertThat(Optional.ofNullable(postV5.getData())
                       .isPresent(), is(false));
  }

  @Test(expected = PercolateGatewayException.class)
  public void givenIOExceptionAtPercolate_getPost_ShouldThrowException() throws IOException {

    final PostRequest request = Mockito.mock(PostRequest.class);

    // given
    given(percolateApi.post()).willReturn(request);
    given(request.get(any(PostGetParams.class))).willReturn(call);
    given(call.execute()).willThrow(IOException.class);

    // when
    percolateGateway.getPost(new PostGetParams("post:123"));
  }

  @Test(expected = PercolateGatewayException.class)
  public void givenIOExceptionAtPercolate_listSchema_ShouldThrowException() throws IOException {

    final SchemasRequest request = Mockito.mock(SchemasRequest.class);

    // given
    given(percolateApi.schemas()).willReturn(request);
    given(request.list(any())).willReturn(call);
    given(call.execute()).willThrow(IOException.class);

    // when
    percolateGateway.listSchema(new SchemasListParams());
  }

  @Test
  public void givenTerms_listTerm_ShouldNotThrowException() throws IOException {

    final Response<Terms> response = Response.success(new Terms());
    final TermsRequest request = Mockito.mock(TermsRequest.class);

    // given
    given(percolateApi.terms()).willReturn(request);
    given(request.get(any())).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    final List<Term> terms = percolateGateway.listTerm(new TermsParams());
    assertThat(Optional.ofNullable(terms)
                       .isPresent(), is(true));
  }

  @Test
  public void givenWorkflowSteps_listWorkflowSteps_ShouldNotThrowException() throws IOException {

    final Response<WorkflowSteps> response = Response.success(new WorkflowSteps());
    final WorkflowStepsRequest request = Mockito.mock(WorkflowStepsRequest.class);

    // given
    given(percolateApi.workflowSteps()).willReturn(request);
    given(request.list(any())).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    final List<WorkflowStepData> terms = percolateGateway.listWorkflowSteps(new WorkflowStepsParams());
    assertThat(Optional.ofNullable(terms)
                       .isPresent(), is(true));
  }

  @Test
  public void givenLicense_listLicenses_ShouldNotThrowException() throws IOException {

    final Response<LicensesV5> response = Response.success(new LicensesV5());
    final LicenseRequest request = Mockito.mock(LicenseRequest.class);

    // given
    given(percolateApi.licenses()).willReturn(request);
    given(request.get(any(LicenseV5Params.class))).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    final List<LicenseV5> terms = percolateGateway.listLicenses(new LicenseV5Params(""));
    assertThat(Optional.ofNullable(terms)
                       .isPresent(), is(true));
  }

  @Test
  public void givenMetaData_updateMetadata_ShouldNotThrowException() throws IOException {

    final Response<SingleMetadataItem> response = Response.success(new SingleMetadataItem());
    final MetadataRequest request = Mockito.mock(MetadataRequest.class);

    // given
    given(percolateApi.metadata()).willReturn(request);
    given(request.update(any())).willReturn(call);
    given(call.execute()).willReturn(response);

    // when
    percolateGateway.updateMetadata(new MetadataItem());
  }

  @Test
  public void givenPercolateException_updateMetadata_ShouldThrowException() throws IOException {

    final Response<SingleMetadataItem> response = Response.error(500, ResponseBody.create(null, "errString"));
    final MetadataRequest request = Mockito.mock(MetadataRequest.class);

    // given
    given(percolateApi.metadata()).willReturn(request);
    given(request.update(any())).willReturn(call);
    given(call.execute()).willReturn(response);

    exception.expect(PercolateException.class);
    exception.expectMessage("HTTP code:500, errString");

    // when
    percolateGateway.updateMetadata(new MetadataItem());
  }

}
