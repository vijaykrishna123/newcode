package com.capgroup.digital.ce.cmp.util;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import com.capgroup.digital.ce.cmp.config.TaxonomyMappingConfig;
import com.capgroup.digital.ce.cmp.services.CMPService;

@RunWith(MockitoJUnitRunner.class)
public class CMPSchedulerTest {

  @Mock
  private MappingCacheEvict cacheEvict;

  @Mock
  private CMPService service;

  @InjectMocks
  private CMPScheduler scheduler;

  @Test
  public void testClearCache() {
    scheduler.clearCaches();
    verify(cacheEvict, times(1)).evictAllMappingCache();
  }

  @Test
  public void testReloadCache() {
    final TaxonomyMappingConfig config = Mockito.mock(TaxonomyMappingConfig.class);
    final MappingCacheEvict cacheEvict = new MappingCacheEvict(config);
    cacheEvict.evictAllMappingCache();
    verify(config, times(1)).loadMappingsJson();
  }

  @Test
  public void testcallAddUrl() {
    scheduler.callAddUrl();
    verify(service, times(1)).addCWBUrl();
  }

}
