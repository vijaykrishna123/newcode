package com.capgroup.digital.ce.cmp.util;

import java.lang.reflect.Constructor;
import org.junit.Test;

public class ContstantsTest {

  @Test
  public void shouldNotBeInstantiable() throws Exception {
    coverageSingleton(CMPContstants.class);
    coverageSingleton(PercolateConstants.class);
  }

  private <S> void coverageSingleton(final Class<S> singletonClass) throws Exception {
    final Constructor<S> constructor = singletonClass.getDeclaredConstructor();
    constructor.setAccessible(true);
    constructor.newInstance();
  }
}
