package com.capgroup.digital.ce.cmp.util;

import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestDataReader {

  static ObjectMapper mapper = new ObjectMapper();
  static ClassLoader loader = TestDataReader.class.getClassLoader();

  public static <T> T readData(final String fileName, final Class<T> t) throws IOException {
    return mapper.readValue(loader.getResourceAsStream(fileName), t);
  }

}
