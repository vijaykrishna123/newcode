echo running-tomcat-post-install
date >> /tmp/post-install.log
chmod 644 /tmp/post-install.log
