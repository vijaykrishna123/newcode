package com.capgroup.digital.ce.cwb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
// @EnableJpaAuditing
public class CreativeWBApplication extends SpringBootServletInitializer {

  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }

  @Override
  protected SpringApplicationBuilder configure(final SpringApplicationBuilder application) {
    return application.sources(CreativeWBApplication.class);
  }

  public static void main(final String[] args) throws Throwable {
    SpringApplication.run(CreativeWBApplication.class, args);
  }
}
