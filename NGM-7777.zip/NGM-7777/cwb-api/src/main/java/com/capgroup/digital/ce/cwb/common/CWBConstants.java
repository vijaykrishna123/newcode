package com.capgroup.digital.ce.cwb.common;

public class CWBConstants {

  public static final String COPY_SECTION = "copy";

  public static final String GRAPHICS_SECTION = "graphics";

  public static final String QUOTE_SECTION = "quote";

  public static final String BACKUP_SECTION = "backup";

  public static final String EMPTY_STRING = "";

  public static final String DEFAULT_CWB_TEMPLATE = "web-template";

  public static final String JSON_STATUS = "status";

  public static final String JSON_STATUS_SUCCESS = "success";

  public static final String JSON_STATUS_FAILURE = "failure";

  public static final String JSON_INTERNAL_MESSAGE = "internalMessage";

  public static final String APPLICATION_JSON = "application/json";

  public static final String IS_PHOTO = "This is a Photo";

  public static final String USERNAME_MENTION_REGEX = "@\\w+";

  public static final String EMAIL_COMMENT_TEXT = "Please click on the link below";

  public static final String HTTPS_SCHEME = "https://";
  
  public static final String EMAIL_COMMENT_SUBJECT_1 = "[Creative Workbench] ";

  public static final String EMAIL_COMMENT_SUBJECT_2 = " shared an assignment with you";

  public static final String FACEBOOK_SECTION = "facebook";

  public static final String LINKEDIN_SECTION = "linkedIn";

  public static final String TWITTER_SECTION = "twitter";
  
  public static final String SOCIAL_MEDIA_NEW_IDENTIFIER = "new";
  
  public static final String STATUS_UNLINKED = "UNLINKED";
  
  public static final String STATUS_DELETED = "DELETED";
  
  public static final String POST_DELETED = ":DELETED";
  
  public enum PURPOSE { SHARE, PROOF, PROOF_VERSION, ADD_REVIEWER}

  private CWBConstants() {
    throw new IllegalStateException("Constants Class");
  }

}
