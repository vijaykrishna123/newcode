package com.capgroup.digital.ce.cwb.common;

public class CWBMessages {

  public static final String FILE_EMPTY = "You failed to upload because the file was empty ";

  public static final String ASSET_ID_NOT_PRESENT = "Please provide asset id for the request";

  public static final String PERCOLATE_ID_NOT_PRESENT = "Please provide percolate ID";

  public static final String FILE_DOWNLOAD_ERROR = "Error while reading file or downloading file";

  public static final String FILE_UPLOAD_ERROR = "Error While Uploading File,Please contact Administrator";

  public static final String FILE_TYPE_NOT_SUPPORTED = "File type is not supported";

  public static final String ASSIGNMENT_NOT_FOUND = "Assignment Id not Found";

  public static final String FILE_NOT_FOUND = "File Not Found ";

  private CWBMessages() {
    throw new IllegalStateException("Constants Class");
  }

}
