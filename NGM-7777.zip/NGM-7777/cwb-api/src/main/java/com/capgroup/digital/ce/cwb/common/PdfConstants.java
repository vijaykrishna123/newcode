package com.capgroup.digital.ce.cwb.common;

public class PdfConstants {

  /** Constants for Copy section **/

  public static final String BODY = "Body";

  public static final String BODY_PLACEHOLDER = "++Body++";

  /** Constants for PDF metadata **/

  public static final String WORKFRONTJOB = "WorkfrontJobId";

  public static final String WORKFRONTJOB_PLACEHOLDER = "++workfrontJobId++";

  public static final String DISCLOSUREPATHS_PLACEHOLDER = "++disclosurePaths++";

  public static final String DISCLOSURETAGS_PLACEHOLDER = "++disclosureTags++";

  public static final String DISCLOSURES_PLACEHOLDER = "++disclosures++";

  public static final String SHORTCODE_REGEX = "(\\[\\w+ \\w+ #\\d+\\])";  

  public static final String CREATIVE_ASSETS = "CreativeAsset";
  
  public static final String BACKUP = "Backups";

  public static final String BACKSLASH = "/";

  public static final String WEB_HTML = "/web-template.html";
  
  public static final String EMAIL_HTML = "/email-template.html";
  
  /** Constants for EMAIL template **/
  
  public static final String EMAIL = "EMAIL";

  public static final String EMAIL_CSS = "email-template.css"; 
  
  public static final String EMAIL_HR_TAG_LOCATIONS = "p:has(strong:matchesOwn((?i)^Standard Disclosure$))";
  
  public static final String EMAIL_HEADINGS = "p:has(strong:matchesOwn((?i)^Subject$|^Pre-Header$|^Logo$|^Hero Image$|^Header$|^Email Body$|^Button link$|^Standard Disclosure$|^Footer$))";
		  
  public static final String EMAIL_HEADINGS_TO_REMOVE = "p:has(strong:matchesOwn((?i)^Logo$|^Hero Image$|^Header$|^Email Body$|^Button text$|^Button link$|^Footer$))";
    
  public static final String EMAIL_SUBTEXT_TO_REMOVE = "p:has(strong:matchesOwn((?i)^Subject$|^Pre-Header$))";
  
  /** Constants for WEB ARTICLE (capital ideas) template **/
  
  public static final String WEB_ARTICLE = "WEB ARTICLE";
  
  public static final String WEB_CSS = "web-template.css";
  
  public static final String WEB_HR_TAG_LOCATIONS = "table.Art, table[class~=Addisclosure]";
  
  public static final String WEB_HEADINGS = "p:has(strong:matchesOwn((?i)^Slug:$|^Key message tag:$|^SEO Title:$|^Web Description/Metadata:$|^Page Title:$|^Headline:$|^Byline/Featuring:$|^Article Text:$|^Social Media Posts:$))"; 
  
  public static final String WEB_HEADINGS_TO_REMOVE = "p:has(strong:matchesOwn((?i)^Hero Image:$|^Headline:$|^Title:$|^Byline/Featuring:$|^Article Text:$|^Investment professional bio:$|^Additional disclosures:$|^Disclosure:$))";

  public static final String WEB_SUBTEXT_TO_REMOVE = "p:has(strong:matchesOwn((?i)^Slug:$|^Key message tag:$|^Web Description/Metadata:$|^Page Title:$))";
  
  public static final String DEFAULT_CONTEXT_TAGS = "audience=adviser&channel=web&product=noProduct&feeStructure=noFeeStructure";
  
  /* Miscellaneous constants */
  
  public static final String SUGGESTION_TAG_REGEX = "<suggestion(.+?)type=\"start\"></suggestion>(.+?)<suggestion(.+?)type=\"end\"></suggestion>";
  
  public static final String CREATIVE = "Creative";

  public static final String PNG_IMAGE_EXTENSION = ".png";

  public static final String JPG_IMAGE_EXTENSION = ".jpg";

  public static final String PDF_EXTENSION = ".pdf";

  public static final String PDF_CONTENT_TYPE = "application/pdf";

  public static final String PDF = "pdf";

  public static final String ZIP = "zip";

  public static final String UTF_8 = "UTF-8";

  public static final String DOT = ".";

  public static final String HTML_BREAK = "<br />";
  
  public static final String EMPTY_P_Tag = "<p>&nbsp;</p>";
  
  public static final String PROOF_MODAL = "proof-modal";

  /* Graphics Constants */

  public static final String GRAPHICS_HEADLINE = "Graphic Headline";

  public static final String GRAPHICS_SUB_HEAD_1 = "Graphic Subhead 1";

  public static final String GRAPHICS_SUB_HEAD_2 = "Graphic Subhead 2";

  public static final String GRAPHICS_SOURCE = "Graphic Source";

  public static final String ADD_GRAPHICS = "Add Graphic";

  public static final String GRAPHICS_FILE_NAME = "Graphic File Name";

  // public static final String GRAPHICS_ALT_TEXT = "Graphic Alt Text";


  private PdfConstants() {
    throw new IllegalStateException("PDF Constants Class");
  }

}
