package com.capgroup.digital.ce.cwb.configs;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.gateways.DisclosureGateway;

@Configuration
@EnableJpaAuditing
public class CWBConfig {

  @Bean
  public DisclosureGateway getDisclosureGateway(@Value("${cg.disclosureServer}") final String host,
      @Value("${cg.disclosureApi}") final String api,
      @Value("${disableSSLCertificationCheck:false}") final boolean ssl) {

    final RestTemplate restTemplate;
    try {
      if (ssl)
        restTemplate = restTemplate();
      else
        restTemplate = new RestTemplate();
    } catch (KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
      throw new CWBException(e);
    }
    return new DisclosureGateway(restTemplate, host + api);
  }

  // temporary fix for discolosure SSL issue. Needs to be removed before going to STAGE
  private RestTemplate restTemplate() throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
    final TrustStrategy acceptingTrustStrategy = (final X509Certificate[] chain, final String authType) -> true;

    final SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
                                                                 .loadTrustMaterial(null, acceptingTrustStrategy)
                                                                 .build();
    final SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
    final CloseableHttpClient httpClient = HttpClients.custom()
                                                      .setSSLSocketFactory(csf)
                                                      .build();
    final HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
    requestFactory.setHttpClient(httpClient);

    return new RestTemplate(requestFactory);
  }
}
