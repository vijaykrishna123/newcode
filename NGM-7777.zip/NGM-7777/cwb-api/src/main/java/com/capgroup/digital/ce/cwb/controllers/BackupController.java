package com.capgroup.digital.ce.cwb.controllers;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import javax.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.capgroup.digital.ce.cwb.services.IBackups;

@RestController
public class BackupController {

  @Autowired
  private IBackups backups;

  private final Logger log = LogManager.getLogger(BackupController.class);

  /**
   * Method for handling backup file upload
   * 
   * @param file
   * @param postId
   * @param userId
   * @return
   * @throws Exception
   */
  @PostMapping(value = "/v1/backups", produces = "application/json")
  public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam(
      value = "postId", defaultValue = "") String postId, @RequestParam(value = "userId",
          defaultValue = "") String userId) throws Exception {

    if (!file.isEmpty() && !postId.isEmpty() && !userId.isEmpty()) {

      return backups.saveBackup(file, postId, userId);
    } else {

      JSONObject responseJson = new JSONObject();
      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put("Status", "Failure");
      responseJson.put("internalMessage", "You failed to upload because no file details found");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);

    }

  }

  /**
   * Method for updating the backup file
   * 
   * @param file
   * @param backupId
   * @param postId
   * @param userId
   * @return
   * @throws Exception
   */
  @PutMapping(value = "/v1/backups", produces = "application/json")
  public ResponseEntity<String> handleFileUpdate(@RequestParam("file") MultipartFile file, @RequestParam(
      value = "backupId") Integer backupId, @RequestParam(value = "postId", defaultValue = "") String postId,
      @RequestParam(value = "userId", defaultValue = "") String userId) throws Exception {

    if (!file.isEmpty() && !postId.isEmpty() && !userId.isEmpty() && backupId != null) {

      return backups.updateBackup(file, backupId, postId, userId);
    } else {

      JSONObject responseJson = new JSONObject();
      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put("Status", "Failure");
      responseJson.put("internalMessage", "You failed to upload because no file details found");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);

    }

  }

  /**
   * Method for downloading the backup file
   * 
   * @param backupId
   * @param request
   * @return
   * @throws Exception
   */
  @GetMapping(value = "/v1/backups/{backupId}")
  public ResponseEntity<InputStreamResource> handleFileDownload(@PathVariable Integer backupId,
      HttpServletRequest request) throws Exception {

    if (backupId != null) {

      return backups.getBackup(backupId);
    } else {

      JSONObject responseJson = new JSONObject();
      responseJson.put("Status", "Failure");
      responseJson.put("internalMessage", "FileId not present in Request");
      InputStream objectInputStream = new ByteArrayInputStream(responseJson.toString()
                                                                           .getBytes());
      InputStreamResource objectStreamResource = new InputStreamResource(objectInputStream);
      return new ResponseEntity<>(objectStreamResource, HttpStatus.BAD_REQUEST);
    }

  }

  /**
   * Method for deleting the backup file
   * 
   * @param backupId
   * @return
   * @throws Exception
   */
  @DeleteMapping(value = "/v1/backups/{backupId}", produces = "application/json")
  public ResponseEntity<String> handleFileDelete(@PathVariable Integer backupId) throws Exception {

    if (backupId != null) {

      return backups.deleteBackup(backupId);
    } else {

      JSONObject responseJson = new JSONObject();
      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put("Status", "Failure");
      responseJson.put("internalMessage", "You failed to upload because no file details found");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);

    }

  }
}
