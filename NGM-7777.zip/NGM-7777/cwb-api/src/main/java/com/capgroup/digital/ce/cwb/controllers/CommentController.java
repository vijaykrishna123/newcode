package com.capgroup.digital.ce.cwb.controllers;

import java.util.Arrays;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capgroup.digital.ce.cwb.common.CWBConstants.PURPOSE;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.CommentsRequest;
import com.capgroup.digital.ce.cwb.model.CommentsResponse;
import com.capgroup.digital.ce.cwb.model.RelatedComment;
import com.capgroup.digital.ce.cwb.repositories.AssignmentsRepository;
import com.capgroup.digital.ce.cwb.services.IComments;

@RestController
public class CommentController {

  @Autowired
  private IComments comments;

  @Autowired
  private AssignmentsRepository assignmentRepository;


  private final Logger log = LogManager.getLogger(CommentController.class);

  /**
   * Method to retrieve Assignment Comments
   * 
   * @param postId
   * @return
   */

  @GetMapping(value = "/v1/comments/{postId}", produces = "application/json")
  public ResponseEntity<List<CommentsResponse>> getComments(@PathVariable final String postId) throws Exception {

    final JSONObject errorJson = new JSONObject();
    final Integer assignmentId = assignmentRepository.getAssignmentId(postId);
    log.debug("**** assignmentId: ****" + assignmentId);
    if (assignmentId != null) {

      log.debug("********assignId:" + assignmentId + "*******");
      return new ResponseEntity<>(comments.getComments(assignmentId), HttpStatus.OK);

    } else {

      errorJson.put("internalMessage", "No Assignment ID found, Enter valid Assignment");
      throw new CWBException("No Valid Assignment ID found");
    }

  }

  /**
   * Method to Save Assignment Comments
   * 
   * @param commentsRequest
   * @return
   */

  @PostMapping(value = "/v1/comments/{purpose}", produces = "application/json")
  public ResponseEntity<String> createComments(@RequestHeader final String host, @PathVariable final String purpose,
      @RequestBody final CommentsRequest commentsRequest) {
	
	final Integer assignmentId = assignmentRepository.getAssignmentId(commentsRequest.getPercolateId());

	//purpose validation
	Arrays.stream(PURPOSE.values())
		.filter(purposeValue -> purposeValue.toString().equalsIgnoreCase(purpose))
		.findAny()
		.orElseThrow( () -> new CWBException ("Please enter a valid purpose: {share, proof, proof_version, add_reviewer} -> You entered: " + purpose));
	
	if (assignmentId !=null ) {
	  return comments.createComments(commentsRequest, host, purpose);
	  
	} else {	  
      throw new CWBException("No assignments found for the given percolateId: " + commentsRequest.getPercolateId());
      
	}
  }
  
  /**
   * Method to retrieve related comments
   * 
   * @param relatedInitial
   * @return
   */

  @GetMapping(value = "/v1/comments", produces = "application/json")
  public ResponseEntity<List<RelatedComment>> getRelatedCommentsByRelatedInitial(@RequestParam final String relatedInitial) throws Exception {

    final JSONObject errorJson = new JSONObject();
    if (relatedInitial != null) {

      log.debug("********initial:" + relatedInitial + "*******");
      return new ResponseEntity<>(comments.getRelatedCommentsByRelatedInitial(relatedInitial), HttpStatus.OK);

    } else {

      errorJson.put("internalMessage", "No initial found");
      throw new CWBException("No Valid initial found");
    }

  }
  
  /**
   * Method for deleting the comment
   * 
   * @param commentId
   * @return
   * @throws Exception
   */
  @DeleteMapping(value = "/v1/comments/{commentId}", produces = "application/json")
  public ResponseEntity<String> deleteComment(@PathVariable Integer commentId) throws Exception {

      return comments.deleteComment(commentId);

  }
 
}
