package com.capgroup.digital.ce.cwb.controllers;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.model.EmailRequest;
import com.capgroup.digital.ce.cwb.services.IEmailNotifiers;

@RestController
public class FeedBackController {

  @Autowired
  IEmailNotifiers notifiers;

  @PostMapping(value = "/v1/feedback/email", produces = "application/json")
  public ResponseEntity<String> emailFeedBackFromUser(@RequestBody final EmailRequest emailRequest) {

    notifiers.sendEmail(emailRequest.getRecepient(), emailRequest.getSubject(), emailRequest.getTextContent());

    final JSONObject responseJson = new JSONObject();

    responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);

    responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Thanks for the response");

    return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);

  }

}
