package com.capgroup.digital.ce.cwb.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.services.IGraphics;

@RestController
public class GraphicController {

  @Autowired
  private IGraphics graphics;

  /**
   * Method for handling graphics file upload
   * 
   * @param file
   * @param postId
   * @param userId
   * @param graphicShortCode
   * @return
   * @throws Exception
   */
  @PostMapping(value = "/v1/graphics", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<String> handleFileUpload(@RequestParam(value = "file", required = true) MultipartFile file,
      @RequestParam(value = "postId", required = true) String postId, @RequestParam(value = "userId",
          required = true) String userId) throws Exception {

    return graphics.saveGraphics(file, postId, userId);

  }

  /**
   * Method for downloading graphics file
   * 
   * @param graphicId
   * @param request
   * @return
   * @throws Exception
   */
  @GetMapping(value = "/v1/graphics/{graphicId}")
  public ResponseEntity<InputStreamResource> handleFileDownload(@PathVariable Integer graphicId) throws Exception {

    return graphics.getGraphics(graphicId);

  }

  /**
   * Method for deleting the graphics file
   * 
   * @param graphicId
   * @return
   * @throws Exception
   */
  @DeleteMapping(value = "/v1/graphics/{graphicId}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<String> handleFileDelete(@PathVariable Integer graphicId) throws Exception {

    return graphics.deleteGraphics(graphicId);

  }

  /**
   * Method for handling graphics file update
   * 
   * @param file
   * @param graphicId
   * @param postId
   * @param userId
   * @param graphicShortCode
   * @return
   * @throws Exception
   */
  @PutMapping(value = "/v1/graphics", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<String> handleFileUpdate(@RequestParam(value = "file", required = true) MultipartFile file,
      @RequestParam(value = "graphicId", required = true) Integer graphicId, @RequestParam(value = "postId",
          required = true) String postId, @RequestParam(value = "userId", required = true) String userId) throws Exception {

    return graphics.updateGraphics(file, graphicId, postId, userId);

  }
}
