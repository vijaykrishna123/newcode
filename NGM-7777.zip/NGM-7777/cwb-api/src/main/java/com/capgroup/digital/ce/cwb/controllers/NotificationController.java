package com.capgroup.digital.ce.cwb.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.RestController;
import com.capgroup.digital.ce.cwb.model.Notification;
import com.capgroup.digital.ce.cwb.services.INotifications;

@RestController
public class NotificationController {


  @Autowired
  private INotifications notificationService;

  @MessageMapping("/sendMessage")
  public ResponseEntity<?> someAction(Notification notification) throws Exception {

    notificationService.notifyUser(notification);

    return new ResponseEntity<>("Notification Sent!!", HttpStatus.OK);
  }

  @MessageExceptionHandler
  @SendTo("/topic/errors")
  public String handleException(Throwable exception) {

    return exception.getMessage();
  }

}
