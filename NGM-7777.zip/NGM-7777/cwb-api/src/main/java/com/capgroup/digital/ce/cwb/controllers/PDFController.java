package com.capgroup.digital.ce.cwb.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgroup.digital.ce.cwb.common.CWBMessages;
import com.capgroup.digital.ce.cwb.common.PdfConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.services.IPdfService;

@RestController
public class PDFController {

	private IPdfService pdfService;

	@Autowired
	public PDFController(IPdfService pdfService) {
		this.pdfService = pdfService;
	}

	@GetMapping(value = "v1/generate/{percolateId}")
	public ResponseEntity<InputStreamResource> generatePDF(@PathVariable final String percolateId,
			@RequestParam(value = "fileType", defaultValue = PdfConstants.PDF) String fileType) throws IOException {

		if (!StringUtils.isEmpty(percolateId)) {
			if (PdfConstants.PDF.equalsIgnoreCase(fileType))

				return pdfService.generatePDFForAssignment(percolateId);
			else if (PdfConstants.ZIP.equalsIgnoreCase(fileType))
				return pdfService.generateZipForAssignment(percolateId);
			else
				throw new CWBException(CWBMessages.FILE_TYPE_NOT_SUPPORTED);
		} else {
			throw new CWBException(CWBMessages.PERCOLATE_ID_NOT_PRESENT);
		}

	}

}
