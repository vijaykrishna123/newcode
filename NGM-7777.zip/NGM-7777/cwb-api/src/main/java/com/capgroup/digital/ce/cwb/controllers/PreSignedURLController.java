package com.capgroup.digital.ce.cwb.controllers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.CDL;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.services.IPreSignedURL;

@RestController
public class PreSignedURLController {

  @Autowired
  private IPreSignedURL s3PreSignedURL;

  private final Logger log = LogManager.getLogger(PreSignedURLController.class);

  @RequestMapping(value = "/v1/signedurl", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<String> getSignedURL(@RequestParam(value = "objectKey", defaultValue = "") String objectKey,
      @RequestParam(value = "requestType", defaultValue = "") String requestType) throws Exception {

    JSONObject errorJson = new JSONObject();
    if (!objectKey.isEmpty()) {

      log.info("********objectKey:" + objectKey + "*******");
      String responseData = "";
      responseData = s3PreSignedURL.getS3PreSignedURL(objectKey, requestType);
      if (!responseData.isEmpty()) {

        JSONArray resultArray = new JSONArray();
        resultArray = CDL.toJSONArray(responseData);
        return ResponseEntity.ok()
                             .body(resultArray.toString());
      } else {

        errorJson.put("internalMessage", "Error generating the URL");
        return ResponseEntity.badRequest()
                             .body(errorJson.toString());
      }

    } else {

      errorJson.put("internalMessage", "No objectKey found");
      return ResponseEntity.badRequest()
                           .body(errorJson.toString());
    }

  }

}
