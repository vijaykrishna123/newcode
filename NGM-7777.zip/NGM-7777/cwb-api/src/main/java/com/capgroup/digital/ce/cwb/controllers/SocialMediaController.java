package com.capgroup.digital.ce.cwb.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.services.ISocialMedia;

@RestController
public class SocialMediaController {

  @Autowired
  private ISocialMedia socialMedia;

  /**
   * Method for handling social media file upload
   * 
   * @param file
   * @param postId
   * @param userId
   * @param socialMediaId
   * @return
   * @throws Exception
   */
  @PostMapping(value = "/v1/socialMedia", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<String> handleFileUpload(@RequestParam(value = "file", required = true) MultipartFile file,
      @RequestParam(value = "postId", required = true) String postId, @RequestParam(value = "userId",
          required = true) String userId, @RequestParam(value = "mediaType", required = true) String mediaType)
      throws Exception {

    return socialMedia.saveSocialMediaFile(file, postId, userId, mediaType);
  }

  /**
   * Method for downloading social media file
   * 
   * @param socialMediaId
   * @param request
   * @return
   * @throws Exception
   */
  @GetMapping(value = "/v1/socialMedia/{socialMediaId}")
  public ResponseEntity<InputStreamResource> handleFileDownload(@PathVariable Integer socialMediaId) throws Exception {

    return socialMedia.getSocialMediaFile(socialMediaId);
  }

  /**
   * Method for deleting the social media file
   * 
   * @param socialMediaId
   * @return
   * @throws Exception
   */
  @DeleteMapping(value = "/v1/socialMedia/{socialMediaId}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<String> handleFileDelete(@PathVariable Integer socialMediaId) throws Exception {

    return socialMedia.deleteSocialMedia(socialMediaId);
  }

  /**
   * Method for handling social media file update
   * 
   * @param file
   * @param socialMediaId
   * @param postId
   * @param userId
   * @param mediaType
   * @return
   * @throws Exception
   */
  @PutMapping(value = "/v1/socialMedia", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<String> handleFileUpdate(@RequestParam(value = "file", required = true) MultipartFile file,
      @RequestParam(value = "socialMediaId", required = true) Integer socialMediaId, @RequestParam(value = "postId",
          required = true) String postId, @RequestParam(value = "userId", required = true) String userId, @RequestParam(
              value = "mediaType", required = true) String mediaType) throws Exception {

    return socialMedia.updateSocialMediaFile(file, socialMediaId, postId, userId, mediaType);

  }
}
