package com.capgroup.digital.ce.cwb.controllers;

import javax.validation.Valid;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgroup.digital.ce.cwb.model.UserRequest;
import com.capgroup.digital.ce.cwb.model.entities.Users;
import com.capgroup.digital.ce.cwb.repositories.UserRepository;
import com.capgroup.digital.ce.cwb.services.IUsers;
import com.capgroup.digital.ce.cwb.services.impl.UserService;

@RestController
public class UserController {

  @Autowired
  private IUsers users;

  @Autowired
  private UserRepository userRepository;


  private final Logger log = LogManager.getLogger(UserService.class);


  /**
   * Method for retrieving all users
   */

  @GetMapping("v1/users")
  public Page<Users> fetchUsersForTagging(Pageable pageable) {

    return userRepository.findAll(pageable);

  }

  /**
   * Method for handling graphics file upload
   * 
   * @param UserRequest
   * @return
   */

  @PutMapping(value = "/v1/users")
  public ResponseEntity<Users> handleUpdateUser(@Valid @RequestBody UserRequest user) {

    log.debug("Create / Update Users for Authentication: " + user.getUserInitials());
    HttpStatus status = users.saveUsers(user);
    return new ResponseEntity<>(status);

  }

}
