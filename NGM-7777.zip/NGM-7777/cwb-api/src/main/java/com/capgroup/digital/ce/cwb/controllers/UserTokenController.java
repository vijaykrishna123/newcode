package com.capgroup.digital.ce.cwb.controllers;

import java.util.Optional;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.capgroup.digital.ce.cwb.configs.CyberArkService;
import com.capgroup.digital.ce.cwb.model.entities.Users;
import com.capgroup.digital.ce.cwb.repositories.UserRepository;
import com.capgroup.digital.ce.cwb.utils.JWTUtils;

@RestController
public class UserTokenController {


  @Value("${cyberArk.ckeditorsecret.accName}")
  private String secretKeyAccName;

  @Value("${cyberArk.ckeditorenvId.accName}")
  private String environmentIdAccName;

  @Value("${cyberArk.enabled}")
  private boolean cyberArkEnabled;


  @Autowired
  UserRepository userRepository;

  @Autowired
  CyberArkService data;

  @GetMapping(value = "/v1/token/{userInitials}", produces = "application/json")
  public ResponseEntity<String> generateTokenForUser(@PathVariable final String userInitials) throws Exception {
    String environmentId = null, secretKey = null;

    Optional<Users> user = userRepository.findByUserInitials(userInitials);
    String jwt = null;
    if (user.isPresent()) {

      Users retrievedUser = user.get();

      Long id = retrievedUser.getId();

      String email = retrievedUser.getEmail();

      String fullName = retrievedUser.getFirstName() + " " + retrievedUser.getLastName();

      JSONObject jwtPayload = new JSONObject();

      long nowMillis = System.currentTimeMillis();

      JSONObject createUserPayload = new JSONObject();

      createUserPayload.put("id", id.toString());

      createUserPayload.put("email", email);

      createUserPayload.put("name", fullName);

      JSONObject createServicesPayload = new JSONObject();

      JSONObject createCKCollabPayload = new JSONObject();

      JSONObject permissions = new JSONObject();

      permissions.put("*", "write");

      createCKCollabPayload.put("permissions", permissions);

      createServicesPayload.put("ckeditor-collaboration", createCKCollabPayload);

      if (cyberArkEnabled) {
        environmentId = data.getKeyFromCyberArk(environmentIdAccName, data.zone, data.env, data.resInstance,
            data.resAddress, data.technology, data.cgId);
        secretKey = data.getKeyFromCyberArk(secretKeyAccName, data.zone, data.env, data.resInstance, data.resAddress,
            data.technology, data.cgId);

      }
      jwtPayload.put("iss", environmentId);

      jwtPayload.put("iat", nowMillis / 1000);

      jwtPayload.put("user", createUserPayload);

      jwtPayload.put("services", createServicesPayload);


      jwt = JWTUtils.createJWT(environmentId, 60000, jwtPayload.toString(), secretKey);

    } else {

      throw new UsernameNotFoundException("User Not Found !!");
    }

    return new ResponseEntity<>(jwt, HttpStatus.OK);

  }

}
