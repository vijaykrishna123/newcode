package com.capgroup.digital.ce.cwb.controllers;

import java.io.IOException;
import java.util.List;
import javax.validation.Valid;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.Assignment;
import com.capgroup.digital.ce.cwb.model.AssignmentDetails;
import com.capgroup.digital.ce.cwb.model.CWBSuccess;
import com.capgroup.digital.ce.cwb.model.DraftAssignment;
import com.capgroup.digital.ce.cwb.model.LinkRequest;
import com.capgroup.digital.ce.cwb.model.ProofDetails;
import com.capgroup.digital.ce.cwb.model.TemplatesResponse;
import com.capgroup.digital.ce.cwb.model.WorkfrontDetails;
import com.capgroup.digital.ce.cwb.services.IAssignments;


@RestController
public class WriteController {

  @Autowired
  private IAssignments assignments;

  private static final Logger logger = LogManager.getLogger(WriteController.class);

  /**
   * Method for creating the assignment
   * 
   * @param assignment
   * @return
   */
  @PutMapping(value = "/v1/assignment")
  public ResponseEntity<Assignment> createAssignment(@Valid @RequestBody final Assignment assignment) {

    logger.debug("Create / Update Assignment for percolate Id: " + assignment.getPercolateId());

    return assignments.createAssignment(assignment);
  }

  /**
   * Method for fetching the assignment details
   *
   * @param percolateId
   * @return
   * @throws IOException
   */
  @GetMapping(value = "/v1/assignment/{percolateId}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<AssignmentDetails> getAssignmentDetails(@PathVariable final String percolateId) {
    logger.debug("Create / Update Assignment for percolate Id: " + percolateId);
    return new ResponseEntity<>(assignments.getAssignmentDetails(percolateId), getHeaders(), HttpStatus.OK);
  }
  
  /**
   * Method for fetching the given user's UNLINKED assignments
   *
   * @return
   * @throws IOException
   */
  @GetMapping(value = "/v1/assignments/unlinked/{userInitials}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<List<DraftAssignment>> getUnlinkedAssignments(@PathVariable final String userInitials) {
    logger.debug("Fetching 'UNLINKED' assignments for " + userInitials + "... ");
    return new ResponseEntity<>(assignments.getUnlinkedAssignments(userInitials), getHeaders(), HttpStatus.OK);
  }
  
  /**
   * Method for fetching all the given user's regular (not unlinked/draft) assignments created via percolate 
   *
   * @return
   * @throws IOException
   */
  @GetMapping(value = "/v1/assignments/{userInitials}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<List<Assignment>> getAssignments(@PathVariable final String userInitials) {
    logger.debug("Fetching all regular (not unlinked/draft) assignments for " + userInitials + "... ");
    return new ResponseEntity<>(assignments.getAssignments(userInitials), getHeaders(), HttpStatus.OK);
  }

  /**
   * Method for saving the assignment details
   * 
   * @param percolateId
   * @param assignmentDetails
   * @return
 * @throws Exception 
   */
  @PutMapping(value = "/v1/assignment/{percolateId}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<AssignmentDetails> saveAssignment(@PathVariable final String percolateId,
	@RequestBody final AssignmentDetails assignmentDetails) throws Exception {
    return new ResponseEntity<>(assignments.saveAssignments(percolateId, assignmentDetails), getHeaders(), HttpStatus.OK);
  }  

  /**
   * Method for saving the proof details
   * 
   * @param percolateId
   * @param proofDetails
   * @return
 * @throws Exception 
   */
  @Validated
  @PutMapping(value = "/v1/persist-proof/{percolateId}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<Object> saveProofDetail(@PathVariable final String percolateId,
      @Valid @RequestBody final ProofDetails proofDetails) {

    assignments.saveProofDetails(percolateId, proofDetails);
    return new ResponseEntity<>(getHeaders(), HttpStatus.NO_CONTENT);
  }
  
  /**
   * Method for saving the workfront details
   * 
   * @param percolateId
   * @param workfrontDetails
   * @return
 * @throws Exception 
   */
  @PutMapping(value = "/v1/persist-workfront-details/{percolateId}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<Object> saveWorkfrontDetails(@PathVariable final String percolateId,
      @Valid @RequestBody final WorkfrontDetails workfrontDetails) {
	
	if ( workfrontDetails.getWorkfrontDocId().isEmpty() || workfrontDetails.getWorkfrontDocId() == null) {
	  throw new CWBException("Workfront Document ID cannot be empty or null");
	}
    assignments.saveWorkfrontDetails(percolateId, workfrontDetails);
    return new ResponseEntity<>(getHeaders(), HttpStatus.NO_CONTENT);
  }
  
  /**
   * Method for fetching the template names 
   * 
   * @param 
   * @return
   */
  @GetMapping(value = "/v1/templates")
  public ResponseEntity<List<TemplatesResponse>> fetchTemplates() {

    logger.debug("Fetching template names from database... ");

    return assignments.fetchTemplates();
  }
  
  /**
   * Method for linking an assignment to a real percolate id
   * 
   * @param 
   * @return
   */
  @PutMapping(value = "/v1/link")
  public void link( @RequestBody final LinkRequest linkRequest ) {

     assignments.link(linkRequest);
  }
  
  /**
   * Method for fetching the unlinked assignment details
   *
   * @return
   * @throws IOException
   */
  @GetMapping(value = "/v1/posts/{percolateId}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<DraftAssignment> getUnlinkedAssignmentsDetails(@PathVariable final String percolateId) {
    
    return new ResponseEntity<>(assignments.getUnlinkedAssignmentsDetails(percolateId), getHeaders(), HttpStatus.OK);
  }  
  
  /**
   * Method for deleting unlinked/draft assignments
   *
   * @return
   * @throws IOException
   */
  @DeleteMapping(value = "/v1/delete/{draftId}", produces = CWBConstants.APPLICATION_JSON)
  public ResponseEntity<CWBSuccess> deleteDraftAssignment(@PathVariable final String draftId) {
  	
  	assignments.deleteDraftAssignment(draftId);    
	  
    return new ResponseEntity<>( new CWBSuccess(HttpStatus.OK,"Deleted Successfully"), getHeaders(), HttpStatus.OK);
  }

  /**
   * Method for getting headers
   * 
   * @return
   */
  private HttpHeaders getHeaders() {
    final HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return headers;
  }

}
