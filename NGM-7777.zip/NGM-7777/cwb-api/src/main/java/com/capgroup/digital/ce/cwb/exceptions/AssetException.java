package com.capgroup.digital.ce.cwb.exceptions;

public class AssetException extends RuntimeException {

	private static final long serialVersionUID = 1527373628274845067L;

	public AssetException(String message) {
		super(message);
	}

}
