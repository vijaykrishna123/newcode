package com.capgroup.digital.ce.cwb.exceptions;

import java.lang.reflect.Method;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;

public class CWBAsyncUncaughtExceptionHandler implements AsyncUncaughtExceptionHandler {

  private final Logger log = LogManager.getLogger(CWBAsyncUncaughtExceptionHandler.class);

  @Override
  public void handleUncaughtException(final Throwable arg0, final Method arg1, final Object... arg2) {

    log.error("Exception while executing aynschronous messages", arg0.getMessage(), arg1.toString());

  }

}
