package com.capgroup.digital.ce.cwb.exceptions;

public class CWBException extends RuntimeException {

  private static final long serialVersionUID = 8635638038520978271L;

  public CWBException() {
    super();
  }

  public CWBException(String message, Throwable reason, boolean enableSuppression, boolean writableStackTrace) {
    super(message, reason, enableSuppression, writableStackTrace);
  }

  public CWBException(String message, Throwable reason) {
    super(message, reason);
  }

  public CWBException(String message) {
    super(message);
  }

  public CWBException(Throwable reason) {
    super(reason);
  }

}
