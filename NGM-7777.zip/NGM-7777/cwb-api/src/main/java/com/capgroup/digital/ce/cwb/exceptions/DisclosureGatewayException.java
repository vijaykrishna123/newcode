package com.capgroup.digital.ce.cwb.exceptions;

public class DisclosureGatewayException extends RuntimeException {

  private static final long serialVersionUID = -6985676801404683847L;

  public DisclosureGatewayException(final String message) {
    super(message);
  }

  public DisclosureGatewayException(final Throwable cause) {
    super(cause);
  }

  public DisclosureGatewayException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
