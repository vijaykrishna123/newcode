package com.capgroup.digital.ce.cwb.gateways;

import java.util.List;
import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.capgroup.digital.ce.cwb.exceptions.DisclosureGatewayException;
import com.capgroup.digital.ce.cwb.model.disclosure.DisclosureResponse;
import com.capgroup.digital.ce.cwb.model.disclosure.Result;

public class DisclosureGateway {

  private static final Logger logger = LogManager.getLogger(DisclosureGateway.class);
  private final RestTemplate restTemplate;
  private final String disclosureApi;

  public DisclosureGateway(final RestTemplate restTemplate, final String disclosureApi) {
    this.restTemplate = restTemplate;
    this.disclosureApi = disclosureApi;
  }

  /**
   * Method for fetching the disclosure language from disclosure tags
   */
  public Optional<List<Result>> fetchDisclosures(final String QueryParam) {

    if (Strings.isBlank(QueryParam))
      return Optional.empty();

    final StringBuilder disclosureUrl = new StringBuilder(disclosureApi);
    disclosureUrl.append("?previewMode=languageAndPath&");
    disclosureUrl.append(QueryParam.trim().replace(" ", ""));

    logger.debug("-> Retreiving disclosure: " + disclosureUrl);
    ResponseEntity<DisclosureResponse> disclosureResponse;
    try {
      disclosureResponse = restTemplate.postForEntity(disclosureUrl.toString(), null, DisclosureResponse.class);
      logger.debug("<- " + disclosureResponse.getStatusCode());
    } catch (final RestClientException ex) {
      throw new DisclosureGatewayException("Error while retreiving disclosures", ex);
    }

    return Optional.ofNullable(disclosureResponse.getBody()
                                                 .getResults());
  }
}
