package com.capgroup.digital.ce.cwb.mailers;

import org.springframework.stereotype.Service;

@Service
public class Mailer {
	
}
