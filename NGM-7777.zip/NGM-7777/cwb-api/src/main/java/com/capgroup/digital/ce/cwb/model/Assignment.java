package com.capgroup.digital.ce.cwb.model;

import java.util.List;
import org.hibernate.validator.constraints.NotEmpty;

public class Assignment {

  private List<DisclosureTags> disclosureTags;

  @NotEmpty
  private String templateName;

  private Integer id;

  
  private String percolateId;

  @NotEmpty
  private String userInitials;

  private Integer templateId;

  private String assignmentName;

  private String updatedAt;

  private String workfrontJobId;

  private String proofURL;

  private String proofFileId;
  
//  private String workfrontDocId;
  
  private String zeplinUrl;
  
  private String wipUrl;
  
  private List<Collaborators> collaborators;
  
  private boolean unlinkedAssignment;

  public Integer getId() {
    return id;
  }

  public void setId(final Integer id) {
    this.id = id;
  }

  public List<DisclosureTags> getDisclosureTags() {
    return disclosureTags;
  }

  public void setDisclosureTags(final List<DisclosureTags> disclosureTags) {
    this.disclosureTags = disclosureTags;
  }

  public String getTemplateName() {
    return templateName;
  }

  public void setTemplateName(final String templateName) {
    this.templateName = templateName;
  }

  public String getPercolateId() {
    return percolateId;
  }

  public void setPercolateId(final String percolateId) {
    this.percolateId = percolateId;
  }

  public Integer getTemplateId() {
    return templateId;
  }

  public void setTemplateId(final Integer templateId) {
    this.templateId = templateId;
  }

  public String getAssignmentName() {
    return assignmentName;
  }

  public void setAssignmentName(final String assignmentName) {
    this.assignmentName = assignmentName;
  }

  public String getUserInitials() {
    return userInitials;
  }

  public void setUserInitials(final String userInitials) {
    this.userInitials = userInitials;
  }

  public String getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(final String updatedAt) {
    this.updatedAt = updatedAt;
  }

  public String getWorkfrontJobId() {
    return workfrontJobId;
  }

  public void setWorkfrontJobId(final String workfrontJobId) {
    this.workfrontJobId = workfrontJobId;
  }

  public String getProofURL() {
    return proofURL;
  }

  public void setProofURL(final String proofURL) {
    this.proofURL = proofURL;
  }

  public String getProofFileId() {
    return proofFileId;
  }

  public void setProofFileId(final String proofFileId) {
    this.proofFileId = proofFileId;
  }

public List<Collaborators> getCollaborators() {
	return collaborators;
}

public void setCollaborators(List<Collaborators> collaborators) {
	this.collaborators = collaborators;
}

public boolean isUnlinkedAssignment() {
	return unlinkedAssignment;
}

public void setUnlinkedAssignment(boolean linkedAssignment) {
	this.unlinkedAssignment = linkedAssignment;
}

/*public String getWorkfrontDocId() {
  return workfrontDocId;
}

public void setWorkfrontDocId(String workfrontDocId) {
  this.workfrontDocId = workfrontDocId;
}*/

public String getZeplinUrl() {
  return zeplinUrl;
}

public void setZeplinUrl(String zeplinUrl) {
  this.zeplinUrl = zeplinUrl;
}

public String getWipUrl() {
  return wipUrl;
}

public void setWipUrl(String wipUrl) {
  this.wipUrl = wipUrl;
}

}
