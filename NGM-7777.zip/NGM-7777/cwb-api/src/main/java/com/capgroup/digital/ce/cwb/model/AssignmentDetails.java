package com.capgroup.digital.ce.cwb.model;

import java.util.List;

public class AssignmentDetails {

  private Assignment assignment = null;
  private Copy copy = null;
  private List<Graphics> graphics = null;
  private List<Twitter> twitter = null;
  private List<LinkedIn> linkedIn = null;
  private List<Facebook> facebook = null;
  private List<Backup> backups = null;

  public AssignmentDetails() {
    super();
  }

  public AssignmentDetails(Assignment assignment, Copy copy, List<Graphics> graphics, List<Twitter> twitter, List<LinkedIn> linkedIn, List<Facebook> facebook, List<Backup> backups ) {
		super();
		this.assignment = assignment;
		this.copy = copy;
		this.graphics = graphics;
		this.twitter = twitter;
		this.linkedIn = linkedIn;
		this.facebook = facebook;
		this.backups = backups;
	}

  public Assignment getAssignment() {
    return assignment;
  }

  public void setAssignment(Assignment assignment) {
    this.assignment = assignment;
  }

  public Copy getCopy() {
    return copy;
  }

  public void setCopy(Copy copy) {
    this.copy = copy;
  }

  public List<Graphics> getGraphics() {
    return graphics;
  }

  public void setGraphics(List<Graphics> graphics) {
    this.graphics = graphics;
  }

  public List<Backup> getBackups() {
    return backups;
  }

  public void setBackups(List<Backup> backups) {
    this.backups = backups;
  }
  public List<Facebook> getFacebook() {
		return facebook;
	}

	public void setFacebook(List<Facebook> facebook) {
		this.facebook = facebook;
	}

	public List<LinkedIn> getLinkedIn() {
		return linkedIn;
	}

	public void setLinkedIn(List<LinkedIn> linkedIn) {
		this.linkedIn = linkedIn;
	}
	
	public List<Twitter> getTwitter() {
		return twitter;
	}

	public void setTwitter(List<Twitter> twitter) {
		this.twitter = twitter;
	}
}
