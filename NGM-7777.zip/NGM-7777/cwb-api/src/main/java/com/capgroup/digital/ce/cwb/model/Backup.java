package com.capgroup.digital.ce.cwb.model;

public class Backup {

  private String backupId;
  private String name;
  private String location;

  public Backup(String backupId, String name, String location) {
    super();
    this.backupId = backupId;
    this.name = name;
    this.location = location;
  }

  public Backup() {}

  public String getBackupId() {
    return backupId;
  }

  public void setBackupId(String backupId) {

    this.backupId = backupId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

}
