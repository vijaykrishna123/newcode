package com.capgroup.digital.ce.cwb.model;

import org.springframework.http.HttpStatus;

public class CWBSuccess {
	
	private HttpStatus httpStatus;
	private String message;
	
	
	public CWBSuccess(HttpStatus httpStatus, String message ) {
		this.setHttpStatus(httpStatus);
		this.setMessage(message);
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public HttpStatus getHttpStatus() {
		return httpStatus;
	}


	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

}
