package com.capgroup.digital.ce.cwb.model;

public class Child {

  private String text;

  private String tagName;

  private Boolean isPercolate;

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

    public String getTagName() {
    return tagName;
  }

  public void setTagName(String tagName) {
    this.tagName = tagName;
  }

  public Boolean getIsPercolate() {
    return isPercolate;
  }

  public void setIsPercolate(Boolean isPercolate) {
    this.isPercolate = isPercolate;
  }
}
