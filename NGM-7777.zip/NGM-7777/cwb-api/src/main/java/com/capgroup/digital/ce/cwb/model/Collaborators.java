package com.capgroup.digital.ce.cwb.model;

public class Collaborators {

	
	private String userInitials;
	
	private String emailId;
	
	public String getUserInitials() {
		return userInitials;
	}
	public void setUserInitials(String userInitials) {
		this.userInitials = userInitials;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
