package com.capgroup.digital.ce.cwb.model;

public class CommentsRequest {
	
  private String userInitials;

  private Integer replyToId;

  private String commentStatus;

  private String commentValue;

  private String percolateId;
  
  private String optionalText;
  
  private String assignmentName;

  public String getUserInitials() {
    return userInitials;
  }

  public void setUserInitials(String userInitials) {
    this.userInitials = userInitials;
  }

  public Integer getReplyToId() {
    return replyToId;
  }

  public void setReplyToId(Integer replyToId) {
    this.replyToId = replyToId;
  }

  public String getCommentStatus() {
    return commentStatus;
  }

  public void setCommentStatus(String commentStatus) {
    this.commentStatus = commentStatus;
  }

  public String getCommentValue() {
    return commentValue;
  }

  public void setCommentValue(String commentValue) {
    this.commentValue = commentValue;
  }

  public String getPercolateId() {
    return percolateId;
  }

  public void setPercolateId(String percolateId) {
    this.percolateId = percolateId;
  }
  
  public String getOptionalText(){
	  return optionalText;
  }
  
  public void setOptionalText(String optionalText){
	  this.optionalText = optionalText;
  }
  
  public String getAssignmentName() {
	return assignmentName;
  }

  public void setAssignmentName(String assignmentName) {
	this.assignmentName = assignmentName;
  }

  @Override
  public String toString() {
    return "ClassPojo [userInitials = " + userInitials + ", replyToId = " + replyToId + ", commentStatus = "
        + commentStatus + ", commentValue = " + commentValue + ", percolateId = " + percolateId + "]";
  }  
}
