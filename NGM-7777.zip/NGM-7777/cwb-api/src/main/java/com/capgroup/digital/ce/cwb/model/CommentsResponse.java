package com.capgroup.digital.ce.cwb.model;

public class CommentsResponse {
  private String updatedAt;

  private String commentId;

  private String userInitials;

  private String commentStatus;

  private String createdAt;

  private String commentValue;

  private String replyToId;


  public String getCommentId() {
    return commentId;
  }

  public void setCommentId(String id) {
    this.commentId = id;
  }

  public String getUserInitials() {
    return userInitials;
  }

  public void setUserInitials(String userInitials) {
    this.userInitials = userInitials;
  }

  public String getCommentValue() {
    return commentValue;
  }

  public void setCommentValue(String commentValue) {
    this.commentValue = commentValue;
  }

  public String getReplyToId() {
    return replyToId;
  }

  public void setReplyToId(String replyToId) {
    this.replyToId = replyToId;
  }

  public String getCommentStatus() {
    return commentStatus;
  }

  public void setCommentStatus(String commentStatus) {
    this.commentStatus = commentStatus;
  }

  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public String getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
  }


}
