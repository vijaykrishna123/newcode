package com.capgroup.digital.ce.cwb.model;

import java.util.ArrayList;
import java.util.List;

public class Copy {

  private List<Field> fields = new ArrayList<>();

  public Copy(List<Field> fields) {
    this.fields = fields;
  }

  public Copy() {}

  public List<Field> getFields() {
    return fields;
  }

  public void setFields(List<Field> fields) {
    this.fields = fields;
  }

}
