package com.capgroup.digital.ce.cwb.model;

import java.util.ArrayList;

public class DisclosureTagList extends ArrayList<DisclosureTags> {

  private static final long serialVersionUID = -2256771625382185334L;
}
