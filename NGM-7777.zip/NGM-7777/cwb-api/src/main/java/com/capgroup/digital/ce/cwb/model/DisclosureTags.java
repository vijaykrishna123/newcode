package com.capgroup.digital.ce.cwb.model;

import java.util.List;

public class DisclosureTags {
  private String parent;

  private String title;

  private List<Child> child;


  public String getParent() {
    return parent;
  }

  public void setParent(final String parent) {
    this.parent = parent;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(final String title) {
    this.title = title;
  }

  public List<Child> getChild() {
    return child;
  }

  public void setChild(final List<Child> child) {
    this.child = child;
  }

}
