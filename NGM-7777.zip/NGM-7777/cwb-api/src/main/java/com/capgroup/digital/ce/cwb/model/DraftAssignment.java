package com.capgroup.digital.ce.cwb.model;

import org.hibernate.validator.constraints.NotEmpty;

public class DraftAssignment {

 // private List<DisclosureTags> disclosureTags;

  private String id; //percolate id
  
  private String name; //assignment name
  
  @NotEmpty
  private String template; //template name
  
  private String createdAt;
  
  private String updatedAt;  
  
  public String getId() {
    return id;
  }

  public void setId(final String id) {
    this.id = id;
  }  

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}
	
}
