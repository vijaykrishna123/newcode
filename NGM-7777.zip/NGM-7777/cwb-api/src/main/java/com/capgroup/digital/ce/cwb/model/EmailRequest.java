package com.capgroup.digital.ce.cwb.model;

public class EmailRequest {

  private String subject;

  private String recepient;

  private String textContent;

  public String getSubject() {
    return subject;
  }

  public void setSubject(final String subject) {
    this.subject = subject;
  }

  public String getRecepient() {
    return recepient;
  }

  public void setRecepient(final String recepient) {
    this.recepient = recepient;
  }

  public String getTextContent() {
    return textContent;
  }

  public void setTextContent(final String textContent) {
    this.textContent = textContent;
  }


}
