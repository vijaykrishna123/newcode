package com.capgroup.digital.ce.cwb.model;

import java.util.List;

public class Facebook
{
    private String name;
    
    private String status;

    private String facebookId;

    private List<Field> fields;

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }
    
    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

    public String getFacebookId ()
    {
        return facebookId;
    }

    public void setFacebookId (String facebookId)
    {
        this.facebookId = facebookId;
    }

    public List<Field> getFields ()
    {
        return fields;
    }

    public void setFields (List<Field> fields)
    {
        this.fields = fields;
    }

}