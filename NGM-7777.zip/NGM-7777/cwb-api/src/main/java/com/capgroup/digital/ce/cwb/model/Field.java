package com.capgroup.digital.ce.cwb.model;

public class Field {

  private String fieldName;

  private String fieldValue;

  private Properties properties;

  private Integer fieldId;

  public Field(String fieldName, String fieldValue, Properties properties, Integer fieldId) {
    this.fieldName = fieldName;
    this.fieldValue = fieldValue;
    this.properties = properties;
    this.fieldId = fieldId;
  }

  public Field() {}

  public String getFieldName() {
    return fieldName;
  }

  public void setFieldName(String fieldName) {
    this.fieldName = fieldName;
  }

  public String getFieldValue() {
    return fieldValue;
  }

  public void setFieldValue(String fieldValue) {
    this.fieldValue = fieldValue;
  }

  public Properties getProperties() {
    return properties;
  }

  public void setProperties(Properties properties) {
    this.properties = properties;
  }

  public Integer getFieldId() {
    return fieldId;
  }

  public void setFieldId(Integer fieldId) {
    this.fieldId = fieldId;
  }

}
