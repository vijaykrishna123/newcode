package com.capgroup.digital.ce.cwb.model;

import java.util.ArrayList;
import java.util.List;

public class Graphics {

  private String graphicsId;
  private String name;
  private String location;
  private String shortCode;
  private List<Field> fields = new ArrayList<>();

  public Graphics(String graphicsId, String name, String location, String shortCode, List<Field> fields) {
    super();
    this.graphicsId = graphicsId;
    this.name = name;
    this.location = location;
    this.shortCode = shortCode;
    this.fields = fields;
  }

  public Graphics() {}

  public String getGraphicsId() {
    return graphicsId;
  }

  public void setGraphicsId(String graphicsId) {
    this.graphicsId = graphicsId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public List<Field> getFields() {
    return fields;
  }

  public void setFields(List<Field> fields) {
    this.fields = fields;
  }

  public String getShortCode() {
    return shortCode;
  }

  public void setShortCode(String shortCode) {
    this.shortCode = shortCode;
  }

}
