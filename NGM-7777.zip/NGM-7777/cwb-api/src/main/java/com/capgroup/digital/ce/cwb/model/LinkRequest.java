package com.capgroup.digital.ce.cwb.model;

public class LinkRequest {

  private String percolateId;

  private String draftId;
  
  private String assignmentName; 

	public String getPercolateId() {
		return percolateId;
	}

	public void setPercolateId(String percolateId) {
		this.percolateId = percolateId;
	}

	public String getDraftId() {
		return draftId;
	}

	public void setDraftId(String drafId) {
		this.draftId = drafId;
	}

	public String getAssignmentName() {
	  return assignmentName;
	}

	public void setAssignmentName(String assignmentName) {
	  this.assignmentName = assignmentName;
	}

  


}
