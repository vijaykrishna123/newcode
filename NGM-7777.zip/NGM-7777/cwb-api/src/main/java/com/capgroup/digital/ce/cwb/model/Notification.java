package com.capgroup.digital.ce.cwb.model;

public class Notification {

  private String message;

  private String userName;

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }
}
