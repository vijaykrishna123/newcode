package com.capgroup.digital.ce.cwb.model;

import java.io.Serializable;
import org.hibernate.validator.constraints.NotBlank;

public class ProofDetails implements Serializable {

  private static final long serialVersionUID = 3141873567155078685L;

  @NotBlank
  private String fileId;
  @NotBlank
  private String proofUrl;

  public String getProofUrl() {
    return proofUrl;
  }

  public void setProofUrl(final String proofUrl) {
    this.proofUrl = proofUrl;
  }

  public String getFileId() {
    return fileId;
  }

  public void setFileId(final String fileId) {
    this.fileId = fileId;
  }

}
