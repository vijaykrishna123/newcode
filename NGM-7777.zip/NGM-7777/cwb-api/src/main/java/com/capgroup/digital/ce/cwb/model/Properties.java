package com.capgroup.digital.ce.cwb.model;

public class Properties {
  private String minLength;
  private String fieldType;
  private String maxLength;
  private String fieldHelperText;

  public String getMinLength() {
    return minLength;
  }

  public void setMinLength(String minLength) {
    this.minLength = minLength;
  }

  public String getFieldType() {
    return fieldType;
  }

  public void setFieldType(String fieldType) {
    this.fieldType = fieldType;
  }

  public String getMaxLength() {
    return maxLength;
  }

  public void setMaxLength(String maxLength) {
    this.maxLength = maxLength;
  }
  
  public String getFieldHelperText() {
	    return fieldHelperText;
	  }

  public void setFieldHelperText(String fieldHelperText) {
  this.fieldHelperText = fieldHelperText;
}

}
