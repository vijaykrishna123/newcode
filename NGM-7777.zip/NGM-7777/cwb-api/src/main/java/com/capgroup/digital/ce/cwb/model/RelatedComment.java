package com.capgroup.digital.ce.cwb.model;

public class RelatedComment {

	  private String commentId;
	  
	  private String percolateId;

	  private String userInitials;

	  private String assignmentName;
	  
	  private String updatedAt;

	  public String getCommentId() {
		  return commentId;
	  }

	  public void setCommentId(String id) {
		  this.commentId = id;
	  }
	  
	  public String getPercolateId() {
	    return percolateId;
	  }

	  public void setPercolateId(final String percolateId) {
	    this.percolateId = percolateId;
	  }

	  public String getAssignmentName() {
	    return assignmentName;
	  }

	  public void setAssignmentName(final String assignmentName) {
	    this.assignmentName = assignmentName;
	  }

	  public String getUserInitials() {
	    return userInitials;
	  }

	  public void setUserInitials(final String userInitials) {
	    this.userInitials = userInitials;
	  }

	  public String getUpdatedAt() {
		return updatedAt;
	  }

	  public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	  }

}
