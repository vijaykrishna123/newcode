package com.capgroup.digital.ce.cwb.model;


public class TemplatesResponse {
  private String templateName;

  public String getTemplateName() {
	  return templateName;
  }
	
  public void setTemplateName(String templateName) {
	  this.templateName = templateName;
  }

}
