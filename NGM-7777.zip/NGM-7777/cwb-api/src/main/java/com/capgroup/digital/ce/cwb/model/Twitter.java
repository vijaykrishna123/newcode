package com.capgroup.digital.ce.cwb.model;

import java.util.List;

public class Twitter {

	private String name;
	
	private String status;

    private String twitterId;

    private List<Field> fields;

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }
    
    public String getTwitterId ()
    {
        return twitterId;
    }

    public void setTwitterId (String twitterId)
    {
        this.twitterId = twitterId;
    }

    public List<Field> getFields ()
    {
        return fields;
    }

    public void setFields (List<Field> fields)
    {
        this.fields = fields;
    }

}
