package com.capgroup.digital.ce.cwb.model;

import java.io.Serializable;
import org.hibernate.validator.constraints.NotBlank;

public class WorkfrontDetails implements Serializable {

  private static final long serialVersionUID = 9026151820031881369L;
  
  private String workfrontDocId;

  public String getWorkfrontDocId() {
	return workfrontDocId;
  }

  public void setWorkfrontDocId(String workfrontDocId) {
	this.workfrontDocId = workfrontDocId;
  }


}
