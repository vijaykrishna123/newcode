package com.capgroup.digital.ce.cwb.model.disclosure;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DisclosureResponse {

  @JsonProperty("Results")
  private List<Result> results;

  public List<Result> getResults() {
    return results;
  }

  public void setResults(final List<Result> results) {
    this.results = results;
  }
}
