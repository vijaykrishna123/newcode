package com.capgroup.digital.ce.cwb.model.disclosure;

import java.util.Collections;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Result {

  @JsonProperty("language")
  private String language;
  @JsonProperty("renditionPath")
  private List<String> renditionPath = Collections.emptyList();
  @JsonProperty("precede")
  private Boolean precede;
  @JsonProperty("proximity")
  private Boolean proximity;
  @JsonProperty("perPageRepeat")
  private Boolean perPageRepeat;
  @JsonProperty("periphery")
  private Boolean periphery;
  @JsonProperty("symbolReceived")
  private Object symbolReceived;
  @JsonProperty("prominence")
  private Boolean prominence;
  @JsonProperty("symbolAssigned")
  private Object symbolAssigned;
  @JsonProperty("customLink")
  private Object customLink;

  public String getLanguage() {
    return language;
  }

  public void setLanguage(final String language) {
    this.language = language;
  }

  public List<String> getRenditionPath() {
    return renditionPath;
  }

  public void setRenditionPath(final List<String> renditionPath) {
    this.renditionPath = renditionPath;
  }

  public Boolean getPrecede() {
    return precede;
  }

  public void setPrecede(final Boolean precede) {
    this.precede = precede;
  }

  public Boolean getProximity() {
    return proximity;
  }

  public void setProximity(final Boolean proximity) {
    this.proximity = proximity;
  }

  public Boolean getPerPageRepeat() {
    return perPageRepeat;
  }

  public void setPerPageRepeat(final Boolean perPageRepeat) {
    this.perPageRepeat = perPageRepeat;
  }

  public Boolean getPeriphery() {
    return periphery;
  }

  public void setPeriphery(final Boolean periphery) {
    this.periphery = periphery;
  }

  public Object getSymbolReceived() {
    return symbolReceived;
  }

  public void setSymbolReceived(final Object symbolReceived) {
    this.symbolReceived = symbolReceived;
  }

  public Boolean getProminence() {
    return prominence;
  }

  public void setProminence(final Boolean prominence) {
    this.prominence = prominence;
  }

  public Object getSymbolAssigned() {
    return symbolAssigned;
  }

  public void setSymbolAssigned(final Object symbolAssigned) {
    this.symbolAssigned = symbolAssigned;
  }

  public Object getCustomLink() {
    return customLink;
  }

  public void setCustomLink(final Object customLink) {
    this.customLink = customLink;
  }
}
