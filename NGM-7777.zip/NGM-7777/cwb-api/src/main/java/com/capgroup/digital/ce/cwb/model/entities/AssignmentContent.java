package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "AssignmentContent")
@Entity
@SequenceGenerator(name = "ASSIGNMENT_CONTENT_SEQ_GEN", sequenceName = "ASSIGNMENT_CONTENT_SEQ_NUM", allocationSize = 1)
public class AssignmentContent extends AuditModel {

  private static final long serialVersionUID = 3600114649556055277L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ASSIGNMENT_CONTENT_SEQ_GEN")
  private Integer id;

  private int assignmentId;

  private int fieldId;

  private String fieldContent;

  private int referenceId;

  public AssignmentContent() {}

  public AssignmentContent(final Integer id, final int assignmentId, final int fieldId, final String fieldContent,
      final int referenceId) {
    this.id = id;
    this.assignmentId = assignmentId;
    this.fieldId = fieldId;
    this.fieldContent = fieldContent;
    this.referenceId = referenceId;
  }

  public int getAssignmentId() {
    return assignmentId;
  }

  public String getFieldContent() {
    return fieldContent;
  }

  public int getFieldId() {
    return fieldId;
  }

  public Integer getId() {
    return id;
  }

  public int getReferenceId() {
    return referenceId;
  }

  public void setAssignmentId(final int assignmentId) {
    this.assignmentId = assignmentId;
  }

  public void setFieldContent(final String fieldContent) {
    this.fieldContent = fieldContent;
  }

  public void setFieldId(final int fieldId) {
    this.fieldId = fieldId;
  }

  public void setId(final Integer id) {
    this.id = id;
  }

  public void setReferenceId(final int referenceId) {
    this.referenceId = referenceId;
  }

}
