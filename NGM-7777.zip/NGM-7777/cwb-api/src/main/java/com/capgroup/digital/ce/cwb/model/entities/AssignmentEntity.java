package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "assignments")
@Entity
@SequenceGenerator(name = "ASSIGNMENTS_SEQ_GEN", sequenceName = "ASSIGNMENTS_SEQ_NUM", allocationSize = 1)
public class AssignmentEntity extends AuditModel {

  private static final long serialVersionUID = -6606325335956111053L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ASSIGNMENTS_SEQ_GEN")
  private Integer id;

  private String percolateId;

  private String assignmentName;

  private String templateName;

  private String disclosureTags;

  private String userInitials;

  private String status;

  private Integer templateId;

  @Column(name = "WORKFRONT_ID")
  private String workfrontJobId;

  @Column(name = "PROOF_HQ_URL")
  private String proofURL;

  @Column(name = "PROOF_HQ_ID")
  private String proofFileId;
  
/*  @Column(name = "WORKFRONT_DOC_ID")
  private String workfrontDocId;*/
  
  @Column(name = "ZEPLIN_URL")
  private String zeplinUrl;
  
  @Column(name = "WIP_URL")
  private String wipUrl;

  public String getAssignmentName() {
    return assignmentName;
  }

  public String getDisclosureTags() {
    return disclosureTags;
  }

  public Integer getId() {
    return id;
  }

  public String getPercolateId() {
    return percolateId;
  }

  public String getStatus() {
    return status;
  }

  public Integer getTemplateId() {
    return templateId;
  }

  public String getTemplateName() {
    return templateName;
  }

  public String getUserInitials() {
    return userInitials;
  }


  public void setAssignmentName(final String assignmentName) {
    this.assignmentName = assignmentName;
  }

  public void setDisclosureTags(final String disclosureTags) {
    this.disclosureTags = disclosureTags;
  }

  public void setId(final Integer id) {
    this.id = id;
  }

  public void setPercolateId(final String percolateId) {
    this.percolateId = percolateId;
  }


  public void setStatus(final String status) {
    this.status = status;
  }

  public void setTemplateId(final Integer templateId) {
    this.templateId = templateId;
  }

  public void setTemplateName(final String templateName) {
    this.templateName = templateName;
  }

  public void setUserInitials(final String userInitials) {
    this.userInitials = userInitials;
  }

  public String getWorkfrontJobId() {
    return workfrontJobId;
  }

  public void setWorkfrontJobId(final String workfrontJobId) {
    this.workfrontJobId = workfrontJobId;
  }

  public String getProofURL() {
    return proofURL;
  }

  public void setProofURL(final String proofURL) {
    this.proofURL = proofURL;
  }

  public String getProofFileId() {
    return proofFileId;
  }

  public void setProofFileId(final String proofFileId) {
    this.proofFileId = proofFileId;
  }

/*  public String getWorkfrontDocId() {
	return workfrontDocId;
  }

  public void setWorkfrontDocId(String workfrontDocId) {
	this.workfrontDocId = workfrontDocId;
  }*/

  public String getZeplinUrl() {
    return zeplinUrl;
  }

  public void setZeplinUrl(String zeplinUrl) {
    this.zeplinUrl = zeplinUrl;
  }

  public String getWipUrl() {
    return wipUrl;
  }

  public void setWipUrl(String wipUrl) {
    this.wipUrl = wipUrl;
  }

}
