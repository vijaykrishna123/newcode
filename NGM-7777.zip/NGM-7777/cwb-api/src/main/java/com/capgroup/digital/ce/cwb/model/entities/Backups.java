package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "backups")
@Entity
@SequenceGenerator(name = "BACKUPS_SEQ_GEN", sequenceName = "BACKUPS_SEQ_NUM", allocationSize = 1)
public class Backups extends AuditModel {

  private static final long serialVersionUID = -2139396369682163263L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BACKUPS_SEQ_GEN")
  private Integer id;

  private Integer assignmentId;

  private String backupName;

  private String backupLocation;

  private boolean isLinked;

  private Integer excerptId;

  public Backups() {

  }

  public Backups(Integer id, Integer assignmentId, String backupName, String backupLocation) {
    this.id = id;
    this.assignmentId = assignmentId;
    this.backupName = backupName;
    this.backupLocation = backupLocation;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getAssignmentId() {
    return assignmentId;
  }

  public void setAssignmentId(Integer assignmentId) {
    this.assignmentId = assignmentId;
  }

  public String getBackupName() {
    return backupName;
  }

  public void setBackupName(String backupName) {
    this.backupName = backupName;
  }

  public String getBackupLocation() {
    return backupLocation;
  }

  public void setBackupLocation(String backupLocation) {
    this.backupLocation = backupLocation;
  }

  public boolean getIsLinked() {
    return isLinked;
  }

  public void setIsLinked(boolean isLinked) {
    this.isLinked = isLinked;
  }

  public Integer getExcerptId() {
    return excerptId;
  }

  public void setExcerptId(Integer excerptId) {
    this.excerptId = excerptId;
  }

}
