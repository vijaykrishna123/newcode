package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "comments")
@Entity
@SequenceGenerator(name = "COMMENTS_SEQ_GEN", sequenceName = "COMMENTS_SEQ_NUM", allocationSize = 1)
public class Comments extends AuditModel {

  private static final long serialVersionUID = 6881265967553687071L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "COMMENTS_SEQ_GEN")
  private Integer id;

  private Integer assignmentId;

  private String userInitials;

  private String commentValue;

  private Integer replyId;

  private Integer excerptId;

  private Integer fieldId;

  private String commentStatus;

  public String getUserInitials() {
    return userInitials;
  }

  public void setUserInitials(String userInitials) {
    this.userInitials = userInitials;
  }

  public Integer getAssignmentId() {
    return assignmentId;
  }

  public void setAssignmentId(Integer assignmentId) {
    this.assignmentId = assignmentId;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getExcerptId() {
    return excerptId;
  }

  public void setExcerptId(Integer excerptId) {
    this.excerptId = excerptId;
  }

  public Integer getReplyId() {
    return replyId;
  }

  public void setReplyId(Integer replyId) {
    this.replyId = replyId;
  }

  public String getCommentValue() {
    return commentValue;
  }

  public void setCommentValue(String commentValue) {
    this.commentValue = commentValue;
  }

  public Integer getFieldId() {
    return fieldId;
  }

  public void setFieldId(Integer fieldId) {
    this.fieldId = fieldId;
  }

  public String getCommentStatus() {
    return commentStatus;
  }

  public void setCommentStatus(String commentStatus) {
    this.commentStatus = commentStatus;
  }
}
