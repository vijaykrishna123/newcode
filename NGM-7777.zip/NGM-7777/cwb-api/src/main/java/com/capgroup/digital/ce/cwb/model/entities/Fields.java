package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "Fields")
@Entity
@SequenceGenerator(name = "FIELDS_SEQ_GEN", sequenceName = "FIELDS_SEQ_NUM", allocationSize = 1)
public class Fields extends AuditModel {

  private static final long serialVersionUID = 6266714265430297479L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FIELDS_SEQ_GEN")
  private Integer id;

  private String fieldType;

  private String fieldLabel;

  private String minLength;

  private String maxLength;

  private String helperText;

  public Fields() {
    super();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getFieldType() {
    return fieldType;
  }

  public void setFieldType(String fieldType) {
    this.fieldType = fieldType;
  }

  public String getFieldLabel() {
    return fieldLabel;
  }

  public void setFieldLabel(String fieldLabel) {
    this.fieldLabel = fieldLabel;
  }

  public String getMinLength() {
    return minLength;
  }

  public void setMinLength(String minLength) {
    this.minLength = minLength;
  }

  public String getMaxLength() {
    return maxLength;
  }

  public void setMaxLength(String maxLength) {
    this.maxLength = maxLength;
  }

  public String getHelperText() {
    return helperText;
  }

  public void setHelperText(String helperText) {
    this.helperText = helperText;
  }

}
