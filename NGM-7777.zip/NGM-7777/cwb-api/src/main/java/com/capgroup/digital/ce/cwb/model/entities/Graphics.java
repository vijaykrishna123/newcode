package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "graphics")
@Entity
@SequenceGenerator(name = "GRAPHICS_SEQ_GEN", sequenceName = "GRAPHICS_SEQ_NUM", allocationSize = 1)
public class Graphics extends AuditModel {

  private static final long serialVersionUID = -7701561629896366490L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GRAPHICS_SEQ_GEN")
  private Integer id;

  private Integer assignmentId;

  private String graphicName;

  private String graphicLocation;

  private String graphicShortcode;



  public Graphics() {
    super();
  }

  public Graphics(Integer id, Integer assignmentId, String graphicName, String graphicLocation,
      String graphicShortcode) {
    super();
    this.id = id;
    this.assignmentId = assignmentId;
    this.graphicName = graphicName;
    this.graphicLocation = graphicLocation;
    this.graphicShortcode = graphicShortcode;
  }

  public String getGraphicName() {
    return graphicName;
  }

  public void setGraphicName(String graphicName) {
    this.graphicName = graphicName;
  }

  public Integer getAssignmentId() {
    return assignmentId;
  }

  public void setAssignmentId(Integer assignmentId) {
    this.assignmentId = assignmentId;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getGraphicLocation() {
    return graphicLocation;
  }

  public void setGraphicLocation(String graphicLocation) {
    this.graphicLocation = graphicLocation;
  }

  public String getGraphicShortCode() {
    return graphicShortcode;
  }

  public void setGraphicShortcode(String graphicShortcode) {
    this.graphicShortcode = graphicShortcode;
  }
}
