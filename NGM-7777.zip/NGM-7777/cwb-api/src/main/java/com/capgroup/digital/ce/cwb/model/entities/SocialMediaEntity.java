package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "social_media")
@Entity
@SequenceGenerator(name = "SOCIAL_MEDIA_SEQ_GEN", sequenceName = "SOCIAL_MEDIA_SEQ_NUM", allocationSize = 1)
public class SocialMediaEntity extends AuditModel {


  private static final long serialVersionUID = -1731287214371773467L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SOCIAL_MEDIA_SEQ_GEN")
  private Integer id;

  private Integer assignmentId;

  private String mediaFileName;

  private String mediaFileLocation;

  private String mediaType;


  public SocialMediaEntity() {
    super();

  }

  public SocialMediaEntity(Integer id, Integer assignmentId, String mediaFileName, String mediaFileLocation,
      String mediaType) {
    super();
    this.id = id;
    this.assignmentId = assignmentId;
    this.mediaFileName = mediaFileName;
    this.mediaFileLocation = mediaFileLocation;
    this.mediaType = mediaType;
  }

  public String getMediaFileName() {
    return mediaFileName;
  }

  public void setMediaFileName(String mediaFileName) {
    this.mediaFileName = mediaFileName;
  }

  public Integer getAssignmentId() {
    return assignmentId;
  }

  public void setAssignmentId(Integer assignmentId) {
    this.assignmentId = assignmentId;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getMediaFileLocation() {
    return mediaFileLocation;
  }

  public void setMediaFileLocation(String mediaFileLocation) {
    this.mediaFileLocation = mediaFileLocation;
  }

  public String getMediaType() {
    return mediaType;
  }

  public void setMediaType(String mediaType) {
    this.mediaType = mediaType;
  }
}
