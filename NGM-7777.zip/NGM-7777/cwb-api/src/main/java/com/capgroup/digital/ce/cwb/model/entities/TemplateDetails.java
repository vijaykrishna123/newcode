package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "TemplateDetails")
@Entity
@SequenceGenerator(name = "TEMPLATE_DETAILS_SEQ_GEN", sequenceName = "TEMPLATE_DETAILS_SEQ_NUM", allocationSize = 1)
public class TemplateDetails extends AuditModel {

  private static final long serialVersionUID = 7466198955002970819L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TEMPLATE_DETAILS_SEQ_GEN")
  private Integer id;

  private Integer fieldId;

  private String templateId;

  private String fieldSection;
  
  private Integer fieldOrder;

  public TemplateDetails() {

  }

  public TemplateDetails(Integer id, Integer fieldId, String templateId, String fieldSection, Integer fieldOrder) {
    this.id = id;
    this.fieldId = fieldId;
    this.templateId = templateId;
    this.fieldSection = fieldSection;
    this.fieldOrder = fieldOrder;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getFieldId() {
    return fieldId;
  }

  public void setFieldId(Integer fieldId) {
    this.fieldId = fieldId;
  }

  public String getTemplateId() {
    return templateId;
  }

  public void setTemplateId(String templateId) {
    this.templateId = templateId;
  }

  public String getFieldSection() {
    return fieldSection;
  }

  public void setFieldSection(String fieldSection) {
    this.fieldSection = fieldSection;
  }
  
  public Integer getFieldOrder() {
    return fieldOrder;
  }

  public void setFieldOrder(Integer fieldOrder) {
    this.fieldOrder = fieldOrder;
  }

}
