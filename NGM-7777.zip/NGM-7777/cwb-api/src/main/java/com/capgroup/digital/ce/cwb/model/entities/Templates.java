package com.capgroup.digital.ce.cwb.model.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "templates")
@Entity
@SequenceGenerator(name = "TEMPLATES_SEQ_GEN", sequenceName = "TEMPLATES_SEQ_NUM", allocationSize = 1)
public class Templates extends AuditModel {

  private static final long serialVersionUID = 3490082979831074126L;

  public Templates() {

  }

  public Templates(Integer id, String templateName, String templateType) {
    this.id = id;
    this.templateName = templateName;
    this.templateType = templateType;
  }

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TEMPLATES_SEQ_GEN")
  private Integer id;

  private String templateName;

  private String templateType;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getTemplateName() {
    return templateName;
  }

  public void setTemplateName(String templateName) {
    this.templateName = templateName;
  }

  public String getTemplateType() {
    return templateType;
  }

  public void setTemplateType(String templateType) {
    this.templateType = templateType;
  }

}
