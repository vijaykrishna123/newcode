package com.capgroup.digital.ce.cwb.pdf;

import static java.util.stream.Collectors.joining;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileSystemUtils;
import org.springframework.util.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;
import org.jsoup.select.Elements;
import com.capgroup.digital.ce.cwb.common.PdfConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.gateways.DisclosureGateway;
import com.capgroup.digital.ce.cwb.model.Assignment;
import com.capgroup.digital.ce.cwb.model.AssignmentDetails;
import com.capgroup.digital.ce.cwb.model.Backup;
import com.capgroup.digital.ce.cwb.model.Child;
import com.capgroup.digital.ce.cwb.model.Copy;
import com.capgroup.digital.ce.cwb.model.DisclosureTags;
import com.capgroup.digital.ce.cwb.model.Field;
import com.capgroup.digital.ce.cwb.model.Graphics;
import com.capgroup.digital.ce.cwb.model.disclosure.Result;
import com.capgroup.digital.ce.cwb.services.IAssignments;
import com.capgroup.digital.ce.cwb.utils.CWBFileUtils;
import com.capgroup.digital.ce.cwb.utils.PDFUtils;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerFontProvider;
import com.itextpdf.tool.xml.XMLWorkerHelper;

public abstract class FileGenerator {

  private final IAssignments assignments;

  private final DisclosureGateway disclosureService;

  private final GraphicsComponent graphicsComponent;
  
  // @Autowired
  public FileGenerator(final IAssignments assignments, final DisclosureGateway disclosureService,
      final GraphicsComponent graphicsComponent) {
    super();
    this.assignments = assignments;
    this.disclosureService = disclosureService;
    this.graphicsComponent = graphicsComponent;
  }

  private final Logger log = LogManager.getLogger(FileGenerator.class);

  /**
   * Method for generating file details
   * 
   * @param percolateId
   * @param dataStream
   * @return
   * @throws IOException
   */
  protected ResponseEntity<InputStreamResource> retrieveDataForGeneratingFile(final String percolateId,
	  final boolean isPdf) throws IOException {

    InputStream cssFile = null;

    final AssignmentDetails assignmentDetails = assignments.getAssignmentDetails(percolateId);

    if (!StringUtils.isEmpty(assignmentDetails)) {

      final Assignment retrievedAssignment = assignmentDetails.getAssignment();

      final List<Backup> backups = assignmentDetails.getBackups();      

      final Copy copyDetails = assignmentDetails.getCopy();

      final List<Graphics> graphics = assignmentDetails.getGraphics();
      
      final List<DisclosureTags> disclosureTagsList = retrievedAssignment.getDisclosureTags();
      
      final Optional<List<Result>> disclosureResult;

      final String assignmentName = retrievedAssignment.getAssignmentName()
												.replaceAll("[^\\dA-Za-z ]", "").replaceAll("\\s+", "_");

      final String templateName = retrievedAssignment.getTemplateName();
      
      final String baseDir = isPdf ? "/tmp" + PdfConstants.BACKSLASH + assignmentName + "_pdf" : 
			"/tmp" + PdfConstants.BACKSLASH + assignmentName;
      
      final File assignmentDir = new File(baseDir); 

      final Document document = new Document(PageSize.A4, 72,72,72,72);

      try {

        final PdfWriter writer = createPdfWriterInstance(baseDir,assignmentName, document);

        writer.setInitialLeading(12.5f);

        String htmlFileContents = null;
        
        if (templateName.equalsIgnoreCase( PdfConstants.EMAIL)){
        	htmlFileContents = CWBFileUtils.getFileContents(PdfConstants.EMAIL_HTML);
        }
        else {
        	htmlFileContents = CWBFileUtils.getFileContents(PdfConstants.WEB_HTML);
        }
        

        for (final Field copyFields : copyDetails.getFields()) {
          if (copyFields.getFieldName()
                        .equalsIgnoreCase(PdfConstants.BODY)) {
            /*final List<String> shortCodes = PDFUtils.findShortCodesFromSection(copyFields.getFieldValue());
            final String graphicsHtmlContents = processAndAddGraphicsSection(shortCodes, copyFields.getFieldValue(),
                graphics, baseDir);*/
            htmlFileContents = replacePlaceHolders(htmlFileContents, PdfConstants.BODY_PLACEHOLDER,
            		copyFields.getFieldValue());
          } else {
            final String placeHolder = "++" + copyFields.getFieldName() + "++";
            htmlFileContents = replacePlaceHolders(htmlFileContents, placeHolder, copyFields.getFieldValue());
          }
        }
        
        downloadBackupsForAssignment(backups, baseDir);
        
//        downloadImages(htmlFileContents, baseDir);
        
        downloadCreativeAssetsForAssignment(graphics, baseDir);
               
        if (disclosureTagsList.isEmpty()) {
          log.debug("No tags exist, so using the default standard disclosure tags");
          disclosureResult = disclosureService.fetchDisclosures(PdfConstants.DEFAULT_CONTEXT_TAGS);
          htmlFileContents = htmlFileContents.replace(PdfConstants.DISCLOSURETAGS_PLACEHOLDER, 
        	  PdfConstants.DEFAULT_CONTEXT_TAGS.replace("&", "\r\n<br/>"));          
        } else {
          disclosureResult = disclosureService.fetchDisclosures(getDisclosureTags(disclosureTagsList, "&"));
          htmlFileContents = htmlFileContents.replace(PdfConstants.DISCLOSURETAGS_PLACEHOLDER, 
        	  getDisclosureTags(disclosureTagsList, PdfConstants.HTML_BREAK));
        }
        
        htmlFileContents = htmlFileContents.replace(PdfConstants.DISCLOSUREPATHS_PLACEHOLDER, 
      	  getDisclosurePaths(disclosureResult)); 
          
//        htmlFileContents = htmlFileContents.replace(PdfConstants.DISCLOSURES_PLACEHOLDER, getDisclosureLanguages(
//          disclosureResult));
        

        final String workfrontJobId = Strings.isBlank(retrievedAssignment.getWorkfrontJobId()) ? Strings.EMPTY
            : retrievedAssignment.getWorkfrontJobId();

        htmlFileContents = htmlFileContents.replace(PdfConstants.WORKFRONTJOB_PLACEHOLDER, workfrontJobId);

        htmlFileContents = addSocialMedia(assignmentDetails, htmlFileContents, baseDir);

        htmlFileContents = editContentForPdfGen(htmlFileContents, templateName);  

        htmlFileContents = PDFUtils.cleanData(htmlFileContents);

		final URL cssPath = Thread.currentThread()
               .getContextClassLoader()
               .getResource(loadCss(templateName));
		cssFile = cssPath.openStream();

        document.open();
        document.add(new Chunk(""));  //this is to prevent "document has no pages" exception when generating the pdf 
        final XMLWorkerFontProvider fontProvider = PDFUtils.loadFonts();

        writeToPdfFile(cssFile, document, writer, htmlFileContents, fontProvider);
        
        return preProcessData(baseDir, assignmentName, retrievedAssignment.getWorkfrontJobId());

      } catch (DocumentException | IOException e) {
        throw new CWBException("Error while generating pdf or zip");

      } finally {
        if (null != cssFile)
        	{ cssFile.close(); }
        if (assignmentDir.exists())
        	{ cleanUpDirectory(assignmentDir); }        	
      }
    }
    throw new CWBException("Unable to fetch the assignment details");
  }
  
  /**
   * Method for fetching the correct css file to load for pdf
   * 
   * @param templateName
   * @return PdfConstants.CSS_XXX
   */
  private String loadCss(String templateName) {
	  if (templateName != null && !templateName.isEmpty()) {
	
		  switch (templateName.toUpperCase()) {
		  case PdfConstants.EMAIL:
			  return PdfConstants.EMAIL_CSS;
		  case PdfConstants.WEB_ARTICLE:
			  return PdfConstants.WEB_CSS;
		  default:
			  return PdfConstants.WEB_CSS;
		  }
	  }else {
		  return PdfConstants.WEB_CSS;
	  }
  }

  /**
   * Method for Preparing htmlFileContents for Pdf Generation
   *  
   * @param htmlData
   * @param templateName
   * @return htmlFileContents 
   */  
  private String editContentForPdfGen(String htmlData, String templateName)  {		
		
	  String htmlFileContents = htmlData;	        
	  htmlFileContents = replaceTags(htmlFileContents);
		
	  org.jsoup.nodes.Document jSoupDoc =  Jsoup.parse(htmlFileContents);

	  if (templateName.equalsIgnoreCase(PdfConstants.EMAIL)){
		  editEmailTemplate(jSoupDoc);
	  }
	  else if (templateName.equalsIgnoreCase(PdfConstants.WEB_ARTICLE)){				   
		  editWebArticleTemplate(jSoupDoc);
	  }				
	  else { 
		  jSoupDoc = Jsoup.parse(htmlFileContents); 
	  }
		        
	  //Adding class to images for css, showing alt text, and removing "srcset" attribute
	  Elements images = jSoupDoc.select("img");
	  for (Element img : images) {        	
		  String width = img.attr("width");
		  String altText = img.attr("alt");
		  altText = altText.replace("\n", "<br />");
		  
		  //Display alt text if not empty
		  if (!altText.isEmpty()) {
			img.before("<table class = altText><tbody><tr><td> Alt text: " + altText + "</td></tr></tbody></table>");
		  }

		  try{	
			  //Apply default width to images if too large
			  if (Integer.parseInt(width) > 550){
				  img.addClass("imgTooLarge");
			  }
		  }
		  catch(NumberFormatException e1){
			  log.debug("No explict width captured for this image");         
		  }            
		  img.removeAttr("srcset");  	         
	  }
	  
	  //Display the actual link after the hyperlink text
	  Elements aTags = jSoupDoc.select("a");
	  for ( Element aTag : aTags) {
		String hyperLink = aTag.attr("href");
		aTag.after(" [link to: " + hyperLink + "]");
	  }
	   
	  jSoupDoc.select("suggestion").remove();
	  jSoupDoc.select("comment").remove();
        
	  htmlFileContents = jSoupDoc.html(); 
	  return htmlFileContents;
  }
  
  /**
   * Method for removing unrecognized/unwanted tags for pdf 
   *  
   * @param htmlFileContents
   * @return htmlFileContents
   */
  private String replaceTags(String htmlFileContents) {
		
	  //tags unrecognized by iText
	  htmlFileContents = htmlFileContents.replace("<mark",         "<span");		
	  htmlFileContents = htmlFileContents.replace("</mark>",       "</span>");
	  htmlFileContents = htmlFileContents.replace("<figure",       "<span");
	  htmlFileContents = htmlFileContents.replace("</figure>",     "</span>");
	  htmlFileContents = htmlFileContents.replace("<figcaption>",  "<table class = caption><tbody><tr><td>");
	  htmlFileContents = htmlFileContents.replace("</figcaption>", "</td></tr></tbody></table><br />");

	  return htmlFileContents;
  }

  /**
   * Method for cleaning up email template for pdf output 
   *  
   * @param jSoupDoc
   */
  private void editEmailTemplate(org.jsoup.nodes.Document jSoupDoc) {
		
	  removeEmptyPTags(jSoupDoc, PdfConstants.EMAIL_HEADINGS);   		    
	  removeHeadingsAndSubText(jSoupDoc, PdfConstants.EMAIL_HEADINGS_TO_REMOVE, PdfConstants.EMAIL_SUBTEXT_TO_REMOVE);	
	  addHorizontalLines(jSoupDoc, PdfConstants.EMAIL_HR_TAG_LOCATIONS);
		
	  //Removing button text and button link table IF EMPTY
	  Elements buttonTables = jSoupDoc.select("table.btext, table.blink");
	  for (Element table: buttonTables){
		  //Unicode to check if empty
		  if (table.text().equals("\u00a0")){
			  table.remove();
		  }
	  }	 
  }
	
  /**
   * Method for cleaning up web article template for pdf output 
   *  
   * @param jSoupDoc
   */
  private void editWebArticleTemplate(org.jsoup.nodes.Document jSoupDoc) {
		
	  removeEmptyPTags(jSoupDoc, PdfConstants.WEB_HEADINGS);     		       
	  removeHeadingsAndSubText(jSoupDoc, PdfConstants.WEB_HEADINGS_TO_REMOVE, PdfConstants.WEB_SUBTEXT_TO_REMOVE);
	  addHorizontalLines(jSoupDoc, PdfConstants.WEB_HR_TAG_LOCATIONS);
      
	  //adding fixed width for the right most column which has images 
	  jSoupDoc.select("table[class~=Fb|Linke|Linkin|Tweet] td:nth-child(3)").addClass("fixedWidth");  
	  jSoupDoc.select("p:has(strong:matchesOwn((?i)^Social Media Posts:$").addClass("social_media"); 
	 
  }

  /**
   * Method for removing extra lines of space in between some headings/labels 
   *  
   * @param jSoupDoc
   */
  private void removeEmptyPTags(org.jsoup.nodes.Document jSoupDoc, String labels) {
		
	  Elements headings = (jSoupDoc.select(labels));
	  for(Element heading: headings) { 
		  if (heading != null) {
			  Node previousSib = heading.previousSibling();
			  Node nextSib = heading.nextSibling();
			  if (previousSib != null && previousSib.toString().equalsIgnoreCase(PdfConstants.EMPTY_P_Tag)){
				  previousSib.remove();
			  }
			  else if (nextSib != null && nextSib.toString().equalsIgnoreCase(PdfConstants.EMPTY_P_Tag)){	
				  nextSib.remove();
			  }
		  }
	  }
  }

  /**
   * Method for removing labels and subText
   *  
   * @param jSoupDoc
   * @param labelsToRemove
   * @param subtextToRemove
   */
  private void removeHeadingsAndSubText(org.jsoup.nodes.Document jSoupDoc, String headingsToRemove, String subtextToRemove) {
		
	  //removes the labels along with the subText under it if present.
	  jSoupDoc.select(headingsToRemove).remove();
		
	  //removes ONLY the subText
	  removeSubText(jSoupDoc, subtextToRemove);	
  }

  /**
   * Method for removing subText. Removes only the text under the given headings if present.
   *  
   * @param jSoupDoc
   * @param subText
   */
  private void removeSubText(org.jsoup.nodes.Document jSoupDoc, String subText) {		
	  Elements pTagsList = jSoupDoc.select(subText);
	  for (Element pTag : pTagsList){
		  if (!pTag.ownText().isEmpty()){
			  for(TextNode text : pTag.textNodes()){									
				  text.remove();
			  }
		  }
		  else{
			  Elements pTagChildren = pTag.children();
			  for(Element child: pTagChildren){
				  if (!child.ownText().isEmpty()){
					  child.remove();
				  }
			  }	
		  }
	  }			
  }

  /**
   * Method for adding Horizontal Lines right before given locations
   * 
   * @param jSoupDoc
   * @param locations
   */
  private void addHorizontalLines(org.jsoup.nodes.Document jSoupDoc, String locations) {
	  Elements allLocations = jSoupDoc.select(locations);
	  for(Element location : allLocations){	        	
		  location.before("<hr>");
	  }
  }

  /**
   * Method for replacing the placeholder in web template
   * 
   * @param htmlFileContents
   * @param placeHolder
   * @param replacementString
   * @return
   */
  private String replacePlaceHolders(final String htmlFileContents, final String placeHolder,
      final String replacementString) {

    if (StringUtils.isEmpty(replacementString))
      return htmlFileContents.replace(placeHolder, replacementString);

    return htmlFileContents.replace(placeHolder, replacementString);
  }

  /**
   * @param assignmentDetails
   * @param html
   * @param baseDir
   * @return
   */
  private String addSocialMedia(final AssignmentDetails assignmentDetails, String html, final String baseDir) {
    // This method needs to be refactored once we have a common pojo for Social media post objects
    final String twitter = assignmentDetails.getTwitter()
                                            .parallelStream()
                                            .filter(template -> Strings.isNotBlank(template.getTwitterId()))
                                            .map(post -> (Strings.isBlank(post.getName()) ? ""
                                                : graphicsComponent.addGraphics(post.getTwitterId(), post.getName(),
                                                    baseDir)) + populateSocialMediaFieds(post.getFields()))
                                            .collect(Collectors.joining("<hr>"));

    final String linkedin = assignmentDetails.getLinkedIn()
                                             .stream()
                                             .filter(template -> Strings.isNotBlank(template.getLinkedinId()))
                                             .map(post -> (Strings.isBlank(post.getName()) ? ""
                                                 : graphicsComponent.addGraphics(post.getLinkedinId(), post.getName(),
                                                     baseDir)) + populateSocialMediaFieds(post.getFields()))
                                             .collect(Collectors.joining("<hr>"));

    final String facebook = assignmentDetails.getFacebook()
                                             .stream()
                                             .filter(template -> Strings.isNotBlank(template.getFacebookId()))
                                             .map(post -> (Strings.isBlank(post.getName()) ? ""
                                                 : graphicsComponent.addGraphics(post.getFacebookId(), post.getName(),
                                                     baseDir)) + populateSocialMediaFieds(post.getFields()))
                                             .collect(Collectors.joining("<hr>"));

    html = html.replace("++Twitter++", twitter);
    html = html.replace("++LinkedIn++", linkedin);
    html = html.replace("++Facebook++", facebook);

    return html;
  }

  /**
   * @param fields
   * @return
   */
  private String populateSocialMediaFieds(final List<Field> fields) {
    return fields.stream()
                 .filter(field -> !(field.getFieldName()
                                         .equals("Image Creative")))
                 .map(field -> field.getFieldName() + " : " + field.getFieldValue())
                 .collect(joining(Strings.EMPTY));
  }

  /**
   * Method for writing to the pdf file
   * 
   * @param cssFile
   * @param document
   * @param writer
   * @param htmlFileContents
   * @param fontProvider
   */
  private void writeToPdfFile(final InputStream cssFile, final Document document, final PdfWriter writer,
      final String htmlFileContents, final XMLWorkerFontProvider fontProvider) {
    try (ByteArrayInputStream is = new ByteArrayInputStream(htmlFileContents.getBytes(Charset.forName("UTF-8")))) {
      XMLWorkerHelper.getInstance()
                     .parseXHtml(writer, document, is, cssFile, Charset.forName("UTF-8"), fontProvider);

    } catch (final IOException ex) {
      throw new CWBException("Error writing to pdf file:" + ex.getMessage(), ex);

    } finally {
      closeResources(document, writer);
    }
  }
  
  /**
   * Method for closing resources
   * 
   * @param document
   * @param writer
   */
  private void closeResources(final Document document, final PdfWriter writer) {
    document.close();
    if (writer.isCloseStream())
      writer.close();

  }

  /**
   * Method for generating the graphics section
   * 
   * @throws IOException
   */
  public String processAndAddGraphicsSection(final List<String> shortCodes, String htmlContents,
      final List<Graphics> graphics, final String baseDir) {

    PDFUtils.makeDirectory(baseDir + PdfConstants.BACKSLASH + PdfConstants.CREATIVE_ASSETS);

    for (final String shortCode : shortCodes) {

      final Optional<Graphics> graphicsObject = graphics.stream()
                                                        .filter(graphic -> shortCode.equalsIgnoreCase(graphic
                                                                                                             .getShortCode()))
                                                        .findFirst();
      htmlContents = generateGraphicsSection(shortCode, graphicsObject, htmlContents, baseDir);
    }

    return htmlContents;

  }

  /**
   * Method for generating the graphics section for the pdf
   * 
   * @param shortCode
   * @param graphicsObject
   * @param htmlContents
   * @return
   * @throws IOException
   * @throws NumberFormatException
   * @throws Exception
   */
  private String generateGraphicsSection(final String shortCode, final Optional<Graphics> graphicsObject,
      final String htmlContents, final String baseDir) {

    final StringBuilder graphicsHtml = new StringBuilder();
    graphicsObject.ifPresent(filteredGraphics -> {
      filteredGraphics.getFields()
                      .parallelStream()
                      .filter(field -> !Strings.isBlank(field.getFieldValue()))
                      .forEach(field -> graphicsComponent.addGraphicsSectionToPdf(field, graphicsHtml, filteredGraphics,
                          baseDir));
      graphicsHtml.append("<br />");
    });
    return htmlContents.replace(shortCode, graphicsHtml);

  }

  /**
   * Collate all the disclosure languages
   * 
   * @param results
   * @return
   */
  public String getDisclosureLanguages(final Optional<List<Result>> results) {

    return results.map(tag -> tag.stream()
                                 .map(Result::getLanguage)
                                 .collect(joining("<br /><br />")))
                  .orElse(Strings.EMPTY);
  }

  /**
   * Collate all the disclosure Paths
   * 
   * @param result
   * @return
   */
  public String getDisclosurePaths(final Optional<List<Result>> results) {

    return results.map(tag -> tag.stream()
                                 .map(result -> String.join("<br />", result.getRenditionPath()))
                                 .collect(joining("<br />")))
                  .orElse(Strings.EMPTY);
  }

  /**
   * Collate all the disclosure Tags
   * 
   * @param result
   * @return
   */
  public String getDisclosureTags(final List<DisclosureTags> tagList, final String joiner) {

    return tagList.stream()
                  .filter(tag -> !(tag.getChild()
                                      .isEmpty()))
                  .map(tag -> new StringBuilder(tag.getParent()
                                                   .substring(tag.getParent()
                                                                 .indexOf(':') + 1)).append("=")
                                                                                    .append(tag.getChild()
                                                                                               .stream()
                                                                                               .map(Child::getText)
                                                                                               .collect(joining(",")))
                                                                                    .toString())
                  .collect(joining(joiner));
  }

  public abstract PdfWriter createPdfWriterInstance(String baseDir,String assignmentName, Document document) throws DocumentException;

  protected abstract ResponseEntity<InputStreamResource> preProcessData(String baseDir, String assignmentName, String workfrontJobId);

  public abstract void downloadBackupsForAssignment(List<Backup> backups, String baseDir) throws IOException;
    
  public abstract void downloadImages(String htmlData, String baseDir) throws IOException;
  
  public abstract void downloadCreativeAssetsForAssignment(List<Graphics> graphics, String baseDir) throws IOException;

  public void cleanUpDirectory(final File assignmentDir) {
    log.debug(">>> Cleaning up " + assignmentDir.getAbsolutePath() + " : " + Arrays.toString(assignmentDir.list()));
    FileSystemUtils.deleteRecursively(assignmentDir);
  }
}
