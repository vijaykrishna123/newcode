package com.capgroup.digital.ce.cwb.pdf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import com.capgroup.digital.ce.cwb.common.CWBMessages;
import com.capgroup.digital.ce.cwb.common.PdfConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.Field;
import com.capgroup.digital.ce.cwb.model.Graphics;
import com.capgroup.digital.ce.cwb.services.IGraphics;
import com.capgroup.digital.ce.cwb.services.impl.SocialMediaService;

@Component
public class GraphicsComponent {

  @Autowired
  IGraphics graphicsService;

  @Autowired
  SocialMediaService socialMediaService;

  private final Logger log = LogManager.getLogger(GraphicsComponent.class);

  /**
   * Method for building out the graphics section of pdf file
   * 
   * @param graphicFields
   * @param graphicsHtml
   * @param filteredGraphics
   * @param baseDir
   * @return
   */
  public StringBuilder addGraphicsSectionToPdf(final Field graphicFields, final StringBuilder graphicsHtml,
      final Graphics filteredGraphics, final String baseDir) {

    switch (graphicFields.getFieldName()) {

      case (PdfConstants.GRAPHICS_HEADLINE):
      case (PdfConstants.GRAPHICS_SUB_HEAD_1):
      case (PdfConstants.GRAPHICS_SUB_HEAD_2):
      case (PdfConstants.GRAPHICS_SOURCE):
        // case (PdfConstants.GRAPHICS_ALT_TEXT):
        graphicsHtml.append("<br />" + graphicFields.getFieldName() + " : " + graphicFields.getFieldValue());
        break;

      case (PdfConstants.ADD_GRAPHICS):

        if (!StringUtils.isEmpty(filteredGraphics.getGraphicsId())) {
          try (OutputStream out = new FileOutputStream(baseDir + PdfConstants.BACKSLASH + PdfConstants.CREATIVE_ASSETS
              + PdfConstants.BACKSLASH + filteredGraphics.getName())) {
            final ResponseEntity<InputStreamResource> graphicSource = graphicsService.getGraphics(Integer.valueOf(
                filteredGraphics.getGraphicsId()));

            final InputStream graphicsStream = graphicSource.getBody()
                                                            .getInputStream();
            int c;
            while ((c = graphicsStream.read()) != -1) {
              out.write(c);
            }
          } catch (final Exception e) {
            throw new CWBException(CWBMessages.FILE_DOWNLOAD_ERROR, e);
          }

          graphicsHtml.append("<br /><img src='" + baseDir + PdfConstants.BACKSLASH + PdfConstants.CREATIVE_ASSETS
              + PdfConstants.BACKSLASH + filteredGraphics.getName() + "'/><br />");
          graphicsHtml.append(PdfConstants.GRAPHICS_FILE_NAME + " : " + filteredGraphics.getName());
        }
        break;
    }
    return graphicsHtml;
  }

  /**
   * @param graphicsId
   * @param graphicsName
   * @param baseDir
   * @return
   */
  public String addGraphics(final String graphicsId, final String graphicsName, final String baseDir) {

    final ResponseEntity<InputStreamResource> graphicSource = socialMediaService.getSocialMediaFile(Integer.valueOf(
        graphicsId));

    try {
      FileUtils.copyInputStreamToFile(graphicSource.getBody()
                                                   .getInputStream(), new File(baseDir + PdfConstants.BACKSLASH
                                                       + PdfConstants.CREATIVE_ASSETS + PdfConstants.BACKSLASH
                                                       + graphicsName));
    } catch (final IOException e) {
      throw new CWBException(CWBMessages.FILE_DOWNLOAD_ERROR, e);
    }

    return "<img class='social_media' src='" + baseDir + PdfConstants.BACKSLASH + PdfConstants.CREATIVE_ASSETS
        + PdfConstants.BACKSLASH + graphicsName + "'/><br />" + PdfConstants.GRAPHICS_FILE_NAME + " : " + graphicsName
        + "<br />";
  }

}
