package com.capgroup.digital.ce.cwb.pdf;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import com.capgroup.digital.ce.cwb.common.PdfConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.gateways.DisclosureGateway;
import com.capgroup.digital.ce.cwb.model.Backup;
import com.capgroup.digital.ce.cwb.model.Graphics;
import com.capgroup.digital.ce.cwb.services.IAssignments;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;

@Component
public class PDFFileGenerator extends FileGenerator {

  @Autowired
  public PDFFileGenerator(final IAssignments assignments, final DisclosureGateway disclosureService,
      final GraphicsComponent graphicsComponent) {
    super(assignments, disclosureService, graphicsComponent);
  }

  private final Logger log = LogManager.getLogger(FileGenerator.class);

  private ByteArrayOutputStream dataStream = null;

  /**
   * Method for generating pdf file through file generator
   * 
   * @param percolateId
   * @return
   * @throws IOException
   * 
   */
  public ResponseEntity<InputStreamResource> generatePDFFile(final String percolateId) throws IOException {

    return retrieveDataForGeneratingFile(percolateId, true);

  }

  /**
   * Method for pre processing of data
   */
  @Override
  public ResponseEntity<InputStreamResource> preProcessData(String baseDir, final String assignmentName, final String workfrontJobId) {

    HttpHeaders headers = null;

    cleanUpDirectory(new File(assignmentName + "_pdf"));

    try (ByteArrayInputStream bis = new ByteArrayInputStream(dataStream.toByteArray())) {

      headers = new HttpHeaders();

      headers.add("Content-Disposition", "inline; filename=" + assignmentName + PdfConstants.DOT + PdfConstants.PDF);
      return ResponseEntity.ok()
                           .headers(headers)
                           .contentType(MediaType.APPLICATION_PDF)
                           .body(new InputStreamResource(bis));
    } catch (final IOException ex) {
      throw new CWBException("Exception while reading pdf input stream pdffile generator");
    }
  }

  /**
   * Method for creating pdf writer instance for pdf file generator
   */
  @Override
  public PdfWriter createPdfWriterInstance(final String baseDir,final String assignmentName, final Document document)
      throws DocumentException {

    dataStream = new ByteArrayOutputStream();

    return PdfWriter.getInstance(document, dataStream);
  }

  /**
   * Method for downloading backups in case of pdf if we require in future
   */
  @Override
  public void downloadBackupsForAssignment(final List<Backup> backups, final String baseDir) throws IOException {
    // We are not downloading backups for pdf which we can do in future in case we
    // want to add the details to pdf

  }

  /**
   * Method for downloading images
   */
  @Override
  public void downloadImages(String htmlData, String baseDir) throws IOException {
	  // We only need to explicitly download images to local for zip file generation, NOT pdf. 		
  }
  
  /**
   * Method for downloading responsive images
   */
  @Override
  public void downloadCreativeAssetsForAssignment(List<Graphics> graphics, String baseDir) throws IOException {
	  // We do not need this for pdf generation, only when downloading a zip file 		
  }
}
