package com.capgroup.digital.ce.cwb.pdf;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import com.capgroup.digital.ce.cwb.common.PdfConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.gateways.DisclosureGateway;
import com.capgroup.digital.ce.cwb.model.Backup;
import com.capgroup.digital.ce.cwb.model.Graphics;
import com.capgroup.digital.ce.cwb.services.IAssignments;
import com.capgroup.digital.ce.cwb.services.IBackups;
import com.capgroup.digital.ce.cwb.services.IGraphics;
import com.capgroup.digital.ce.cwb.utils.CWBFileInputStream;
import com.capgroup.digital.ce.cwb.utils.PDFUtils;
import com.capgroup.digital.ce.cwb.utils.ZipUtils;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;

@Component
public class ZipFileGenerator extends FileGenerator {

  private final IBackups backupService;
  
  private final IGraphics graphicService;

  @Autowired
  public ZipFileGenerator(final IBackups backupService, final IGraphics graphicService, final IAssignments assignments,
      final DisclosureGateway disclosureService, final GraphicsComponent graphicsComponent) {
    super(assignments, disclosureService, graphicsComponent);
    this.backupService = backupService;
    this.graphicService = graphicService;
  }

  private final Logger log = LogManager.getLogger(ZipFileGenerator.class);

  /**
   * Method for generating the zip file
   * 
   * @param percolateId
   * @return
   * @throws IOException
   */
  public ResponseEntity<InputStreamResource> generateZipFile(final String percolateId) throws IOException {

    return retrieveDataForGeneratingFile(percolateId, false);

  }

  /**
   * Method for pre process of zip file data
   */
  @Override
  public ResponseEntity<InputStreamResource> preProcessData(String baseDir, String assignmentName, String workfrontJobId) {

    final ZipUtils appZip = new ZipUtils();   
    final File assignmentDir = new File(baseDir);    
    appZip.generateFileList(assignmentDir);
    if (!Strings.isBlank(workfrontJobId)) {
      workfrontJobId = workfrontJobId.replaceAll("\\s+", "");
      assignmentName = baseDir + "_" + workfrontJobId;
    }
    else {assignmentName = baseDir;}
    final String outputFilename = assignmentName + ".zip";

    log.debug(">>> Creating zip file: " + Arrays.toString(assignmentDir.list()));
    appZip.zipIt(baseDir,outputFilename);

    cleanUpDirectory(assignmentDir);

    final HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.parseMediaType("application/zip"));
    headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
    headers.add("Content-Disposition", "attachment; filename=\"" + outputFilename.replace("/tmp/", "") + "\"");
    FileInputStream fileinout;
    try {
      fileinout = new CWBFileInputStream(new File(outputFilename));
    } catch (final FileNotFoundException e) {
      throw new CWBException("Exception while generating zip file:" + e.getMessage(), e);
    }
   
    return ResponseEntity.ok()
                         .headers(headers)
                         .body(new InputStreamResource(fileinout));
  }

  /**
   * Creating a PDF writer instance for zip file generation
   */
  @Override
  public PdfWriter createPdfWriterInstance(final String baseDir,final String assignmentName, final Document document)
      throws DocumentException {
    PDFUtils.makeDirectory(baseDir);
    PdfWriter writer = null;
    OutputStream stream = null;
    try {
      final File pdf = new File(baseDir + PdfConstants.BACKSLASH + assignmentName + ".pdf");
      stream = new FileOutputStream(pdf);
    } catch (final FileNotFoundException e) {
      throw new CWBException(e.getMessage(), e);
    }

    writer = PdfWriter.getInstance(document, stream);

    return writer;
  }

  /**
   * Method for downloading backup files to a folder
   * 
   * @throws IOException
   */
  @Override
  public void downloadBackupsForAssignment(final List<Backup> backups, final String baseDir) throws IOException {

    PDFUtils.makeDirectory(baseDir + PdfConstants.BACKSLASH + PdfConstants.BACKUP);

    for (final Backup backup : backups) {

      if (!StringUtils.isEmpty(backup.getBackupId())) {
        InputStream backupStream = null;

        try (OutputStream out = new FileOutputStream(baseDir + PdfConstants.BACKSLASH + PdfConstants.BACKUP
            + PdfConstants.BACKSLASH + backup.getName())) {
          final ResponseEntity<InputStreamResource> backupSource = backupService.getBackup(Integer.valueOf(backup
                                                                                                                 .getBackupId()));
          backupStream = backupSource.getBody()
                                     .getInputStream();
          int c;

          while ((c = backupStream.read()) != -1) {
            out.write(c);
          }
        } catch (final Exception e) {
          throw new CWBException(e.getMessage(), e);
        } finally {
          if (null != backupStream)
            backupStream.close();
        }
      }
    }
  }
  
  /**
   * Method for downloading the responsive images into the "Creative" folder inside zip file
   * 
   * @throws IOException
   */
  @Override
  public void downloadCreativeAssetsForAssignment(final List<Graphics> graphics, final String baseDir) throws IOException {
	
	PDFUtils.makeDirectory(baseDir + PdfConstants.BACKSLASH + PdfConstants.CREATIVE);

    for (final Graphics graphic : graphics) {

      if (!StringUtils.isEmpty(graphic.getGraphicsId())) {
        InputStream graphicStream = null;

        try (OutputStream out = new FileOutputStream(baseDir + PdfConstants.BACKSLASH + PdfConstants.CREATIVE
            + PdfConstants.BACKSLASH + graphic.getName())) {
          final ResponseEntity<InputStreamResource> graphicSource = graphicService.getGraphics(Integer.valueOf(graphic.getGraphicsId()));
          graphicStream = graphicSource.getBody()
                                     .getInputStream();
          int c;

          while ((c = graphicStream.read()) != -1) {
            out.write(c);
          }
        } catch (final Exception e) {
          throw new CWBException(e.getMessage(), e);
        } finally {
          if (null != graphicStream)
        	graphicStream.close();
        }
      }
    }
  }
  
  /**
	 * Method for downloading the images into the "Creative" folder inside zip file
	 * 
	 * @param htmlData
	 * @param baseDir
	 * @return htmlFileContents
	 * @throws IOException 
	 */
  @Override
  public void downloadImages(String htmlData, String baseDir) throws IOException {
	  
	String htmlFileContents = htmlData;		
	int i = 0;
	URL url;
	InputStream imageStream = null;
	Path imgPath = null; 
		
	org.jsoup.nodes.Document jSoupDoc = Jsoup.parse(htmlFileContents);
	PDFUtils.makeDirectory(baseDir + PdfConstants.BACKSLASH + PdfConstants.CREATIVE);	
	
	//picking up all the "img" tags and extracting the source link
    Elements images = jSoupDoc.select("img");
    for (Element img : images) {    
    	String theLink = img.attr("src").toString();
		try { 
			if (theLink.endsWith("png")){
	    		imgPath = Paths.get(baseDir + PdfConstants.BACKSLASH +  PdfConstants.CREATIVE
		            + PdfConstants.BACKSLASH  + "Image_" + i++ + PdfConstants.PNG_IMAGE_EXTENSION);
			} 
			else {
	    		imgPath = Paths.get(baseDir + PdfConstants.BACKSLASH +  PdfConstants.CREATIVE
			            + PdfConstants.BACKSLASH  + "Image_" + i++ + PdfConstants.JPG_IMAGE_EXTENSION);
	    	}
			
			//downloading images to local
			url = new URL(theLink);
			imageStream = url.openStream();
			Files.copy(imageStream, imgPath,  StandardCopyOption.REPLACE_EXISTING);	
		
		} catch (InvalidPathException e1){
			log.error(">>>> Error while converting given string into a valid Path " + e1.getMessage(), e1);
				
		} catch (MalformedURLException e2) {
			log.error(">>>> Error with image URL, make sure image is sourced from fully qualified url: ", e2);	
	
		} catch (SecurityException e3){				
			log.error(">>>> Error: Security Violation " + e3.getMessage(), e3);
				
		} catch (IOException e4) {
			throw new CWBException("Exception while downloading/saving image: " + e4.getMessage(), e4);			
		}
		finally{ 
			if (null != imageStream)
				{imageStream.close();}
		}
    }
  }
}
