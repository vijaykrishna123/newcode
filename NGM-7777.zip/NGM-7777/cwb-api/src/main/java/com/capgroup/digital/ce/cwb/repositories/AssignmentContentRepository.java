package com.capgroup.digital.ce.cwb.repositories;

import java.sql.Clob;
import javax.persistence.EntityNotFoundException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import com.capgroup.digital.ce.cwb.model.entities.AssignmentContent;

public interface AssignmentContentRepository extends JpaRepository<AssignmentContent, Long> {

  /** Check if Content already available **/
  @Query(value = "SELECT  COUNT(*) FROM ASSIGNMENT_CONTENT WHERE ASSIGNMENT_ID=?1 AND FIELD_ID=?2 AND REFERENCE_ID=?3",
      nativeQuery = true)
  String checkContentExist(@Param("assignmentId") long assignmentId, @Param("fieldId") Integer fieldId,
      @Param("referenceId") Integer referenceId);

  @Query(value = "SELECT  COUNT(*) FROM ASSIGNMENT_CONTENT WHERE ASSIGNMENT_ID=?1 AND REFERENCE_ID=?2",
      nativeQuery = true)
  String checkCopyContentExist(@Param("assignmentId") Integer assignmentId, @Param("referenceId") Integer referenceId);

  @Query(value = "SELECT * FROM ASSIGNMENT_CONTENT WHERE ASSIGNMENT_ID=?1 AND FIELD_ID=?2 AND REFERENCE_ID=?3",
      nativeQuery = true)
  AssignmentContent getContent(@Param("assignmentId") Integer assignmentId, @Param("fieldId") Integer fieldId,
      @Param("referenceId") Integer referenceId);

  @Query(
      value = "SELECT FIELD_CONTENT FROM ASSIGNMENT_CONTENT WHERE ASSIGNMENT_ID=?1 AND FIELD_ID=?2 AND REFERENCE_ID=?3",
      nativeQuery = true)
  Clob getContentValue(@Param("assignmentId") long assignmentId, @Param("fieldId") Integer fieldId,
      @Param("referenceId") Integer referenceId);

  @Modifying
  @Transactional
  @Query(value = "DELETE FROM ASSIGNMENT_CONTENT WHERE ASSIGNMENT_ID=?1 AND REFERENCE_ID=?2", nativeQuery = true)
  void deleteReferenceContent(@Param("assignmentId") Integer assignmentId, @Param("referenceId") Integer referenceId)
      throws EntityNotFoundException;

  AssignmentContent findById(Integer id) throws EntityNotFoundException;
  
  @Modifying
  @Transactional
  void deleteByAssignmentId(int assignmentId);

}
