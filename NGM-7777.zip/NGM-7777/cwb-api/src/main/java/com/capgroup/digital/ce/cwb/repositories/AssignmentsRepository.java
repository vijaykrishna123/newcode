package com.capgroup.digital.ce.cwb.repositories;

import java.sql.Clob;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgroup.digital.ce.cwb.model.entities.AssignmentEntity;
import java.util.List;

import javax.transaction.Transactional;

public interface AssignmentsRepository extends JpaRepository<AssignmentEntity, Long> {

  @Query(value = "SELECT * FROM ASSIGNMENTS WHERE ID= ?1", nativeQuery = true)
  AssignmentEntity getAssignment(@Param("assignmentId") Integer assignmentId);

  @Query(value = "SELECT * FROM ASSIGNMENTS WHERE PERCOLATE_ID= ?1", nativeQuery = true)
  AssignmentEntity getAssignment(@Param("percolateId") String percolateId);

  @Query(value = "SELECT  COUNT(*) FROM ASSIGNMENTS WHERE PERCOLATE_ID =?1", nativeQuery = true)
  String checkAssignmentExists(@Param("percolateId") String percolateId);

  @Query(value = "SELECT ID FROM ASSIGNMENTS WHERE PERCOLATE_ID=?1", nativeQuery = true)
  Integer getAssignmentId(@Param("percolateId") String percolateId);

  @Query(value = "SELECT DISCLOSURE_TAGS FROM ASSIGNMENTS WHERE PERCOLATE_ID=?1", nativeQuery = true)
  Clob getDisclosureTags(@Param("percolateId") String percolateId);
  
  boolean existsByUserInitialsAndPercolateId(String commentValue, String percolateId);
  
  List<AssignmentEntity> findByStatusIsNullAndUserInitials(String userInitials);
  
  List<AssignmentEntity> findByStatusAndUserInitials(String status, String userInitials);
  
  AssignmentEntity findByStatusAndPercolateId(String status, String percolateId);
  
  @Query(value = "SELECT STATUS FROM ASSIGNMENTS WHERE PERCOLATE_ID=?1", nativeQuery = true)
  String getStatus(@Param ("percolateId")String percolateId);
  
  @Modifying
  @Transactional
  void deleteById(int id);

}
