package com.capgroup.digital.ce.cwb.repositories;

import java.util.List;
import javax.persistence.EntityNotFoundException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.capgroup.digital.ce.cwb.model.entities.Backups;


public interface BackupsRepository extends JpaRepository<Backups, Long> {

  /** Check if Graphic is available and it is Unique **/
  @Query(value = "SELECT  COUNT(*) FROM BACKUPS WHERE ASSIGNMENT_ID=?1 AND BACKUP_LOCATION=?2", nativeQuery = true)
  String checkBackupsExist(@Param("assignmentId") long assignmentId, @Param("backupLocation") String backupLocation);

  @Query(value = "SELECT  ID FROM BACKUPS WHERE ASSIGNMENT_ID=?1 AND BACKUP_LOCATION=?2", nativeQuery = true)
  Integer getBackupId(@Param("assignmentId") long assignmentId, @Param("backupLocation") String backupLocation);

  @Query(value = "SELECT  COUNT(*) FROM BACKUPS WHERE ASSIGNMENT_ID=?1 ", nativeQuery = true)
  String checkBackupsExist(@Param("assignmentId") long assignmentId);

  @Query(value = "SELECT * FROM BACKUPS WHERE ASSIGNMENT_ID=?1 ", nativeQuery = true)
  List<Backups> getBackups(@Param("assignmentId") long assignmentId);

  Backups findById(Integer backupId) throws EntityNotFoundException;
  
  @Modifying
  @Transactional
  void deleteByAssignmentId(int assignmentId);
}
