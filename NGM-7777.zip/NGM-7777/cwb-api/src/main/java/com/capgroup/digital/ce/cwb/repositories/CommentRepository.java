package com.capgroup.digital.ce.cwb.repositories;

import java.util.List;
import javax.persistence.EntityNotFoundException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.capgroup.digital.ce.cwb.model.entities.Comments;


@Repository
public interface CommentRepository extends JpaRepository<Comments, Long> {

  List<Comments> findByAssignmentId(Integer assignmentId) throws EntityNotFoundException;
  
  Comments findById(Integer commentId) throws EntityNotFoundException;
  
  long countByCommentValueAndAssignmentId(String commentValue,Integer assignmentId) throws EntityNotFoundException;  

  @Query(value = "SELECT * FROM COMMENTS WHERE upper(COMMENT_VALUE)= ?1", nativeQuery = true)
  List<Comments> findByRelatedInitial(String initial) throws EntityNotFoundException;
  
  @Modifying
  @Transactional
  void deleteByAssignmentId(int assignmentId);

}
