package com.capgroup.digital.ce.cwb.repositories;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgroup.digital.ce.cwb.model.entities.Fields;

public interface FieldRepository extends JpaRepository<Fields, Long> {

  @Query(value = "SELECT * FROM FIELDS WHERE ID= ?1", nativeQuery = true)
  Fields getWriteFields(@Param("fieldId") BigDecimal fieldId);

  @Query(value = "SELECT * FROM FIELDS where FIELD_SECTION = 'graphics' AND FIELD_NAME LIKE %?1", nativeQuery = true)
  Fields getGraphicWriteFields(@Param("fieldName") String fieldName);

  @Query(value = "SELECT FIELD_NAME FROM FIELDS where FIELD_SECTION =?1", nativeQuery = true)
  List<String> getWriteFieldsForTemplates(@Param("fieldSection") String fieldSection);

  @Query(value = "SELECT * FROM FIELDS where FIELD_SECTION = 'quote' AND FIELD_NAME LIKE %?1", nativeQuery = true)
  Fields getQuoteWriteFields(@Param("fieldName") String fieldName);
}
