package com.capgroup.digital.ce.cwb.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgroup.digital.ce.cwb.model.entities.SocialMediaEntity;

public interface SocialMediaRepository extends JpaRepository<SocialMediaEntity, Long> {

  SocialMediaEntity findById(Integer socialMediaId);

  List<SocialMediaEntity> findByAssignmentId(long assignmentId);

  @Query(value = "SELECT * FROM SOCIAL_MEDIA WHERE ASSIGNMENT_ID=?1 AND MEDIA_TYPE=?2", nativeQuery = true)
  List<SocialMediaEntity> getSocialMediaItems(@Param("assignmentId") long assignmentId,
      @Param("mediaType") String mediaType);
}
