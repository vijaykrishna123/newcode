package com.capgroup.digital.ce.cwb.repositories;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgroup.digital.ce.cwb.model.entities.TemplateDetails;

public interface TemplateDetailsRepository extends JpaRepository<TemplateDetails, Long> {

  @Query(value = "SELECT FIELD_ID FROM TEMPLATE_DETAILS WHERE TEMPLATE_ID= ?1 AND FIELD_SECTION= ?2 ORDER BY FIELD_ORDER",
      nativeQuery = true)
  List<BigDecimal> getTemplateFields(@Param("templateId") Integer templateId,
      @Param("fieldSection") String fieldSection);

  @Query(value = "SELECT FIELD_SECTION FROM TEMPLATE_DETAILS WHERE FIELD_ID= ?1", nativeQuery = true)
  String getFieldSection(@Param("fieldId") String fieldId);

}
