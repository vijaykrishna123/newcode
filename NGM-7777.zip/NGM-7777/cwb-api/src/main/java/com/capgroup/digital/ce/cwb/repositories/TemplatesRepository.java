package com.capgroup.digital.ce.cwb.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgroup.digital.ce.cwb.model.entities.Templates;

public interface TemplatesRepository extends JpaRepository<Templates, Long> {

  @Query(value = "SELECT ID FROM TEMPLATES WHERE TEMPLATE_NAME = ?1", nativeQuery = true)
  Integer getTemplateId(@Param("templateName") String templateName);
  
  List<Templates> findAll();

}
