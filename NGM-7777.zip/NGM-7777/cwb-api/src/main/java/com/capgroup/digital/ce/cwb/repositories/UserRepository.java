package com.capgroup.digital.ce.cwb.repositories;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgroup.digital.ce.cwb.model.entities.Users;

@Repository
public interface UserRepository extends JpaRepository<Users, Long> {

  @Query(value = "SELECT COUNT(*) FROM Users WHERE USER_INITIALS = ?1", nativeQuery = true)
  Integer checkUserExists(@Param("userInitials") String userInitials);

  Optional<Users> findByUserInitials(String userInitials);

}
