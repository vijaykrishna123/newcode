package com.capgroup.digital.ce.cwb.schema;

public class SchemaGenerator {

}
