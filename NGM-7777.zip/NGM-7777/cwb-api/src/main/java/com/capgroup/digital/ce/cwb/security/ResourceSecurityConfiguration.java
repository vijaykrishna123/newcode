package com.capgroup.digital.ce.cwb.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

@Configuration
public class ResourceSecurityConfiguration extends WebSecurityConfigurerAdapter {

  @Value("${cors.allow-origins}")
  private String allowOrigins;

  @Override
  public void configure(HttpSecurity http) throws Exception {
    http.cors();
    // not applicable for rest api
    http.csrf()
        .disable();
    http.headers()
        .frameOptions()
        .disable();

    http.addFilterAfter(new SimpleCorsFilter(allowOrigins), BasicAuthenticationFilter.class);
    http.authorizeRequests()
        .antMatchers(HttpMethod.OPTIONS, "/**")
        .permitAll();
    /*
     * http.authorizeRequests().antMatchers(PREFIX + CWBConstants.STATUS_ENDPOINT).permitAll();
     * http.authorizeRequests().antMatchers(PREFIX + "/advisors/sign-up").permitAll();
     * http.authorizeRequests().antMatchers(PREFIX + "/sources/
     **/
    /*
     * logo").permitAll(); http.authorizeRequests().antMatchers(PREFIX +
     * "/advisors/password/**").permitAll(); http.authorizeRequests().antMatchers(PREFIX +
     * "/advisors/password").permitAll(); http.authorizeRequests().antMatchers(INTERNAL_PREFIX +
     * "/**").permitAll();
     * http.authorizeRequests().antMatchers(Constants.SWAGGER_UI_ENDPOINT).permitAll ();
     * http.authorizeRequests().antMatchers(Constants.SWAGGER_API_DOCS_ENDPOINT). permitAll();
     * http.authorizeRequests().antMatchers(Constants.SWAGGER_RESOURCES_ENDPOINT). permitAll();
     * http.authorizeRequests().antMatchers(Constants.SPRINGFOX_SWAGGER_UI_ENDPOINT) .permitAll();
     */
    /*
     * http.authorizeRequests().anyRequest().authenticated();
     * http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy. STATELESS);
     */
  }

  @Bean
  public BCryptPasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  @Autowired
  public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
    auth.inMemoryAuthentication()
        .passwordEncoder(passwordEncoder())
        .withUser("daaApp")
        .password(passwordEncoder().encode("We Did it."))
        .authorities("ROLE_USER");
  }
}
