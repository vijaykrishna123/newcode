package com.capgroup.digital.ce.cwb.security;


import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This filter updates response with headers to allow REST calls from all domains, as intended
 * client is running in customer browser.
 */
public class SimpleCorsFilter implements Filter {

  private String allowOrigins;

  public SimpleCorsFilter(String allowOrigins) {
    this.allowOrigins = allowOrigins;
  }

  public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException,
      ServletException {
    HttpServletResponse response = (HttpServletResponse) res;

    response.setHeader("Access-Control-Allow-Origin", allowOrigins);
    response.setHeader("Access-Control-Allow-Methods", "GET,POST, PUT, OPTIONS, DELETE");
    response.setHeader("Access-Control-Max-Age", "3600");
    /*
     * response.setHeader("Access-Control-Allow-Headers",
     * "Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Allow-Credentials, "
     * + "Cache-Control, If-Modified-Since");
     */
    response.setHeader("Access-Control-Allow-Headers",
        "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
    // response.setHeader("Access-Control-Allow-Credentials", "true");

    // response.setHeader("Access-Control-Expose-Headers", "Accept-Range, Content-Range");

    HttpServletRequest request = (HttpServletRequest) req;
    if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
      // make Chrome prefly access control happy for authorization call
      response.setStatus(HttpServletResponse.SC_OK);
    } else {
      chain.doFilter(req, res);
    }
  }

  public void init(FilterConfig filterConfig) {}

  public void destroy() {}
}
