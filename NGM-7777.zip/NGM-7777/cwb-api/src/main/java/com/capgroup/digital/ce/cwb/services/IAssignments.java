package com.capgroup.digital.ce.cwb.services;

import java.util.List;
import org.springframework.http.ResponseEntity;
import com.capgroup.digital.ce.cwb.model.Assignment;
import com.capgroup.digital.ce.cwb.model.AssignmentDetails;
import com.capgroup.digital.ce.cwb.model.DraftAssignment;
import com.capgroup.digital.ce.cwb.model.LinkRequest;
import com.capgroup.digital.ce.cwb.model.DisclosureTags;
import com.capgroup.digital.ce.cwb.model.ProofDetails;
import com.capgroup.digital.ce.cwb.model.TemplatesResponse;
import com.capgroup.digital.ce.cwb.model.WorkfrontDetails;
import com.capgroup.digital.ce.cwb.model.entities.AssignmentEntity;

public interface IAssignments {

  public AssignmentDetails getAssignmentDetails(String percolateId);

  public AssignmentDetails saveAssignments(String percolateId, AssignmentDetails assignmentDetails) throws Exception;

  public Integer saveAssignmentGraphics(com.capgroup.digital.ce.cwb.model.entities.Graphics graphics);

  public ResponseEntity<Assignment> createAssignment(Assignment assignment);

  public List<DisclosureTags> getDisclosureTags(AssignmentEntity assignmentEntity);

  public void saveAssignmentFacebook(AssignmentDetails assignmentDetails, Integer assignmentId);

  public void saveAssignmentTwitter(AssignmentDetails assignmentDetails, Integer assignmentId);

  public void saveAssignmentLinkedIn(AssignmentDetails assignmentDetails, Integer assignmentId) throws Exception;

  public void saveProofDetails(String percolateId, ProofDetails proofDetails);
  
  public void saveWorkfrontDetails(String percolateId, WorkfrontDetails workfrontDetails);

	public ResponseEntity<List<TemplatesResponse>> fetchTemplates();
	
	public void link(LinkRequest linkRequest );
	
	public List<Assignment> getAssignments(String userInitials);
	
	public List<DraftAssignment> getUnlinkedAssignments(String userInitials);
	
	public DraftAssignment getUnlinkedAssignmentsDetails(String percolateId);
	
	public void deleteDraftAssignment(String draftId);

}
