package com.capgroup.digital.ce.cwb.services;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface IBackups {

  public ResponseEntity<InputStreamResource> getBackup(Integer backupId) throws Exception;

  public ResponseEntity<String> saveBackup(MultipartFile file, String assignId, String userId) throws Exception;

  public ResponseEntity<String> updateBackup(MultipartFile file, Integer backupId, String postId, String userId)
      throws Exception;

  public ResponseEntity<String> deleteBackup(Integer backupId) throws Exception;

}