package com.capgroup.digital.ce.cwb.services;


import java.util.List;
import org.springframework.http.ResponseEntity;
import com.capgroup.digital.ce.cwb.model.CommentsRequest;
import com.capgroup.digital.ce.cwb.model.CommentsResponse;
import com.capgroup.digital.ce.cwb.model.RelatedComment;

public interface IComments {

  public List<CommentsResponse> getComments(Integer assignmentId) throws Exception;

  public ResponseEntity<String> createComments(CommentsRequest commentRequest, String host, String purpose);
  
  public List<RelatedComment> getRelatedCommentsByRelatedInitial(String initial) throws Exception;
  
  public ResponseEntity<String> deleteComment(final Integer commentId) throws Exception;

}