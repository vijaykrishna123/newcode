package com.capgroup.digital.ce.cwb.services;

public interface IEmailNotifiers {

  void sendEmail(String recipient, String subject, String htmlContent);
}
