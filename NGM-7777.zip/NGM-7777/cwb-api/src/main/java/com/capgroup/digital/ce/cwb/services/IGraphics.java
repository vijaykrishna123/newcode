package com.capgroup.digital.ce.cwb.services;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface IGraphics {

  public ResponseEntity<InputStreamResource> getGraphics(Integer graphicId) throws Exception;

  public ResponseEntity<String> saveGraphics(MultipartFile file, String assignId, String userId);

  public ResponseEntity<String> deleteGraphics(Integer graphicId) throws Exception;

  public ResponseEntity<String> updateGraphics(MultipartFile file, Integer graphicId, String postId, String userId);

}