package com.capgroup.digital.ce.cwb.services;

import com.capgroup.digital.ce.cwb.model.Notification;

public interface INotifications {

  public void notifyUser(Notification notification) throws Exception;

}
