package com.capgroup.digital.ce.cwb.services;

import java.io.IOException;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;

public interface IPdfService {

  public ResponseEntity<InputStreamResource> generatePDFForAssignment(String percolateId) throws IOException;

  public ResponseEntity<InputStreamResource> generateZipForAssignment(String percolateId) throws IOException;

}
