package com.capgroup.digital.ce.cwb.services;


public interface IPreSignedURL {


  public String getS3PreSignedURL(String objectKey, String requestType);
}
