package com.capgroup.digital.ce.cwb.services;

import org.springframework.web.multipart.MultipartFile;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;

public interface IS3Uploader {

  public String uploadFile(MultipartFile file, String assignId, String userId, String assetType);

  public S3Object downloadFile(String fileLocation);

  public AmazonS3 getS3Client() throws Exception;

  boolean deleteFile(String fileLocation);

}
