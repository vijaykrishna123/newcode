package com.capgroup.digital.ce.cwb.services;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.capgroup.digital.ce.cwb.model.entities.SocialMediaEntity;

public interface ISocialMedia {

  public ResponseEntity<InputStreamResource> getSocialMediaFile(Integer socialMediaId) throws Exception;

  public ResponseEntity<String> saveSocialMediaFile(MultipartFile file, String assignId, String userId,
	      String mediaType) throws Exception;

  public ResponseEntity<String> deleteSocialMedia(Integer socialMediaId) throws Exception;

  public ResponseEntity<String> updateSocialMediaFile(MultipartFile file, Integer socialMediaId, String postId, String userId,
	      String mediaType) throws Exception;

  public Integer saveSocialMedia(Integer assignmentId, String twitterSection, SocialMediaEntity socialMediaEntity);

}
