package com.capgroup.digital.ce.cwb.services;

import org.springframework.http.HttpStatus;
import com.capgroup.digital.ce.cwb.model.UserRequest;


public interface IUsers {

  public HttpStatus saveUsers(UserRequest user);

}