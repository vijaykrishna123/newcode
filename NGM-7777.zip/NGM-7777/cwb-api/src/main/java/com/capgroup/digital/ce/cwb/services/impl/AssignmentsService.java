package com.capgroup.digital.ce.cwb.services.impl;


import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.Assignment;
import com.capgroup.digital.ce.cwb.model.AssignmentDetails;
import com.capgroup.digital.ce.cwb.model.DraftAssignment;
import com.capgroup.digital.ce.cwb.model.Backup;
import com.capgroup.digital.ce.cwb.model.Collaborators;
import com.capgroup.digital.ce.cwb.model.Copy;
import com.capgroup.digital.ce.cwb.model.DisclosureTagList;
import com.capgroup.digital.ce.cwb.model.DisclosureTags;
import com.capgroup.digital.ce.cwb.model.Facebook;
import com.capgroup.digital.ce.cwb.model.Field;
import com.capgroup.digital.ce.cwb.model.Graphics;
import com.capgroup.digital.ce.cwb.model.LinkRequest;
import com.capgroup.digital.ce.cwb.model.LinkedIn;
import com.capgroup.digital.ce.cwb.model.ProofDetails;
import com.capgroup.digital.ce.cwb.model.Properties;
import com.capgroup.digital.ce.cwb.model.TemplatesResponse;
import com.capgroup.digital.ce.cwb.model.Twitter;
import com.capgroup.digital.ce.cwb.model.WorkfrontDetails;
import com.capgroup.digital.ce.cwb.model.entities.AssignmentContent;
import com.capgroup.digital.ce.cwb.model.entities.AssignmentEntity;
import com.capgroup.digital.ce.cwb.model.entities.Backups;
import com.capgroup.digital.ce.cwb.model.entities.Comments;
import com.capgroup.digital.ce.cwb.model.entities.Fields;
import com.capgroup.digital.ce.cwb.model.entities.SocialMediaEntity;
import com.capgroup.digital.ce.cwb.model.entities.Users;
import com.capgroup.digital.ce.cwb.repositories.AssignmentContentRepository;
import com.capgroup.digital.ce.cwb.repositories.AssignmentsRepository;
import com.capgroup.digital.ce.cwb.repositories.BackupsRepository;
import com.capgroup.digital.ce.cwb.repositories.CommentRepository;
import com.capgroup.digital.ce.cwb.repositories.FieldRepository;
import com.capgroup.digital.ce.cwb.repositories.GraphicsRepository;
import com.capgroup.digital.ce.cwb.repositories.SocialMediaRepository;
import com.capgroup.digital.ce.cwb.repositories.TemplateDetailsRepository;
import com.capgroup.digital.ce.cwb.repositories.TemplatesRepository;
import com.capgroup.digital.ce.cwb.repositories.UserRepository;
import com.capgroup.digital.ce.cwb.services.IAssignments;
import com.capgroup.digital.ce.cwb.services.ISocialMedia;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class AssignmentsService implements IAssignments {

  private final AssignmentsRepository assignmentRepository;

  private final TemplatesRepository templateRepository;

  private final TemplateDetailsRepository templateDetailsRepository;

  private final FieldRepository fieldRepository;

  private final AssignmentContentRepository assignmentContentRepository;

  private final GraphicsRepository graphicsRepository;

  private final BackupsRepository backupsRepository;

  private final UserRepository userRepository;

  private final SocialMediaRepository socialMediaRepository;
  
  private final CommentRepository commentRepository;

  @Autowired
  private ISocialMedia socialMedia;

  @Autowired
  public AssignmentsService(final AssignmentsRepository assignmentRepository,
      final TemplatesRepository templateRepository, final TemplateDetailsRepository templateDetailsRepository,
      final FieldRepository fieldRepository, final AssignmentContentRepository assignmentContentRepository,
      final GraphicsRepository graphicsRepository, final BackupsRepository backupsRepository,
      final UserRepository userRepository, final SocialMediaRepository socialMediaRepository, final CommentRepository commentRepository ) {
    this.assignmentRepository = assignmentRepository;
    this.templateRepository = templateRepository;
    this.templateDetailsRepository = templateDetailsRepository;
    this.fieldRepository = fieldRepository;
    this.assignmentContentRepository = assignmentContentRepository;
    this.graphicsRepository = graphicsRepository;
    this.backupsRepository = backupsRepository;
    this.userRepository = userRepository;
    this.socialMediaRepository = socialMediaRepository;
    this.commentRepository = commentRepository;
  }

  private static final Logger log = LogManager.getLogger(AssignmentsService.class); 

  /**
   * Method for creating the assignment
   */
  @Override
  public ResponseEntity<Assignment> createAssignment(final Assignment assignment) {

    HttpStatus status;

    Integer templateId = templateRepository.getTemplateId(assignment.getTemplateName());

    if (null == templateId) {
      templateId = 4;
    }

    if (userRepository.checkUserExists(assignment.getUserInitials()) == 0) {
      throw new CWBException("User Initals: " + assignment.getUserInitials()
          + " doesn't exist. Check with System Administrator");
    }

    AssignmentEntity assignmentEntity= null;
    if (!assignment.isUnlinkedAssignment()) {
    	assignmentEntity = assignmentRepository.getAssignment(assignment.getPercolateId());
    }
    
    if (assignmentEntity != null) {

      /** Assignment already exists **/
      status = HttpStatus.OK;
    } else {

      /** Assignment doesn't exist **/
      assignmentEntity = new AssignmentEntity();
      status = HttpStatus.CREATED;
    }
    assignmentEntity.setAssignmentName(assignment.getAssignmentName());

    /** Save Disclosure JSOn object in assignment table **/
    final ObjectMapper objectMapper = new ObjectMapper();
    try {
      if (assignment.getDisclosureTags() != null) {

        assignmentEntity.setDisclosureTags(objectMapper.writeValueAsString(assignment.getDisclosureTags()));
      }

    } catch (final JsonProcessingException e) {
      throw new CWBException(e.getMessage(), e);
    }
    
    /** Set a dummy percolate id-> draftId, if assignment is 'UNLINKED' **/
    if (assignment.isUnlinkedAssignment()) {
    	Instant instant = Instant.now();
    	long draftId = instant.toEpochMilli();
    	assignmentEntity.setPercolateId("post:"+Long.toString(draftId));
    	assignmentEntity.setStatus(CWBConstants.STATUS_UNLINKED);
    }
    else {
    	assignmentEntity.setPercolateId(assignment.getPercolateId());
    	assignmentEntity.setStatus(null);
    }
    
    assignmentEntity.setUserInitials(assignment.getUserInitials());
    assignmentEntity.setTemplateId(templateId);
    assignmentEntity.setTemplateName(assignment.getTemplateName());
    assignmentEntity.setWorkfrontJobId(assignment.getWorkfrontJobId());
    assignmentRepository.save(assignmentEntity);

    /** Update Assignment object with database values **/
    assignment.setId(assignmentEntity.getId());
    assignment.setTemplateId(assignmentEntity.getTemplateId());
    assignment.setUpdatedAt(Optional.ofNullable(assignmentEntity.getUpdatedAt())
                                    .orElse(new Date())
                                    .toString());
    assignment.setProofURL(assignmentEntity.getProofURL());
    assignment.setProofFileId(assignmentEntity.getProofFileId());
//    assignment.setWorkfrontDocId(assignmentEntity.getWorkfrontDocId());
    return new ResponseEntity<>(assignment, status);
  }

  @Override
  public AssignmentDetails saveAssignments(final String percolateId, final AssignmentDetails assignmentDetails)
      throws Exception {

    final AssignmentEntity assignmentEntity = assignmentRepository.getAssignment(percolateId);
    final Integer assignmentId = assignmentEntity.getId();

    /** Save data to the Assignments Table **/
    if (null != assignmentDetails.getAssignment()) {
      final Assignment assignment = assignmentDetails.getAssignment();

      assignmentEntity.setAssignmentName(assignment.getAssignmentName());

      /** Save Disclosure JSOn object in assignment table **/
      final ObjectMapper objectMapper = new ObjectMapper();
      try {
        if (assignment.getDisclosureTags() != null) {

          assignmentEntity.setDisclosureTags(objectMapper.writeValueAsString(assignment.getDisclosureTags()));
        }
      } catch (final JsonProcessingException e) {

        throw new CWBException(e.getMessage(), e);
      }
      assignmentEntity.setPercolateId(assignment.getPercolateId());
      assignmentEntity.setUserInitials(assignment.getUserInitials());
      assignmentEntity.setTemplateId(assignment.getTemplateId());
      assignmentEntity.setTemplateName(assignment.getTemplateName());
      assignmentEntity.setWorkfrontJobId(assignment.getWorkfrontJobId());
      assignmentEntity.setZeplinUrl(assignment.getZeplinUrl());
      assignmentEntity.setWipUrl(assignment.getWipUrl());
      assignmentEntity.setUpdatedAt(new Date());

      // Commenting out as a workaround because UI is unable to send the right values
      // assignmentEntity.setProofURL(assignment.getProofURL());
      // assignmentEntity.setProofFileId(assignment.getProofFileId());
      assignmentRepository.save(assignmentEntity);
    }

    /** Saving Assignment Copy details **/
    if (null != assignmentDetails.getCopy()) {
      for (final Field copyFields : assignmentDetails.getCopy()
                                                     .getFields()) {
        AssignmentContent content = null;
        content = assignmentContentRepository.getContent(assignmentId, copyFields.getFieldId(), 0);
        if (null == content) {
          content = new AssignmentContent();
        }
        content.setAssignmentId(assignmentId);
        content.setFieldId(copyFields.getFieldId());
        if (null != copyFields.getFieldValue() && !copyFields.getFieldValue()
                                                             .isEmpty()) {
          content.setFieldContent(copyFields.getFieldValue());
          assignmentContentRepository.save(content);
        } else {
          if (null != content.getId()) {
            assignmentContentRepository.delete(content);
          }
        }

      }
    }

    /** Saving Assignment Graphics Details **/
    if (null != assignmentDetails.getGraphics()) {
      for (final Graphics graphic : assignmentDetails.getGraphics()) {
        if (null != graphic.getGraphicsId() && !graphic.getGraphicsId()
                                                       .isEmpty()) {
          AssignmentContent content = null;
          final String referenceId = graphic.getGraphicsId();
          for (final Field field : graphic.getFields()) {
            content = assignmentContentRepository.getContent(assignmentId, field.getFieldId(), Integer.valueOf(
                referenceId));
            if (null == content) {
              content = new AssignmentContent();
            }
            content.setAssignmentId(assignmentId);
            content.setFieldId(field.getFieldId());
            content.setReferenceId(Integer.valueOf(referenceId));
            if (null != field.getFieldValue() && !field.getFieldValue()
                                                       .isEmpty()) {
              content.setFieldContent(field.getFieldValue());
              assignmentContentRepository.save(content);
            } else {
              if (null != content.getId()) {
                assignmentContentRepository.delete(content);
              }
            }
          }

        }
      }
    }

    /** Save Assignment Facebook Details **/
    if (null != assignmentDetails.getFacebook()) {
      saveAssignmentFacebook(assignmentDetails, assignmentId);
    }

    /** Save Assignment Twitter Details **/
    if (null != assignmentDetails.getTwitter()) {
      saveAssignmentTwitter(assignmentDetails, assignmentId);
    }

    /** Save Assignment LinkedIn Details **/
    if (null != assignmentDetails.getLinkedIn()) {
      saveAssignmentLinkedIn(assignmentDetails, assignmentId);
    }
    return getAssignmentDetails(percolateId);

  }

  /**
   * Method for saving assignment graphics
   */
  @Override
  public Integer saveAssignmentGraphics(final com.capgroup.digital.ce.cwb.model.entities.Graphics graphics) {
    final Integer graphicsId = graphicsRepository.getGraphicsId(graphics.getAssignmentId(), graphics
                                                                                                    .getGraphicLocation());
    if (null != graphicsId && graphicsId != 0) {
      /** If Graphic id is already available **/
      graphics.setId(graphicsId);
    }
    final com.capgroup.digital.ce.cwb.model.entities.Graphics savedGraphics = graphicsRepository.save(graphics);
    return savedGraphics.getId();
  }

  /**
   * Method for saving assignment facebook
   */
  @Override
  public void saveAssignmentFacebook(final AssignmentDetails assignmentDetails, final Integer assignmentId) {
    log.debug("Start Saving Facebook: " + assignmentId);

    final List<Facebook> facebookList = assignmentDetails.getFacebook();
    for (int i = 1; i < facebookList.size(); i++) {

      String referenceId = "";
      if (CWBConstants.SOCIAL_MEDIA_NEW_IDENTIFIER.equalsIgnoreCase(facebookList.get(i)
                                                                                .getStatus())) {

        final SocialMediaEntity socialMediaEntity = new SocialMediaEntity();
        referenceId = socialMedia.saveSocialMedia(assignmentId, CWBConstants.FACEBOOK_SECTION, socialMediaEntity)
                                 .toString();
      } else {

        referenceId = facebookList.get(i)
                                  .getFacebookId();
      }
      AssignmentContent linkedInContent;
      for (final Field field : facebookList.get(i)
                                           .getFields()) {
        linkedInContent = assignmentContentRepository.getContent(assignmentId, field.getFieldId(), Integer.valueOf(
            referenceId));
        if (null == linkedInContent) {
          linkedInContent = new AssignmentContent();
        }
        linkedInContent.setAssignmentId(assignmentId);
        linkedInContent.setFieldId(field.getFieldId());
        linkedInContent.setReferenceId(Integer.valueOf(referenceId));
        if (null != field.getFieldValue() && !field.getFieldValue()
                                                   .isEmpty()) {
          linkedInContent.setFieldContent(field.getFieldValue());
          assignmentContentRepository.save(linkedInContent);
        } else {
          if (null != linkedInContent.getId()) {
            assignmentContentRepository.delete(linkedInContent);

          }
        }
      }

    }
  }

  /**
   * Method for saving assignment twitter
   */
  @Override
  public void saveAssignmentTwitter(final AssignmentDetails assignmentDetails, final Integer assignmentId) {
    log.debug("Start Saving Twitter: " + assignmentId);
    final List<Twitter> twitterList = assignmentDetails.getTwitter();
    for (int i = 1; i < twitterList.size(); i++) {

      String referenceId = "";
      if (CWBConstants.SOCIAL_MEDIA_NEW_IDENTIFIER.equalsIgnoreCase(twitterList.get(i)
                                                                               .getStatus())) {

        final SocialMediaEntity socialMediaEntity = new SocialMediaEntity();
        referenceId = socialMedia.saveSocialMedia(assignmentId, CWBConstants.TWITTER_SECTION, socialMediaEntity)
                                 .toString();
      } else {

        referenceId = twitterList.get(i)
                                 .getTwitterId();
      }
      AssignmentContent linkedInContent;
      for (final Field field : twitterList.get(i)
                                          .getFields()) {
        linkedInContent = assignmentContentRepository.getContent(assignmentId, field.getFieldId(), Integer.valueOf(
            referenceId));
        if (null == linkedInContent) {
          linkedInContent = new AssignmentContent();
        }
        linkedInContent.setAssignmentId(assignmentId);
        linkedInContent.setFieldId(field.getFieldId());
        linkedInContent.setReferenceId(Integer.valueOf(referenceId));
        if (null != field.getFieldValue() && !field.getFieldValue()
                                                   .isEmpty()) {
          linkedInContent.setFieldContent(field.getFieldValue());
          assignmentContentRepository.save(linkedInContent);
        } else {
          if (null != linkedInContent.getId()) {
            assignmentContentRepository.delete(linkedInContent);

          }
        }
      }

    }
  }

  /**
   * Method for saving assignment linkedIn
   * 
   * @throws Exception
   */
  @Override
  public void saveAssignmentLinkedIn(final AssignmentDetails assignmentDetails, final Integer assignmentId)
      throws Exception {
    log.debug("Start Saving Linkedin: " + assignmentId);
    final List<LinkedIn> linkedinList = assignmentDetails.getLinkedIn();
    for (int i = 1; i < linkedinList.size(); i++) {

      String referenceId = "";
      if (CWBConstants.SOCIAL_MEDIA_NEW_IDENTIFIER.equalsIgnoreCase(linkedinList.get(i)
                                                                                .getStatus())) {

        final SocialMediaEntity socialMediaEntity = new SocialMediaEntity();
        referenceId = socialMedia.saveSocialMedia(assignmentId, CWBConstants.LINKEDIN_SECTION, socialMediaEntity)
                                 .toString();

      } else {

        referenceId = linkedinList.get(i)
                                  .getLinkedinId();
      }
      AssignmentContent linkedInContent;
      for (final Field field : linkedinList.get(i)
                                           .getFields()) {
        linkedInContent = assignmentContentRepository.getContent(assignmentId, field.getFieldId(), Integer.valueOf(
            referenceId));
        if (null == linkedInContent) {
          linkedInContent = new AssignmentContent();
        }
        linkedInContent.setAssignmentId(assignmentId);
        linkedInContent.setFieldId(field.getFieldId());
        linkedInContent.setReferenceId(Integer.valueOf(referenceId));
        if (null != field.getFieldValue() && !field.getFieldValue()
                                                   .isEmpty()) {
          linkedInContent.setFieldContent(field.getFieldValue());
          assignmentContentRepository.save(linkedInContent);
        } else {
          if (null != linkedInContent.getId()) {
            assignmentContentRepository.delete(linkedInContent);
          }
        }
      }
    }
  }

  @Override
  public AssignmentDetails getAssignmentDetails(final String percolateId) {

    final AssignmentEntity assignmentEntity = assignmentRepository.getAssignment(percolateId);

    if (!StringUtils.isEmpty(assignmentEntity)) {
      final Assignment assignment = new Assignment();
      assignment.setId(assignmentEntity.getId());
      assignment.setAssignmentName(assignmentEntity.getAssignmentName());

      assignment.setPercolateId(assignmentEntity.getPercolateId());
      assignment.setDisclosureTags(getDisclosureTags(assignmentEntity));

      assignment.setUserInitials(assignmentEntity.getUserInitials());
      assignment.setTemplateId(assignmentEntity.getTemplateId());
      assignment.setTemplateName(assignmentEntity.getTemplateName());
      assignment.setWorkfrontJobId(assignmentEntity.getWorkfrontJobId());
      assignment.setProofURL(assignmentEntity.getProofURL());
      assignment.setProofFileId(assignmentEntity.getProofFileId());
      assignment.setUpdatedAt(assignmentEntity.getUpdatedAt()
                                              .toString());
      assignment.setCollaborators(fetchAssignmentCollaborators(assignmentEntity.getId(), assignmentEntity.getUserInitials()));
//      assignment.setWorkfrontDocId(assignmentEntity.getWorkfrontDocId());
      assignment.setZeplinUrl(assignmentEntity.getZeplinUrl());
      assignment.setWipUrl(assignmentEntity.getWipUrl());
      log.debug("Assignment updated date: " + assignmentEntity.getUpdatedAt()
                                                              .toString());
      final AssignmentDetails assignmentDetails = new AssignmentDetails();

      assignmentDetails.setAssignment(assignment);
      assignmentDetails.setCopy(getCopyDetails(assignment));

      assignmentDetails.setGraphics(getGraphicsDetails(assignment));
      assignmentDetails.setTwitter(getTwitterDetails(assignment));
      assignmentDetails.setLinkedIn(getLinkedInDetails(assignment));
      assignmentDetails.setFacebook(getFacebookDetails(assignment));
      assignmentDetails.setBackups(getBackupDetails(assignment));

      return assignmentDetails;

    } else {
      throw new CWBException("Please provide appropriate percolate id, percolateId=" + percolateId);
    }
  }
  
  /**
   * Method for getting all the regular (NOT unlinked/draft) assignments
   * 
   * @return
   */
  @Override
  public List<Assignment> getAssignments(String userInitials) {
    final List<AssignmentEntity> assignmentEntities = assignmentRepository.findByStatusIsNullAndUserInitials(userInitials.toUpperCase());

    if (!assignmentEntities.isEmpty()) {
      log.debug("Found " + assignmentEntities.size() + " assignment(s)");
      return assignmentEntities.stream()
                               .map(assignmentEntity -> {
                                 Assignment assignment = new Assignment();
                                 assignment.setAssignmentName(assignmentEntity.getAssignmentName());
                                 assignment.setPercolateId(assignmentEntity.getPercolateId());
                                 assignment.setUpdatedAt(assignmentEntity.getUpdatedAt()
                                                                         .toString());
                                 return assignment;
                               })
                               .collect(Collectors.toList());
    } else {
      log.debug("No assignments found for user: " + userInitials);
      return Collections.emptyList();
    }
  }
  
  
  /**
   * Method for getting all the unlinked/draft assignments 
   * 
   * @return 
   */
  @Override
  public List<DraftAssignment> getUnlinkedAssignments(String userInitials) {

    final List<AssignmentEntity> assignmentEntities = assignmentRepository.findByStatusAndUserInitials(CWBConstants.STATUS_UNLINKED, userInitials.toUpperCase());

    if (!assignmentEntities.isEmpty()) {
    	log.debug("Found " + assignmentEntities.size() +" " + CWBConstants.STATUS_UNLINKED + " assignment(s)");
    	return  assignmentEntities.stream().map( assignmentEntity -> {	DraftAssignment draftAssignment = new DraftAssignment();
																																    	draftAssignment.setId(assignmentEntity.getPercolateId());
																																    	draftAssignment.setName(assignmentEntity.getAssignmentName());
																																    	draftAssignment.setTemplate(assignmentEntity.getTemplateName());
																																    	draftAssignment.setCreatedAt(assignmentEntity.getCreatedAt().toString());
																																    	draftAssignment.setUpdatedAt(assignmentEntity.getUpdatedAt().toString());
																																   		return draftAssignment;})
    										.collect(Collectors.toList());    														
    }
    else {
    	log.debug("No "+ CWBConstants.STATUS_UNLINKED + " assignments found for user: " + userInitials);
      return Collections.emptyList(); 
    }
  }
  
  /**
   * Method to fetch unlinked/draft assignment details
   * @param percolateId
   * @return 
   */
	@Override
	public DraftAssignment getUnlinkedAssignmentsDetails(String percolateId) {
		AssignmentEntity assignmentEntity = assignmentRepository.getAssignment(percolateId);
		DraftAssignment draftAssignment = new DraftAssignment();
		
		draftAssignment.setId(percolateId);
		draftAssignment.setName(assignmentEntity.getAssignmentName());
		draftAssignment.setTemplate(assignmentEntity.getTemplateName());
		draftAssignment.setCreatedAt(assignmentEntity.getCreatedAt().toString());
		
		return draftAssignment;
	}

  /**
   * Method for getting the list of collaborators in assignment 
   * 
   * @param assignmentId
   * @param userInitials
   * @return 
   */
  private List<Collaborators> fetchAssignmentCollaborators(Integer assignmentId, String userInitials) {
	
	List<String> collaboratorsInitials = new ArrayList<>();
	List<Comments> comments = commentRepository.findByAssignmentId(assignmentId);
	
	log.debug("Fetching assignment collaborators...");
	
	//fetch the initials of the people this assignment has been shared with 
	if(!comments.isEmpty()) {
		collaboratorsInitials = comments.stream()
								.map(comment -> comment.getCommentValue().replace("@", "").replace("capgroup.com", "").toUpperCase().trim())
								.collect(Collectors.toList());
	}
	
	//add the writer himself (logged in user in cwb)
	collaboratorsInitials.add(userInitials.trim());
	
	//use the collaborator's initials to fetch his/her EmailId from the user repository 
	return collaboratorsInitials.stream()
															.map(collaboratorInitial -> {
																	  	Optional<Users> user = userRepository.findByUserInitials(collaboratorInitial);
																	  	Collaborators collab = null;
																  		if(user.isPresent()) {
																  			Users retrievedUser = user.get();
																  			collab = new Collaborators();
																  			collab.setEmailId(retrievedUser.getEmail());
																  			collab.setUserInitials(retrievedUser.getUserInitials());
																  			return collab;
																  		}
																  		return collab;
																		})
																  .collect(Collectors.toList());
	
  }

  /**
   * Method for getting the disclosure tags
   * 
   * @param assignmentEntity
   * @return
   */
  @Override
  public List<DisclosureTags> getDisclosureTags(final AssignmentEntity assignmentEntity) {

    final String disclosureTags = assignmentEntity.getDisclosureTags();
    final ObjectMapper mapper = new ObjectMapper();
    DisclosureTagList disclosureTagList = new DisclosureTagList();
    if (disclosureTags != null) {
      try {

        disclosureTagList = mapper.readValue(disclosureTags, DisclosureTagList.class);
      } catch (final IOException e) {
        throw new CWBException("Exception in getDisclosureTags: " + e.getMessage(), e);
      }
    }
    return disclosureTagList;
  }

  @Override
  public void saveProofDetails(final String percolateId, final ProofDetails proof) {
    final AssignmentEntity assignment = Optional.ofNullable(assignmentRepository.getAssignment(percolateId))
                                                .orElseThrow(() -> new CWBException("Assignment " + percolateId
                                                    + " doesn't exist"));
    assignment.setProofFileId(proof.getFileId());
    assignment.setProofURL(proof.getProofUrl());
    assignmentRepository.save(assignment);
  }
  
  @Override
  public void saveWorkfrontDetails(final String percolateId, final WorkfrontDetails workfrontDetails) {
    final AssignmentEntity assignment = Optional.ofNullable(assignmentRepository.getAssignment(percolateId))
                                                .orElseThrow(() -> new CWBException("Assignment " + percolateId
                                                    + " doesn't exist"));
//    assignment.setWorkfrontDocId(workfrontDetails.getWorkfrontDocId());
    assignmentRepository.save(assignment);
  }

  /**
   * Method for getting the copy fragment details
   * 
   * @param assignment
   * @return
   */
  private Copy getCopyDetails(final Assignment assignment) {

    final List<BigDecimal> copyFieldList = templateDetailsRepository.getTemplateFields(assignment.getTemplateId(),
        CWBConstants.COPY_SECTION);
    final Copy copyDetails = new Copy();
    final List<Field> copyFieldsToSetList = new ArrayList<>();
    for (final BigDecimal fieldId : copyFieldList) {
      final Fields field = fieldRepository.getWriteFields(fieldId);
      String fieldValue = CWBConstants.EMPTY_STRING;
      final Clob clob = assignmentContentRepository.getContentValue(assignment.getId(), fieldId.intValue(), 0);
      try {
        if (clob != null) {
          fieldValue = clob.getSubString(1, (int) clob.length());
        }
      } catch (final SQLException ex) {
        throw new CWBException("SQL Exception when accessing Field Content for assignmentId:" + assignment.getId()
            + ", FieldId: " + fieldId);
      }
      final Field copyField = generateCopyFieldDetails(field, fieldValue);
      copyFieldsToSetList.add(copyField);
    }

    copyDetails.setFields(copyFieldsToSetList);
    return copyDetails;

  }

  private Field generateCopyFieldDetails(final Fields field, final String fieldValue) {
    final Field copyField = new Field();
    copyField.setFieldId(field.getId());
    copyField.setFieldValue(fieldValue);
    copyField.setFieldName(field.getFieldLabel());
    copyField.setProperties(generatePropertiesDetails(field));
    return copyField;
  }

  private List<Graphics> getGraphicsDetails(final Assignment assignment) {

    final List<BigDecimal> graphicFieldList = templateDetailsRepository.getTemplateFields(assignment.getTemplateId(),
        CWBConstants.GRAPHICS_SECTION);
    final List<Graphics> graphicDetails = new ArrayList<>();
    /** Generate Graphic Templates **/

    if (Integer.parseInt(graphicsRepository.checkGraphicsExist(assignment.getId())) > 0) {
      final List<com.capgroup.digital.ce.cwb.model.entities.Graphics> graphicsList = graphicsRepository.getGraphics(
          assignment.getId());
      for (final com.capgroup.digital.ce.cwb.model.entities.Graphics graphicItem : graphicsList) {

        final Graphics graphics = new Graphics();
        graphics.setGraphicsId(String.valueOf(graphicItem.getId()));
        graphics.setName(graphicItem.getGraphicName());
        graphics.setLocation(graphicItem.getGraphicLocation());
        graphics.setShortCode(graphicItem.getGraphicShortCode());
        graphics.setFields(getFieldDetails(graphicFieldList, assignment.getId(), graphicItem.getId()));

        graphicDetails.add(graphics);
      }
    }
    Collections.sort(graphicDetails, new SortGraphics());
    graphicDetails.add(0, generateGraphicsTemplate(graphicFieldList));
    return graphicDetails;
  }

  private Graphics generateGraphicsTemplate(final List<BigDecimal> graphicFieldList) {
    final Graphics graphics = new Graphics();
    graphics.setGraphicsId(CWBConstants.EMPTY_STRING);
    graphics.setName(CWBConstants.EMPTY_STRING);
    graphics.setLocation(CWBConstants.EMPTY_STRING);
    graphics.setShortCode(CWBConstants.EMPTY_STRING);
    final List<Field> fieldDetails = new ArrayList<>();
    for (final BigDecimal fieldId : graphicFieldList) {
      final Fields field = fieldRepository.getWriteFields(fieldId);
      final Field fieldDetail = new Field();
      fieldDetail.setFieldId(field.getId());
      fieldDetail.setFieldName(field.getFieldLabel());

      /* Adding Default value in template for Is Photo field */
      if (field.getFieldLabel()
               .equalsIgnoreCase(CWBConstants.IS_PHOTO)) {

        fieldDetail.setFieldValue("true");
      } else {

        fieldDetail.setFieldValue(CWBConstants.EMPTY_STRING);
      }
      fieldDetail.setProperties(generatePropertiesDetails(field));
      fieldDetails.add(fieldDetail);
    }
    graphics.setFields(fieldDetails);
    return graphics;
  }

  private List<Facebook> getFacebookDetails(final Assignment assignment) {

    final List<BigDecimal> facebookFieldList = templateDetailsRepository.getTemplateFields(assignment.getTemplateId(),
        CWBConstants.FACEBOOK_SECTION);
    final List<Facebook> facebookDetails = new ArrayList<>();
    if (!facebookFieldList.isEmpty()) {

      /** Generate Facebook Templates **/

      final List<SocialMediaEntity> socialMediaList = socialMediaRepository.getSocialMediaItems(assignment.getId(),
          CWBConstants.FACEBOOK_SECTION);

      for (final SocialMediaEntity socialMediaItem : socialMediaList) {

        final Facebook facebook = new Facebook();
        facebook.setFacebookId(String.valueOf(socialMediaItem.getId()));
        facebook.setName(socialMediaItem.getMediaFileName());
        facebook.setFields(getFieldDetails(facebookFieldList, assignment.getId(), socialMediaItem.getId()));

        facebookDetails.add(facebook);
      }
      Collections.sort(facebookDetails, new SortFacebook());
      facebookDetails.add(0, generateFacebookTemplate(facebookFieldList));
    }
    return facebookDetails;
  }

  private Facebook generateFacebookTemplate(final List<BigDecimal> facebookFieldList) {

    final Facebook facebook = new Facebook();
    facebook.setFacebookId(CWBConstants.EMPTY_STRING);
    facebook.setName(CWBConstants.EMPTY_STRING);
    final List<Field> fieldDetails = new ArrayList<>();
    for (final BigDecimal fieldId : facebookFieldList) {
      final Fields field = fieldRepository.getWriteFields(fieldId);
      final Field fieldDetail = new Field();
      fieldDetail.setFieldId(field.getId());
      fieldDetail.setFieldName(field.getFieldLabel());
      fieldDetail.setFieldValue(CWBConstants.EMPTY_STRING);

      fieldDetail.setProperties(generatePropertiesDetails(field));
      fieldDetails.add(fieldDetail);
    }
    facebook.setFields(fieldDetails);
    return facebook;
  }

  private List<LinkedIn> getLinkedInDetails(final Assignment assignment) {

    final List<BigDecimal> linkedInFieldList = templateDetailsRepository.getTemplateFields(assignment.getTemplateId(),
        CWBConstants.LINKEDIN_SECTION);
    final List<LinkedIn> linkedInDetails = new ArrayList<>();
    if (!linkedInFieldList.isEmpty()) {

      /** Generate linkedIn Templates **/

      final List<SocialMediaEntity> socialMediaList = socialMediaRepository.getSocialMediaItems(assignment.getId(),
          CWBConstants.LINKEDIN_SECTION);

      for (final SocialMediaEntity socialMediaItem : socialMediaList) {

        final LinkedIn linkedIn = new LinkedIn();
        linkedIn.setLinkedinId(String.valueOf(socialMediaItem.getId()));
        linkedIn.setName(socialMediaItem.getMediaFileName());
        linkedIn.setFields(getFieldDetails(linkedInFieldList, assignment.getId(), socialMediaItem.getId()));

        linkedInDetails.add(linkedIn);
      }
      Collections.sort(linkedInDetails, new SortLinkedIn());
      linkedInDetails.add(0, generateLinkedInTemplate(linkedInFieldList));
    }
    return linkedInDetails;
  }

  private LinkedIn generateLinkedInTemplate(final List<BigDecimal> linkedInFieldList) {

    final LinkedIn linkedIn = new LinkedIn();
    linkedIn.setLinkedinId(CWBConstants.EMPTY_STRING);
    linkedIn.setName(CWBConstants.EMPTY_STRING);
    final List<Field> fieldDetails = new ArrayList<>();
    for (final BigDecimal fieldId : linkedInFieldList) {
      final Fields field = fieldRepository.getWriteFields(fieldId);
      final Field fieldDetail = new Field();
      fieldDetail.setFieldId(field.getId());
      fieldDetail.setFieldName(field.getFieldLabel());
      fieldDetail.setFieldValue(CWBConstants.EMPTY_STRING);

      fieldDetail.setProperties(generatePropertiesDetails(field));
      fieldDetails.add(fieldDetail);
    }
    linkedIn.setFields(fieldDetails);
    return linkedIn;
  }

  private List<Twitter> getTwitterDetails(final Assignment assignment) {

    final List<BigDecimal> twitterFieldList = templateDetailsRepository.getTemplateFields(assignment.getTemplateId(),
        CWBConstants.TWITTER_SECTION);
    final List<Twitter> twitterDetails = new ArrayList<>();
    if (!twitterFieldList.isEmpty()) {

      /** Generate Twitter Templates **/

      final List<SocialMediaEntity> socialMediaList = socialMediaRepository.getSocialMediaItems(assignment.getId(),
          CWBConstants.TWITTER_SECTION);
      for (final SocialMediaEntity socialMediaItem : socialMediaList) {

        final Twitter twitter = new Twitter();
        twitter.setTwitterId(String.valueOf(socialMediaItem.getId()));
        twitter.setName(socialMediaItem.getMediaFileName());
        twitter.setFields(getFieldDetails(twitterFieldList, assignment.getId(), socialMediaItem.getId()));

        twitterDetails.add(twitter);
      }
      Collections.sort(twitterDetails, new SortTwitter());
      twitterDetails.add(0, generateTwitterTemplate(twitterFieldList));
    }
    return twitterDetails;
  }

  private Twitter generateTwitterTemplate(final List<BigDecimal> twitterFieldList) {

    final Twitter twitter = new Twitter();
    twitter.setTwitterId(CWBConstants.EMPTY_STRING);
    twitter.setName(CWBConstants.EMPTY_STRING);
    final List<Field> fieldDetails = new ArrayList<>();
    for (final BigDecimal fieldId : twitterFieldList) {
      final Fields field = fieldRepository.getWriteFields(fieldId);
      final Field fieldDetail = new Field();
      fieldDetail.setFieldId(field.getId());
      fieldDetail.setFieldName(field.getFieldLabel());
      fieldDetail.setFieldValue(CWBConstants.EMPTY_STRING);

      fieldDetail.setProperties(generatePropertiesDetails(field));
      fieldDetails.add(fieldDetail);
    }
    twitter.setFields(fieldDetails);
    return twitter;
  }

  private List<Field> getFieldDetails(final List<BigDecimal> fieldList, final long assignmentId,
      final int referenceId) {
    final List<Field> fieldDetails = new ArrayList<>();
    for (final BigDecimal fieldId : fieldList) {
      String fieldValue = CWBConstants.EMPTY_STRING;
      if (Integer.parseInt(assignmentContentRepository.checkContentExist(assignmentId, fieldId.intValue(),
          referenceId)) > 0) {
        final Clob clob = assignmentContentRepository.getContentValue(assignmentId, fieldId.intValue(), referenceId);
        try {
          fieldValue = clob.getSubString(1, (int) clob.length());
        } catch (final SQLException e) {
          throw new CWBException("SQL Exception when accessing Field Content for assignmentId:" + assignmentId
              + ", FieldId: " + fieldId + ", referenceId: " + referenceId);
        }
      }
      fieldDetails.add(generateFieldDetails(fieldRepository.getWriteFields(fieldId), fieldValue));
    }
    return fieldDetails;
  }

  private Field generateFieldDetails(final Fields field, final String fieldValue) {
    final Field fieldDetails = new Field();
    fieldDetails.setFieldId(field.getId());
    fieldDetails.setFieldValue(fieldValue);
    fieldDetails.setFieldName(field.getFieldLabel());
    fieldDetails.setProperties(generatePropertiesDetails(field));
    return fieldDetails;
  }

  private Properties generatePropertiesDetails(final Fields field) {

    final Properties properties = new Properties();
    properties.setFieldType(field.getFieldType());
    properties.setMinLength(field.getMinLength());
    properties.setMaxLength(field.getMaxLength());
    properties.setFieldHelperText(field.getHelperText());
    return properties;

  }

  private List<Backup> getBackupDetails(final Assignment assignment) {

    final List<Backup> backupDetails = new ArrayList<>();
    if (Integer.parseInt(backupsRepository.checkBackupsExist(assignment.getId())) > 0) {
      final List<Backups> backupsList = backupsRepository.getBackups(assignment.getId());
      for (final Backups backupsItem : backupsList) {
        final Backup backup = new Backup();
        backup.setBackupId(String.valueOf(backupsItem.getId()));
        backup.setName(backupsItem.getBackupName());
        backup.setLocation(backupsItem.getBackupLocation());
        backupDetails.add(backup);
      }
    }
    Collections.sort(backupDetails, new SortBackups());
    backupDetails.add(0, generateBackupTemplate());
    return backupDetails;
  }

  private Backup generateBackupTemplate() {
    final Backup backup = new Backup();
    backup.setBackupId(CWBConstants.EMPTY_STRING);
    backup.setName(CWBConstants.EMPTY_STRING);
    backup.setLocation(CWBConstants.EMPTY_STRING);
    return backup;
  }
  
  //Method to fetch all the template names from cwb templates repository 
  @Override
  public ResponseEntity<List<TemplatesResponse>> fetchTemplates() {
  	List<TemplatesResponse> templates;
  	templates = templateRepository.findAll().stream()
  												.map(template -> {TemplatesResponse templatesResponse = new TemplatesResponse();
					  												templatesResponse.setTemplateName(template.getTemplateName());
					  												return templatesResponse;})
  												.collect(Collectors.toList());  	
	
  	return new ResponseEntity<>(templates,HttpStatus.OK);
  }
  
  /**
   * Method to link an UNLINKED assignment(with draftId) to an assignment with a real percolateId
   * 
   * @param assignmentId
   * @param userInitials
   * @return 
   */
  @Override
  public void link(final LinkRequest linkRequest) {
  	
  	String draftId = linkRequest.getDraftId(); //dummyId of draft assignment
  	String percolateId = linkRequest.getPercolateId();  //real percolateId of actual assignment you want to link/merge with
  	
  	log.debug("Linking UNLINKED assignment("+ draftId +") with real assignment("+percolateId+")...");																																																															
																																																															
  	AssignmentEntity unLinkedAssignment = assignmentRepository.findByStatusAndPercolateId(CWBConstants.STATUS_UNLINKED, draftId);  	
  	if (unLinkedAssignment == null) {
  		throw new CWBException("Assignment with percolateId: " + draftId + "  either does not exist or is not a 'DRAFT' assignment");
  	}
  	
  	AssignmentEntity actualAssignment = assignmentRepository.findByStatusAndPercolateId(null, percolateId);
		if (actualAssignment != null) {
			log.debug(" Assignment with percolate id =" + percolateId + " exist in CWB database");
			actualAssignment.setPercolateId(draftId + CWBConstants.POST_DELETED);
			actualAssignment.setStatus(CWBConstants.STATUS_DELETED);
			assignmentRepository.save(actualAssignment);
		} 

		//replace the draftId with the given (real) percolateId and set the status to null (this is the actual linking)		
		unLinkedAssignment.setPercolateId(percolateId);
		unLinkedAssignment.setStatus(null);
		unLinkedAssignment.setAssignmentName(linkRequest.getAssignmentName());
		assignmentRepository.save(unLinkedAssignment);		
		
  	log.debug("Assignments linked sucessfully");
				
  }
  
  /**
   * Method to DELETE a draft assignment 
   * 
   * @param draftId 
   */
	@Override
	@Modifying
	@Transactional
	public void deleteDraftAssignment(final String draftId) {
		
		Integer assignmentId = assignmentRepository.getAssignmentId(draftId);
		String status = assignmentRepository.getStatus(draftId);		
		log.debug("Deleting draft assignment with draftId: " + draftId + " and status: " + status);
		
		if(assignmentId != null && status != null) {			
			commentRepository.deleteByAssignmentId(assignmentId);
			backupsRepository.deleteByAssignmentId(assignmentId);			
			graphicsRepository.deleteByAssignmentId(assignmentId);			
			assignmentContentRepository.deleteByAssignmentId(assignmentId);			
			assignmentRepository.deleteById(assignmentId);		
		}
		else {
			throw new CWBException("This draft assignment doesn't exist");

		}  
	}
  
  class SortGraphics implements Comparator<Graphics> {

    @Override
    public int compare(final Graphics a, final Graphics b) {
      return Integer.parseInt(a.getGraphicsId()) - Integer.parseInt(b.getGraphicsId());
    }
  }

  class SortBackups implements Comparator<Backup> {

    @Override
    public int compare(final Backup a, final Backup b) {
      return Integer.parseInt(a.getBackupId()) - Integer.parseInt(b.getBackupId());
    }
  }

  class SortFacebook implements Comparator<Facebook> {

    @Override
    public int compare(final Facebook a, final Facebook b) {
      return Integer.parseInt(a.getFacebookId()) - Integer.parseInt(b.getFacebookId());
    }
  }

  class SortTwitter implements Comparator<Twitter> {

    @Override
    public int compare(final Twitter a, final Twitter b) {
      return Integer.parseInt(a.getTwitterId()) - Integer.parseInt(b.getTwitterId());
    }
  }

  class SortLinkedIn implements Comparator<LinkedIn> {

    @Override
    public int compare(final LinkedIn a, final LinkedIn b) {
      return Integer.parseInt(a.getLinkedinId()) - Integer.parseInt(b.getLinkedinId());
    }
  }

}
