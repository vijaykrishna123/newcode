package com.capgroup.digital.ce.cwb.services.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.amazonaws.services.s3.model.S3Object;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.entities.Backups;
import com.capgroup.digital.ce.cwb.repositories.AssignmentsRepository;
import com.capgroup.digital.ce.cwb.repositories.BackupsRepository;
import com.capgroup.digital.ce.cwb.services.IAssignments;
import com.capgroup.digital.ce.cwb.services.IBackups;
import com.capgroup.digital.ce.cwb.services.IS3Uploader;

@Service
public class BackupService implements IBackups {

  @Autowired
  private IS3Uploader s3Uploader;

  @Autowired
  private BackupsRepository backupRepository;

  @Autowired
  private AssignmentsRepository assignmentRepository;

  @Autowired
  private IAssignments assignments;

  private final Logger log = LogManager.getLogger(BackupService.class);

  /**
   * Method To retrieve Backup file from S3
   * 
   * @throws Exception
   */
  @Override
  public ResponseEntity<InputStreamResource> getBackup(Integer backupId) throws Exception {

    JSONObject errorJson = new JSONObject();
    String backupLocation = "";
    String backupName = "";
    Backups backups;
    S3Object backupS3Object = null;

    if (backupId != null) {
      try {

        // Get Backup File Path
        backups = backupRepository.findById(backupId);

        if (backups != null) {

          backupLocation = backups.getBackupLocation();
          log.debug("****File backupLocation: " + backupLocation);

          // Get Backup Object
          if (!backupLocation.isEmpty()) {

            backupS3Object = s3Uploader.downloadFile(backupLocation);
            backupName = backups.getBackupName();
          }
        }
        if (backupS3Object != null && backupS3Object.getObjectMetadata()
                                                    .getContentLength() > 0) {

          // Send Response as Input Stream Resource
          log.debug("******** Content Length*****" + backupS3Object.getObjectMetadata()
                                                                   .getContentLength());
          InputStream objectInputStream = backupS3Object.getObjectContent();
          InputStreamResource objectStreamResource = new InputStreamResource(objectInputStream);
          HttpHeaders respHeaders = new HttpHeaders();
          String contentType = "";

          contentType = backupS3Object.getObjectMetadata()
                                      .getContentType();
          log.debug("****File Content Type: " + contentType);

          respHeaders.setContentType(MediaType.parseMediaType(contentType));
          respHeaders.setContentLength(backupS3Object.getObjectMetadata()
                                                     .getContentLength());
          respHeaders.setContentDispositionFormData("attachment", backupName);

          log.debug("******Response Headers set");

          return new ResponseEntity<>(objectStreamResource, respHeaders, HttpStatus.OK);

        } else {

          // Send Response as File not found
          log.debug("****** File Not found: " + backupId);
          throw new CWBException("File Not found for FileId: " + backupId + " Check with System Administrator");

        }
      } catch (Exception e) {
        log.error("****** Internal Server Error,Please contact Administrator: " + e.getMessage());
        errorJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        errorJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        HttpHeaders respHeaders = new HttpHeaders();
        InputStream objectInputStream = new ByteArrayInputStream(errorJson.toString()
                                                                          .getBytes());
        InputStreamResource objectStreamResource = new InputStreamResource(objectInputStream);
        return new ResponseEntity<>(objectStreamResource, respHeaders, HttpStatus.BAD_REQUEST);
      }
    } else {

      log.error("****** No FileId present");
      errorJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      errorJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "No FileId present");
      HttpHeaders respHeaders = new HttpHeaders();
      InputStream objectInputStream = new ByteArrayInputStream(errorJson.toString()
                                                                        .getBytes());
      InputStreamResource objectStreamResource = new InputStreamResource(objectInputStream);
      return new ResponseEntity<>(objectStreamResource, respHeaders, HttpStatus.BAD_REQUEST);
    }

  }


  /**
   * Method To save Backup file to S3
   * 
   * @throws Exception
   * 
   */
  @Override
  public ResponseEntity<String> saveBackup(MultipartFile file, String postId, String userId) throws Exception {

    Integer assignmentId;
    JSONObject responseJson = new JSONObject();

    if (!file.isEmpty() && !postId.isEmpty() && !userId.isEmpty()) {
      try {

        String backupLocation = "";

        // Get Assignment Id
        log.debug("**** postId: ****" + postId);
        assignmentId = assignmentRepository.getAssignmentId(postId);
        log.debug("**** assignmentId: ****" + assignmentId);
        if (assignmentId != null) {

          // Upload Backup File to S3
          backupLocation = s3Uploader.uploadFile(file, postId, userId, CWBConstants.BACKUP_SECTION);

          if (!backupLocation.isEmpty()) {

            // Save Backup metadata to DB

            Backups backups = new Backups();
            backups.setAssignmentId(assignmentId);
            backups.setBackupLocation(backupLocation);
            backups.setBackupName(file.getOriginalFilename());

            Integer backupId = backupRepository.save(backups).getId();

            log.debug("**** backup DB location: ****" + backupLocation);
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
            responseJson.put("BackupId", backupId);
            responseJson.put("BackupName", file.getOriginalFilename());
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);
          } else {

            log.debug("**** Error While Uploading File ****");
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
            responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE,
                "Error While Uploading File,Please contact Administrator");
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
          }
        } else {

          log.debug("**** You failed to upload because Assignment id not found ****");
          throw new CWBException("You failed to upload because Assignment id not found");
        }

      } catch (Exception e) {

        log.error("**** Internal Server Error,Please contact Administrator ****" + e.getMessage());
        responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
      }
    } else {

      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "You failed to upload because the file was empty.");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }

  }

  /**
   * Method To delete Backup file from S3
   * 
   * @throws Exception
   */
  @Override
  public ResponseEntity<String> deleteBackup(Integer backupId) throws Exception {

    JSONObject responseJson = new JSONObject();
    Backups backups = new Backups();
    try {

      // Get Backup File Path
      backups = backupRepository.findById(backupId);
      if (backups != null) {

        // Delete Backup file from S3
        if (s3Uploader.deleteFile(backups.getBackupLocation())) {

          // Delete Backup file from DB
          backupRepository.delete(backups);
          responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
          responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "File Deleted Successfully");
          responseJson.put("Backupid", backupId);
          return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);

        } else {

          log.debug("**** Error While Deleting file in Server ****");
          responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
          responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "File Deletion Unsuccessful");
          responseJson.put("Backupid", backupId);
          return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
        }
      } else {

        log.debug("**** File not found in Database ****");
        throw new CWBException("File not found in Database");
      }
    } catch (Exception e) {

      log.error("**** Internal Server Error,Please contact Administrator ****" + e.getMessage());
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }

  }

  /**
   * Method To update Backup file in S3
   * 
   * @throws Exception
   */
  @Override
  public ResponseEntity<String> updateBackup(MultipartFile file, Integer backupId, String postId, String userId)
      throws Exception {

    Backups backups;
    JSONObject responseJson = new JSONObject();
    String existingFileName = "";

    if (!file.isEmpty() && backupId != null) {
      try {

        String backupLocation = "";
        log.debug("**** BackupId: ****" + backupId);

        // Get Backup File Path
        backups = backupRepository.findById(backupId);

        if (backups != null) {

          existingFileName = backups.getBackupName();
          if (!file.getOriginalFilename()
                   .equals(existingFileName)) {

            // Delete existing Backup file from S3
            s3Uploader.deleteFile(backups.getBackupLocation());
            log.debug("**** Existing backup file Deleted Successfully from S3 ****");
          }

          // Upload new Backup File to S3
          backupLocation = s3Uploader.uploadFile(file, postId, userId, CWBConstants.BACKUP_SECTION);

          if (!backupLocation.isEmpty()) {

            // Update Backup metadata to DB

            backups.setBackupLocation(backupLocation);
            backups.setBackupName(file.getOriginalFilename());
            backupRepository.save(backups);

            log.debug("**** backup DB location: ****" + backupLocation);
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
            responseJson.put("BackupId", backupId);
            responseJson.put("BackupName", file.getOriginalFilename());
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);
          } else {

            log.debug("**** Error While Uploading File ****");
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
            responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE,
                "Error While Uploading File,Please contact Administrator");
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
          }

        } else {

          log.debug("**** You failed to upload because Backup Id is not valid ****");
          throw new CWBException("You failed to upload because Backup Id is not valid");

        }

      } catch (Exception e) {

        log.error("**** Internal Server Error,Please contact Administrator ****" + e.getMessage());
        responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
      }
    } else {

      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "You failed to upload because the file was empty.");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }

  }

}
