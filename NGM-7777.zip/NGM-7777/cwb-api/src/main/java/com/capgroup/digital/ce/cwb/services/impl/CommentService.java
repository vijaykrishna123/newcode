package com.capgroup.digital.ce.cwb.services.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.common.CWBConstants.PURPOSE;
import com.capgroup.digital.ce.cwb.model.CommentsRequest;
import com.capgroup.digital.ce.cwb.model.CommentsResponse;
import com.capgroup.digital.ce.cwb.model.RelatedComment;
import com.capgroup.digital.ce.cwb.model.entities.AssignmentEntity;
import com.capgroup.digital.ce.cwb.model.entities.Comments;
import com.capgroup.digital.ce.cwb.repositories.AssignmentsRepository;
import com.capgroup.digital.ce.cwb.repositories.CommentRepository;
import com.capgroup.digital.ce.cwb.services.IComments;
import com.capgroup.digital.ce.cwb.utils.ParseComments;


@Service
public class CommentService implements IComments {


  private final Logger log = LogManager.getLogger(CommentService.class);

  private final CommentRepository commentsRepository;

  private final AssignmentsRepository assignmentRepository;

  private final ParseComments parseComment;

  @Autowired
  public CommentService(final CommentRepository commentsRepository, final AssignmentsRepository assignmentRepository,
      final ParseComments parseComment) {
    super();
    this.commentsRepository = commentsRepository;
    this.assignmentRepository = assignmentRepository;
    this.parseComment = parseComment;
  }


  /**
   * Method To save comments
   *
   */
  @Override
  public ResponseEntity<String> createComments(final CommentsRequest commentRequest, final String host, final String purpose) {

	final String assignmentStatus = assignmentRepository.getStatus(commentRequest.getPercolateId());
    final Integer assignmentId = assignmentRepository.getAssignmentId(commentRequest.getPercolateId());
    log.debug("**** assignmentId: ****" + assignmentId);
    final Comments commentsEntity = new Comments();
    commentsEntity.setAssignmentId(assignmentId);
    commentsEntity.setCommentStatus(commentRequest.getCommentStatus());
    commentsEntity.setCommentValue(commentRequest.getCommentValue());
    commentsEntity.setReplyId(commentRequest.getReplyToId());
    commentsEntity.setUserInitials(commentRequest.getUserInitials());
    
    //check if user owns assignment 
    boolean isOwnedByUser = assignmentRepository.existsByUserInitialsAndPercolateId(commentRequest.getCommentValue().replace("@", "").trim().toUpperCase(), commentRequest.getPercolateId());
    
    //we only want to create an entry in the comments (sharing) table in the database if the purpose is to SHARE the assignment
    if(isOwnedByUser || !purpose.equalsIgnoreCase(PURPOSE.SHARE.toString())){
    	parseComment.processComment(commentRequest, host, purpose, assignmentStatus );
        return new ResponseEntity<>(HttpStatus.OK); 
    } else {
    	//check if user is already collaborating on assignment 
	    long comments = commentsRepository.countByCommentValueAndAssignmentId(commentRequest.getCommentValue(), assignmentId);
	    if(comments == 0 ) { 
		    final Comments savedComments = commentsRepository.save(commentsEntity);
		    parseComment.processComment(commentRequest, host, purpose, assignmentStatus);
		    final JSONObject responseJson = new JSONObject();
		    responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
		    responseJson.put("commentId", savedComments.getId());
		    return new ResponseEntity<>(responseJson.toString(), HttpStatus.CREATED);
	    } else {
	    	log.debug(commentRequest.getCommentValue() +" is already collaborating on assignment");
	    	parseComment.processComment(commentRequest, host, purpose, assignmentStatus);
	        return new ResponseEntity<>(HttpStatus.OK);
	    }
    }
  }
  /**
   * Method for generating the comment json for the requested assignment
   *
   * @throws Exception
   */
  @Override
  public List<CommentsResponse> getComments(final Integer assignId) throws Exception {

    final List<CommentsResponse> commentResponseList = new ArrayList<>();
    log.info("assignId: " + assignId);

    final List<Comments> commentList = commentsRepository.findByAssignmentId(assignId);
    if (!commentList.isEmpty()) {

      // List down all comments for the assignment
      commentList.forEach(commentItem -> {

        final CommentsResponse commentsResponse = new CommentsResponse();
        String commentStatus = "";
        String replyToId = "";

        commentsResponse.setCommentId(commentItem.getId()
                                                 .toString());
        commentsResponse.setUserInitials(commentItem.getUserInitials());
        commentsResponse.setCommentValue(commentItem.getCommentValue());
        if (commentItem.getReplyId() != null) {

          replyToId = commentItem.getReplyId()
                                 .toString();
        }
        commentsResponse.setReplyToId(replyToId);
        if (commentItem.getCommentStatus() != null) {

          commentStatus = commentItem.getCommentStatus();
        }
        commentsResponse.setCommentStatus(commentStatus);

        commentsResponse.setCreatedAt(commentItem.getCreatedAt()
                                                 .toString());
        commentsResponse.setUpdatedAt(commentItem.getUpdatedAt()
                                                 .toString());

        // Add the commentsResponse to the assignment comment List
        commentResponseList.add(commentsResponse);
      });


    }

    return commentResponseList;
  }
  /**
   * Method for generating the related comment json for the requested related user initial
   * (Fetching assignments the user is collaborating on)
   *
   * @throws Exception
   */
  @Override
  public List<RelatedComment> getRelatedCommentsByRelatedInitial(final String relatedInitial) throws Exception {

    final List<RelatedComment> relatedCommentList = new ArrayList<>();

    final List<Comments> commentList = commentsRepository.findByRelatedInitial("@" + relatedInitial.toUpperCase());
    if (!commentList.isEmpty()) {

      // List down all comments for the assignment
      commentList.forEach(commentItem -> {

        AssignmentEntity assignment = assignmentRepository.getAssignment(commentItem.getAssignmentId());

        if (assignment.getStatus() == null || assignment.getStatus().equalsIgnoreCase("UNLINKED")) {
          
          final RelatedComment relatedComment = new RelatedComment();
          relatedComment.setCommentId(commentItem.getId().toString());
          relatedComment.setUserInitials(assignment.getUserInitials());
          relatedComment.setPercolateId(assignment.getPercolateId());
          relatedComment.setAssignmentName(assignment.getAssignmentName());
          relatedComment.setUpdatedAt(assignment.getUpdatedAt().toString());

          // Add the commentsResponse to the assignment comment List
          relatedCommentList.add(relatedComment);          
        }        
        
      });


    }

    return relatedCommentList;
  }

  @Override
  public ResponseEntity<String> deleteComment(final Integer commentId) throws Exception {

    final JSONObject responseJson = new JSONObject();
    try {

      Comments comment = commentsRepository.findById(commentId);
      if (comment != null) {
    	  commentsRepository.delete(comment);
          return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);
      }else{
          responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
          responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Comment not found");
          responseJson.put("commentId", commentId);
    	  return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
      }

    } catch (final Exception e) {

      log.debug("**** Internal Server Error,Please contact Administrator ****" + e.getMessage());
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }


  }
 
  
  
}
