package com.capgroup.digital.ce.cwb.services.impl;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.services.IEmailNotifiers;

@Service
public class EmailNotificationService implements IEmailNotifiers {

  private final Logger log = LogManager.getLogger(EmailNotificationService.class);

  private final JavaMailSender sender;

  @Autowired
  public EmailNotificationService(final JavaMailSender sender) {
    this.sender = sender;
  }

  @Override
  @Async
  public void sendEmail(final String recipient, final String subject, final String htmlContent) {

    try {
      final MimeMessage message = sender.createMimeMessage();

      // Enable the multipart flag!
      final MimeMessageHelper helper = new MimeMessageHelper(message, true);

      helper.setTo(recipient);

      helper.setText(htmlContent, true);

      helper.setSubject(subject);
      helper.setFrom("CreativeWorkBench@capgroup.com");
      sender.send(message);
    } catch (final MessagingException e) {
      throw new CWBException("Exception while sending mail" + e.getMessage());
    }
  }

}
