package com.capgroup.digital.ce.cwb.services.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.amazonaws.services.s3.model.S3Object;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.common.CWBMessages;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.entities.Graphics;
import com.capgroup.digital.ce.cwb.repositories.AssignmentContentRepository;
import com.capgroup.digital.ce.cwb.repositories.AssignmentsRepository;
import com.capgroup.digital.ce.cwb.repositories.GraphicsRepository;
import com.capgroup.digital.ce.cwb.services.IAssignments;
import com.capgroup.digital.ce.cwb.services.IGraphics;
import com.capgroup.digital.ce.cwb.services.IS3Uploader;


@Service
public class GraphicService implements IGraphics {

  @Autowired
  private IS3Uploader s3Uploader;

  @Autowired
  private AssignmentsRepository assignmentRepository;

  @Autowired
  private AssignmentContentRepository assignmentContentRepository;

  @Autowired
  private GraphicsRepository graphicRepository;

  @Autowired
  private IAssignments assignments;

  private final Logger log = LogManager.getLogger(GraphicService.class);


  @Override
  public ResponseEntity<InputStreamResource> getGraphics(final Integer graphicId) throws Exception {

    final JSONObject errorJson = new JSONObject();

    String graphicLocation = "";

    String graphicName = "";


    Graphics graphics = null;

    S3Object graphicS3Object = null;


    if (graphicId != null) {
      try {

        // Get Graphic File Path
        graphics = graphicRepository.findById(graphicId);
        if (graphics != null) {

          graphicLocation = graphics.getGraphicLocation();
          log.debug("****File graphicLocation: " + graphicLocation);


          // Get Graphic Object
          if (!graphicLocation.isEmpty()) {

            graphicS3Object = s3Uploader.downloadFile(graphicLocation);
            graphicName = graphics.getGraphicName();
          }
        }

        if (graphicS3Object != null && graphicS3Object.getObjectMetadata()
                                                      .getContentLength() > 0) {

          // Send Response asInput Stream Resource
          log.debug("******** Content Length*****" + graphicS3Object.getObjectMetadata()
                                                                    .getContentLength());
          final InputStream objectInputStream = graphicS3Object.getObjectContent();
          final InputStreamResource objectStreamResource = new InputStreamResource(objectInputStream);
          final HttpHeaders respHeaders = new HttpHeaders();

          String contentType = "";

          contentType = graphicS3Object.getObjectMetadata()
                                       .getContentType();
          log.debug("****File Content Type: " + contentType);

          respHeaders.setContentType(MediaType.parseMediaType(contentType));
          respHeaders.setContentLength(graphicS3Object.getObjectMetadata()
                                                      .getContentLength());
          respHeaders.setContentDispositionFormData("attachment", graphicName);

          log.debug("******Response Headers set");

          return new ResponseEntity<>(objectStreamResource, respHeaders, HttpStatus.OK);

        } else {

          // Send Response as File not found
          log.debug("****** File Not found: " + graphicId);
          throw new CWBException("File Not found for FileId: " + graphicId + " Check with System Administrator");

        }
      } catch (final Exception e) {

        log.error("****** No FileId present: " + e.getMessage());
        errorJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        errorJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        final InputStream objectInputStream = new ByteArrayInputStream(errorJson.toString()
                                                                                .getBytes());
        final InputStreamResource objectStreamResource = new InputStreamResource(objectInputStream);
        return new ResponseEntity<>(objectStreamResource, HttpStatus.BAD_REQUEST);
      }
    } else {

      throw new CWBException("No FileId present");
    }

  }


  @Override
  public ResponseEntity<String> saveGraphics(final MultipartFile file, final String postId, final String userId) {

    final JSONObject responseJson = new JSONObject();
    Integer assignmentId;
    if (!file.isEmpty() && !postId.isEmpty() && !userId.isEmpty()) {
      try {

        String graphicLocation = "";

        // Get Assignment Id
        log.debug("**** postId: ****" + postId);
        assignmentId = assignmentRepository.getAssignmentId(postId);
        log.debug("**** assignmentId: ****" + assignmentId);
        if (assignmentId != null) {

          // Upload Graphic File to S3
          graphicLocation = s3Uploader.uploadFile(file, postId, userId, CWBConstants.GRAPHICS_SECTION);

          if (!graphicLocation.isEmpty()) {

            // Save Graphic metadata to DB

            final Graphics graphics = new Graphics();
            graphics.setAssignmentId(assignmentId);
            graphics.setGraphicLocation(graphicLocation);
            graphics.setGraphicName(file.getOriginalFilename());
           

            final Integer graphicId = assignments.saveAssignmentGraphics(graphics);
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
            responseJson.put("graphicId", graphicId);
            responseJson.put("graphicName", file.getOriginalFilename());

            log.debug("**** graphic DB location: ****" + graphicId);
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);
          } else {

            log.debug("**** Error While Uploading File ****");
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
            responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, CWBMessages.FILE_UPLOAD_ERROR);
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
          }
        } else {

          log.debug("**** You failed to upload because Assignment id not found ****");
          throw new CWBException(CWBMessages.ASSIGNMENT_NOT_FOUND);
        }

      } catch (final Exception e) {

        log.debug("**** Exception in saveGraphics****" + e.getMessage());
        responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
      }
    } else {

      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, CWBMessages.FILE_EMPTY);
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }


  }


  @Override
  public ResponseEntity<String> deleteGraphics(final Integer graphicId) throws Exception {

    final JSONObject responseJson = new JSONObject();
    Graphics graphics = new Graphics();
    try {

      // Get Graphics File Path
      graphics = graphicRepository.findById(graphicId);
      if (graphics != null) {

        // Delete Graphics file from S3
        if (s3Uploader.deleteFile(graphics.getGraphicLocation())) {

          log.debug("**** File Deleted from S3 successfully ****" + graphicId);
          // Delete Graphics file from DB
          assignmentContentRepository.deleteReferenceContent(graphics.getAssignmentId(), graphicId);
          log.debug("**** Graphic Data deleted from AssignmentContent in DB ****");
          graphicRepository.delete(graphics);
          log.debug("**** Graphic Data deleted from Graphics in DB ****");
          responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
          responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "File Deleted Successfully");
          responseJson.put("graphicId", graphicId);
          return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);

        } else {

          log.debug("**** Error While Deleting file in Server ****");
          responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
          responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "File Deletion Unsuccessful");
          responseJson.put("graphicId", graphicId);
          return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
        }
      } else {

        log.debug("**** File not found in Database ****");
        throw new CWBException(CWBMessages.FILE_NOT_FOUND + graphicId);
      }
    } catch (final Exception e) {

      log.debug("**** Internal Server Error,Please contact Administrator ****" + e.getMessage());
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }


  }

  @Override
  public ResponseEntity<String> updateGraphics(final MultipartFile file, final Integer graphicId, final String postId,
      final String userId) {

    Graphics graphics;
    final JSONObject responseJson = new JSONObject();
    String existingFileName = "";

    if (!file.isEmpty() && graphicId != null && !postId.isEmpty() && !userId.isEmpty()) {
      try {

        String graphicLocation = "";
        log.debug("**** GraphicId: ****" + graphicId);

        // Get Backup File Path
        graphics = graphicRepository.findById(graphicId);

        if (graphics != null) {

          existingFileName = graphics.getGraphicName();
          if (!file.getOriginalFilename()
                   .equals(existingFileName)) {

            // Delete existing Graphic file from S3
            s3Uploader.deleteFile(graphics.getGraphicLocation());
            log.debug("**** Existing Graphic file Deleted Successfully from S3 ****");
          }

          // Upload new Graphic File to S3
          graphicLocation = s3Uploader.uploadFile(file, postId, userId, CWBConstants.GRAPHICS_SECTION);

          if (!graphicLocation.isEmpty()) {

            // Update Graphic metadata to DB

            graphics.setGraphicLocation(graphicLocation);
            graphics.setGraphicName(file.getOriginalFilename());
            assignments.saveAssignmentGraphics(graphics);

            log.debug("**** graphic DB location: ****" + graphicLocation);
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
            responseJson.put("graphicId", graphicId);
            responseJson.put("graphicName", file.getOriginalFilename());
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);
          } else {

            log.debug("**** Error While Uploading File ****");
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
            responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, CWBMessages.FILE_UPLOAD_ERROR);
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
          }

        } else {

          log.debug("**** You failed to upload because Graphic Id is not valid ****");
          throw new CWBException("You failed to upload because graphicid: " + graphicId + " not valid");

        }

      } catch (final Exception e) {

        log.error("**** Internal Server Error,Please contact Administrator ****" + e.getMessage());
        responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
      }
    } else {

      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE,
          "You failed to upload because required parameters are Empty");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }


  }

}
