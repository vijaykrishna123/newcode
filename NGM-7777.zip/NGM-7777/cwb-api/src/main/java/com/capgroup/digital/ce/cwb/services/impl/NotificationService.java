package com.capgroup.digital.ce.cwb.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import com.capgroup.digital.ce.cwb.model.Notification;
import com.capgroup.digital.ce.cwb.services.INotifications;

@Service
public class NotificationService implements INotifications {

  // The SimpMessagingTemplate is used to send Stomp over WebSocket messages.
  @Autowired
  private SimpMessagingTemplate messagingTemplate;

  /**
   * Send notification to users subscribed on channel "/user/queue/notify".
   * <p>
   * The message will be sent only to the user with the given username.
   *
   * @param notification The notification message.
   * @param username The username for the user to send notification.
   */

  @Override
  public void notifyUser(Notification notification) throws Exception {
    messagingTemplate.convertAndSend("/queue/notify", notification);
  }

}
