package com.capgroup.digital.ce.cwb.services.impl;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.capgroup.digital.ce.cwb.pdf.PDFFileGenerator;
import com.capgroup.digital.ce.cwb.pdf.ZipFileGenerator;
import com.capgroup.digital.ce.cwb.services.IPdfService;

@Service
public class PdfService implements IPdfService {

  private PDFFileGenerator pdfGenerator;

  private ZipFileGenerator zipGenerator;


  @Autowired
  public PdfService(PDFFileGenerator pdfGenerator, ZipFileGenerator zipGenerator) {
    this.pdfGenerator = pdfGenerator;
    this.zipGenerator = zipGenerator;
  }


  /**
   * Method for generating the pdf for the request
   * 
   * @throws IOException
   */
  @Override
  public ResponseEntity<InputStreamResource> generatePDFForAssignment(String percolateId) throws IOException {

    return pdfGenerator.generatePDFFile(percolateId);

  }

  /**
   * Method for generating zip files for the request
   */
  @Override
  public ResponseEntity<InputStreamResource> generateZipForAssignment(String percolateId) throws IOException {

    return zipGenerator.generateZipFile(percolateId);

  }

}
