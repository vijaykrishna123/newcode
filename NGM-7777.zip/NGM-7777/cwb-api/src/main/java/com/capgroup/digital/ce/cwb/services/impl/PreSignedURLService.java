package com.capgroup.digital.ce.cwb.services.impl;

import java.net.URL;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.HttpMethod;
import com.amazonaws.Protocol;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.capgroup.digital.ce.cwb.services.IPreSignedURL;

@Service
public class PreSignedURLService implements IPreSignedURL {

  private final Logger log = LogManager.getLogger(PreSignedURLService.class);

  private String resultString = "";

  @Value("${amazon-bucketName}")
  private String amazonBucketName;

  @Value("${amazon-accessKey}")
  private String amazonAccessKey;

  @Value("${amazon-secretId}")
  private String amazonSecretId;

  @Value("${amazon-clientRegion}")
  private String amazonClientRegion;

  @Value("${cg-proxyHost}")
  private String cgProxyHost;

  @Value("${cg-proxyPort}")
  private Integer cgProxyPort;

  @Value("${s3PreSignedURL-expTime}")
  private Integer s3URLExpiryTime;

  @Override
  public String getS3PreSignedURL(String objectKey, String requestType) {
    // TODO Auto-generated method stub

    if (!objectKey.isEmpty()) {
      log.info("*****GraphicController:getSignedURL start *****" + objectKey);
      resultString = "objectKey, requestType, s3PreSignedURL \n";
      try {
        ClientConfiguration clientConfiguration = new ClientConfiguration();
        clientConfiguration.setProxyHost(cgProxyHost);
        clientConfiguration.setProxyPort(cgProxyPort);
        BasicAWSCredentials credentials = new BasicAWSCredentials(amazonAccessKey, amazonSecretId);
        AWSStaticCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(credentials);
        AmazonS3 s3Client = AmazonS3Client.builder()
                                          .withCredentials(credentialsProvider)
                                          .withRegion(amazonClientRegion)
                                          .withClientConfiguration(clientConfiguration.withProtocol(Protocol.HTTP))
                                          .build();

        // Set the presigned URL to expire after one hour.
        log.debug("*****Set the presigned URL to expire*****");
        java.util.Date expiration = new java.util.Date();
        long expTimeMillis = expiration.getTime();
        expTimeMillis += s3URLExpiryTime;
        expiration.setTime(expTimeMillis);

        // Generate the presigned URL for GET.
        log.debug("*****Generate the presigned URL*****");
        String urlString = "";
        if (!requestType.isEmpty() && requestType.equalsIgnoreCase("PUT")) {

          GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(amazonBucketName,
              objectKey).withMethod(HttpMethod.PUT)
                        .withExpiration(expiration);
          URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
          urlString = url.toString();
        } else if (!requestType.isEmpty() && requestType.equalsIgnoreCase("POST")) {

          GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(amazonBucketName,
              objectKey).withMethod(HttpMethod.POST)
                        .withExpiration(expiration);
          URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
          urlString = url.toString();
        } else if (!requestType.isEmpty() && requestType.equalsIgnoreCase("GET")) {

          GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(amazonBucketName,
              objectKey).withMethod(HttpMethod.GET)
                        .withExpiration(expiration);
          URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
          urlString = url.toString();
        } else {

          resultString = "";
          log.debug("******Not a valid RequestType******");
          return resultString;
        }

        if (!urlString.isEmpty()) {

          log.debug("****Pre-Signed URL: " + urlString);
          resultString = resultString + objectKey + ", " + requestType + ", " + urlString + "\n";
        } else {

          log.debug("******Not a valid URL******");
          resultString = "";
        }


      } catch (AmazonServiceException e) {
        // The call was transmitted successfully, but Amazon S3 couldn't process
        // it, so it returned an error response.
    	  log.error(e);
      } catch (SdkClientException e) {
        // Amazon S3 couldn't be contacted for a response, or the client
        // couldn't parse the response from Amazon S3.
    	  log.error(e);
      }


    } else {

      resultString = "";
      log.debug("*****ObjectKey is Empty *****");

    }
    log.info("*****GraphicController:getSignedURL end *****");
    return resultString;
  }

}
