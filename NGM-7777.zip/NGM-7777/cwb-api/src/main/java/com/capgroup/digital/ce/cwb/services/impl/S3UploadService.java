package com.capgroup.digital.ce.cwb.services.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.amazonaws.AmazonClientException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.services.IS3Uploader;

@Service
public class S3UploadService implements IS3Uploader {

  @Value("${amazon-bucketName}")
  private String amazonBucketName;

  @Value("${amazon-accessKey}")
  private String amazonAccessId;

  @Value("${amazon-secretId}")
  private String amazonSecretId;

  @Value("${amazon-clientRegion}")
  private String amazonClientRegion;

  @Value("${cg-proxyHost}")
  private String cgProxyHost;

  @Value("${cg-proxyPort}")
  private Integer cgProxyPort;

  private final Logger log = LogManager.getLogger(S3UploadService.class);

  private S3Object s3Object;

  private AmazonS3 s3Client;

  @Override
  public String uploadFile(final MultipartFile file, final String assignId, final String userId,
      final String assetType) {

    String fileLocation = "";
    if (!file.isEmpty()) {
      try {
        final ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentLength(file.getSize());
        objectMetadata.setContentType(file.getContentType());

        fileLocation = "ce/assignments/" + assignId + "/" + userId + "/" + assetType + "/" + file.getOriginalFilename();
        log.debug("*****File name: " + file.getOriginalFilename());
        // Upload the file for public read
        getS3Client().putObject(new PutObjectRequest(amazonBucketName, fileLocation, file.getInputStream(),
            objectMetadata));
        log.debug("*****You successfully uploaded: " + file.getOriginalFilename());
      } catch (final Exception e) {
        throw new CWBException(" Error while Uploading file to S3: " + e.getMessage(), e);
      }

    } else {
      fileLocation = "";
      log.debug("****File Not found ");
    }

    return fileLocation;

  }

  @Override
  public AmazonS3 getS3Client() throws Exception {

    // Create Amazon S3 client
    final ClientConfiguration clientConfiguration = new ClientConfiguration();
    clientConfiguration.setProxyHost(cgProxyHost);
    clientConfiguration.setProxyPort(cgProxyPort);
    log.debug("EC2 login validation");
    final BasicAWSCredentials credentials = new BasicAWSCredentials(amazonAccessId, amazonSecretId);
    final AWSStaticCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(credentials);
    if (s3Client == null) {
      try {

        log.debug("*** Creating new S3 connection ***");
        s3Client = AmazonS3ClientBuilder.standard()
                                        .withCredentials(new InstanceProfileCredentialsProvider(false))
                                        .build();

        if (!s3Client.doesBucketExistV2(amazonBucketName)) {

          log.debug("** Unable to do EC2 connection thus connecting with Credentials");
          s3Client = AmazonS3Client.builder()
                                   .withCredentials(credentialsProvider)
                                   .withRegion(amazonClientRegion)
                                   .withClientConfiguration(clientConfiguration.withProtocol(Protocol.HTTPS))
                                   .build();
        }
      } catch (final AmazonClientException e) {

        log.debug("** Exception while EC2 connection thus connecting with Credentials");
        s3Client = AmazonS3Client.builder()
                                 .withCredentials(credentialsProvider)
                                 .withRegion(amazonClientRegion)
                                 .withClientConfiguration(clientConfiguration.withProtocol(Protocol.HTTPS))
                                 .build();
      }

      log.debug("Amazon S3 client was created.");
    }
    return s3Client;
  }

  @Override
  public S3Object downloadFile(final String fileLocation) {

    log.debug("******** Downloading an object from S3 ********");
    s3Object = new S3Object();
    try {

      s3Object = getS3Client().getObject(new GetObjectRequest(amazonBucketName, fileLocation));
      log.debug("******** File object downloaded from S3*****");

    } catch (final Exception e) {

      log.error("******** Exception in S3 while downloading file***** " + e.getMessage());
    }
    return s3Object;
  }

  @Override
  public boolean deleteFile(final String fileLocation) {

    s3Object = new S3Object();
    try {

      /*
       * Delete an object
       */

      log.debug("**Deleting an object\n");
      getS3Client().deleteObject(amazonBucketName, fileLocation);
      return true;

    } catch (final Exception e) {

      log.error("******** Exception in S3 while deleting file*****" + e.getMessage());
      return false;
    }

  }

}
