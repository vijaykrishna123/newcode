package com.capgroup.digital.ce.cwb.services.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.amazonaws.services.s3.model.S3Object;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.common.CWBMessages;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.entities.SocialMediaEntity;
import com.capgroup.digital.ce.cwb.repositories.AssignmentContentRepository;
import com.capgroup.digital.ce.cwb.repositories.AssignmentsRepository;
import com.capgroup.digital.ce.cwb.repositories.SocialMediaRepository;
import com.capgroup.digital.ce.cwb.services.IS3Uploader;
import com.capgroup.digital.ce.cwb.services.ISocialMedia;

@Service
public class SocialMediaService implements ISocialMedia {

  @Autowired
  private IS3Uploader s3Uploader;

  @Autowired
  private AssignmentsRepository assignmentRepository;

  @Autowired
  private AssignmentContentRepository assignmentContentRepository;

  @Autowired
  private SocialMediaRepository socialMediaRepository;

  private final Logger log = LogManager.getLogger(SocialMediaService.class);

  @Override
  public ResponseEntity<InputStreamResource> getSocialMediaFile(final Integer socialMediaId) {

    final JSONObject errorJson = new JSONObject();
    String socialMediaLocation = "";
    String socialMediaName = "";
    SocialMediaEntity socialMedia = null;
    S3Object socialMediaS3Object = null;

    if (socialMediaId != null) {
      try {

        // Get SocialMedia File Path
        socialMedia = socialMediaRepository.findById(socialMediaId);
        if (socialMedia != null) {

          socialMediaLocation = socialMedia.getMediaFileLocation();
          log.debug("****File socialMediaLocation: " + socialMediaLocation);

          // Get Social Media Object
          if (!socialMediaLocation.isEmpty()) {

            socialMediaS3Object = s3Uploader.downloadFile(socialMediaLocation);
            socialMediaName = socialMedia.getMediaFileName();
          }
        }

        if (socialMediaS3Object != null && socialMediaS3Object.getObjectMetadata()
                                                              .getContentLength() > 0) {

          // Send Response asInput Stream Resource
          log.debug("******** Content Length*****" + socialMediaS3Object.getObjectMetadata()
                                                                        .getContentLength());
          final InputStream objectInputStream = socialMediaS3Object.getObjectContent();
          final InputStreamResource objectStreamResource = new InputStreamResource(objectInputStream);
          final HttpHeaders respHeaders = new HttpHeaders();

          String contentType = "";

          contentType = socialMediaS3Object.getObjectMetadata()
                                           .getContentType();
          log.debug("****File Content Type: " + contentType);

          respHeaders.setContentType(MediaType.parseMediaType(contentType));
          respHeaders.setContentLength(socialMediaS3Object.getObjectMetadata()
                                                          .getContentLength());
          respHeaders.setContentDispositionFormData("attachment", socialMediaName);

          log.debug("******Response Headers set");
          return new ResponseEntity<>(objectStreamResource, respHeaders, HttpStatus.OK);

        } else {

          // Send Response as File not found
          log.debug("****** Exception in getSocialMediaFile: " + socialMediaId);
          throw new CWBException("File Not found for FileId: " + socialMediaId + " Check with System Administrator");

        }
      } catch (final Exception e) {

        log.error("****** No FileId present: " + e.getMessage());
        errorJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        errorJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        final InputStream objectInputStream = new ByteArrayInputStream(errorJson.toString()
                                                                                .getBytes());
        final InputStreamResource objectStreamResource = new InputStreamResource(objectInputStream);
        return new ResponseEntity<>(objectStreamResource, HttpStatus.BAD_REQUEST);
      }
    } else {

      log.error("****** No FileId present");
      throw new CWBException("No FileId present");
    }

  }

  @Override
  public Integer saveSocialMedia(final Integer assignmentId, final String socialMediaType,
      final SocialMediaEntity socialMediaEntity) {

    if (assignmentId != null && !socialMediaType.isEmpty()) {

      // Save Social Media metadata to DB

      socialMediaEntity.setAssignmentId(assignmentId);
      socialMediaEntity.setMediaType(socialMediaType);

    }
    return socialMediaRepository.save(socialMediaEntity)
                                .getId();
  }

  @Override
  public ResponseEntity<String> saveSocialMediaFile(final MultipartFile file, final String postId, final String userId,
      final String socialMediaType) {

    final JSONObject responseJson = new JSONObject();
    Integer assignmentId;
    if (!file.isEmpty() && !postId.isEmpty() && !userId.isEmpty() && !socialMediaType.isEmpty()) {
      try {

        String socialMediaLocation = "";

        // Get Assignment Id
        log.debug("**** postId: ****" + postId);
        assignmentId = assignmentRepository.getAssignmentId(postId);
        log.debug("**** assignmentId: ****" + assignmentId);
        if (assignmentId != null) {

          // Upload Social Media File to S3
          socialMediaLocation = s3Uploader.uploadFile(file, postId, userId, socialMediaType);

          if (!socialMediaLocation.isEmpty()) {

            // Save Social Media metadata to DB
            final SocialMediaEntity socialMediaEntity = new SocialMediaEntity();

            socialMediaEntity.setMediaFileLocation(socialMediaLocation);
            socialMediaEntity.setMediaFileName(file.getOriginalFilename());
            final Integer socialMediaId = saveSocialMedia(assignmentId, socialMediaType, socialMediaEntity);

            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
            responseJson.put("socialMediaId", socialMediaId);
            responseJson.put("socialMediaName", file.getOriginalFilename());

            log.debug("**** Social Media DB location: ****" + socialMediaId);
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);
          } else {

            log.debug("**** Error While Uploading File ****");
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
            responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, CWBMessages.FILE_UPLOAD_ERROR);
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
          }
        } else {

          log.debug("**** You failed to upload because Assignment id not found ****");
          throw new CWBException(CWBMessages.ASSIGNMENT_NOT_FOUND);
        }

      } catch (final Exception e) {

        log.debug("**** Internal Server Error,Please contact Administrator ****" + e.getMessage());
        responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
      }
    } else {

      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, CWBMessages.FILE_EMPTY);
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }

  }

  @Override
  public ResponseEntity<String> deleteSocialMedia(final Integer socialMediaId) throws Exception {

    final JSONObject responseJson = new JSONObject();
    boolean isMediaDataDeleteFlag = false;
    SocialMediaEntity socialMediaEntity = new SocialMediaEntity();
    try {

      // Get Social Media File Path
      socialMediaEntity = socialMediaRepository.findById(socialMediaId);
      if (socialMediaEntity != null) {

        if (null == socialMediaEntity.getMediaFileLocation()) {

          isMediaDataDeleteFlag = true;
          log.debug("**** No Media Associated for Social media ****");
        }

        // Delete Social Media file from S3
        else if (s3Uploader.deleteFile(socialMediaEntity.getMediaFileLocation())) {

          log.debug("**** File Deleted from S3 successfully ****" + socialMediaId);
          isMediaDataDeleteFlag = true;

        }
        if (isMediaDataDeleteFlag) {

          // Delete Social Media details from DB
          assignmentContentRepository.deleteReferenceContent(socialMediaEntity.getAssignmentId(), socialMediaId);
          log.debug("**** Social Media Data deleted from AssignmentContent in DB ****");
          socialMediaRepository.delete(socialMediaEntity);
          log.debug("**** Social Media Data deleted in DB ****");
          responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
          responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "File Deleted Successfully");
          responseJson.put("socialMediaId", socialMediaId);
          return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);
        } else {

          log.debug("**** Error While Deleting file in Server ****");
          responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
          responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "File Deletion Unsuccessful");
          responseJson.put("socialMediaId", socialMediaId);
          return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
        }
      } else {

        log.debug("**** File not found in Database ****");
        throw new CWBException("File not found in Database. socialMediaId: " + socialMediaId);
      }
    } catch (final Exception e) {

      log.debug("**** Internal Server Error in deletion,Please contact Administrator ****" + e.getMessage());
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }

  }

  @Override
  public ResponseEntity<String> updateSocialMediaFile(final MultipartFile file, final Integer socialMediaId,
      final String postId, final String userId, final String socialMediaType) {

    final JSONObject responseJson = new JSONObject();
    String existingFileName = "";

    if (!file.isEmpty() && socialMediaId != null && !postId.isEmpty() && !userId.isEmpty() && !socialMediaType
                                                                                                              .isEmpty()) {
      try {

        String socialMediaLocation = "";
        log.debug("**** Social Media Id: ****" + socialMediaId);

        // Get Backup File Path
        final SocialMediaEntity socialMediaEntity = socialMediaRepository.findById(socialMediaId);

        if (socialMediaEntity != null) {

          existingFileName = socialMediaEntity.getMediaFileName();
          if (!file.getOriginalFilename()
                   .equals(existingFileName)) {

            // Delete existing Social Media file from S3
            s3Uploader.deleteFile(socialMediaEntity.getMediaFileLocation());
            log.debug("**** Existing Social Media file Deleted Successfully from S3 ****");
          }

          // Upload new Social Media File to S3
          socialMediaLocation = s3Uploader.uploadFile(file, postId, userId, socialMediaType);

          if (!socialMediaLocation.isEmpty()) {

            // Update Social Media metadata to DB
            socialMediaEntity.setMediaFileLocation(socialMediaLocation);
            socialMediaEntity.setMediaFileName(file.getOriginalFilename());
            socialMediaEntity.setMediaType(socialMediaType);
            socialMediaRepository.save(socialMediaEntity);

            log.debug("**** Social Media DB location: ****" + socialMediaLocation);
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_SUCCESS);
            responseJson.put("socialMediaId", socialMediaId);
            responseJson.put("socialMediaName", file.getOriginalFilename());
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);
          } else {

            log.debug("**** Error While Uploading File ****");
            responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
            responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, CWBMessages.FILE_UPLOAD_ERROR);
            return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
          }

        } else {

          log.debug("**** You failed to upload because Social Media Id is not valid ****");
          throw new CWBException("You failed to upload because socialMediaId: " + socialMediaId + " not valid");

        }

      } catch (final Exception e) {

        log.error("**** Internal Server Error,Please contact Administrator ****" + e.getMessage());
        responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
        responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE, "Internal Server Error,Please contact Administrator");
        return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
      }
    } else {

      log.debug("**** You failed to upload because the file was empty ****");
      responseJson.put(CWBConstants.JSON_STATUS, CWBConstants.JSON_STATUS_FAILURE);
      responseJson.put(CWBConstants.JSON_INTERNAL_MESSAGE,
          "You failed to upload because required parameters are Empty");
      return new ResponseEntity<>(responseJson.toString(), HttpStatus.BAD_REQUEST);
    }

  }

}
