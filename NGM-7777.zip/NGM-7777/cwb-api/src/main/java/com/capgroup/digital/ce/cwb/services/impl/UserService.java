package com.capgroup.digital.ce.cwb.services.impl;

import java.sql.Timestamp;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.capgroup.digital.ce.cwb.model.UserRequest;
import com.capgroup.digital.ce.cwb.model.entities.Users;
import com.capgroup.digital.ce.cwb.repositories.UserRepository;
import com.capgroup.digital.ce.cwb.services.IUsers;


@Service
public class UserService implements IUsers {

  @Autowired
  private UserRepository userRepository;

  private final Logger log = LogManager.getLogger(UserService.class);


  /**
   * Method To save/ update User details
   *
   */
  @Override
  public HttpStatus saveUsers(final UserRequest userRequestPayload) {

    final Users users = userRepository.findByUserInitials(userRequestPayload.getUserInitials())
                                      .orElseGet(() -> createUser(userRequestPayload));

    users.setLastLoginAt(new Timestamp(System.currentTimeMillis()));
    log.debug("******User Initials : " + userRequestPayload.getUserInitials());
    userRepository.save(users);

    final HttpStatus status = HttpStatus.NO_CONTENT;
    log.debug("******User Repository saved for : " + userRequestPayload.getUserInitials());

    return status;

  }

  /**
   * Method for creating user
   * 
   * @param userRequestPayload
   * @return
   */
  private Users createUser(final UserRequest userRequestPayload) {

    final Users user = new Users();
    user.setUserInitials(userRequestPayload.getUserInitials()
                                           .toUpperCase());
    user.setEmail(userRequestPayload.getEmail());
    user.setFirstName(userRequestPayload.getFirstName());
    user.setLastName(userRequestPayload.getLastName());
    return userRepository.save(user);
  }

}