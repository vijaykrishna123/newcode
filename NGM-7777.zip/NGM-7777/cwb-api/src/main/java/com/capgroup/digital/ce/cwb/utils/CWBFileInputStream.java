package com.capgroup.digital.ce.cwb.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CWBFileInputStream extends FileInputStream {

  private final File file;
  private final Logger log = LogManager.getLogger(CWBFileInputStream.class);

  public CWBFileInputStream(final File file) throws FileNotFoundException {
    super(file);
    this.file = file;
  }

  @Override
  public void close() throws IOException {
    super.close();
    if (!file.delete()){
    	log.error("Error deleting file, filename: "+ file.getName());
    }
  }

}
