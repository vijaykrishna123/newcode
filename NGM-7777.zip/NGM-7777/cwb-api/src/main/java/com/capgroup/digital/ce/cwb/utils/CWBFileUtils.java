package com.capgroup.digital.ce.cwb.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CWBFileUtils {

  private final static Logger log = LogManager.getLogger(CWBFileUtils.class);
  /**
   * Method for getting file contents
   * 
   * @param fileName
   * @return
   */
  public static String getFileContents(String fileName) {
    InputStream in = CWBFileUtils.class.getResourceAsStream(fileName);
    return getFileContents(in);
  }

  /**
   * Getting the html file contents
   * 
   * @param inputStream
   * @return
   */
  public static String getFileContents(InputStream inputStream) {
    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
    StringBuilder out = new StringBuilder();
    String line;
    try {
      while ((line = reader.readLine()) != null) {
        out.append(line);
      }
      reader.close();
    } catch (IOException e) {
      log.error(e);
    }
    return out.toString();
  }

}
