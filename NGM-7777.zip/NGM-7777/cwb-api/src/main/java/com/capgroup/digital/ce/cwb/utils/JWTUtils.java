package com.capgroup.digital.ce.cwb.utils;

import java.io.UnsupportedEncodingException;
import io.jsonwebtoken.Header;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JWTUtils {

  public static String createJWT(String issuer, long ttlMillis, String payload, String secretKey)
      throws UnsupportedEncodingException {

    // The JWT signature algorithm we will be using to sign the token
    SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;


    // We will sign our JWT with our ApiKey secret
    // byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secretKey);
    // Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

    // Let's set the JWT Claims
    JwtBuilder builder = Jwts.builder()
                             .setHeaderParam("typ", Header.JWT_TYPE)
                             .setPayload(payload)
                             .signWith(signatureAlgorithm, secretKey.getBytes("UTF-8"));

    // if it has been specified, let's add the expiration
    /*
     * if (ttlMillis >= 0) { long expMillis = nowMillis + ttlMillis; Date exp = new Date(expMillis);
     * builder.setExpiration(exp); }
     */

    // Builds the JWT and serializes it to a compact, URL-safe string
    return builder.compact();
  }
}
