package com.capgroup.digital.ce.cwb.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.tidy.Tidy;
import com.capgroup.digital.ce.cwb.common.PdfConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.itextpdf.tool.xml.XMLWorkerFontProvider;

public class PDFUtils {

  private PDFUtils() {
    throw new IllegalStateException("PDF Utility class");
  }

  private final static Logger log = LogManager.getLogger(PDFUtils.class);

  /**
   * Method for formatting the html data
   * 
   * @param data
   * @return
   * @throws UnsupportedEncodingException
   */
  public static String cleanData(final String data) throws UnsupportedEncodingException {
    final Tidy tidy = new Tidy();
    tidy.setInputEncoding(PdfConstants.UTF_8);
    tidy.setOutputEncoding(PdfConstants.UTF_8);
    tidy.setBreakBeforeBR(false);
    tidy.setXHTML(true);
    tidy.setQuiet(true);
    tidy.setLowerLiterals(true);
//    tidy.setMakeClean(true); //this causes em dash and en dash to not work. They both end up looking the same
    tidy.setNumEntities(true);
    tidy.setQuoteNbsp(false);
    tidy.setQuoteAmpersand(false);
    tidy.setShowWarnings(false);
    tidy.setXmlOut(true);
    tidy.setDropEmptyParas(true);
    tidy.setWraplen(Integer.MAX_VALUE);

    final ByteArrayInputStream inputStream = new ByteArrayInputStream(data.getBytes(PdfConstants.UTF_8));
    final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    tidy.parseDOM(inputStream, outputStream);

    return outputStream.toString(PdfConstants.UTF_8);
  }

  /**
   * Method for loading the avenir fonts
   * 
   * @return
   */
  public static XMLWorkerFontProvider loadFonts() {
    final XMLWorkerFontProvider fontProvider = new XMLWorkerFontProvider(XMLWorkerFontProvider.DONTLOOKFORFONTS);
    URL fontPath = Thread.currentThread()
    		.getContextClassLoader()
    		.getResource("fonts/AvenirNextLTCom-Regular.ttf");
    fontProvider.register(fontPath.toString());
    fontPath = Thread.currentThread()
    		.getContextClassLoader()
    		.getResource("fonts/AvenirNextLTCom-Bold.ttf");
    fontProvider.register(fontPath.toString());
    fontPath = Thread.currentThread()
    		.getContextClassLoader()
    		.getResource("fonts/AvenirNextLTCom-Italic.ttf");
    fontProvider.register(fontPath.toString());
    fontPath = Thread.currentThread()
            .getContextClassLoader()
            .getResource("fonts/AvenirNextLTCom-BoldIt.ttf");
    fontProvider.register(fontPath.toString());

    return fontProvider;
  }

  /**
   * Method for scanning the section to retrieve short codes
   * 
   * @param section
   * @return
   */
  public static List<String> findShortCodesFromSection(final String section) {

    final Matcher m = Pattern.compile(PdfConstants.SHORTCODE_REGEX)
                             .matcher(section);

    final List<String> shortCodes = new ArrayList<>();

    while (m.find()) {
      shortCodes.add(m.group(1));
    }

    return shortCodes;

  }

  /**
   * Method for creating the directory
   */
  public static void makeDirectory(final String directoryName) {

    final Path path = Paths.get(directoryName);
    if (!path.toFile()
             .exists()) {
      try {

    	 log.debug("directoryName: " + directoryName + "\nAbolute Path: " + path.toAbsolutePath().toString());
        Files.createDirectories(path);
      } catch (final IOException e) {
        throw new CWBException("Exception while creating directories " + directoryName + " Using absolute path: " + path.toAbsolutePath().toString() + e.getMessage(), e);
      }
    } else {
      log.debug(">>>>>>>>>>> " + directoryName + " already exist");
    }
  }
}
