package com.capgroup.digital.ce.cwb.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import com.capgroup.digital.ce.cwb.common.CWBConstants;
import com.capgroup.digital.ce.cwb.common.PdfConstants;
import com.capgroup.digital.ce.cwb.model.CommentsRequest;
import com.capgroup.digital.ce.cwb.repositories.UserRepository;
import com.capgroup.digital.ce.cwb.services.IEmailNotifiers;

@Component
public class ParseComments {

  private final Logger log = LogManager.getLogger(ParseComments.class);

  private final IEmailNotifiers mailingService;

  private final UserRepository userRepository;

  @Autowired
  public ParseComments(final IEmailNotifiers mailingService, final UserRepository userRepository) {
    super();
    this.mailingService = mailingService;
    this.userRepository = userRepository;
  }


  /**
   * Method for process comment for finding
   * 
   * @param commentRequest
   * @param host
   */
  public void processComment(final CommentsRequest commentRequest, final String host, final String purpose, final String assignmentStatus) {
	  
	  String emailSubject;
	  String emailBodyLineOne;
	  String linkToCwb;
	  String unlinkedParameter;
	  String assignmentName = commentRequest.getAssignmentName();
	  String user= commentRequest.getUserInitials();
	  String optionalText = commentRequest.getOptionalText();	  
	  
	  if (optionalText == null) {
		  optionalText = "";
	  }
	  
	  if (assignmentStatus != null && assignmentStatus.equalsIgnoreCase("UNLINKED")) {
		unlinkedParameter = "?unlinked=true";
	  } else {
		unlinkedParameter ="";
	  }
	  
	  log.debug("Sending email for purpose: " + purpose);	
	 
	  switch (purpose.toUpperCase()) {
	  	case "PROOF":
	  	  emailSubject = "[ "+ assignmentName + " ] " + user + " generated a Proof";
	  	  emailBodyLineOne = optionalText;
	  	  linkToCwb = CWBConstants.HTTPS_SCHEME + host + PdfConstants.BACKSLASH + commentRequest.getPercolateId() + PdfConstants.BACKSLASH + PdfConstants.PROOF_MODAL + unlinkedParameter;
		  break;		  
	  	case "PROOF_VERSION":
	  	  emailSubject = "[ "+ assignmentName + " ] " + user + " generated a New Proof";
	  	  emailBodyLineOne = optionalText;
	  	  linkToCwb = CWBConstants.HTTPS_SCHEME + host + PdfConstants.BACKSLASH + commentRequest.getPercolateId() + PdfConstants.BACKSLASH + PdfConstants.PROOF_MODAL + unlinkedParameter;
		  break;		  
	  	case "ADD_REVIEWER":
	      emailSubject = "[ "+ assignmentName + " ] " + user + " added you as a Reviewer";
	      emailBodyLineOne = optionalText;
	  	  linkToCwb = CWBConstants.HTTPS_SCHEME + host + PdfConstants.BACKSLASH + commentRequest.getPercolateId() + unlinkedParameter;
		  break;		  
		default: //SHARE
		  emailSubject = "[ "+ assignmentName + " ] " + user + " shared an assignment";
		  emailBodyLineOne = optionalText;
		  linkToCwb = CWBConstants.HTTPS_SCHEME + host + PdfConstants.BACKSLASH + commentRequest.getPercolateId() + unlinkedParameter;
		  break;			
	  }
	  
    final String htmlContent =
        "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n"
            + "<html xmlns=\"http://www.w3.org/1999/xhtml\" style=\"font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n"
            + "<head>\r\n" + "<meta name=\"viewport\" content=\"width=device-width\" />\r\n"
            + "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n"
            + "<title>Email Notification</title>\r\n" + "\r\n" + "\r\n" + "<style type=\"text/css\">\r\n" + "img {\r\n"
            + "max-width: 100%;}\r\nbody {\r\n"
            + "-webkit-font-smoothing: antialiased; -webkit-text-size-adjust: none; width: 100% !important; height: 100%; line-height: 1.6em;\r\n"
            + "}\r\n body {\r\n" + "background-color: #f6f6f6;\r\n" + "}\r\n"
            + "@media only screen and (max-width: 640px) {\r\n body {\r\n padding: 0 !important;}"
            + "\r\n .container {\r\n" + "    padding: 0 !important; width: 100% !important;}\r\n" + ".content {\r\n"
            + "padding: 0 !important;\r\n" + "  }\r\n" + "  .content-wrap {\r\n" + "padding: 10px !important;\r\n"
            + "}\r\n }\r\n" + "</style>\r\n" + "</head>\r\n" + "\r\n"
            + "<body><table style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px;"
            + " width: 100%; background-color: #f6f6f6;\" bgcolor=\"#f6f6f6\">"
            + "<tr style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">"
            + "<td class=\"container\" width=\"600\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box;"
            + "font-size: 14px; vertical-align: top; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto;\" valign=\"top\">\r\n"
            + "<div class=\"content\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; max-width: 600px;"
            + "display: block; margin: 0 auto; padding: 20px;\">\r\n"
            + "<table class=\"main\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\""
            + "style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; border-radius: 3px; background-color: #fff; "
            + "margin: 0; border: 1px solid #e9e9e9;\" bgcolor=\"#fff\"><tr style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">"
            + "<td class=\"content-wrap\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 20px;\" "
            + "valign=\"top\">\r\n"
            + "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">"
            + "<tr style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">"
            + "<td class=\"content-block\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px;"
            + " vertical-align: top; margin: 0; padding: 0 0 20px;\" valign=\"top\">\r\n"
            + emailBodyLineOne
            + "</td></tr>\r\n<br /><tr><td>" + CWBConstants.EMAIL_COMMENT_TEXT
            + "</td></tr>\r\n<br /><tr style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">"
            + "<td class=\"content-block\" itemprop=\"handler\" "
            + "itemscope itemtype=\"http://schema.org/HttpActionHandler\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;\" valign=\"top\">\r\n"
            + "<a href=\'" + linkToCwb 
            + "' class=\"btn-primary\" itemprop=\"url\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF;"
            + " text-decoration: none; line-height: 2em; font-weight: bold; text-align: center; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize;"
            + " background-color: #348eda; margin: 0; border-color: #348eda; border-style: solid; border-width: 10px 20px;\">View Assignment</a>"
            + "</td>\r\n</tr><tr style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\"><td class=\"content-block\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;\" valign=\"top\">\r\n"
            + "&mdash; Creative Workbench\r\n</tr></table><div class=\"footer\" style=\"font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; clear: both; color: #999; margin: 0; padding: 20px;\">\r\n"
            + "</div></div>\r\n</td>\r\n</tr></table></body>\r\n</html>";


    if (!StringUtils.isEmpty(commentRequest.getCommentValue())) {

      final Pattern pattern = Pattern.compile(CWBConstants.USERNAME_MENTION_REGEX);
      final Matcher matcher = pattern.matcher(commentRequest.getCommentValue());
      final List<String> mailingUsers = new ArrayList<>();
      while (matcher.find()) {
        mailingUsers.add(matcher.group());
      }

      mailingUsers.forEach(userInitials -> {
        userInitials = userInitials.replace("@", "")
                                   .trim()
                                   .toUpperCase();
        userRepository.findByUserInitials(userInitials)
                      .ifPresent(users -> mailingService.sendEmail(users.getEmail(), emailSubject, htmlContent));
      });
    }
  }
}
