package com.capgroup.digital.ce.cwb.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.capgroup.digital.ce.cwb.common.PdfConstants;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;

public class ZipUtils {

  private final Logger log = LogManager.getLogger(ZipUtils.class);

  private final List<String> fileList;

  public ZipUtils() {
    fileList = new ArrayList<>();
  }

  public void zipIt(final String baseDir,final String zipFile) {
    final byte[] buffer = new byte[1024];

    try (FileOutputStream fos = new FileOutputStream(zipFile); ZipOutputStream zos = new ZipOutputStream(fos)) {

      for (final String file : this.fileList) {
        final ZipEntry ze = new ZipEntry(file.replace(baseDir + PdfConstants.BACKSLASH, ""));
        zos.putNextEntry(ze);
        try (FileInputStream in = new FileInputStream(file)) {
          int len;
          while ((len = in.read(buffer)) > 0) {
            zos.write(buffer, 0, len);
          }
        }
      }

      zos.closeEntry();

    } catch (final IOException ex) {
      throw new CWBException("Exception while zipping file " + ex.getMessage(), ex);
    }
  }

  public void generateFileList(final File node) {
    // add file only
    if (node.isFile()) {
      fileList.add(node.getPath());
    }

    if (node.isDirectory())
      iterateFiles(node);

  }

  private void iterateFiles(final File node) {

    if (node.isDirectory()) {
      final File[] subNote = node.listFiles();
      for (final File subFile : subNote) {
        if (subFile.isDirectory())
          generateFileList(subFile);
        if (subFile.isFile()) {
          fileList.add(subFile.getPath());
        }
      }
    }
  }

}
