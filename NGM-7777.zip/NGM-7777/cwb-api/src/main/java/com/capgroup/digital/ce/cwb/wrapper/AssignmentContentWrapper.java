package com.capgroup.digital.ce.cwb.wrapper;

import java.util.List;
import com.capgroup.digital.ce.cwb.model.Assignment;
import com.capgroup.digital.ce.cwb.model.entities.AssignmentContent;

public class AssignmentContentWrapper {

  Assignment assignment;

  List<AssignmentContent> assignmentContent;

  public AssignmentContentWrapper(Assignment assignment, List<AssignmentContent> assignmentContent) {
    super();
    this.assignment = assignment;
    this.assignmentContent = assignmentContent;
  }

  public AssignmentContentWrapper() {
    super();
  }

  public Assignment getAssignment() {
    return assignment;
  }

  public void setAssignment(Assignment assignment) {
    this.assignment = assignment;
  }

  public List<AssignmentContent> getAssignmentContent() {
    return assignmentContent;
  }

  public void setAssignmentContent(List<AssignmentContent> assignmentContent) {
    this.assignmentContent = assignmentContent;
  }

}
