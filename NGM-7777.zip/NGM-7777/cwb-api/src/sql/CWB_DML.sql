INSERT INTO TEMPLATES (id, template_name, template_type, created_at, updated_at) VALUES(1,'web-template', 'web',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP );


INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(1,'TextField','SEO Metadescription',0,160, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(2,'Editor','Short Headline',0, 50, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(3,'Editor','Long Headline',0,200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(4,'Editor','Subhead',0,200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(5,'Editor','Body',0,0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(6,'CheckBox','This is a Photo',0,0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(7,'TextField','Graphic Headline',0,80, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(8,'TextField','Graphic Subhead 1',0,80, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(9,'TextField','Graphic Subhead 2',0,80, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(10,'FileUpload','Add Graphic',80,0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(11,'MultiText','Graphic Source', 0,125, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(13,'TextField','Graphic Alt Text',0,80, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(14,'TextField','Add Disclosure',0,200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(19,'FileUpload','Backup File',0,0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id,field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(20,'Editor','Post',0,116, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(21,'Editor','Headline',0, 70, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id,field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(22,'Editor','Post',0,150, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(23,'Editor','Headline',0, 100, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id,field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(24,'Editor','Post',0,150, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(25,'Editor','Headline',0, 70, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(26,'FileUpload','Image Creative',0,0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'Image Creative (1200px wide, 627px H) or (800px W x 800px H)');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(27,'FileUpload','Image Creative',0,0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'Image Creative (1200x627px)');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(28,'FileUpload','Image Creative',0,0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'Image Creative (1200x627px)');
INSERT INTO FIELDS (id, field_type, field_label, min_length, max_length, created_at, updated_at, helper_text) VALUES(29,'TextField','Byline',0,200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'');


INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(1, 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'copy');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(2, 1, 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'copy');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(3, 1, 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'copy');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(4, 1, 4, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'copy');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(5, 1, 5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'copy');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(32, 1, 29, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'copy');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(6, 1, 6, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(7, 1, 7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(8, 1, 8, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(9, 1, 9, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(10, 1, 10, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(11, 1, 11, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(12, 1, 12, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(13, 1, 13, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(14, 1, 14, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'graphics');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(19, 1, 19, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'backup');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(23, 1, 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'twitter');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(24, 1, 21, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'twitter');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(25, 1, 22, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'facebook');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(26, 1, 23, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'facebook');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(27, 1, 24, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'linkedin');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(28, 1, 25, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'linkedin');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(29, 1, 26, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'twitter');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(30, 1, 27, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'facebook');
INSERT INTO TEMPLATE_DETAILS (id, template_id, field_id, created_at, updated_at, field_section) VALUES(31, 1, 28, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'linkedin');

UPDATE template_details set field_order=10 where field_id=1;
UPDATE template_details set field_order=20 where field_id=2;
UPDATE template_details set field_order=30 where field_id=3;
UPDATE template_details set field_order=40 where field_id=4;
UPDATE template_details set field_order=50 where field_id=29;
UPDATE template_details set field_order=60 where field_id=5;

UPDATE template_details set field_order=10 where field_id=7;
UPDATE template_details set field_order=20 where field_id=8;
UPDATE template_details set field_order=30 where field_id=9;
UPDATE template_details set field_order=40 where field_id=10;
UPDATE template_details set field_order=50 where field_id=11;
UPDATE template_details set field_order=60 where field_id=13;
update template_details set field_order=70 where field_id=14;

UPDATE template_details set field_order=10 where field_id=20;
UPDATE template_details set field_order=20 where field_id=21;
UPDATE template_details set field_order=30 where field_id=26;

UPDATE template_details set field_order=10 where field_id=22;
UPDATE template_details set field_order=20 where field_id=23;
UPDATE template_details set field_order=30 where field_id=27;

UPDATE template_details set field_order=10 where field_id=24;
UPDATE template_details set field_order=20 where field_id=25;
UPDATE template_details set field_order=30 where field_id=28;
  
COMMIT;
