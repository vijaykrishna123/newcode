package com.capgroup.digital.ce.cwb.controllers;

import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import com.capgroup.digital.ce.cwb.model.UserRequest;
import com.capgroup.digital.ce.cwb.repositories.UserRepository;
import com.capgroup.digital.ce.cwb.services.IUsers;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { UserController.class }, secure = false)
@ActiveProfiles("test")
public class UserControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private IUsers users;
  
  @MockBean
  private UserRepository userRepository;
  
  @MockBean
  private RestTemplate restTemplate;
  
  @Test
  public void addUserShouldReturn201WhenThereIsNoException() throws Exception {
	  
	final UserRequest userRequest = new UserRequest();
	userRequest.setUserInitials("");
	
	final HttpStatus status = HttpStatus.NO_CONTENT;
	given(users.saveUsers(any(UserRequest.class))).willReturn(status);

    this.mockMvc.perform(put("/v1/users")
    	.contentType(MediaType.APPLICATION_JSON)
    	.content(asJsonString(userRequest)))
        .andExpect(status().isNoContent());
  }
  
  public static String asJsonString(final Object obj) {
	    try {
	        return new ObjectMapper().writeValueAsString(obj);
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}

}
