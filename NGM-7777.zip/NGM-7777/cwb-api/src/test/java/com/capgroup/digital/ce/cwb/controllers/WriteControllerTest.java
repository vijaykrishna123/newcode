package com.capgroup.digital.ce.cwb.controllers;

import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.AssignmentDetails;
import com.capgroup.digital.ce.cwb.services.IAssignments;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = WriteController.class, secure = false)
@ActiveProfiles("test")
public class WriteControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @MockBean
  private IAssignments service;

  @Test
  public void getAssignmentDetailsShouldReturn200WhenThereIsNoException() throws Exception {

    given(service.getAssignmentDetails("post:123")).willReturn(new AssignmentDetails());
    this.mockMvc.perform(get("/v1/assignment/post:123"))
                .andExpect(status().isOk());
  }

  @Test
  public void getAssignmentDetailsShouldReturn401WhenAssignmentDoesNotExist() throws Exception {

    given(service.getAssignmentDetails("post:123")).willThrow(new CWBException(""));
    this.mockMvc.perform(get("/v1/assignment/post:123"))
                .andExpect(status().isNotFound());
  }

  @Test
  public void saveAssignmentShouldReturn200WhenAssignmentExists() throws Exception {

    final AssignmentDetails assignmentDetails = new AssignmentDetails();
    given(service.saveAssignments(any(String.class), any(AssignmentDetails.class))).willReturn(assignmentDetails);

    this.mockMvc.perform(put("/v1/assignment/post:123").contentType(MediaType.APPLICATION_JSON)
                                                       .content(
                                                           "{\"assignment\":{},\"copy\":{},\"graphics\":[],\"twitter\":[],\"linkedIn\":[],\"facebook\":[],\"backups\":[]}"))
                .andExpect(status().isOk());
  }

  @Test
  public void saveAssignmentShouldReturn400WhenBodyIsMissing() throws Exception {

    this.mockMvc.perform(put("/v1/assignment/post:123"))
                .andExpect(status().isBadRequest());
  }

}
