package com.capgroup.digital.ce.cwb.services.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import com.capgroup.digital.ce.cwb.exceptions.CWBException;
import com.capgroup.digital.ce.cwb.model.Assignment;
import com.capgroup.digital.ce.cwb.model.entities.AssignmentEntity;
import com.capgroup.digital.ce.cwb.repositories.AssignmentContentRepository;
import com.capgroup.digital.ce.cwb.repositories.AssignmentsRepository;
import com.capgroup.digital.ce.cwb.repositories.BackupsRepository;
import com.capgroup.digital.ce.cwb.repositories.FieldRepository;
import com.capgroup.digital.ce.cwb.repositories.GraphicsRepository;
import com.capgroup.digital.ce.cwb.repositories.SocialMediaRepository;
import com.capgroup.digital.ce.cwb.repositories.TemplateDetailsRepository;
import com.capgroup.digital.ce.cwb.repositories.TemplatesRepository;
import com.capgroup.digital.ce.cwb.repositories.UserRepository;

@ActiveProfiles("test")
@RunWith(MockitoJUnitRunner.class)
public class AssignmentsServiceTest {

  @Mock
  private AssignmentsRepository assignmentsRepository;
  @Mock
  private TemplatesRepository templatesRepository;
  @Mock
  private TemplateDetailsRepository templateDetailsRepository;
  @Mock
  private FieldRepository fieldRepository;
  @Mock
  private AssignmentContentRepository assignmentContentRepository;
  @Mock
  private GraphicsRepository graphicsRepository;
  @Mock
  private BackupsRepository backupsRepository;
  @Mock
  private UserRepository userRepository;
  @Mock
  private SocialMediaRepository socialMediaRepository;
  @InjectMocks
  private AssignmentsService assignmentsService;
  @Rule
  public ExpectedException exception = ExpectedException.none();

  @Before
  public void setUp() {
    assignmentsService = Mockito.spy(this.assignmentsService);
  }

  @Test
  public void createAssignmentShouldReturn200IfAssignmentExists() throws Exception {

    final Assignment assignment = new Assignment();
    assignment.setTemplateName("web_template");
    assignment.setUserInitials("conpask");
    assignment.setPercolateId("post:123");

    // given
    given(templatesRepository.getTemplateId("web_template")).willReturn(5);
    given(userRepository.checkUserExists("conpask")).willReturn(1);
    given(assignmentsRepository.getAssignment("post:123")).willReturn(new AssignmentEntity());

    // when
    final ResponseEntity<Assignment> entity = assignmentsService.createAssignment(assignment);

    // then
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.OK);
  }

  @Test
  public void createAssignmentShouldReturn201ForNewAssignment() throws Exception {

    final Assignment assignment = new Assignment();
    assignment.setTemplateName("web_template");
    assignment.setUserInitials("conpask");
    assignment.setPercolateId("post:123");

    // given
    given(templatesRepository.getTemplateId("web_template")).willReturn(5);
    given(userRepository.checkUserExists("conpask")).willReturn(1);
    given(assignmentsRepository.getAssignment("post:123")).willReturn(null);

    // when
    final ResponseEntity<Assignment> entity = assignmentsService.createAssignment(assignment);

    // then
    assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.CREATED);
  }


  @Test(expected = CWBException.class)
  public void createAssignmentShouldThrowExceptionForInvalidUserInitial() throws Exception {

    final Assignment assignment = new Assignment();
    assignment.setTemplateName("web_template");
    assignment.setUserInitials("InvalidUserInitial");
    assignment.setPercolateId("post:123");

    // given
    given(templatesRepository.getTemplateId("web_template")).willReturn(5);
    given(userRepository.checkUserExists("conpask")).willReturn(0);

    // when
    assignmentsService.createAssignment(assignment);
  }
}
