echo running-apache-post-install

cd /users/cgc/cwb/{{environment}}/apache/httpd-cwb1/bin
./httpdctl stop
./httpdctl start

date >> /tmp/post-install.log
chmod 644 /tmp/post-install.log
