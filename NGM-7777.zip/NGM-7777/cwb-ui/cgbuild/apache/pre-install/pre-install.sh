echo running-apache-pre-install

date >> /tmp/pre-install.log
chmod 644 /tmp/pre-install.log