The two modules were obtained from: https://www.adobeaemcloud.com/content/companies/public/adobe/dispatcher/dispatcher.html

Win:
https://www.adobeaemcloud.com/content/companies/public/adobe/dispatcher/dispatcher/_jcr_content/top/download_38/file.res/dispatcher-apache2.2-windows-x86-ssl09-4.1.8.zip

Linux:
https://www.adobeaemcloud.com/content/companies/public/adobe/dispatcher/dispatcher/_jcr_content/top/download_28/file.res/dispatcher-apache2.2-linux-x86-64-ssl10-4.1.8.tar.gz
