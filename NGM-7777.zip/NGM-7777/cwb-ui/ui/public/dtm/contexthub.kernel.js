window.ContextHubKernelConfig={debug:false,initializationTimeout:2000,stores:{surferinfo:{type:"contexthub.surferinfo",required:true},profile:{type:"granite.profile",required:true},emulators:{type:"granite.emulators",required:true},eventdata:{type:"contexthub.eventdata",required:true,config:{events:[]}},pagedata:{type:"contexthub.pagedata",required:true},metadata:{type:"campaign.metadata",required:false},seeddata:{type:"campaign.seeddata",required:false},"digitalData-component":{type:"contexthub.digitalData-component",required:true},"digitalData-event":{type:"contexthub.digitalData-event",required:true},"digitalData-page":{type:"contexthub.digitalData-page",required:true},"digitalData-user":{type:"contexthub.digitalData-user",required:true}}};
window.ContextHubJQ=window.jQuery.noConflict(true);
/*!
 * ### OVERLAY ###
 * Expose the ContextHub jQuery to the global scope
 */
;
window.jQuery=window.$=window.$CQ=window.ContextHubJQ;
(function(){if(!Function.prototype.bind){Function.prototype.bind=function a(d){var e=this;
var b=[].slice.call(arguments,1);
var c=function(){var h;
if(this instanceof c){var i=function(){};
i.prototype=e.prototype;
var g=new i();
var f=e.apply(g,b.concat([].slice.call(arguments)));
h=(Object(f)===f)?f:g
}else{h=e.apply(d,b.concat([].slice.call(arguments)))
}return h
};
return c
}
}}());
(function(c){c.ContextHub=c.ContextHub||{};
var b=function(f,e){return((c.ContextHubKernelConfig.debug||e)&&f)?Function.prototype.bind.call(f,c.console):function(){}
};
var d=function(g){var f=c.console||{};
var h=function(){};
ContextHub.console={log:b(f.log),warn:b(f.warn),info:b(f.info),error:b(f.error,true),debug:b(f.debug),time:b(f.time),timeEnd:b(f.timeEnd),timeStamp:b(f.timeStamp)};
var e=g||"info";
if(e==="info"){ContextHub.console.info=h;
ContextHub.console.debug=h
}if(e==="debug"){ContextHub.console.log=h;
ContextHub.console.warn=h
}};
function a(e,f){if(typeof e!=="undefined"){c.ContextHubKernelConfig.debug=e===true;
d(f)
}return !!c.ContextHubKernelConfig.debug 
}d();
ContextHub.debug=a
}(window));
(function($,window){window.ContextHub=window.ContextHub||{};
window.ContextHub.Utils=window.ContextHub.Utils||{};
window.ContextHub.Utils.JSON=window.ContextHub.Utils.JSON||{};
var returnUnicode=function(character){return"\\u"+("0000"+character.charCodeAt(0).toString(16)).slice(-4)
};
var quoteString=function(str){var sensitiveCharacters=/["\\\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
var replacementMapping={"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"};
var escapeCharacter=function(character){var mapped=replacementMapping[character];
return mapped?mapped:returnUnicode(character)
};
return'"'+str.replace(sensitiveCharacters,escapeCharacter)+'"'
};
var serializeDate=function(date){var year=date.getUTCFullYear();
var month=ContextHub.Shared.pad(date.getUTCMonth()+1);
var day=ContextHub.Shared.pad(date.getUTCDate());
var hours=ContextHub.Shared.pad(date.getUTCHours());
var minutes=ContextHub.Shared.pad(date.getUTCMinutes());
var seconds=ContextHub.Shared.pad(date.getUTCSeconds());
var milliseconds=ContextHub.Shared.pad(date.getUTCMilliseconds(),3);
return'"'+year+"-"+month+"-"+day+"T"+hours+":"+minutes+":"+seconds+"."+milliseconds+'Z"'
};
var serializeArray=function(array){var result=[];
for(var idx=0;
idx<array.length;
idx++){result.push(stringify(array[idx])||"null")
}return"["+result.join(",")+"]"
};
var serializeObject=function(object){var result=[];
for(var item in object){if(Object.prototype.hasOwnProperty.call(object,item)){var type=typeof item;
if(type!=="number"&&type!=="string"){continue
}var value=object[item];
type=typeof value;
if(type!=="function"&&type!=="undefined"){result.push(quoteString(item)+":"+stringify(value))
}}}return"{"+result.join(",")+"}"
};
var stringify=function(data){var type=$.type(data);
if(type==="object"&&$.isArray(data)){type="array"
}switch(type){case"null":case"boolean":return String(data);
case"undefined":return undefined;
case"array":return serializeArray(data);
case"number":return String(isFinite(data)?data:"null");
case"string":return quoteString(data);
case"date":return serializeDate(data);
case"regexp":return"{}";
case"function":return undefined;
case"object":default:return serializeObject(data)
}};
var parse=function(data){var unicodeExceptions=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
data=String(data).replace(unicodeExceptions,returnUnicode);
var filtered=data.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,"@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,"]").replace(/(?:^|:|,)(?:\s*\[)+/g,"");
return(/^[\],:{}\s]*$/.test(filtered))?eval("("+data+")"):{}
};
var nativeJSONSupported=window.JSON&&JSON.stringify&&JSON.parse;
ContextHub.Utils.JSON.stringify=nativeJSONSupported?JSON.stringify:stringify;
ContextHub.Utils.JSON.parse=function(data){var json;
try{json=(nativeJSONSupported?JSON.parse:parse)(data)
}catch(e){json={}
}return json
}
}(ContextHubJQ,window));
ContextHub.console.log("[loading] contexthub.constants - ContextHub.constants.js");
(function(b){var a={EVENT_NAMESPACE:"ch",EVENT_ALL_STORES_READY:"all-stores-ready",EVENT_STORES_PARTIALLY_READY:"stores-partially-ready",EVENT_STORE_REGISTERED:"store-registered",EVENT_STORE_READY:"store-ready",EVENT_STORE_UPDATED:"store-updated",PERSISTENCE_CONTAINER_NAME:"ContextHubPersistence",SERVICE_RAW_RESPONSE_KEY:"/_/raw-response",SERVICE_RESPONSE_TIME_KEY:"/_/response-time",SERVICE_LAST_URL_KEY:"/_/url",IS_CONTAINER_EXPANDED:"/_/container-expanded"};
ContextHub.Constants=b.extend(true,ContextHub.Constants,a);
ContextHub.console.time("contexthub.js");
ContextHub.console.timeStamp("contexthub.start")
}(ContextHubJQ));
ContextHub.console.log("[loading] contexthub.constants - ContextHub.constants.deprecated.js");
(function(b){window.ContextHub=window.ContextHub||{};
var a={EVENT_INITIALIZED:ContextHub.Constants.EVENT_ALL_STORES_READY,EVENT_REGISTER:ContextHub.Constants.EVENT_STORE_REGISTERED,EVENT_DATA_UPDATE:ContextHub.Constants.EVENT_STORE_UPDATED,CONTAINER_VISIBLE:ContextHub.Constants.IS_CONTAINER_EXPANDED,EVENT_CONFIG_LOADED:""};
ContextHub.Constants=b.extend(true,ContextHub.Constants,a)
}(ContextHubJQ));
(function(c,b){b.ContextHub.Shared=b.ContextHub.Shared||{};
ContextHub.Shared.pad=function(f,e){var i=e||2;
var d=String(f);
var h=i-d.length;
if(h>0){var g=Math.pow(10,Math.min(h,20));
d=String(g).slice(1)+d
}return d
};
var a={};
ContextHub.Shared.timers={start:function(e){var d=e||"id"+Math.random();
a[d]=new Date().getTime();
return d
},finish:function(e){var d=a[e];
return d?(new Date().getTime()-d):0
}};
ContextHub.Shared.timestamp=function(){var g=new Date();
var i=g.getYear()+1900;
var j=ContextHub.Shared.pad(g.getMonth()+1);
var e=ContextHub.Shared.pad(g.getDate());
var d=ContextHub.Shared.pad(g.getHours());
var h=ContextHub.Shared.pad(g.getMinutes());
var k=ContextHub.Shared.pad(g.getSeconds());
var f=ContextHub.Shared.pad(g.getMilliseconds(),3);
return i+"-"+j+"-"+e+" "+d+":"+h+":"+k+"."+f
};
ContextHub.Shared.uuid=function(){function d(){return Math.floor((1+Math.random())*65536).toString(16).substring(1)
}return d()+d()+"-"+d()+"-"+d()+"-"+d()+"-"+d()+d()+d()
};
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.shared - ContextHub.Shared.js")
}(ContextHubJQ,window));
ContextHubJQ(function(){ContextHub.console.log(ContextHub.Shared.timestamp(),"[event] DOM ready")
});
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.shared - ContextHub.Shared.CookieContainer.js");
(function(c,b){b.ContextHub.Shared=b.ContextHub.Shared||{};
b.ContextHub.Shared.CookieContainer={};
var a=b.ContextHub.Shared.CookieContainer;
var d=function(f){var h=ContextHub.Utils.Cookie.getItem(c.trim(f))||"";
var g=h.split(/\|/);
var e={};
c.each(g,function(m,i){var l=i.match(/(^.*?):=(.*)/);
if(l&&(l.length===3)){l.shift();
var j=l.shift();
var k=l.shift();
e[j]=decodeURIComponent(k)
}});
return e
};
a.setItem=function(e,h,j){var f=c.trim(e);
var i=d(f);
var g=[];
if(f.length<=0){return
}if((j===null)||(typeof j==="undefined")){delete i[h]
}else{i[h]=j
}c.each(i,function(l,k){g.push(l+":="+encodeURIComponent(k))
});
ContextHub.Utils.Cookie.setItem(f,g.join("|"))
};
a.getItem=function(e,f){var g=d(e);
return g[f]
};
a.removeItem=function(e,f){a.setItem(e,f,null)
}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.utils - ContextHub.Utils.cookie.js");
(function(f,i){i.ContextHub.Utils=i.ContextHub.Utils||{};
var e={path:"/",expires:undefined,domain:undefined,secure:false,trimUndefined:true};
var g=function(){return i.document.cookie?i.document.cookie.split(/;/):[]
};
var c=function(o){return decodeURIComponent(f.trim(o.split(/\=/)[0]))
};
var b=function(o){return decodeURIComponent(f.trim(o.split(/\=/).slice(1).join("=")))
};
var k=function(r,p){var o=f.type(p);
if(o==="object"&&f.isArray(p)){o="array"
}switch(o){case"regexp":return p.test(r);
case"string":return r===p;
case"function":return p(r)===true;
case"array":var q=false;
f(p).each(function(s,t){q=k(r,t);
return !q
});
return q;
default:return false
}};
var n=function(o){var r=typeof o==="undefined";
var q=g();
var p=[];
f(q).each(function(s,u){var t=c(u);
if(t.length&&(f.inArray(t,p)===-1)&&(r||k(t,o))){p.push(t)
}});
return p.sort()
};
var h=function(r,u,t){if(typeof r==="undefined"){return false
}var s=f.type(u);
var p=f.extend(true,{},e,t);
var v=(p.trimUndefined&&(s==="undefined"||s==="null"))?"":u;
switch(f.type(p.expires)){case"date":break;
case"number":var o=new Date();
o.setDate(o.getDate()+p.expires);
p.expires=o;
break;
default:p.expires=undefined
}var q=[encodeURIComponent(r),"=",encodeURIComponent(v),p.expires?("; expires="+p.expires.toUTCString()):"",p.domain?("; domain="+p.domain):"",p.path?("; path="+p.path):"",p.secure?"; secure":""].join("");
i.document.cookie=q;
return q
};
var m=function(p){var q=g();
var o=null;
f(q).each(function(r,t){var u=b(t);
var s=c(t);
if(s===p){o=u
}return o===null
});
return o
};
var a=function(o){var p={};
f(n(o)).each(function(q,r){var t=m(r);
var s=f.type(t);
if(s!=="undefined"&&s!=="null"){p[r]=t
}});
return p
};
var j=function(o){return m(o)!==null
};
var l=function(p,o){h(p,"",f.extend({},o,{expires:-1}))
};
var d=function(p,o){f(n(p)).each(function(q,r){l(r,o)
})
};
ContextHub.Utils.Cookie={setItem:h,getItem:m,getAllItems:a,getKeys:n,exists:j,removeItem:l,vanish:d}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.utils - ContextHub.Utils.json.js");
(function(c,h){h.ContextHub.Utils=h.ContextHub.Utils||{};
var e=function(m){var l=null;
if(typeof m==="string"){l=m.split(/(?:\s*\/+\s*)+/);
if(l[0]===""){l.shift()
}if(l.length&&(l[l.length-1]==="")){l.pop()
}}return l
};
var f=function(l,m,p){m=e(m);
l=c.extend(true,{},l);
if(m){var o=l;
var n={};
c.each(m,function(q,s){n=o;
var r=c.type(o[s]);
if(r!=="object"&&r!=="array"){o[s]={}
}o=o[s]
});
n[m.slice(-1)]=p
}return l
};
var k=function(l,m){var n=null;
m=e(m);
if(m){n=l;
c.each(m,function(o,p){n=n[p];
return(n!==null)&&(typeof n!=="undefined")
})
}return(typeof n==="undefined")?null:n
};
var i=function(l,n){n=e(n);
l=c.extend(true,{},l);
if(n){var s={object:true,array:true};
var q=l;
var m=[l];
c.each(n.slice(0,-1),function(t,u){q=q[u];
m.push(q);
return s[c.type(q)]===true
});
if(q){delete q[n.slice(-1)];
n.pop();
m.pop();
while(m&&n&&(m.length>0)&&(n.length>0)){var r=n.pop();
q=m.pop();
var p=q[r];
var o=c.type(p);
if(((o==="object")||(o==="array"))&&c.isEmptyObject(p)){delete q[r]
}else{break
}}}}return l
};
var a=/^\[object (DIV|DOM|CSS|HTML|NamedNode|Node|Window)/;
var g=function(l){if(l){if(l instanceof h.Node){return true
}if((l instanceof c)||(typeof l.css==="function")){return true
}if((typeof l.toString==="function")&&a.test(l.toString())){return true
}}return false
};
var j=function(v,s,n,l,m){s=s||"/";
m=m||0;
var w;
var u=[];
var q=c.type(v);
if((q==="object")&&g(v)){q="invalid"
}if((q==="object")||(q==="array")){if(l){v=ContextHub.Utils.JSON.tree.cleanup(v)
}for(var t in v){if(!v.hasOwnProperty(t)){continue
}var r=v[t];
var p=s+t;
var o=c.type(r);
u.push(p);
if((o==="object")&&g(r)){o="invalid"
}if((o==="object")||(o==="array")){c.merge(u,j(r,p+"/",null,l,m+1))
}}}if(m===0){w=(typeof n==="function")?u.sort(n):u.sort()
}else{w=u
}return w
};
var b=function(l){l=c.extend(true,{},l);
var m=j(l,null,function(o,n){var p=o.split(/\//).length;
var q=n.split(/\//).length;
if(p!==q){return(p>q)?-1:1
}return(o===n)?0:((o>n)?1:-1)
});
c.each(m,function(n,p){var q=k(l,p);
var o=c.type(q);
if((o==="object"||o==="array")&&c.isEmptyObject(q)){l=i(l,p)
}});
return l
};
var d=function(l,m){return c.extend(true,{},l,m)
};
c.extend(ContextHub.Utils.JSON,{tree:{sanitizeKey:e,setItem:f,getItem:k,removeItem:i,getKeys:j,cleanup:b,addAllItems:d}})
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.utils - ContextHub.Utils.eventing.js");
(function(h,m){m.ContextHub.Utils=m.ContextHub.Utils||{};
var v=(function(){var E=h.grep([m.requestAnimationFrame,m.msRequestAnimationFrame,m.mozRequestAnimationFrame,m.webkitRequestAnimationFrame,m.oRequestAnimationFrame],h.isFunction).shift();
if(!E){var D=0;
E=function(I){var F=new Date().getTime();
var H=Math.max(0,16-(F-D));
var G=m.setTimeout(function(){I(F+H)
},H);
D=F+H;
return G
}
}return E
})();
var z=(function(){var D=h.grep([m.cancelAnimationFrame,m.cancelRequestAnimationFrame,m.msCancelRequestAnimationFrame,m.mozCancelRequestAnimationFrame,m.webkitCancelRequestAnimationFrame,m.oCancelRequestAnimationFrame],h.isFunction).shift();
if(!D){D=function(E){m.clearTimeout(E)
}
}return D
})();
var g={};
var q=function(E,F,D){E=h.trim(E);
if(E.length){D=h.extend({},{defer:this.config.defer},D);
l.call(this,h.trim(this.config.namespace),new x(E,F,D))
}};
var l=function(F,H){var E="/"+F+"/"+H.channel;
var G=ContextHub.Utils.JSON.tree.getItem(this.queue,E)||{};
G=h.extend({},{executeAt:null,data:[]},H._,G);
var D=new Date().getTime()+H.defer;
if(!G.executeAt||(H.defer===0)||(G.executeAt>D)){G.executeAt=D
}if(!h.isEmptyObject(H.data)){G.data.push(H.data)
}this.queue=ContextHub.Utils.JSON.tree.setItem(this.queue,E,G);
this.eventingCounter=H.defer?this.eventingCounter:0;
var I=this.queueIsEmpty===true;
this.queueIsEmpty=false;
if(I){this.eventingMonitor()
}};
var f=function(){return this.queue
};
var r=function(D,E){D.list.push(E.key);
D.hash[E.key]=E
};
var n=function(E){var F=h.extend(true,{},E,{data:[]});
var H={};
var K=function(W,U,T){var X=W.key||("temp"+Math.random());
var V=H[X];
var S=(V||{}).old||null;
H[X]=h.extend(true,{},W);
H[X]._idx=parseFloat(U+"."+(T||0));
if(V){H[X].old=S
}};
for(var N=0;
N<E.data.length;
N++){var Q=E.data[N];
var R=ContextHub.Utils.JSON.tree.getKeys(Q.old);
var I=ContextHub.Utils.JSON.tree.getKeys(Q.value);
if(R.length||I.length){var J=(Q.key==="/")?"":Q.key;
var D=1;
var L;
var O;
for(L=0;
L<R.length;
L++,D++){O=R[L];
K({key:J+O,value:null,old:ContextHub.Utils.JSON.tree.getItem(Q.old,O),action:"remove"},N,D)
}for(L=0;
L<I.length;
L++,D++){O=I[L];
K({key:J+O,value:ContextHub.Utils.JSON.tree.getItem(Q.value,O),old:ContextHub.Utils.JSON.tree.getItem(Q.old||{},O),action:"set"},N,D)
}}else{var G=!!(Q.key&&Q.action)&&!/^\/_\//.test(Q.key);
var M=H[Q.key]||{};
if(G&&(M.old===Q.value)){delete H[Q.key]
}else{K(Q,N)
}}}H=h.map(H,function(S){return S
}).sort(function(T,S){return T._idx-S._idx
});
var P={set:{list:[],hash:{}},removed:{list:[],hash:{}},all:{list:[],hash:{}}};
h.each(H,function(T,S){delete S._idx;
if(S.key&&S.action){r(this.keys.all,S);
if(S.action==="set"){r(this.keys.set,S)
}if(S.action==="remove"){r(this.keys.removed,S)
}}}.bind({keys:P}));
F.data=H;
F.keys=P;
return F
};
var t=function(D){var E=D;
if(E.indexOf(this.config.namespace+"-")!==0){E=this.config.namespace+"-"+E
}if(E.indexOf(".")!==-1){E=E.split(/\./).shift()
}return g[E]===true
};
var b=function(){if(!this.windowBroadcast.initialized){var D=m;
var E=m.parent;
try{while(D.location.origin===E.location.origin){D=E;
E=E.parent;
if(D===m.top){break
}}}catch(F){}try{this.windowBroadcast.top=(this.config.broadcast===D)?null:D
}catch(F){}this.windowBroadcast.initialized=true
}return this.windowBroadcast.top
};
var C=function(M,D){var E=this.config.namespace+"-"+M;
var H=D.duration?"("+D.duration+") ":"";
var J=ContextHub.debug();
var O=h(this.config.broadcast);
var I=b.call(this);
D=n(D);
D.event=E;
if(D.overlay){D=h.extend(true,D,D.overlay)
}if(!D.muteWhenNoData||(D.muteWhenNoData&&(D.data.length>0))){for(var G=E.split(/:/),K=M.split(/:/),L=G.length;
L>0;
L--){D.channel=K.slice(0,L).join(":");
var N=G.slice(0,L).join(":");
O.trigger(N,D);
if(I&&I.document){var F=I.document.createEvent("Event");
F.initEvent(N,true,true);
F.data=D;
I.dispatchEvent(F)
}if(J){ContextHub.console.debug(ContextHub.Shared.timestamp(),N,"-",D)
}g[N]=true
}ContextHub.console.log(ContextHub.Shared.timestamp(),"[event]",E,H+"-",D)
}delete (this.queue[this.config.namespace]||{})[M];
this.queueIsEmpty=h.isEmptyObject(this.queue[this.config.namespace])
};
var s=function(){if(!this.running||this.queueIsEmpty){return
}if((this.eventingCounter++%this.periodicity)===0){h.each(this.queue[this.config.namespace]||{},function(D,E){if(!E.paused&&new Date().getTime()>E.executeAt){C.call(this,D,E)
}}.bind(this))
}v(this.eventingMonitor)
};
var i=function(){this.running=true;
this.eventingMonitor()
};
var a=function(){this.running=false
};
var d=function(){return this.running
};
var c=function(){this.queue={}
};
var y=function(E,D,F){this.queue=ContextHub.Utils.JSON.tree.setItem(this.queue,"/"+this.config.namespace+"/"+E+"/"+D,F)
};
var w=function(E,D){return ContextHub.Utils.JSON.tree.getItem(this.queue,"/"+this.config.namespace+"/"+E+"/"+D)
};
var u=function(D){y.call(this,D,"executeAt",0)
};
var j=function(D){y.call(this,D,"paused",true)
};
var e=function(D){y.call(this,D,"paused",undefined)
};
var k=function(D){return w.call(this,D,"paused")===true
};
var p=function(F,H,E){var J=E?("."+E):"";
var G=(typeof F==="string")?F.split(/ /):F;
for(var D=0;
D<G.length;
D++){var I=G[D];
if(I.indexOf(H+"-")!==0){G[D]=H+"-"+I+J
}}return G.join(" ")
};
var o=function(G,I,F,E){G=p(G,this.config.namespace,F);
h(this.config.broadcast).on(G,I);
if(E){var D=false;
var H=this;
h.each(G.split(/ /),function(J,K){D=t.call(H,K);
return D!==true
});
if(D){I()
}}};
var A=function(G,I,F,E){var D=false;
G=p(G,this.config.namespace,F);
if(E){var H=this;
h.each(G.split(/ /),function(J,K){D=t.call(H,K);
return D!==true
})
}if(D){I()
}else{h(this.config.broadcast).one(G,I)
}};
var B=function(E,D){E=p(E,this.config.namespace,D);
h(this.config.broadcast).off(E)
};
function x(E,F,D){return{channel:E,data:F,defer:D.defer,_:D._||{}}
}ContextHub.Utils.Eventing=function(D){this.config=h.extend(true,{},ContextHub.Utils.Eventing.defaultConfig,D);
this.eventingCounter=0;
this.periodicity=Math.floor(Math.max(16,this.config.periodicity)/16);
this.eventingMonitor=s.bind(this);
this.windowBroadcast={top:null,initialized:false};
c.call(this);
if(this.config.autoStart){i.call(this)
}else{a.call(this)
}return{log:this.log,trigger:q.bind(this),getQueue:f.bind(this),isRunning:d.bind(this),enableEventing:i.bind(this),disableEventing:a.bind(this),alreadyTriggered:t.bind(this),clearQueue:c.bind(this),flush:u.bind(this),pause:j.bind(this),resume:e.bind(this),isPaused:k.bind(this),once:A.bind(this),on:o.bind(this),off:B.bind(this),namespace:this.config.namespace,broadcast:this.config.broadcast}
};
ContextHub.Utils.Eventing.defaultConfig={autoStart:true,defer:100,periodicity:16*12,namespace:ContextHub.Constants.EVENT_NAMESPACE,broadcast:m}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.utils - ContextHub.Utils.persistence.js");
(function(e,f){f.ContextHub.Utils=f.ContextHub.Utils||{};
var i=new RegExp("^/*store($|/)");
var b=new RegExp("^/*store/(emulators|surferinfo)($|/)");
function g(l,k,m){return e.extend(true,{},{name:l,isSupported:m||function(){return true
},getInterface:function(o){var n=k(o);
return{name:l,getItem:n.getItem,setItem:n.setItem,removeItem:n.removeItem,getKeys:n.getKeys,getTree:n.getTree}
}})
}g.prototype.setItem=function(m,l,k,o){var p=(k||"").match(i)&&!(k||"").match(b);
if(p&&ContextHub.isOptedOut()){return
}var n=l();
n=ContextHub.Utils.JSON.tree.setItem(n,k,o);
m(n)
};
g.prototype.getItem=function(l,k){var n=(k||"").match(i)&&!(k||"").match(b);
if(n&&ContextHub.isOptedOut()){return null
}var m=l();
return ContextHub.Utils.JSON.tree.getItem(m,k)
};
g.prototype.removeItem=function(m,l,k){var o=(k||"").match(i)&&!(k||"").match(b);
if(o&&ContextHub.isOptedOut()){return null
}var n=l();
n=ContextHub.Utils.JSON.tree.removeItem(n,k);
m(n)
};
var d=new g("null",function(){return{setItem:function(){return false
},getItem:function(){return{}
},removeItem:function(){},getKeys:function(){return[]
},getTree:function(){return{}
}}
});
var h=function(){var k=false;
e(e.merge([this.config.mode],this.config.fallback||[])).each(function(l,m){if(m&&m.isSupported()){k=true;
this.config.mode=m
}return !k
}.bind(this));
if(!k){this.config.mode=d
}return k
};
ContextHub.Utils.Persistence=function(l){this.config=e.extend(true,{},ContextHub.Utils.Persistence.defaultConfig,l);
var m=this.config.mode;
var n=h.call(this);
var k={initialized:n,usingFallback:(this.config.mode!==m),window:this.config.window,container:this.config.container};
e.extend(k,new this.config.mode.getInterface(this.config));
return k
};
ContextHub.Utils.Persistence.prototype.PersistenceMode=g;
ContextHub.Utils.Persistence.Modes={};
var j=function(m,l){var k=g.prototype.setItem.bind(null,m,l);
var p=g.prototype.getItem.bind(null,l);
var n=g.prototype.removeItem.bind(null,m,l);
var o=function(){var q=l();
return ContextHub.Utils.JSON.tree.getKeys(q)
};
return{setItem:k,getItem:p,removeItem:n,getKeys:o,getTree:l}
};
ContextHub.Utils.Persistence.Modes.LOCAL=new g("local",function c(l){var k=l.container;
var o=l.window.localStorage;
var n=function(){var p=null;
try{p=o.getItem(k)
}catch(q){p=null
}p=ContextHub.Utils.JSON.parse(p);
return(e.type(p)==="object")?p:{}
};
var m=function(p){var q=ContextHub.Utils.JSON.stringify(p);
o.setItem(k,q)
};
return j(m,n)
},function a(){var l="contexthub.test."+this.name;
var k;
try{var n=f.localStorage;
n.setItem(l,l);
k=n.getItem(l)===l;
n.removeItem(l)
}catch(m){k=false
}return k
});
ContextHub.Utils.Persistence.Modes.SESSION=new g("session",function c(l){var k=l.container;
var o=l.window.sessionStorage;
var n=function(){var p=o.getItem(k);
p=ContextHub.Utils.JSON.parse(p);
return(e.type(p)==="object")?p:{}
};
var m=function(p){var q=ContextHub.Utils.JSON.stringify(p);
o.setItem(k,q)
};
return j(m,n)
},function a(){var l="contexthub.test."+this.name;
var k;
try{var n=f.sessionStorage;
n.setItem(l,l);
k=n.getItem(l)===l;
n.removeItem(l)
}catch(m){k=false
}return k
});
ContextHub.Utils.Persistence.Modes.COOKIE=new g("cookie",function c(l){var k=l.container;
var o=ContextHub.Utils.Cookie;
var n=function(){var p=o.getItem(k);
p=ContextHub.Utils.JSON.parse(p);
return(e.type(p)==="object")?p:{}
};
var m=function(p){var q=ContextHub.Utils.JSON.stringify(p);
o.setItem(k,q)
};
return j(m,n)
},function a(){var l="contexthub.test."+this.name;
f.document.cookie=l+"=1";
var k=f.document.cookie.indexOf(l)!==-1;
f.document.cookie=l+"=; expires=Thu, 01-Jan-1970 00:00:01 GMT";
return k
});
ContextHub.Utils.Persistence.Modes.WINDOW=new g("window",function c(l){var k=l.container;
var o=l.window;
var n=function(){var p=ContextHub.Utils.JSON.parse(o.name)[k];
return(e.type(p)==="object")?p:{}
};
var m=function(p){var q=ContextHub.Utils.JSON.parse(o.name);
q[k]=p;
o.name=ContextHub.Utils.JSON.stringify(q)
};
return j(m,n)
});
ContextHub.Utils.Persistence.defaultConfig={container:ContextHub.Constants.PERSISTENCE_CONTAINER_NAME,window:f,mode:ContextHub.Utils.Persistence.Modes.LOCAL,fallback:[ContextHub.Utils.Persistence.Modes.SESSION,ContextHub.Utils.Persistence.Modes.WINDOW]}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.utils - ContextHub.Utils.storeCandidates.js");
(function(g,d){d.ContextHub.Utils=d.ContextHub.Utils||{};
var f={};
var c=function(){return true
};
var e=function(j,l,k,i){var n;
var m={store:j,priority:k,applies:i||c};
f[l]=f[l]||[];
n=f[l];
n.push(m);
n.sort(function(p,o){return o.priority-p.priority
})
};
var b=function(l){var k=f[l.type]||[];
var i;
var j;
for(i=0;
i<k.length;
i++){j=k[i];
if(j.applies(j.store,j.priority)){return j.store
}}if(l.required===true){ContextHub.console.error('No suitable store implementation found for type: "'+l.type+'".')
}};
var h=function(j){var i=f;
if(j){i=i[j]||[]
}return i
};
var a=function(){var i=[];
g.each(f,function(j){i.push(j)
});
return i.sort()
};
ContextHub.Utils.storeCandidates={registerStoreCandidate:e,getStoreFromCandidates:b,getRegisteredCandidates:h,getSupportedStoreTypes:a}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.utils - ContextHub.Utils.inheritance.js");
(function(a){a.ContextHub.Utils=a.ContextHub.Utils||{};
ContextHub.Utils.inheritance={inherit:function(e,b){e.prototype=new b();
e.prototype.constructor=b;
var d={};
var c;
e.prototype.uber=function(g){d[g]=d[g]||0;
var j;
var f;
var h;
var i=d[g];
if(i){h=b.prototype;
while(i){h=h.constructor.prototype;
i--
}if(h&&(h[g]===c)){h=h.constructor.prototype||{}
}j=h[g]
}else{h=this;
while(h&&!h.hasOwnProperty(g)){h=h.__proto__||h.constructor.prototype
}j=h[g];
if(j===this[g]){j=(h.__proto__||h.constructor.prototype)[g]
}}d[g]++;
c=j;
if(typeof j==="function"){f=j.apply(this,Array.prototype.slice.apply(arguments,[1]))
}c=null;
d[g]--;
return f
};
return e
},newInstance:function(b,c){return new (b.bind.apply(b,[null].concat([].slice.call(c))))()
}}
}(window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.kernel - ContextHub.js");
(function(e,h){if(typeof h.ContextHubKernelConfig==="undefined"){ContextHub.console.error("[-] ContextHub configuration is not set!")
}h.ContextHub=e.extend({version:"0.2.38-20170215-2314"},h.ContextHub);
var d={};
var n=[];
var g=[];
var v=new ContextHub.Utils.Persistence();
var o=new ContextHub.Utils.Eventing(h.ContextHubKernelConfig.eventing);
var f=null;
var c=function(z,x){if(e.type(x)==="object"){d=d||{};
if(!d[z]){d[z]=x;
ContextHub.console.timeStamp('registering "'+z+'"');
var A=x.getKeys();
var y={keys:{all:{hash:{},list:A}}};
e.each(A,function(B,C){y.keys.all.hash[C]=true
});
this.eventing.trigger(ContextHub.Constants.EVENT_STORE_REGISTERED+":"+z,{},{defer:0,_:{action:"store-registered",store:z,registeredAt:new Date().getTime(),overlay:y}});
if(!x.queryService){x.announceReadiness()
}}}};
var m=function(){return d
};
var q=function(x){return((e.type(x)==="string")&&x.length)?ContextHub.Utils.JSON.tree.getItem(d,x):null
};
var t=function(x){return this.getItem("/store/"+x)
};
var l=function(x,y){this.setItem("/store/"+x,y)
};
var r=function(A){var C=ContextHub.persistence;
var z=A;
var B=ContextHub.Utils.JSON.tree.sanitizeKey(z);
if(B){var y=B.shift();
if(y==="store"){y=B.shift()
}var x=ContextHub.getStore(y);
if(x){C=x;
z="/"+B.join("/")
}}return{storage:C,storeProperty:z}
};
var j=function(x){var y=r(x);
return y.storage.getItem(y.storeProperty)
};
var b=function(x,z){var y=r(x);
y.storage.setItem(y.storeProperty,z)
};
var u=function(x){var y=r(x);
y.storage.removeItem(y.storeProperty)
};
var k=function(y){var x={};
var z=0;
var A=[];
e.each(y,function(B,C){if(C){var E=ContextHub.Utils.JSON.tree.sanitizeKey(C);
if(E[0]==="store"){C="/"+E.slice(1).join("/")
}else{E.unshift("store")
}E="/"+E.join("/");
var D=ContextHub.getItem(E);
if(D!==null){z++;
x=ContextHub.Utils.JSON.tree.setItem(x,C,D);
A.push(C)
}}});
x._length=z;
x._keys=A;
return x
};
var i=function(C,y,B,F){if(e.type(C)==="string"){C=[C]
}var z=[];
e.each(C,function(I,H){var G="/"+ContextHub.Utils.JSON.tree.sanitizeKey(H).join("/");
z.push(G)
});
C=z;
y=y||function(){};
B=B||function(){};
var A=k(C);
if(A._length===C.length){y(A);
return
}var D=0;
var E=false;
var x=function(H){if(E){return true
}var G=k(C);
var I=null;
if(e.type(H)==="undefined"){I=B
}if(G._length===C.length){I=y;
h.clearTimeout(D)
}if(I){E=true;
I(G)
}return E
};
D=h.setTimeout(x,F);
n.push(x)
};
var s=function(){var x=o.isPaused();
this.eventing.pause();
e.each(m(),function(y,z){z.clean()
});
if(!x){this.eventing.resume()
}};
var p=function(y){var x=o.isPaused();
ContextHub.isOptedOut(true);
ContextHub.eventing.pause();
e.each(m(),function(z,A){A.reset(y)
});
if(!x){ContextHub.eventing.resume()
}};
var w=function(D,y,B,F){if(e.type(D)==="string"){D=[D]
}var z=[];
e.each(D,function(I,H){var G="/"+ContextHub.Utils.JSON.tree.sanitizeKey(H).join("/");
z.push(G)
});
D=z;
y=y||function(){};
B=B||function(){};
var A=k(D);
var C=true;
if(A._length===D.length){C=false;
y(A)
}var E=0;
var x=function(J,H){if(H){var M={};
var L=true;
e.each(H,function(N){M=ContextHub.Utils.JSON.tree.setItem(M,N,true)
});
for(var G=0;
G<D.length;
G++){if(ContextHub.Utils.JSON.tree.getItem(M,D[G])){L=false;
break
}}if(L){return
}}var I=k(D);
var K=B;
if(I._length===D.length){K=y;
h.clearTimeout(E)
}K(I)
};
if(C){E=h.setTimeout(x,F)
}g.push(x)
};
var a=function(x){if(x){f=null
}if(f===null){f=ContextHub.Utils.Cookie.getItem("cq-opt-out")!==null
}return f
};
e.extend(ContextHub,{persistence:v,eventing:o,registerStore:c,getAllStores:m,getStore:q,set:l,get:t,getItem:j,setItem:b,removeItem:u,cleanAllStores:s,resetAllStores:p,sync:i,bind:w,isOptedOut:a});
ContextHub.eventing.on(ContextHub.Constants.EVENT_STORE_UPDATED,function(y,z){e.each(n||[],function(B,A){if(A&&A(B)){delete n[B];
n=e.grep(n,e.isFunction)
}});
if((g||[]).length){var x={};
if(z.keys){e.each(z.keys.all.list,function(A,B){x["/"+z.store+B]=true
})
}e.each(g||[],function(B,A){if(A){A(B,x)
}})
}},"sync-bind")
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.kernel - task.stores-initialization-watcher.js");
(function(d,b){var a="initialization-watcher";
var c={};
var e=b.setTimeout(function(){var f={};
d.each(b.ContextHubKernelConfig.stores,function(g){if(!c[g]){f[g]=true
}});
ContextHub.eventing.trigger(ContextHub.Constants.EVENT_STORES_PARTIALLY_READY,{},{defer:0,_:{wasReadyAt:new Date().getTime(),storesReady:c,storesNotReady:f}});
ContextHub.eventing.off(ContextHub.Constants.EVENT_STORE_READY,a)
},b.ContextHubKernelConfig.initializationTimeout);
ContextHub.eventing.on(ContextHub.Constants.EVENT_STORE_READY,function(g,h){c[h.store]=true;
var f=true;
d.each(b.ContextHubKernelConfig.stores,function(i,j){if(!c[i]&&j.required){f=false
}});
if(f){b.clearTimeout(e);
ContextHub.console.timeStamp("contexthub initialized");
ContextHub.eventing.off(g.type,a);
ContextHub.eventing.trigger(ContextHub.Constants.EVENT_ALL_STORES_READY,{},{defer:0,_:{wasReadyAt:new Date().getTime(),stores:c}})
}},a)
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.generic-stores - ContextHub.Store.Core.js");
(function(d,c){c.ContextHub.Store=c.ContextHub.Store||{};
var b=new ContextHub.Utils.Persistence.prototype.PersistenceMode("memory",function a(g){var e=g.container;
var j=g.storage;
var i=function(){var k=((d.type(j)==="object")?j:{})[e];
return(d.type(k)==="object")?k:{}
};
var h=function(k){j=(d.type(j)==="object")?j:{};
j[e]=k
};
var f=ContextHub.Utils.Persistence.prototype.PersistenceMode.prototype;
return{setItem:f.setItem.bind(null,h,i),getItem:f.getItem.bind(null,i),removeItem:f.removeItem.bind(null,h,i),getKeys:function(){return ContextHub.Utils.JSON.tree.getKeys(i())
},getTree:i}
});
ContextHub.Store.Core=function(){};
ContextHub.Store.Core.prototype.init=function(g,f){this.config=d.extend(true,{},ContextHub.Store.Core.defaultConfig,f);
this.name=g;
this.eventChannel=ContextHub.Constants.EVENT_STORE_UPDATED+":"+this.name;
this.storeDataKey="/store/"+this.name;
this.data={};
this.references={};
if(!this.config.persistence){this.config.persistence=new ContextHub.Utils.Persistence({container:"data",mode:b,storage:this.data})
}if(!this.config.eventing){var h=function(){};
this.config.eventing={trigger:h,isPaused:h,pause:h,resume:h}
}this.persistence=this.config.persistence;
this.eventing=this.config.eventing;
var e=this.isEventingPaused();
this.pauseEventing();
d.each(this.config.initialValues||{},function(i,j){if(!this.getItem(i)){this.setItem(i,j)
}}.bind(this));
if(!e){this.resumeEventing()
}};
ContextHub.Store.Core.defaultConfig={eventDeferring:16*2,eventing:ContextHub.eventing,persistence:ContextHub.persistence};
ContextHub.Store.Core.prototype.clean=function(){this.removeItem("/")
};
ContextHub.Store.Core.prototype.reset=function(f){var e=this.isEventingPaused();
this.pauseEventing();
if(!f){this.clean()
}this.addAllItems(this.config.initialValues||{});
if(!e){this.resumeEventing()
}};
ContextHub.Store.Core.prototype.setItem=function(m,l,n){var f=this.resolveReference(m);
var e=this.getItem(f);
var i=true;
var h=typeof l;
if(typeof e===h){var g=(h==="string"||h==="number"||h==="boolean");
if(g){i=(e!==l)
}else{var k=ContextHub.Utils.JSON.stringify(e);
var j=ContextHub.Utils.JSON.stringify(l);
i=(k.length!==j.length)||(k!==j)
}}if(i){this.persistence.setItem(this.storeDataKey+"/"+f,l);
if(!(n||{}).silent){this.eventing.trigger(this.eventChannel,{key:f,value:l,old:e,action:"set"},d.extend(true,{defer:this.config.eventDeferring,_:{store:this.name,muteWhenNoData:true}},n))
}}return i
};
ContextHub.Store.Core.prototype.getItem=function(f){var e=this.resolveReference(f);
return this.persistence.getItem(this.storeDataKey+"/"+e)
};
ContextHub.Store.Core.prototype.removeItem=function(i,h){var e=this.resolveReference(i);
var g=false;
var f=this.getItem(e);
if(f!==null){g=true;
this.persistence.removeItem(this.storeDataKey+"/"+e);
if(!h||!h.silent){this.eventing.trigger(this.eventChannel,{key:e,value:null,old:f,store:this.name,action:"remove"},d.extend(true,{defer:this.config.eventDeferring,_:{store:this.name,muteWhenNoData:true}},h))
}}return g
};
ContextHub.Store.Core.prototype.getKeys=function(f){var e=this.persistence.getTree();
e=ContextHub.Utils.JSON.tree.getItem(e,this.storeDataKey)||{};
if(!f){delete e._
}return ContextHub.Utils.JSON.tree.getKeys(e)
};
ContextHub.Store.Core.prototype.getTree=function(f){var e=this.persistence.getItem(this.storeDataKey)||{};
if(!f){delete e._
}return e
};
ContextHub.Store.Core.prototype.addAllItems=function(e,g){var h=d.type(e);
var f=this;
var i=false;
if(h==="object"||h==="array"){d.each(e,function(k,l){var j=f.setItem(k,l,g);
i=i||j
})
}return i
};
ContextHub.Store.Core.prototype.addReference=function(h,e){var j=ContextHub.Utils.JSON.tree.sanitizeKey(h);
var k=ContextHub.Utils.JSON.tree.sanitizeKey(e);
var f=false;
if(j&&k){var g="/"+j.join("/");
var i="/"+k.join("/");
if(g!==i){f=true;
this.references[g]=i
}}return f
};
ContextHub.Store.Core.prototype.removeReference=function(g){var h=ContextHub.Utils.JSON.tree.sanitizeKey(g);
var e=false;
if(h){e=true;
var f="/"+h.join("/");
delete this.references[f]
}return e
};
ContextHub.Store.Core.prototype.getReferences=function(){return this.references
};
ContextHub.Store.Core.prototype.resolveReference=function(n,f){var h=ContextHub.Utils.JSON.tree.sanitizeKey(n);
var k="/"+h.join("/");
if(!d.isEmptyObject(this.references)&&n){var e=f||5;
var l=k;
while((e>0)&&l){e--;
var j=ContextHub.Utils.JSON.tree.sanitizeKey(k);
var i="";
var g=j.slice(0);
for(var m=0;
m<j.length&&!this.references[i];
m++){i+="/"+j[m];
g.shift()
}l=this.references[i];
if(l){l=l+"/"+g.join("/");
l="/"+ContextHub.Utils.JSON.tree.sanitizeKey(l).join("/")
}k=l||k
}}return k
};
ContextHub.Store.Core.prototype.pauseEventing=function(){if(this.eventing){this.eventing.pause(this.eventChannel)
}};
ContextHub.Store.Core.prototype.resumeEventing=function(){if(this.eventing){this.eventing.resume(this.eventChannel)
}};
ContextHub.Store.Core.prototype.isEventingPaused=function(){return this.eventing&&this.eventing.isPaused(this.eventChannel)
};
ContextHub.Store.Core.prototype.announceReadiness=function(){var f=this.name;
var e=null;
ContextHub.console.timeStamp('"'+f+'" ready');
if(this instanceof ContextHub.Store.JSONPStore){var g=this.getKeys();
e={keys:{all:{hash:{},list:g}}};
d.each(g,function(h,i){e.keys.all.hash[i]=true
})
}this.eventing.trigger(ContextHub.Constants.EVENT_STORE_READY+":"+f,{},{defer:0,_:{action:"ready",store:f,wasReadyAt:new Date().getTime(),duration:this.duration||0,overlay:e}})
};
ContextHub.Store.Core.prototype.onUpdate=function(e,h){var g=typeof h==="function";
var f=this.eventChannel;
if(g){ContextHub.eventing.on(f,h.bind(this),e)
}else{ContextHub.eventing.off(f,e)
}}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.generic-stores - ContextHub.Store.SessionStore.js");
(function(b,a){a.ContextHub.Store=a.ContextHub.Store||{};
ContextHub.Store.SessionStore=function(){};
ContextHub.Store.SessionStore.defaultConfig={eventDeferring:16*2,persistence:null,eventing:ContextHub.eventing};
ContextHub.Utils.inheritance.inherit(ContextHub.Store.SessionStore,ContextHub.Store.Core);
ContextHub.Store.SessionStore.prototype.init=function(d,c){this.config=b.extend(true,{},this.config,ContextHub.Store.SessionStore.defaultConfig,c);
this.uber("init",d,this.config)
}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.generic-stores - ContextHub.Store.PersistedStore.js");
(function(b,a){a.ContextHub.Store=a.ContextHub.Store||{};
ContextHub.Store.PersistedStore=function(){};
ContextHub.Store.PersistedStore.defaultConfig={eventDeferring:16*2,persistence:ContextHub.persistence};
ContextHub.Utils.inheritance.inherit(ContextHub.Store.PersistedStore,ContextHub.Store.Core);
ContextHub.Store.PersistedStore.prototype.init=function(d,c){this.config=b.extend(true,{},this.config,ContextHub.Store.PersistedStore.defaultConfig,c);
this.uber("init",d,this.config)
}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.generic-stores - ContextHub.Store.JSONPStore.js");
(function(c,b){b.ContextHub.Store=b.ContextHub.Store||{};
ContextHub.Store.JSONPStore=function(){};
ContextHub.Utils.inheritance.inherit(ContextHub.Store.JSONPStore,ContextHub.Store.Core);
var a=function(f){var e=f||"";
e=e.replace(/[^a-zA-Z0-9]/g,"");
var d=function(){var h=0;
for(var i=0;
i<f.length;
i++){h=~~(((h<<5)-h)+f.charCodeAt(i))
}var g=Math.sin(h)*10000;
return g-Math.floor(g)
};
if((e.length===0)||(e!==f)){e="x"+e+d().toString(36).substr(2,5)
}return e
};
ContextHub.Store.JSONPStore.prototype.init=function(e,d){this.config=c.extend(true,{},this.config,ContextHub.Store.JSONPStore.defaultConfig,d);
this.callbackName=a(e);
this.uber("init",e,this.config)
};
ContextHub.Store.JSONPStore.defaultConfig={eventDeferring:16*2,persistence:null,eventing:ContextHub.eventing,service:null};
ContextHub.Store.JSONPStore.prototype.getServiceDetails=function(){return this.config.service
};
ContextHub.Store.JSONPStore.prototype.configureService=function(e,d){this.config.service=d?e:c.extend(true,{},this.config.service,e)
};
ContextHub.Store.JSONPStore.prototype.resolveParameter=function(h){var e=(c.type(h)==="boolean")?String(h):h;
var d=e||"";
var g=["ContextHub.Paths."];
if(c.type(e)==="string"){var f=d.match(/\$\{(contexthub|variable):[^}]+}/g);
if(f){c.each(f,function(i,m){var n=m.slice(2,-1).split(/:/);
var l=n.shift();
var j=n.shift();
var k=null;
if(l==="contexthub"){k=ContextHub.persistence.getItem(j)
}if((l==="variable")&&j){c.each(this.allowedPrefix,function(o,p){var q=j.indexOf(p)===0;
if(q){k=ContextHub.Utils.JSON.tree.getItem(b,j.replace(/\./g,"/"))
}return !q
})
}d=d.replace(m,k||"")
}.bind({allowedPrefix:g}))
}}return d
};
ContextHub.Store.JSONPStore.prototype.getServiceURL=function(h){var e=this.getServiceDetails();
var f=[];
var i=[];
var g;
if(c.type(e)!=="object"){return null
}if(e.jsonp){var d;
if(e.jsonp===true){d="callback"
}else{d=(""+e.jsonp).replace(/[^a-zA-Z0-9_$]/g,"")
}e.params=e.params||{};
e.params[d]="ContextHub.Callbacks."+this.callbackName
}e.port=(e.port&&e.port===80)?"":e.port;
if(e.host){if(typeof e.secure==="undefined"||e.secure==="auto"){f.push("//")
}else{f.push(e.secure?"https://":"http://")
}f.push(e.host);
f.push(e.port?(":"+e.port):"")
}else{f.push(b.location.protocol+"//"+b.location.host)
}e.path=e.path||"/";
g=""+(h?this.resolveParameter(e.path):e.path);
f.push(g);
c.each(e.params||{},function(j,k){i.push(encodeURIComponent(j)+"="+encodeURIComponent(h?this.resolveParameter(k):k))
}.bind(this));
if(i.length){f.push((g.indexOf("?")===-1)?"?":"&");
f.push(i.join("&"))
}return f.join("")
};
ContextHub.Store.JSONPStore.prototype.queryService=function(d){var f=this.getServiceURL(true);
if(!f){return
}var h=this.config.service.jsonp||this.config.service.script;
var j=this.isEventingPaused();
var k=this;
if(d){this.removeItem("_",{silent:true})
}var e=this.getItem(ContextHub.Constants.SERVICE_RESPONSE_TIME_KEY)||0;
var g=this.getItem(ContextHub.Constants.SERVICE_LAST_URL_KEY);
if((e+this.config.service.ttl>new Date().getTime())&&(g===f)){this.duration="cached";
this.announceReadiness();
return
}this.setItem(ContextHub.Constants.SERVICE_LAST_URL_KEY,f);
b.ContextHub.Callbacks=b.ContextHub.Callbacks||{};
ContextHub.Callbacks[this.callbackName]=this.callbackFunction.bind(this);
var l={url:f,timeout:this.config.service.timeout,async:this.config.service.synchronous?false:true,method:this.config.service.method||"GET"};
if(h){c.extend(l,{dataType:"script",cache:true})
}this.pauseEventing();
this.duration=0;
ContextHub.Shared.timers.start(this.name);
var i=c.ajax(l);
if(!h){i.done(function(m,n,o){var p=ContextHub.Utils.JSON.parse(o.responseText);
ContextHub.Callbacks[k.callbackName](p)
})
}i.fail(function(m){k.failureHandler(m)
});
i.always(function(){if(!j){k.resumeEventing()
}k.announceReadiness()
})
};
ContextHub.Store.JSONPStore.prototype.successHandler=function(d){return d
};
ContextHub.Store.JSONPStore.prototype.failureHandler=function(e){var d=(this.config||{}).service;
ContextHub.console.log('There was an error while accessing JSONP service in the store "'+this.name+'", configuration: ',d,", error: ",e)
};
ContextHub.Store.JSONPStore.prototype.callbackFunction=function(d){this.duration=ContextHub.Shared.timers.finish(this.name)+"ms";
this.setItem(ContextHub.Constants.SERVICE_RESPONSE_TIME_KEY,new Date().getTime());
this.setItem(ContextHub.Constants.SERVICE_RAW_RESPONSE_KEY,this.successHandler(d))
};
ContextHub.Store.JSONPStore.prototype.getRawResponse=function(){return this.getItem(ContextHub.Constants.SERVICE_RAW_RESPONSE_KEY)||{}
};
ContextHub.Store.JSONPStore.prototype.reset=function(d){this.uber("reset",d);
this.queryService(false)
}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.generic-stores - ContextHub.Store.PersistedJSONPStore.js");
(function(b,a){a.ContextHub.Store=a.ContextHub.Store||{};
ContextHub.Store.PersistedJSONPStore=function(){};
ContextHub.Store.PersistedJSONPStore.defaultConfig={eventDeferring:16*2,persistence:ContextHub.persistence};
ContextHub.Utils.inheritance.inherit(ContextHub.Store.PersistedJSONPStore,ContextHub.Store.JSONPStore);
ContextHub.Store.PersistedJSONPStore.prototype.init=function(d,c){this.config=b.extend(true,{},this.config,ContextHub.Store.PersistedJSONPStore.defaultConfig,c);
this.uber("init",d,this.config)
}
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.Constants.js");
(function(b){var a={EVENT_SEGMENT_REGISTERED:"segment-engine:segment-registered",EVENT_SEGMENT_UNREGISTERED:"segment-engine:segment-unregistered",EVENT_SEGMENT_UPDATED:"segment-engine:segment-updated",EVENT_SCRIPT_REGISTERED:"segment-engine:script-registered",EVENT_SCRIPT_UNREGISTERED:"segment-engine:script-unregistered",EVENT_SCRIPT_UPDATED:"segment-engine:script-updated",EVENT_TEASER_REGISTERED:"segment-engine:teaser-registered",EVENT_TEASER_UNREGISTERED:"segment-engine:teaser-unregistered",EVENT_TEASER_LOADED:"segment-engine:teaser-loaded"};
b.extend(true,ContextHub.Constants,a)
}(ContextHubJQ));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.js");
(function(b,a){a.ContextHub.SegmentEngine={version:"0.2.20-20170309-0724"};
ContextHub.SegmentEngine.getResolvedSegments=function(c){return ContextHub.SegmentEngine.SegmentManager.getResolvedSegments(c)
};
ContextHub.SegmentEngine.getSegment=function(c){return ContextHub.SegmentEngine.SegmentManager.getSegment(c)
};
ContextHub.SegmentEngine.getComparisonOperators=function(){return ContextHub.SegmentEngine.OperatorManager.getAllOperators()
};
ContextHub.SegmentEngine.getObjectValue=function(d){var c;
if(d===null||d===undefined){c=null
}else{if(d instanceof ContextHub.SegmentEngine.Operator){c=d.isResolved()
}else{if(d instanceof ContextHub.SegmentEngine.Property){c=d.getValue()
}else{if(d instanceof ContextHub.SegmentEngine.ScriptReference){c=d.execute()
}else{if(d instanceof ContextHub.SegmentEngine.SegmentReference){c=d.isResolved()
}else{c=d
}}}}}return c
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.Property.js");
(function(b,a){a.ContextHub.SegmentEngine=a.ContextHub.SegmentEngine||{};
ContextHub.SegmentEngine.Property=function(d){var c=ContextHub.SegmentEngine.Property;
if(!(this instanceof c)){return ContextHub.Utils.inheritance.newInstance(c,arguments)
}d=ContextHub.Utils.JSON.tree.sanitizeKey(d);
this.key="/"+d.join("/");
this.storeName=d.shift();
this.itemName=d.join("/")
};
ContextHub.SegmentEngine.Property.prototype.info={className:"Property",updateEvent:ContextHub.Constants.EVENT_STORE_UPDATED};
ContextHub.SegmentEngine.Property.prototype.getKey=function(){return this.key
};
ContextHub.SegmentEngine.Property.prototype.getStoreName=function(){return this.storeName
};
ContextHub.SegmentEngine.Property.prototype.getItemName=function(){return this.itemName
};
ContextHub.SegmentEngine.Property.prototype.getValue=function(){return ContextHub.get(this.key)
};
ContextHub.SegmentEngine.Property.prototype.toString=function(){return this.info.className+'("'+this.getKey()+'") -> '+this.getValue()
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.Operator.js");
(function(b,a){a.ContextHub.SegmentEngine=a.ContextHub.SegmentEngine||{};
ContextHub.SegmentEngine.Operator=function(d,e){var c=ContextHub.SegmentEngine.Operator;
if(!(this instanceof c)){return ContextHub.Utils.inheritance.newInstance(c,arguments)
}e=[].slice.call(arguments,1);
this.operatorName=d;
this.operatorArguments=e
};
ContextHub.SegmentEngine.Operator.prototype.getOperatorName=function(){return this.operatorName
};
ContextHub.SegmentEngine.Operator.prototype.getOperatorArguments=function(){return this.operatorArguments
};
ContextHub.SegmentEngine.Operator.prototype.isResolved=function(){var i=false;
var j=true;
var p=this.getOperatorName();
var o=/^and(\.|$)/.test(p);
var c=/^or(\.|$)/.test(p);
var k=this.getOperatorArguments();
if((o||c)&&k.length<2){var q=k.length;
if(q===0){k.push(null);
k.push(null)
}if(q===1){k.push(o?true:null)
}}var d=k[0];
var m=ContextHub.SegmentEngine.getObjectValue(d);
var n=b.type(m);
var s=ContextHub.SegmentEngine.OperatorManager.getOperator(p,n);
var e=function(u){if(o&&u===false){i=false;
j=false
}if(c&&u===true){i=true;
j=false
}};
e(m);
var t=k.length?k.slice(1):[null];
if(s&&j){var l=(o||c)?k.length:2;
p=s.operatorName;
t=[];
for(var r=1;
(r<l)&&j;
r++){var g=k[r];
var f=ContextHub.SegmentEngine.getObjectValue(g);
t.push(f);
e(f)
}if(j){var h=[m].concat([].slice.call(t));
i=s.handler.apply(this,h)
}}ContextHub.console.debug("    comparing:",m,p,(t.length?t.join(" "+p+" "):t+""),"=",i);
this._resolution=[p,i,[].concat.call([m],t)];
return i
};
ContextHub.SegmentEngine.Operator.prototype.traverse=function(e,d){var c=[];
var f=function(g){if(g&&(typeof g.isResolved!=="function")){return
}if((typeof d==="undefined")||((typeof d==="function")&&d(g))){c.push(g);
if(typeof e==="function"){e(g)
}}};
f(this);
if(ContextHub.SegmentEngine.OperatorManager.getOperator(this.operatorName)){b.each(this.getOperatorArguments(),function(g,h){if(h instanceof ContextHub.SegmentEngine.Operator){b.merge(c,h.traverse(e,d))
}else{f(h)
}})
}return c
};
ContextHub.SegmentEngine.Operator.prototype.toString=function(){var c='Operator("'+this.getOperatorName()+'"';
b.each(this.getOperatorArguments(),function(e,d){c+=", "+d
});
c+=") -> "+this.isResolved();
return c
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.OperatorManager.js");
(function(c,a){a.ContextHub.SegmentEngine=a.ContextHub.SegmentEngine||{};
var b={};
ContextHub.SegmentEngine.OperatorManager={};
ContextHub.SegmentEngine.OperatorManager.register=function(e,d){if((typeof e==="string")&&e.length&&!/\.$/.test(e)){b[e]={operatorName:e,handler:d}
}};
ContextHub.SegmentEngine.OperatorManager.unregister=function(d){delete b[d]
};
ContextHub.SegmentEngine.OperatorManager.unregisterAllOperators=function(){b={}
};
ContextHub.SegmentEngine.OperatorManager.getAllOperators=function(){return b
};
ContextHub.SegmentEngine.OperatorManager.getOperator=function(g,e){var h=(g||"").split(".",2);
g=h.shift();
var d=h.shift()||"";
var f=b[g+"."+d]||b[g+"."+e]||b[g];
return f||null
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.Segment.js");
(function(c,a){a.ContextHub.SegmentEngine=a.ContextHub.SegmentEngine||{};
ContextHub.SegmentEngine.Segment=function(g,j){var e=ContextHub.SegmentEngine.Segment;
if(!(this instanceof e)){return ContextHub.Utils.inheritance.newInstance(e,arguments)
}var f=g||{};
if(typeof f==="string"){f={path:g}
}var h=c.trim(f.name);
var d=c.trim(f.path);
var i=parseInt(c.trim(f.boost),10)||0;
if(h.length===0){h=d.split("/").pop()
}h=h.replace(/ /g,"-").replace(/[^a-z0-9\-]/ig,"").toLowerCase();
this.name=h;
this.path=d;
this.boost=i;
this.register(j)
};
ContextHub.SegmentEngine.Segment.prototype.info={className:"Segment",updateEvent:ContextHub.Constants.EVENT_SEGMENT_UPDATED};
ContextHub.SegmentEngine.Segment.prototype.register=function(d){if(this.getPath().length===0||this.isRegistered()){return
}if(d instanceof ContextHub.SegmentEngine.Operator){this.cachedResult=null;
this.condition=d;
this.enabled=false;
this.registered=false;
ContextHub.SegmentEngine.Dependency.findAllDependencies.call(this,this.getCondition());
ContextHub.SegmentEngine.SegmentManager.register(this)
}};
ContextHub.SegmentEngine.Segment.prototype.unregister=function(){this.registered=false;
this.enabled=false;
this.condition=null;
this.isResolved();
ContextHub.SegmentEngine.SegmentManager.unregister(this.getPath())
};
ContextHub.SegmentEngine.Segment.prototype.isResolved=function(){var d=false;
if(this.cachedResult!==null){ContextHub.console.debug('[+] Segment "'+this.getPath()+'" resolution (cached):',this.cachedResult);
return this.cachedResult
}ContextHub.console.debug('[+] Segment "'+this.getPath()+'" resolution:');
if(this.isEnabled()&&this.isRegistered()){d=this.condition.isResolved()
}if(d!==this.cachedResult){this.cachedResult=d;
ContextHub.eventing.trigger(this.info.updateEvent+":"+this.getName(),{segment:this,resolved:d,key:this.getPath(),action:"set",value:d},{defer:0,_:{segment:this,resolved:d,path:this.getPath()}})
}return d
};
var b=function(i,e){var d=i._resolution;
var k;
e=e||[];
if(d){var h=d.shift();
var g=d.shift();
var j=d.shift();
k=h+" ("+g+")";
var f={};
f[k]=j;
if(e instanceof Array){e.push(f)
}else{return f
}}c.each(i.operatorArguments,function(l,n){if(n instanceof ContextHub.SegmentEngine.Operator){var o=((e instanceof Array)?e[e.length-1]:e)[k];
var m=(typeof o[l]==="boolean")?{}:[];
o[l]=b(n,m)
}});
return e
};
ContextHub.SegmentEngine.Segment.prototype.debug=function(){var e=this.getCondition();
if(e){var f=this.isResolved();
var d=b(e);
ContextHub.console.debug("[todo] debug: ",f,d)
}else{ContextHub.console.debug('[-] [SegmentEngine] Segment "'+this.getPath()+'" is invalid.')
}};
ContextHub.SegmentEngine.Segment.prototype.isRegistered=function(){return this.registered===true
};
ContextHub.SegmentEngine.Segment.prototype.isEnabled=function(){return this.enabled===true
};
ContextHub.SegmentEngine.Segment.prototype.enable=function(){if(this.condition instanceof ContextHub.SegmentEngine.Operator){this.enabled=true
}};
ContextHub.SegmentEngine.Segment.prototype.disable=function(){this.enabled=false
};
ContextHub.SegmentEngine.Segment.prototype.getName=function(){return this.name
};
ContextHub.SegmentEngine.Segment.prototype.getPath=function(){return this.path
};
ContextHub.SegmentEngine.Segment.prototype.getBoost=function(){return this.boost
};
ContextHub.SegmentEngine.Segment.prototype.getCondition=function(){return this.condition
};
ContextHub.SegmentEngine.Segment.prototype.getDependencies=function(){return this.dependencyList||ContextHub.SegmentEngine.Dependency.getEmptyDependencyList()
};
ContextHub.SegmentEngine.Segment.prototype.onUpdate=function(d,g){var f=typeof g==="function";
var e=this.info.updateEvent+":"+this.getName();
if(f){ContextHub.eventing.on(e,g,d)
}else{ContextHub.eventing.off(e,d)
}};
ContextHub.SegmentEngine.Segment.prototype.toString=function(){var d='("'+this.getPath()+'", '+this.getBoost()+", "+this.getCondition()+")";
return this.info.className+d+" -> "+this.isResolved()
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.SegmentReference.js");
(function(b,a){a.ContextHub.SegmentEngine=a.ContextHub.SegmentEngine||{};
ContextHub.SegmentEngine.SegmentReference=function(c){var d=ContextHub.SegmentEngine.SegmentReference;
if(!(this instanceof d)){return ContextHub.Utils.inheritance.newInstance(d,arguments)
}this.segmentPath=b.trim(c)
};
ContextHub.SegmentEngine.SegmentReference.prototype.info={className:"SegmentReference",updateEvent:ContextHub.Constants.EVENT_SEGMENT_UPDATED};
ContextHub.SegmentEngine.SegmentReference.prototype.getSegmentPath=function(){return this.segmentPath
};
ContextHub.SegmentEngine.SegmentReference.prototype.isResolved=function(){var c=false;
var d=ContextHub.SegmentEngine.SegmentManager.getSegment(this.getSegmentPath());
if(d){c=d.isResolved()
}return c
};
ContextHub.SegmentEngine.SegmentReference.prototype.toString=function(){return this.info.className+'("'+this.getSegmentPath()+'") -> '+this.isResolved()
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.SegmentManager.js");
(function(b,a){a.ContextHub.SegmentEngine=a.ContextHub.SegmentEngine||{};
var c={};
ContextHub.SegmentEngine.SegmentManager={};
ContextHub.SegmentEngine.SegmentManager.info={registerEvent:ContextHub.Constants.EVENT_SEGMENT_REGISTERED,unregisterEvent:ContextHub.Constants.EVENT_SEGMENT_UNREGISTERED};
ContextHub.SegmentEngine.SegmentManager.register=function(d){if(!(d instanceof ContextHub.SegmentEngine.Segment)||!d.getCondition()){return false
}c[d.getPath()]=d;
d.enabled=true;
d.registered=true;
ContextHub.eventing.trigger(ContextHub.SegmentEngine.SegmentManager.info.registerEvent,{segment:d,key:d.getPath(),action:"set",value:"registered"},{defer:0});
ContextHub.SegmentEngine.Dependency.dependencyMonitor(d,true);
d.isResolved();
return true
};
ContextHub.SegmentEngine.SegmentManager.unregister=function(d){var e;
if(d instanceof ContextHub.SegmentEngine.Segment){e=d
}else{e=this.getSegment(d)
}if(e){e.registered=false;
e.disable();
delete c[e.getPath()];
ContextHub.SegmentEngine.Dependency.dependencyMonitor(e,false);
e.cachedResult=null;
e.dependencyList=ContextHub.SegmentEngine.Dependency.getEmptyDependencyList();
e.isResolved();
ContextHub.eventing.trigger(ContextHub.SegmentEngine.SegmentManager.info.unregisterEvent,{segment:e,key:e.getPath(),action:"remove",value:"unregistered"},{defer:0})
}};
ContextHub.SegmentEngine.SegmentManager.unregisterAllSegments=function(){b.each(c,function(d,e){e.unregister()
})
};
ContextHub.SegmentEngine.SegmentManager.getAllSegments=function(){return c
};
ContextHub.SegmentEngine.SegmentManager.getSegment=function(d){return c[d]||null
};
ContextHub.SegmentEngine.SegmentManager.getResolvedSegments=function(d){var f=(d||{}).returnLookup===true;
var e=f?{}:[];
var g=ContextHub.Shared.timers.start();
b.each(c,function(h,i){if(i.isResolved()){if(f){e[i.getPath()]=i
}else{e.push(i)
}}});
ContextHub.console.log(ContextHub.Shared.timestamp(),"[+] checking resolved segments ("+ContextHub.Shared.timers.finish(g)+"ms)");
return e
};
ContextHub.SegmentEngine.SegmentManager.getUnresolvedSegments=function(d){var f=(d||{}).returnLookup===true;
var e=f?{}:[];
var g=ContextHub.Shared.timers.start();
b.each(c,function(h,i){if(!i.isResolved()){if(f){e[i.getPath()]=i
}else{e.push(i)
}}});
ContextHub.console.log(ContextHub.Shared.timestamp(),"[+] checking unresolved segments ("+ContextHub.Shared.timers.finish(g)+"ms)");
return e
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.ScriptReference.js");
(function(b,a){a.ContextHub.SegmentEngine=a.ContextHub.SegmentEngine||{};
ContextHub.SegmentEngine.ScriptReference=function(f,e){var d=ContextHub.SegmentEngine.ScriptReference;
if(!(this instanceof d)){return ContextHub.Utils.inheritance.newInstance(d,arguments)
}e=[].slice.call(arguments,1);
this.scriptName=b.trim(f);
this.scriptArguments=e;
this.cachedResult=null;
this.dependencyList=ContextHub.SegmentEngine.Dependency.getEmptyDependencyList();
for(var c=0;
c<this.scriptArguments.length;
c++){this.dependOn(this.scriptArguments[c])
}ContextHub.SegmentEngine.Dependency.dependencyMonitor(this,true)
};
ContextHub.SegmentEngine.ScriptReference.prototype.info={className:"ScriptReference",updateEvent:ContextHub.Constants.EVENT_SCRIPT_UPDATED};
ContextHub.SegmentEngine.ScriptReference.prototype.dependOn=function(c){ContextHub.SegmentEngine.Dependency.addDependency.call(this,c)
};
ContextHub.SegmentEngine.ScriptReference.prototype.getScriptName=function(){return this.scriptName
};
ContextHub.SegmentEngine.ScriptReference.prototype.getScriptHandler=function(){return ContextHub.SegmentEngine.ScriptManager.getScript(this.getScriptName())
};
ContextHub.SegmentEngine.ScriptReference.prototype.getScriptArguments=function(){return this.scriptArguments
};
ContextHub.SegmentEngine.ScriptReference.prototype.getDependencies=function(){return this.dependencyList||ContextHub.SegmentEngine.Dependency.getEmptyDependencyList()
};
ContextHub.SegmentEngine.ScriptReference.prototype.execute=function(){var d=null;
var c=this.getScriptHandler();
if(this.cachedResult!==null){return this.cachedResult
}if(typeof c==="function"){var e=this.getScriptArguments();
var g=[];
b.each(e,function(h,i){var j=ContextHub.SegmentEngine.getObjectValue(i);
g.push(j)
});
try{d=c.apply(this,g)
}catch(f){ContextHub.console.error('[-] [SegmentEngine] User script "'+this.getScriptName()+'" failed:',f);
d=null
}}if(this.cachedResult!==d){this.cachedResult=d;
ContextHub.eventing.trigger(this.info.updateEvent+":"+this.getScriptName(),{script:this,key:this.getScriptName(),action:"set",resolved:d,value:d},{defer:0,_:{result:d,scriptName:this.getScriptName()}})
}return d
};
ContextHub.SegmentEngine.ScriptReference.prototype.isResolved=function(){return this.execute()
};
ContextHub.SegmentEngine.ScriptReference.prototype.toString=function(){var c=this.info.className+'("'+this.getScriptName()+'"';
b.each(this.getScriptArguments(),function(d,e){if(typeof e==="string"){e='"'+e+'"'
}c+=", "+e
});
c+=") -> "+this.execute();
return c
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.ScriptManager.js");
(function(c,b){b.ContextHub.SegmentEngine=b.ContextHub.SegmentEngine||{};
var a={};
ContextHub.SegmentEngine.ScriptManager={};
ContextHub.SegmentEngine.ScriptManager.register=function(f,e){if((typeof f==="string")&&f.length&&(typeof e==="function")){a[f]=e;
ContextHub.eventing.trigger(ContextHub.Constants.EVENT_SCRIPT_REGISTERED,{key:f,action:"set",value:"registered"},{defer:0})
}};
ContextHub.SegmentEngine.ScriptManager.unregister=function(e){if(this.isRegistered(e)){ContextHub.eventing.trigger(ContextHub.Constants.EVENT_SCRIPT_UNREGISTERED,{key:e,action:"remove",value:"unregistered"},{defer:0})
}delete a[e]
};
ContextHub.SegmentEngine.ScriptManager.unregisterAllScripts=function(){c.each(this.getAllScripts(),function(e){this.unregister(e)
}.bind(this))
};
ContextHub.SegmentEngine.ScriptManager.getAllScripts=function(){return a
};
var d=function(e){ContextHub.console.error('[-] [SegmentEngine] User script "'+e+'" not found.');
return function(){return null
}
};
ContextHub.SegmentEngine.ScriptManager.getScript=function(e){return a[e]||d(e)
};
ContextHub.SegmentEngine.ScriptManager.isRegistered=function(e){return !!a[e]
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine - ContextHub.SegmentEngine.Dependency.js");
(function(b,a){a.ContextHub.SegmentEngine=a.ContextHub.SegmentEngine||{};
ContextHub.SegmentEngine.Dependency={};
ContextHub.SegmentEngine.Dependency.allowedDependencies=[ContextHub.SegmentEngine.SegmentReference,ContextHub.SegmentEngine.ScriptReference,ContextHub.SegmentEngine.Property];
ContextHub.SegmentEngine.Dependency.getEmptyDependencyList=function(){var c={};
b.each(ContextHub.SegmentEngine.Dependency.allowedDependencies,function(d,e){c[e.prototype.info.className]={keys:[],updateEvent:null}
});
return c
};
ContextHub.SegmentEngine.Dependency.addDependency=function(f){if(!f){return
}this.dependencyList=this.dependencyList||ContextHub.SegmentEngine.Dependency.getEmptyDependencyList();
var d=null;
var c=null;
if(f instanceof ContextHub.SegmentEngine.Property){d=f.getKey();
c=d.replace(/(^\/|\/$)/g,"").split(/\//).shift()||null
}else{if(f instanceof ContextHub.SegmentEngine.ScriptReference){d=f.getScriptName()
}else{if(f instanceof ContextHub.SegmentEngine.SegmentReference){d=f.getSegmentPath()
}else{d=null
}}}if(d){var e=this.dependencyList[f.info.className];
if(!e[d]){e[d]=true;
e.keys.push(d)
}e.variant=f.info.className;
e.updateEvent=f.info.updateEvent;
if(c){e.stores=e.stores||{};
e.stores[c]=true
}}};
ContextHub.SegmentEngine.Dependency.findAllDependencies=function(j){var d=(j||{}).operatorArguments;
if(d){var i=j.getOperatorName();
var f=/^and(\.|$)/.test(i);
var e=/^or(\.|$)/.test(i);
var g=Math.min(d.length,(f||e)?Number.MAX_VALUE:2);
var c;
for(c=0;
c<g;
c++){var h=d[c];
if(h instanceof ContextHub.SegmentEngine.Operator){ContextHub.SegmentEngine.Dependency.findAllDependencies.call(this,d[c])
}else{ContextHub.SegmentEngine.Dependency.addDependency.call(this,h)
}}}};
ContextHub.SegmentEngine.Dependency.dependencyMonitor=function(d,f){if(!(d instanceof ContextHub.SegmentEngine.Segment)&&!(d instanceof ContextHub.SegmentEngine.ScriptReference)){return
}var c=(d.getPath||d.getScriptName).call(d).replace(/[^a-z]/ig,"");
var e=d.getDependencies();
var g=[];
b.each(e,function(h,i){if(i.keys.length){g.push(i.updateEvent)
}});
if(g.length){g=g.join(" ");
if(f){ContextHub.eventing.on(g,function(i,k){var j=d.getDependencies();
var h=null;
switch(k.channel){case ContextHub.SegmentEngine.SegmentReference.prototype.info.updateEvent:h=j.SegmentReference;
break;
case ContextHub.SegmentEngine.ScriptReference.prototype.info.updateEvent:h=j.ScriptReference;
break;
case ContextHub.SegmentEngine.Property.prototype.info.updateEvent:h=j.Property;
break;
default:ContextHub.console.error("[-] [SegmentEngine] Unsupported event type:",k.channel)
}if(h&&ContextHub.SegmentEngine.Dependency.isMatching(k,h)){d.cachedResult=null;
d.isResolved()
}},c)
}else{ContextHub.eventing.off(g,c)
}}};
ContextHub.SegmentEngine.Dependency.isMatching=function(f,c){var d=(c||{}).variant;
var e=ContextHub.SegmentEngine.Dependency[d+"Handler"];
return(typeof e==="function")?e.call(this,f,c):false
};
ContextHub.SegmentEngine.Dependency.SegmentReferenceHandler=function(e,d){for(var c=0;
c<d.keys.length;
c++){var f=d.keys[c];
if(e.keys.all.hash[f]){return true
}}return false
};
ContextHub.SegmentEngine.Dependency.ScriptReferenceHandler=function(e,d){for(var c=0;
c<d.keys.length;
c++){var f=d.keys[c];
if(e.keys.all.hash[f]){return true
}}return false
};
ContextHub.SegmentEngine.Dependency.PropertyHandler=function(e,d){if(d.stores[e.store]){for(var c=0;
c<d.keys.length;
c++){var f=d.keys[c];
f=f.substr(f.indexOf("/",1));
if(e.keys.all.hash[f]){return true
}}}return false
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.operators - Operator.and.js");
(function(){var a=function(c,b){return !!(c&&b)
};
ContextHub.SegmentEngine.OperatorManager.register("and",a)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.operators - Operator.or.js");
(function(){var a=function(c,b){return !!(c||b)
};
ContextHub.SegmentEngine.OperatorManager.register("or",a)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.operators - Operator.equal.js");
(function(g){var c=function(j,i){return j===i
};
var e=function(j,i){j=String(j);
i=String(i);
return j===i
};
var f=function(j,i){j=Number(j||undefined);
i=Number(i||undefined);
return j===i
};
var a=function(i){if(typeof i!=="boolean"){i=(/^true$/i).test(g.trim(String(i)))
}return i
};
var h=function(j,i){j=a(j);
i=a(i);
return j===i
};
var b=function(j,i){j=new Date(j||undefined);
i=new Date(i||undefined);
return Number(j)===Number(i)
};
var d=function(k,j){var i=false;
if(typeof k==="string"&&j){if(!(j instanceof RegExp)){j=new RegExp(j)
}i=j.test(k)
}return i
};
ContextHub.SegmentEngine.OperatorManager.register("equal",c);
ContextHub.SegmentEngine.OperatorManager.register("equal.string",e);
ContextHub.SegmentEngine.OperatorManager.register("equal.number",f);
ContextHub.SegmentEngine.OperatorManager.register("equal.boolean",h);
ContextHub.SegmentEngine.OperatorManager.register("equal.date",b);
ContextHub.SegmentEngine.OperatorManager.register("equal.regexp",d)
})(ContextHubJQ);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.operators - Operator.not-equal.js");
(function(b){var a=function(c){return function(){return !c.apply(this,arguments)
}
};
b.each(ContextHub.SegmentEngine.OperatorManager.getAllOperators(),function(d,c){if(/^equal(\.|$)/.test(d)){ContextHub.SegmentEngine.OperatorManager.register("not-"+d,a(c.handler))
}})
})(ContextHubJQ);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.operators - Operator.less-than.js");
(function(){var b=function(f,e){return f<e
};
var d=function(f,e){f=String(f);
e=String(e);
return f<e
};
var a=function(f,e){f=Number(f||undefined);
e=Number(e||undefined);
return f<e
};
var c=function(f,e){f=new Date(f||undefined);
e=new Date(e||undefined);
return Number(f)<Number(e)
};
ContextHub.SegmentEngine.OperatorManager.register("less-than",b);
ContextHub.SegmentEngine.OperatorManager.register("less-than.string",d);
ContextHub.SegmentEngine.OperatorManager.register("less-than.number",a);
ContextHub.SegmentEngine.OperatorManager.register("less-than.date",c)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.operators - Operator.less-than-or-equal.js");
(function(c){var d=function(f,e){ContextHub.console.error("[-] [SegmentEngine] Comparison operator not found:",(f+(e?"."+e:"")));
return function(){return false
}
};
var b=function(g,e){var f=ContextHub.SegmentEngine.OperatorManager.getOperator(g,e)||{};
return f.handler||d(g,e)
};
var a=function(f){var g=b("less-than",f);
var e=b("equal",f);
return function(){return g.apply(this,arguments)||e.apply(this,arguments)
}
};
c.each(ContextHub.SegmentEngine.OperatorManager.getAllOperators(),function(h){if(/^less-than(\.|$)/.test(h)){var i=h.split(".",2);
var g=i.shift();
var f=i.shift();
var e=g.replace("less-than","less-than-or-equal");
if(f){e+="."+f
}ContextHub.SegmentEngine.OperatorManager.register(e,a(f))
}})
})(ContextHubJQ);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.operators - Operator.greater-than.js");
(function(){var d=function(f,e){return f>e
};
var b=function(f,e){f=String(f);
e=String(e);
return f>e
};
var c=function(f,e){f=Number(f||undefined);
e=Number(e||undefined);
return f>e
};
var a=function(f,e){f=new Date(f||undefined);
e=new Date(e||undefined);
return Number(f)>Number(e)
};
ContextHub.SegmentEngine.OperatorManager.register("greater-than",d);
ContextHub.SegmentEngine.OperatorManager.register("greater-than.string",b);
ContextHub.SegmentEngine.OperatorManager.register("greater-than.number",c);
ContextHub.SegmentEngine.OperatorManager.register("greater-than.date",a)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.operators - Operator.greater-than-or-equal.js");
(function(c){var d=function(f,e){ContextHub.console.error("[-] [SegmentEngine] Comparison operator not found:",(f+(e?"."+e:"")));
return function(){return false
}
};
var b=function(g,e){var f=ContextHub.SegmentEngine.OperatorManager.getOperator(g,e)||{};
return f.handler||d(g,e)
};
var a=function(f){var g=b("greater-than",f);
var e=b("equal",f);
return function(){return g.apply(this,arguments)||e.apply(this,arguments)
}
};
c.each(ContextHub.SegmentEngine.OperatorManager.getAllOperators(),function(h){if(/^greater-than(\.|$)/.test(h)){var i=h.split(".",2);
var g=i.shift();
var f=i.shift();
var e=g.replace("greater-than","greater-than-or-equal");
if(f){e+="."+f
}ContextHub.SegmentEngine.OperatorManager.register(e,a(f))
}})
})(ContextHubJQ);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - PageInteraction.js");
(function(b,a){a.ContextHub.SegmentEngine.PageInteraction=a.ContextHub.SegmentEngine.PageInteraction||{};
ContextHub.SegmentEngine.PageInteraction={};
ContextHub.SegmentEngine.PageInteraction.info={propertyHolder:"data-contexthub-property",processorHolder:"data-processor",defaultHolder:"data-default-value"};
ContextHub.SegmentEngine.PageInteraction.getPropertyPlaceholders=function(f){var d="["+ContextHub.SegmentEngine.PageInteraction.info.propertyHolder+(f?'^="%1"]':"]");
var e=b([d.replace(/%1/,"/"+f),d.replace(/%1/,f)].join(", "));
var c=[];
b.each(e,function(g,h){var i=ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder(h);
if(i.isValid()){c.push(i)
}});
return c
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - PageInteraction.PropertyPlaceholder.js");
(function(b,a){a.ContextHub.SegmentEngine.PageInteraction=a.ContextHub.SegmentEngine.PageInteraction||{};
var c=function(){var e=this.element.attr(ContextHub.SegmentEngine.PageInteraction.info.propertyHolder);
if(!this.element||!e){this.storeName=null;
this.keyName=null;
this.propertyName=null;
this.defaultValue=null;
this.processors=[];
return
}var d=ContextHub.Utils.JSON.tree.sanitizeKey(e);
this.storeName=d.shift();
this.propertyName="/"+d.join("/");
this.keyName="/"+this.storeName+this.propertyName;
this.defaultValue=b.trim(this.element.attr(ContextHub.SegmentEngine.PageInteraction.info.defaultHolder)||"");
this.processors=[];
b.each((this.element.attr(ContextHub.SegmentEngine.PageInteraction.info.processorHolder)||"").split(/,/),function(f,g){var h=b.trim(g);
if(h.length){this.processors.push(h)
}}.bind(this))
};
ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder=function(e){var d=ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder;
if(!(this instanceof d)){return ContextHub.Utils.inheritance.newInstance(d,arguments)
}this.element=b(e);
c.call(this)
};
ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder.prototype.update=function(h){c.call(this);
var i=h;
var f=this.getValueProcessors();
if(!i){i=ContextHub.get(this.getKey())
}if(!i||(i==="")){i=this.getDefaultValue()
}for(var d=0;
d<f.length;
d++){var e=f[d];
var g=ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.getProcessor(e);
i=b.trim(g.handler.call(this,i))
}if(this.element.val()!==i){this.element.text(i)
}};
ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder.prototype.getPropertyName=function(){c.call(this);
return this.propertyName||""
};
ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder.prototype.getKey=function(){c.call(this);
return this.keyName||""
};
ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder.prototype.getDefaultValue=function(){c.call(this);
return this.defaultValue||""
};
ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder.prototype.getValueProcessors=function(){return this.processors||[]
};
ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder.prototype.isValid=function(){return !!this.propertyName
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - PageInteraction.PropertyProcessor.js");
(function(c,b){b.ContextHub.SegmentEngine.PageInteraction=b.ContextHub.SegmentEngine.PageInteraction||{};
var d={};
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor={};
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.register=function(f,e){if((typeof f==="string")&&f.length){d[f]={processorName:f,handler:e}
}};
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.unregister=function(e){delete d[e]
};
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.unregisterAllProcessors=function(){d={}
};
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.getAllProcessors=function(){return d
};
var a={processorName:"default",handler:function(e){return e
}};
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.getProcessor=function(e){return d[e]||a
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - PageInteraction.Teaser.js");
(function(b,a){a.ContextHub.SegmentEngine.PageInteraction=a.ContextHub.SegmentEngine.PageInteraction||{};
ContextHub.SegmentEngine.PageInteraction.Teaser=function(d){var c=ContextHub.SegmentEngine.PageInteraction.Teaser;
if(!(this instanceof c)){return ContextHub.Utils.inheritance.newInstance(c,arguments)
}d=d||{};
this.details={locationId:b.trim(d.locationId),variants:d.variants||[],strategy:b.trim(d.strategy),trackingURL:b.trim(d.trackingURL)};
this.register()
};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.info={className:"Teaser",loadEvent:ContextHub.Constants.EVENT_TEASER_LOADED};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.register=function(){if(!this.details.locationId.length||!this.details.variants.length||this.isRegistered()){return
}this.registered=ContextHub.SegmentEngine.PageInteraction.TeaserManager.register(this)
};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.unregister=function(){this.registered=false;
ContextHub.SegmentEngine.PageInteraction.TeaserManager.unregister(this)
};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.updatePlaceholder=function(){var c=this.getBestCandidate();
if(c&&((this.currentlyLoaded||{}).path===c.path)){return
}if(c){this.getVariantContent(c.url,function(e){var d=b("#"+this.details.locationId);
d.html(e);
ContextHub.eventing.trigger(ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.info.loadEvent,{teaser:this,variant:c,key:this.details.locationId,action:"set",value:"loaded"},{defer:0})
}.bind(this));
this.currentlyLoaded=c
}else{delete this.currentlyLoaded
}};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.getVariantContent=function(f,e,g){var c=ContextHub.SegmentEngine.PageInteraction.Cache.get(f);
if(c){e.call(this,c.content,c.status,c.xhr);
return
}var d={url:f,async:true};
var h=b.ajax(d);
h.done(function(j,i,k){ContextHub.SegmentEngine.PageInteraction.Cache.set(f,{content:j,status:i,xhr:k});
e.call(this,j,i,k)
});
if(typeof g==="function"){h.fail(function(i){g.call(this,i)
})
}};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.getBestCandidate=function(){var g=null;
var h=[];
var l=[];
var k=ContextHub.SegmentEngine.SegmentManager.getResolvedSegments({returnLookup:true});
var e=this.details.variants;
for(var n=0;
n<e.length;
n++){var o=e[n];
var i=o.segments||[];
var c=false;
var f=false;
o.boost=0;
if(i.length===0){c=true;
f=true
}else{for(var m=0;
m<i.length;
m++){var j=k[i[m]];
if(typeof j!=="undefined"){c=true;
o.boost=Math.max(o.boost,j.boost||0)
}}}if(c){var d=f?l:h;
d.push(o)
}}if((h.length===0)||(this.details.strategy==="random")){h=[].concat.call(h,l)
}if(h.length){h.sort(function(q,p){return p.boost-q.boost
});
g=ContextHub.SegmentEngine.PageInteraction.StrategyManager.chooseCandidate(h,this.details.strategy)
}return g
};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.getCurrentlyLoaded=function(){return this.currentlyLoaded||null
};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.isRegistered=function(){return this.registered===true
};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.getTeaserId=function(){return this.details.locationId
};
ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.toString=function(){var c=[];
b.each(c,function(d,e){c.push(d+': "'+e+'"')
});
return this.info.className+"("+c.join(", ")+")"
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - PageInteraction.TeaserManager.js");
(function(b,a){a.ContextHub.SegmentEngine.PageInteraction=a.ContextHub.SegmentEngine.PageInteraction||{};
var c={};
ContextHub.SegmentEngine.PageInteraction.TeaserManager={};
ContextHub.SegmentEngine.PageInteraction.TeaserManager.info={registerEvent:ContextHub.Constants.EVENT_TEASER_REGISTERED,unregisterEvent:ContextHub.Constants.EVENT_TEASER_UNREGISTERED};
ContextHub.SegmentEngine.PageInteraction.TeaserManager.register=function(d){if(!(d instanceof ContextHub.SegmentEngine.PageInteraction.Teaser)){return false
}c[d.getTeaserId()]=d;
ContextHub.eventing.trigger(ContextHub.SegmentEngine.PageInteraction.TeaserManager.info.registerEvent,{teaser:d,key:d.getTeaserId(),action:"set",value:"registered"},{defer:0});
return true
};
ContextHub.SegmentEngine.PageInteraction.TeaserManager.unregister=function(d){var e;
if(d instanceof ContextHub.SegmentEngine.PageInteraction.Teaser){e=d
}else{e=this.getTeaser(d)
}if(e){e.registered=false;
delete c[e.getTeaserId()];
ContextHub.eventing.trigger(ContextHub.SegmentEngine.PageInteraction.TeaserManager.info.unregisterEvent,{teaser:e,key:e.getTeaserId(),action:"remove",value:"unregistered"},{defer:0})
}};
ContextHub.SegmentEngine.PageInteraction.TeaserManager.unregisterAllTeasers=function(){b.each(c,function(d,e){e.unregister()
})
};
ContextHub.SegmentEngine.PageInteraction.TeaserManager.getAllTeasers=function(){return c
};
ContextHub.SegmentEngine.PageInteraction.TeaserManager.getTeaser=function(d){return c[d]||null
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - PageInteraction.StrategyManager.js");
(function(d,c){c.ContextHub.SegmentEngine.PageInteraction=c.ContextHub.SegmentEngine.PageInteraction||{};
var a={};
ContextHub.SegmentEngine.PageInteraction.StrategyManager={};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.register=function(g,e,f){if((typeof g==="string")&&g.length){a[g]={strategyName:g,displayName:e,handler:f}
}};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.unregister=function(e){delete a[e]
};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.unregisterAllStrategies=function(){a={}
};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.getAllStrategies=function(){return a
};
var b={strategyName:"default",displayName:"Default (first teaser candidate)",handler:function(e){return(e||[])[0]||null
}};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.getStrategy=function(e){return a[e]||b
};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.chooseCandidate=function(f,e){var g=ContextHub.SegmentEngine.PageInteraction.StrategyManager.getStrategy(e);
return g.handler.call(this,f)
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - PageInteraction.Cache.js");
(function(c,b){b.ContextHub.SegmentEngine.PageInteraction=b.ContextHub.SegmentEngine.PageInteraction||{};
var a={};
ContextHub.SegmentEngine.PageInteraction.Cache={};
ContextHub.SegmentEngine.PageInteraction.Cache.set=function(d,e){a[d]=e
};
ContextHub.SegmentEngine.PageInteraction.Cache.get=function(d){return a[d]||null
};
ContextHub.SegmentEngine.PageInteraction.Cache.getAllItems=function(){return a||{}
};
ContextHub.SegmentEngine.PageInteraction.Cache.clear=function(d){delete a[d]
};
ContextHub.SegmentEngine.PageInteraction.Cache.clearAllItems=function(){a={}
}
})(ContextHubJQ,window);
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - util.case-manipulation.js");
(function(){var b=function(d){return String(d).toLowerCase()
};
var a=function(d){return String(d).toUpperCase()
};
var c=function(d){return String(d).toLowerCase().replace(/(^| )+(.)/g,function(e){return e.toUpperCase()
})
};
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.register("lower-case",b);
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.register("upper-case",a);
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.register("title-case",c)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - util.number-formatting.js");
(function(){var a=function(c){var d=function(e){return((e<=9)?"0":"")+e
};
var b=new Date(c*1000);
b=isNaN(b.getMilliseconds())?new Date():b;
return[[b.getFullYear(),d(b.getMonth()+1),d(b.getDay())].join("-"),[d(b.getHours()),d(b.getMinutes()),d(b.getSeconds())].join(":")].join(" ")
};
ContextHub.SegmentEngine.PageInteraction.PropertyProcessor.register("timestamp-to-date",a)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - task.page-update-watcher.js");
(function(d,c){var b=c.MutationObserver||c.WebKitMutationObserver;
if(b){var a={childList:true,attributes:true,characterData:true,subtree:true,attributeOldValue:true,characterDataOldValue:true,attributeFilter:[ContextHub.SegmentEngine.PageInteraction.info.propertyHolder,ContextHub.SegmentEngine.PageInteraction.info.defaultHolder,ContextHub.SegmentEngine.PageInteraction.info.processorHolder]};
d(function(){var e=new b(function(g){var j="["+ContextHub.SegmentEngine.PageInteraction.info.propertyHolder+"]";
var i=[];
for(var f=0;
f<g.length;
f++){var h=g[f];
d.merge(i,d(h.addedNodes).filter(j));
if(h.attributeName&&h.target){i.push(h.target)
}}d.each(d.unique(i),function(k,l){var m=ContextHub.SegmentEngine.PageInteraction.PropertyPlaceholder(l);
if(m.isValid()){m.update()
}})
});
e.observe(c.document.body,a)
})
}d(function(){var e=ContextHub.SegmentEngine.PageInteraction.getPropertyPlaceholders();
d.each(e,function(f,g){if(g.isValid()){g.update()
}})
})
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - task.data-update-watcher.js");
(function(b){var a="page-interaction";
ContextHub.eventing.on(ContextHub.Constants.EVENT_STORE_UPDATED,function(e,f){var d=(f||{}).store;
var c=ContextHub.SegmentEngine.PageInteraction.getPropertyPlaceholders(d);
b.each(c,function(g,l){var h=l.getPropertyName();
var k=this.eventData.keys.set.hash[h];
var i=this.eventData.keys.removed.hash[h];
var j=k?k.value:undefined;
if(k||i){l.update(j)
}}.bind({eventData:f}))
},a,true)
}(ContextHubJQ));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - task.teaser-update.js");
(function(b){var d=80;
var e=0;
var c=function(){var f=ContextHub.SegmentEngine.PageInteraction.TeaserManager.getAllTeasers();
b.each(f,function(h,g){if(g.isRegistered()){g.updatePlaceholder()
}})
};
var a=function(){var f=new Date().getTime();
if((f-e)>=d){c();
e=0;
return
}window.requestAnimationFrame(a)
};
ContextHub.eventing.once([ContextHub.Constants.EVENT_ALL_STORES_READY,ContextHub.Constants.EVENT_STORES_PARTIALLY_READY],function(){var f=[ContextHub.Constants.EVENT_SEGMENT_UPDATED,ContextHub.Constants.EVENT_STORE_UPDATED+":campaign",ContextHub.Constants.EVENT_TEASER_REGISTERED];
ContextHub.eventing.off(f,"teaser-updater");
ContextHub.eventing.on(f,function(){var g=e===0;
e=new Date().getTime()+d;
if(g){a()
}},"teaser-updater",true)
},"teaser-initialization",true)
}(ContextHubJQ));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - strategy.first.js");
(function(){var a=function(b){return(b||[])[0]||null
};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.register("first","First candidate",a)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - strategy.last.js");
(function(){var a=function(c){var b;
if(c){b=c[c.length-1]
}return b||null
};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.register("last","Last candidate",a)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.segment-engine.page-interaction - strategy.random.js");
(function(){var a=function(c){var b;
if(c){b=c[Math.floor(Math.random()*c.length)]
}return b||null
};
ContextHub.SegmentEngine.PageInteraction.StrategyManager.register("random","Random",a)
})();
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.store.contexthub.surferinfo - store.surferinfo.js");
(function(d,g){var e;
var h=function(l,m){var k={};
k[l]=m;
e=d.extend(true,e,k);
return k
};
var f=function(){var l=d("<div>").css({width:"1in",visibility:"hidden",position:"absolute",top:0,left:0});
l.appendTo(d("body"));
var k=l.innerWidth();
l.detach();
return k
};
var b=function(l){var n;
var k;
var m=l.orientation;
if(typeof m==="undefined"){n=(l.screen.width>l.screen.height)?"landscape":"portrait";
k="normal"
}else{if(m===-90||m===90){n="landscape";
k=(m===90)?"left":"right"
}else{n="portrait";
k=(m===0)?"normal":"upside-down"
}}return{mode:n,direction:k}
};
var j=function(){var l;
var k=["Opera","Chromium","Chrome","Safari","Edge","Trident","MSIE","Firefox","AppleWebKit"];
var n=g.navigator.userAgent;
var m=n.match(new RegExp("( |^)("+k.join("|")+")(/| )[0-9.]*","ig"));
if(m){m=d.map(m,function(o){o=d.trim(o).split(/[\/ ]/);
return{version:o.pop(),family:o.pop()}
});
m=m.sort(function(p,o){if(p.family===o.family){return(p.version<o.version)?-1:1
}return(d.inArray(p.family,k)<d.inArray(o.family,k))?-1:1
});
l=m.shift();
if(l.family==="Trident"){l.family="MSIE";
l.version={"7.0":"11","6.0":"10","5.0":"9","4.0":"8"}[l.version]
}}else{l={version:"Unresolved",family:"Unresolved"}
}return d.extend(l,{userAgent:n})
};
var c=function(){var n=null;
var q;
var p;
var L=g.navigator.userAgent;
var l=L.match(/mobile|touch/i);
var t=L.match(/tablet/i);
var k=L.match(/iphone/i);
var r=L.match(/ipod/i);
var v=L.match(/ipad/i);
var G=L.match(/htc/i);
var w=L.match(new RegExp("(BlackBerry)([^/]*)/([0-9.]*)","i"));
var y=L.match(/GT-([^ ]*)/);
var u=L.match(/ipad|ipod|iphone/i);
var K=L.match(/android/i);
var H=L.match(/windows/i);
var o=L.match(/(mobile|tablet);/i)&&L.match(/; rv:/i);
var M=K&&l;
var m=K&&t;
var B=H&&l;
var F=H&&t;
var J=w&&l;
var s=w&&t;
var x=o&&l;
var E=o&&t;
var A=k||r||M||B||J||x;
var D=v||m||F||s||E;
var C="Desktop";
if(A){C="Mobile"
}else{if(D){C="Tablet"
}}if(u){n="iOS";
p=u.shift();
q=(L.match("OS ([0-9_]*)")||[""]).pop().replace(/_/g,".")
}if(!n&&H){n="windows"
}if(!n&&G){n="Android";
p=G.shift();
q=(L.match("HTC[_ /]([^ _;-]*)")||[""]).pop()
}if(!n&&w&&w.length===4){n="Blackberry";
p=w.slice(1,3).join(" ");
q=w.pop()
}if(!n&&y){var I={I90:"Galaxy S",I91:"Galaxy S II",I93:"Galaxy S III",I95:"Galaxy S IV",N70:"Note",N71:"Note II",P31:"Tab",P51:"Tab II"};
var z=y.pop();
n="Android";
p="Samsung "+(I[z.slice(0,3)]||"GT-"+z);
q=(L.match("Android ([0-9.]*)")||[z]).pop()
}if(!n&&K){n="Android";
p="Unresolved";
q=(L.match("Android ([0-9.]*)")||[""]).pop()
}if(!n){n="Desktop";
p="PC";
q=""
}return{category:C,type:n,model:p,version:q}
};
var a=function(){var n=null;
var k;
var m=g.navigator.userAgent;
var p=m.match(/Mac OS X|Macintosh/);
if(p){n="Mac OS X";
k=(m.match(/(Mac OS X|CPU OS) ([0-9_]*)/)||[""]).pop().replace(/_/g,".");
k=(m.match(/iPod|iPad|iPhone/)?"iOS ":"")+k
}if(!n&&m.indexOf("Windows")!==-1){n="Windows";
k=null;
var o=m.match(/Windows (.+?);/).pop();
var l={"NT 10.0":"10","NT 6.3":"8.1","NT 6.2":"8","NT 6.1":"7","NT 6.0":"Vista","NT 5.2":"XP x64","NT 5.1":"XP","NT 5.01":"2000 SP1","NT 5.0":"2000","NT 4.0":"NT 4.0","98":"98","NT 95":"95","NT CE":"CE"};
k=l[o];
if(k==="98"&&m.indexOf("Win 9x 4.90")!==-1){k="ME"
}}if(!n&&m.match(/Linux/)){n="Linux";
k=null
}if(!n&&m.match(/Android/)){n="Android";
k=(m.match("Android ([0-9.]*)")||[""]).pop()
}return{name:(n||"Unresolved"),version:(k||"Unresolved")}
};
function i(l,k){this.init(l,k);
this.config=d.extend({},this.config,k);
this.readData()
}ContextHub.Utils.inheritance.inherit(i,ContextHub.Store.PersistedStore);
i.prototype.readData=function(){e={};
var p=this.getItem("display");
if(!p){var k=g.devicePixelRatio||1;
var n=g.screen.colorDepth;
p=h("display",{resolution:{width:g.screen.width*k,height:g.screen.height*k},devicePixelRatio:k,colorDepth:n,nrOfColors:Math.pow(2,n),pixelsPerInch:f(),orientation:b(g)}).display.resolution
}if(!this.getItem("window")){var m=h("window",{dimension:{width:d(g).innerWidth()*k,height:d(g).innerHeight()*k}}).window.dimension;
h("window",{percentageUsage:Math.floor(((m.width*m.height)/(p.width*p.height))*100)/100})
}if(!this.getItem("browser")){h("browser",j())
}var o=c();
if(!this.getItem("device")){h("device",o)
}if(!this.getItem("isMobile")){h("isMobile",o.type!=="desktop")
}if(!this.getItem("os")){h("os",a())
}var l=new Date();
e.year=l.getFullYear();
e.month=l.getMonth()+1;
e.day=l.getDate();
e.hour=l.getHours();
e.minutes=l.getMinutes();
this.addAllItems(e,{defer:0})
};
i.prototype.reset=function(k){this.uber("reset",k);
this.readData()
};
ContextHub.Utils.storeCandidates.registerStoreCandidate(i,"contexthub.surferinfo",0)
}(ContextHubJQ,this));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.store.granite.profile - store.profile.js");
(function(c){var a={service:{jsonp:false,timeout:1000,path:"${contexthub:/store/profile/path}.infinity.json"},initialValues:{path:ContextHub.Constants.ANONYMOUS_HOME||"/home/users/a/anonymous"}};
var d=function(g){var e=24*3600*365.25*1000;
var f=new Date(g).getTime();
return ~~((Date.now()-f)/e)
};
var b=function(f,e){this.config=c.extend(true,{},a,e);
this.init(f,this.config);
this.onUpdate("age-update",function(i,j){var h=j.keys.set.hash["/birthday"];
if(h){var g=this;
window.setTimeout(function(){g.setItem("age",d(h.value))
},50)
}});
this.queryService(false)
};
ContextHub.Utils.inheritance.inherit(b,ContextHub.Store.PersistedJSONPStore);
b.prototype.successHandler=function(g){this.pauseEventing();
var j=this.getItem("path");
if(j){j=Granite.HTTP.externalize(j)
}var e=c.extend(true,{},g.profile);
var i=!!ContextHub.Utils.JSON.tree.getItem(e,"/photos/primary/image");
var h=/\/(jcr|sling|):/;
c.each(ContextHub.Utils.JSON.tree.getKeys(e),function(m,n){if(n.match(h)){e=ContextHub.Utils.JSON.tree.removeItem(e,n)
}});
e=ContextHub.Utils.JSON.tree.setItem(e,"path",j);
if(i){e=ContextHub.Utils.JSON.tree.setItem(e,"avatar",j+"/profile/photos/primary/image")
}if(e.birthday){e=ContextHub.Utils.JSON.tree.setItem(e,"age",d(e.birthday))
}e.authorizableId=e.authorizableId||g["rep:authorizableId"];
var f="anonymous";
if(e.givenName&&e.familyName){f=e.givenName+" "+e.familyName
}else{if(e.givenName){f=e.givenName
}else{if(e.familyName){f=e.familyName
}else{if(e.authorizableId){f=e.authorizableId
}}}}e=ContextHub.Utils.JSON.tree.setItem(e,"displayName",f);
this.setItem("/",e);
var l=(e.displayName==="anonymous")?"anonymous":e.authorizableId;
var k=l?("authorizableId="+l):null;
ContextHub.Shared.CookieContainer.setItem("SessionPersistence","PROFILEDATA",k);
this.resumeEventing()
};
b.prototype.loadProfile=function(f){var e=ContextHub.getStore("profile");
e.setItem("path",f?Granite.HTTP.externalize(f):f);
e.queryService(true)
};
ContextHub.Utils.storeCandidates.registerStoreCandidate(b,"granite.profile",0)
}(ContextHubJQ));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] cq.contexthub - store.clientcontext-backedstore.js (clientcontext connector)");
(function(a){window.ContextHub.Store=window.ContextHub.Store||{};
ContextHub.Store.ClientContextBackedStore=function(){};
ContextHub.Utils.inheritance.inherit(ContextHub.Store.ClientContextBackedStore,ContextHub.Store.PersistedJSONPStore);
ContextHub.Store.ClientContextBackedStore.defaultConfig={mappingConfig:{propertyMapping:{},mapOtherProperties:true,replicateToClientContext:true}};
ContextHub.Store.ClientContextBackedStore.prototype.init=function(c,b){this.uber("init",c,b);
this.config=a.extend(true,{},this.config,ContextHub.Store.ClientContextBackedStore.defaultConfig,b)
};
ContextHub.Store.ClientContextBackedStore.prototype.successHandler=function(d){var b=this.isEventingPaused();
var c=this.config.mappingConfig.clientContextStoreName;
var g={};
var f;
if(this.preventSelfUpdating){return
}this.preventSelfUpdating=true;
d=d||function(h,i){return i
};
this.pauseEventing();
this.setItem("/",{});
a.each(this.config.mappingConfig.propertyMapping,function(h,i){g[i]=true;
f=ClientContext.get(c+"/"+i);
f=d(i,f);
this.setItem("/"+h,f)
}.bind(this));
if(this.config.mappingConfig.mapOtherProperties){var e=ClientContext.get(c).data||{};
a.each(e,function(h,i){if(!g[h]){i=d(h,i);
this.setItem("/"+h,i)
}}.bind(this))
}if(!b){this.resumeEventing()
}this.preventSelfUpdating=false
};
ContextHub.Store.ClientContextBackedStore.prototype.failureHandler=function(b){};
ContextHub.Store.ClientContextBackedStore.prototype.queryService=function(d,c){var e=this.config.mappingConfig.clientContextStoreName;
var b=this;
var f=function(){var g=ClientContext.get(e);
var h=b.isEventingPaused();
b.pauseEventing();
if(g){g.addListener("update",function(){if(b.preventSelfUpdating!==true){b.successHandler(c)
}});
b.successHandler(c)
}else{b.failureHandler()
}if(!h){b.resumeEventing()
}b.announceReadiness()
};
if(ClientContext.get(e)){f()
}else{CQ_Analytics.ClientContextMgr.addListener("storeregister",function(h,g){if(g.STORENAME===e){f()
}})
}};
ContextHub.Store.ClientContextBackedStore.prototype.setItem=function(c,d){this.uber("setItem",c,d);
if(this.config.mappingConfig.replicateToClientContext&&(this.preventSelfUpdating!==true)){var b=c.replace(/^\//,"");
if(b.length){var e=this.config.mappingConfig.propertyMapping[b];
if(!e&&this.config.mappingConfig.mapOtherProperties){e=b
}if(e){ClientContext.set(this.config.mappingConfig.clientContextStoreName+"/"+e,d)
}}}};
ContextHub.Store.ClientContextBackedStore.prototype.removeItem=function(d){this.uber("removeItem",d);
if(this.config.mappingConfig.replicateToClientContext&&(this.preventSelfUpdating!==true)){var b=d.replace(/^\//,"");
if(b.length){var e=this.config.mappingConfig.propertyMapping[b];
if(!e&&this.config.mappingConfig.mapOtherProperties){e=b
}if(e){var c=CQ_Analytics.StoreRegistry.getStore(this.config.mappingConfig.clientContextStoreName);
if(c){c.removeProperty(e)
}}}}}
}(ContextHubJQ));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.store.granite.profile - store.clientcontext-profile.js (clientcontext connector)");
(function(c){var a={mappingConfig:{clientContextStoreName:"profile",propertyMapping:{displayName:"formattedName",path:"path",avatar:"avatar"},mapOtherProperties:true,replicateToClientContext:true}};
var b=function(e,f){if(e==="path"&&typeof(f)==="string"){f=f.replace(/\/profile$/,"")
}return f
};
var d=function(f,e){this.config=c.extend({},true,a,e);
this.init(f,this.config);
this.queryService(true,b)
};
ContextHub.Utils.inheritance.inherit(d,ContextHub.Store.ClientContextBackedStore);
d.prototype.loadProfile=function(e){var f=(e||"").split("/").pop();
if(f.length){ClientContext.get(this.config.mappingConfig.clientContextStoreName).loadProfile(f)
}};
d.prototype.reset=function(){var e=ClientContext.get(this.config.mappingConfig.clientContextStoreName);
if(e){e.reset()
}};
ContextHub.Utils.storeCandidates.registerStoreCandidate(d,"granite.profile",10,function(){return !!window.ClientContext
})
}(ContextHubJQ));
(function(c,f){c.Granite=c.Granite||{};
c.Granite.author=c.Granite.author||{};
function b(){var g=document.body,h=document.createElement("div");
g.appendChild(h);
h.style.width="1in";
var i=document.defaultView.getComputedStyle(h,null).getPropertyValue("width");
g.removeChild(h);
return parseFloat(i)
}function e(){var g={type:"screen",width:c.innerWidth||document.documentElement.clientWidth,height:c.innerHeight||document.documentElement.clientHeight,"device-width":c.screen.width,"device-height":c.screen.height,"device-pixel-ratio":1,resolution:b(),scan:"progressive",grid:false,color:c.screen.colorDepth,"color-index":c.screen.pixelDepth,monochrome:0};
g["aspect-ratio"]=g.width/g.height;
g.orientation=g.width>g.height?"landscape":"portrait";
g["device-aspect-ratio"]=g["device-width"]/g["device-height"];
return g
}function d(g){var h=g.createElement("style");
h.appendChild(g.createTextNode(""));
g.head.appendChild(h);
return h
}var a=function(g){this.document=g;
this._getRules()
};
a.getNativeDevice=e;
a.prototype={};
Object.defineProperty(a.prototype,"appliedStyleSheet",{get:function(){var h=true,g=this._appliedStyleSheet;
while(g&&(g=g.parentNode)){if(g===this.document){h=false;
break
}}if(!this._appliedStyleSheet||h){this._appliedStyleSheet=d(this.document)
}return this._appliedStyleSheet
}});
a.prototype._getRules=function(){var n=[],m=a.parser.getMediaRules(this.document),l,k,h,g;
for(k=0;
k<m.length;
k++){g=[];
l=a.parser.parseMediaRule(m[k].media.mediaText);
for(h=0;
h<m[k].cssRules.length;
h++){g.push(m[k].cssRules[h].cssText)
}n.push({mediaText:m[k].media.mediaText,cssRules:g,parsed:l,mediaRule:m[k]})
}this.rules=n
};
a.prototype.removeMediaRules=function(){for(var g=0;
g<this.rules.length;
g++){while(this.rules[g].mediaRule.cssRules[0]){this.rules[g].mediaRule.deleteRule(0)
}}};
a.prototype.clear=function(){document.head.removeChild(this.appliedStyleSheet);
this.appliedStyleSheet=null
};
a.prototype.restore=function(){var l,k,g;
document.head.removeChild(this.appliedStyleSheet);
this.appliedStyleSheet=null;
for(k=0;
k<this.rules.length;
k++){try{l=this.rules[k];
for(g=0;
g<l.cssRules.length;
g++){l.mediaRule.insertRule(l.cssRules[g],l.mediaRule.cssRules.length)
}}catch(h){}}};
a.prototype.applyDevice=function(l){var m,k,g;
this.clear();
this.removeMediaRules();
this.appliedStyleSheet.sheet.insertRule("html, body { width: "+l.width+"px; }",0);
for(k=0;
k<this.rules.length;
k++){try{m=this.rules[k];
if(a.parser.matchDevice(m.parsed,l)){for(g=0;
g<m.cssRules.length;
g++){this.appliedStyleSheet.sheet.insertRule(m.cssRules[g],this.appliedStyleSheet.sheet.cssRules.length)
}}}catch(h){}}};
a.prototype.prepareDevice=function(h){var g={type:h.type||"screen","device-pixel-ratio":h["device-pixel-ratio"]||1,resolution:h.resolution||96,scan:h.scan||"progressive",grid:!!h.grid,color:h.color||8,"color-index":h["color-index"]||0,monochrome:h.monochrome||0};
g.width=Math.floor(h.width/g["device-pixel-ratio"]);
g.height=Math.floor(h.height/g["device-pixel-ratio"]);
g["device-width"]=h["device-width"]||g.width;
g["device-height"]=h["device-height"]||g.height;
g["aspect-ratio"]=h["aspect-ratio"]||(h.width/h.height);
g.orientation=h.orientation||(h.width>h.height?"landscape":"portrait");
g["device-aspect-ratio"]=h["device-aspect-ratio"]||(h["device-width"]/h["device-height"]);
return g
};
c.Granite.author.MediaEmulator=a
}(this));
(function(k,e){var m=/^(?:(only|not)?\s*([_a-z][_a-z0-9-]*)|(\([^\)]+\)))(?:\s*and\s*(.*))?$/i,a=/^\(\s*([_a-z-][_a-z0-9-]*)\s*(?:\:\s*([^\)]+))?\s*\)$/,b=/^(?:(min|max)-)?(.+)/,j=/(em|rem|px|cm|mm|in|pt|pc)?\s*$/,g=/(dpi|dpcm|dppx)?\s*$/;
function f(p){var o=Number(p),n;
if(!o){n=p.match(/^(\d+)\s*\/\s*(\d+)$/);
o=n[1]/n[2]
}return o
}function c(o){var p=parseFloat(o),n=String(o).match(g)[1];
switch(n){case"dpcm":return p/2.54;
case"dppx":return p*96;
default:return p
}}function l(o){var p=parseFloat(o),n=String(o).match(j)[1];
switch(n){case"em":return p*16;
case"rem":return p*16;
case"cm":return p*96/2.54;
case"mm":return p*96/2.54/10;
case"in":return p*96;
case"pt":return p*72;
case"pc":return p*72/12;
default:return p
}}function h(r){var u,t,q,v,s;
u=r.styleSheets;
t=[];
for(var o=0;
o<u.length;
o++){try{q=u[o];
v=q.cssRules;
for(var n=0;
n<(v?v.length:0);
n++){s=v[n];
if(s.type===CSSRule.MEDIA_RULE){t.push(s)
}}}catch(p){}}return t
}function d(n){return n.split(",").map(function(r){var q=r.trim().match(m),p=((q[3]||"")+(q[4]||"")).trim().match(/\([^\)]+\)/g),o={};
o.not=!!q[1]&&q[1].toLowerCase()==="not";
o.type=q[2]?q[2].toLowerCase():"all";
o.expressions=p?p.map(function(u){var t=u.match(a),s=t[1].toLowerCase().match(b);
return{modifier:s[1],feature:s[2],value:t[2]}
}):[];
return o
})
}function i(p,q){var r,n,s;
for(var o=0;
o<p.length;
o++){r=p[o];
n=r.type==="all"||q.type===r.type;
if((n&&r.not)||!(n||r.not)){continue
}s=r.expressions.every(function(x){var u=x.feature,t=x.modifier,w=x.value,v=q[u];
if(!v){return false
}switch(u){case"orientation":case"scan":return v.toLowerCase()===w.toLowerCase();
case"width":case"height":case"device-width":case"device-height":w=l(w);
v=l(v);
break;
case"resolution":w=c(w);
v=c(v);
break;
case"aspect-ratio":case"device-aspect-ratio":case"device-pixel-ratio":w=f(w);
v=f(v);
break;
case"grid":case"color":case"color-index":case"monochrome":w=parseInt(w,10)||1;
v=parseInt(v,10)||0;
break
}switch(t){case"min":return v>=w;
case"max":return v<=w;
default:return v===w
}});
if((s&&!r.not)||(!s&&r.not)){return true
}}}Granite.author.MediaEmulator.parser={getMediaRules:h,parseMediaRule:d,matchDevice:i}
}(this));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.store.granite.emulators - store.emulators.js");
(function(c){var b=[{id:"ipad",title:"iPad",type:"tablet",platform:"iOS",platformVersion:"5.1.1",width:768,height:1024,canRotate:true,orientation:"Portrait","device-pixel-ratio":1},{id:"ipad-2",title:"iPad 2",type:"tablet",platform:"iOS",platformVersion:"8.1.3",width:768,height:1024,canRotate:true,orientation:"Portrait","device-pixel-ratio":1},{id:"ipad-3",title:"iPad 3 / 4 / Air",type:"tablet",platform:"iOS",platformVersion:"8.1.3",width:1536,height:2048,canRotate:true,orientation:"Portrait","device-pixel-ratio":2},{id:"iphone-4",title:"iPhone 4",type:"mobile",platform:"iOS",platformVersion:"7.1.2",width:640,height:960,canRotate:true,orientation:"Portrait","device-pixel-ratio":2},{id:"iphone-5",title:"iPhone 5",type:"mobile",platform:"iOS",platformVersion:"8.1.3",width:640,height:1136,canRotate:true,orientation:"Portrait","device-pixel-ratio":2},{id:"iphone-6",title:"iPhone 6",type:"mobile",platform:"iOS",platformVersion:"8.1.3",width:750,height:1334,canRotate:true,orientation:"Portrait","device-pixel-ratio":2},{id:"iphone-6-plus",title:"iPhone 6 Plus",type:"mobile",platform:"iOS",platformVersion:"8.1.3",width:1080,height:1920,canRotate:true,orientation:"Portrait","device-pixel-ratio":3},{id:"galaxy-s4",title:"Samsung Galaxy S4",type:"mobile",platform:"Android",platformVersion:"4.4.2 KitKat",width:1080,height:1920,canRotate:true,orientation:"Portrait","device-pixel-ratio":3}];
var a={defaultEmulators:b};
var d=function(g,f){this.config=c.extend(true,{},a,f);
var e=this.getSupportedEmulators();
c.extend(true,this.config,{initialValues:{devices:e,currentDeviceId:e[0].id,orientations:[{id:"landscape",title:"Landscape"},{id:"portrait",title:"Portrait"}]}});
this.init(g,this.config);
this.mediaEmulator=null;
if(window.Granite&&Granite.author&&Granite.author.MediaEmulator){this.mediaEmulator=new Granite.author.MediaEmulator(window.document)
}this.emulateDevice(this.getItem("currentDeviceId")||"native")
};
ContextHub.Utils.inheritance.inherit(d,ContextHub.Store.PersistedStore);
d.prototype.detectNativeDevice=function(){var h=window.innerWidth||document.documentElement.clientWidth;
var i=window.innerHeight||document.documentElement.clientHeight;
var f=(h>i)?"Landscape":"Portrait";
var e=ContextHub.get("surferinfo/os/name")||"";
var g=ContextHub.get("surferinfo/os/version")||"";
return{id:"native",title:"Native",type:"screen",width:h,height:i,orientation:f,platform:e,platformVersion:g,canRotate:!(/mac os x|windows/i).test(e)}
};
d.prototype.getSupportedEmulators=function(){return c.merge([this.detectNativeDevice()],this.config.defaultEmulators)
};
d.prototype.emulateDevice=function(f){var e=f?this.getDeviceById(f):ContextHub.get("emulators/currentDevice");
if(e&&this.mediaEmulator){this.setItem("currentDeviceId",e.id);
this.setItem("currentDevice",e);
if(f==="native"){this.mediaEmulator.restore()
}else{this.mediaEmulator.applyDevice(e)
}this.eventing.trigger("emulating-device:"+e.id,{device:e})
}return e
};
d.prototype.getDeviceById=function(g){var e=null;
var f=this.getItem("devices")||[];
c.each(f,function(h,i){if(i.id===g){e=i
}return e===null
});
return e
};
d.prototype.reset=function(){this.uber("reset");
var e=this.getItem("currentDeviceId");
this.emulateDevice(e)
};
ContextHub.Utils.storeCandidates.registerStoreCandidate(d,"granite.emulators",0)
}(ContextHubJQ));
ContextHub.console.log("[+] loading [contexthub.store.contexthub.eventdata------------------------------] store.eventdata.js");
(function(c){var a={initialValues:{events:[]}},b=function(e,d){this.config=c.extend(true,{},a,d);
this.init(e,this.config);
this.clean();
this.setItem("number",Math.random())
};
ContextHub.Utils.inheritance.inherit(b,ContextHub.Store.Core);
ContextHub.Utils.storeCandidates.registerStoreCandidate(b,"contexthub.eventdata",0)
}(ContextHubJQ,this));
ContextHub.console.log("[+] loading [contexthub.store.contexthub.pagedata------------------------------] store.pagedata.js");
(function(c){var a={initialValues:{}},b=function(e,d){this.config=c.extend(true,{},a,d);
this.init(e,this.config);
this.clean();
this.setItem("number",Math.random())
};
ContextHub.Utils.inheritance.inherit(b,ContextHub.Store.Core);
ContextHub.Utils.storeCandidates.registerStoreCandidate(b,"contexthub.pagedata",0)
}(ContextHubJQ,this));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.store.campaign.metadata - store.campaign.metadata.js");
(function(d,c){var a={service:{jsonp:false,ttl:0,secure:"auto",host:document.location.host,port:80,path:Granite.HTTP.externalize(Granite.HTTP.getPath()+"/_jcr_content.campaign.metadata.json")},persistence:ContextHub.Utils.Persistence({mode:ContextHub.Utils.Persistence.Modes.WINDOW})};
var f=d("#campaignContextHub");
if(f.length){a.service.method=f.data("metadata-method")||"GET";
var e=f.data("path");
if(e){a.service.path=Granite.HTTP.externalize(e+"/_jcr_content.campaign.metadata.json")
}}var b=function(h,g){this.config=d.extend(true,{},a,g);
this.dataAvailable=false;
this.init(h,this.config);
this.setItem("/",{},{silent:true});
this.queryService(true)
};
ContextHub.Utils.inheritance.inherit(b,ContextHub.Store.JSONPStore);
d.extend(b.prototype,{isOldMetaDataFormat:function(){var g=this.getItem("/_/version");
return !!g&&g===1
},isDataAvailable:function(){return this.dataAvailable
},getMetadataVariable:function(h){function g(j,l){var k=l.indexOf(".");
if(k==-1){k=l.length
}var i=l.substring(0,k);
if(!j.hasOwnProperty(i)){return null
}if(k==l.length){return j[i]
}return g(j[i].content,l.substring(k+1))
}return g(this.getTree(),h)
},getFilteredTree:function(g){function h(l){for(var j in l){if(!l.hasOwnProperty(j)){continue
}if(l[j].type&&!g(l[j])){delete l[j]
}else{if(l[j].content){l[j].content=h(l[j].content);
var k=true;
for(var i in l[j].content){if(l[j].content.hasOwnProperty(i)){k=false;
break
}}if(k){delete l[j]
}}}}return l
}return h(this.getTree())
},convertToColumnViewFormat:function(h){var j="tags";
var g="tag";
function i(o,l){var q=[];
for(var s in o){if(o.hasOwnProperty(s)){q.push(o[s]);
o[s].key=s
}}q.sort(function(v,u){if(v.hasOwnProperty("order")&&u.hasOwnProperty("order")){return(v.order<u.order?-1:1)
}if(v.hasOwnProperty("order")){return 1
}return v.label.localeCompare(u.label)
});
var r=[];
for(var p=0;
p<q.length;
p++){var n=q[p];
var k=l+(l?".":"")+n.key;
var t={_links:{self:{href:k,title:n.label}},properties:{}};
if(n.tag){t.value=n.tag
}if(n.type){t.type=n.type
}if(n.content){t.icon=j;
t.hasChildren=true;
var m=i(n.content,k);
if(!m.length){continue
}t._embedded={items:m}
}else{t.icon=g
}r.push(t)
}return r
}return{_links:{self:{href:"foo"}},_embedded:{items:i(h,"")}}
},successHandler:function(h){if(h){this.dataAvailable=true;
var g;
if(h.hasOwnProperty("schema")){g=1
}else{g=2
}this.setItem("/_/version",g);
this.setItem("/",h)
}return h
},failureHandler:function(g){ContextHub.console.log("Error while getting mcm campaign metadata information:",g)
}});
ContextHub.Utils.storeCandidates.registerStoreCandidate(b,"campaign.metadata",0,function(){return(f.length>0&&!!(f.attr("data-register")))
})
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.store.campaign.seeddata - store.campaign.seeddata.js");
(function(d,f){var b=false;
var g=new RegExp(/(^[a-zA-Z0-9\/_-]+)*(\.[a-zA-Z]+)?/);
var e=g.exec(document.location.pathname);
var i="";
if(e){i=e[1]+"/_jcr_content.campaign.seeddata.json"
}var c={service:{jsonp:false,ttl:0,secure:"auto",host:document.location.host,port:80,path:i+"/${contexthub:/store/profile/campaign/seedId}"},persistence:ContextHub.Utils.Persistence({mode:ContextHub.Utils.Persistence.Modes.WINDOW})};
var h=function(k,j){this.config=d.extend(true,{},c,j);
this.init(k,this.config)
};
ContextHub.Utils.inheritance.inherit(h,ContextHub.Store.JSONPStore);
d.extend(h.prototype,{successHandler:function(j){if(j){this.setItem("/",j)
}return j
},failureHandler:function(j){ContextHub.console.log("Error while getting mcm campaign seeddata information:",j)
},queryService:function(j){if(b){this.uber("queryService",j)
}}});
var a=function(){var j=ContextHub.getStore("profile");
if(j){var k=j.getItem("/");
b=!!(k&&k.campaign&&k.campaign.seedId)
}return b
};
ContextHub.Utils.storeCandidates.registerStoreCandidate(h,"campaign.seeddata",0,function(){var k=d("#campaignContextHub").eq(0);
var j=(k.length>0&&!!(k.attr("data-register")));
if(j){ContextHub.eventing.on(ContextHub.Constants.EVENT_STORE_UPDATED+":profile",function(m,n){var l=ContextHub.getStore("seeddata");
if(l){l.setItem("/",{});
if(a()){l.queryService(false)
}}})
}return j
})
}(ContextHubJQ,window));
ContextHub.console.log("[+] loading [contexthub.store.contexthub.digitalData-component------------------------------] store.digitalData-component.js");
(function(e){var d={initialValues:{componentList:[]}},f={INFO_TYPES:{NAVIGATION:"navigation"},SETTING_IDS:{FUNDS:"funds"}};
function c(){this.attribute={assets:"",onSiteSearchFilter:"",onSiteSearchResult:"",onSiteSearchSuggestion:"",onSiteSearchTerm:"",participants:"",searchMatchType:"",settingList:[],sitePromotionId:"",sponsorName:""};
this.category={accountType:"",assetClass:"",audience:"",brand:"",country:"",dealerFirm:"",investmentName:"",investmentObjective:"",language:"",objective:"",productType:"",purpose:"",region:"",theme:"",ticker:"",type:""};
this.info={author:"",id:"",name:"",publishDate:"",variant:"",version:""}
}function b(){this.id="";
this.valueList=[]
}function a(h,g){this.config=e.extend(true,{},g,d);
this.init(h,this.config);
this.reset();
this.setItem("number",Math.random());
this.models={newComponentListItem:function(){return new c()
},newSettingListItem:function(){return new b()
}};
this.Constants=e.extend(true,{},f)
}ContextHub.Utils.inheritance.inherit(a,ContextHub.Store.JSONPStore);
ContextHub.Utils.storeCandidates.registerStoreCandidate(a,"contexthub.digitalData-component",0)
}(ContextHubJQ,this));
ContextHub.console.log("[+] loading [contexthub.store.contexthub.digitalData-event------------------------------] store.digitalData-event.js");
(function(d){var b={initialValues:{eventList:[]}},e={EVENT_ACTIONS:{START:"start",STEP:"step",STOP:"stop",COMPLETE:"complete",COMPLETE_25_PERCENT:"complete25Percent",COMPLETE_50_PERCENT:"complete50Percent",COMPLETE_75_PERCENT:"complete75Percent",DOWNLOAD:"download",FAILURE:"failure",LOCKOUT:"lockout",SETTING_ADD:"settingAdd",SETTING_REMOVE:"settingRemove",SETTING_REVIEW:"settingReview",SETTING_COMMIT:"settingCommit",LOAD:"load",CLICK_THROUGH:"clickThrough",LOAD:"load",PLAY:"play",NAVIGATE:"navigate",AUTOCOMPLETE:"autocomplete",FILTER:"filter",RESULTS:"results"},EVENT_NAMES:{ADVISOR_LOCATOR:"advisorLocator",APPLICATION:"application",CONTENT_SET:"contentSet",LIT_CENTER:"litCenter",MULTI_STEP:"multiStep",NAVIGATION_LOCATION:"navigationLocation",ON_SITE_SEARCH:"onSiteSearch",ON_SITE_SEARCH_FACET:"onSiteSearchFacet",PROMO:"promo",SCENE7:"scene7"},EVENT_TYPES:{ACCOUNT_ACTIVITY:"accountActivity",CONTENT:"content",LOGIN:"login",MEDIA:"media",NAVIGATION:"navigation",SEARCH:"search",SELF_SERVICE:"selfService",TOOL:"tool"},STORE_ITEM_KEYS:{EVENT_LIST:"eventList"}};
function c(){this.info={action:"",label:"",name:"",timestamp:(new Date()).getTime(),type:"",value:""}
}function a(g,f){this.config=d.extend(true,{},f,b);
this.init(g,this.config);
this.reset();
this.setItem("number",Math.random());
this.models={newEventListItem:function(){return new c()
}};
this.Constants=d.extend(true,{},e)
}ContextHub.Utils.inheritance.inherit(a,ContextHub.Store.JSONPStore);
ContextHub.Utils.storeCandidates.registerStoreCandidate(a,"contexthub.digitalData-event",0)
}(ContextHubJQ,this));
ContextHub.console.log("[+] loading [contexthub.store.contexthub.digitalData-page------------------------------] store.digitalData-page.js");
(function(c){var a={initialValues:{category:{audience:"",brand:"",channel:"",country:"",language:"",objective:"",purpose:"",region:"",theme:"",type:""},info:{author:"",breadCrumbList:[],dataCenter:"",destinationUrl:"",errorType:"",id:"",name:"",namePrefix:"",namePostfix:"",publishDate:"",referringUrl:"",templateName:"",variant:"",version:""},instanceId:""}},b=function(f,e){this.config=c.extend(true,{},e,a);
this.init(f,this.config);
this.reset();
this.setItem("number",Math.random());
this.getFullPageName=function(){return d(this)
}
};
function d(h){var e=h.getItem("info/name")||"",f=h.getItem("info/namePrefix")||"",g=h.getItem("info/namePostfix")||"";
return f+e+g
}ContextHub.Utils.inheritance.inherit(b,ContextHub.Store.JSONPStore);
ContextHub.Utils.storeCandidates.registerStoreCandidate(b,"contexthub.digitalData-page",0)
}(ContextHubJQ,this));
ContextHub.console.log("[+] loading [contexthub.store.contexthub.digitalData-user------------------------------] store.digitalData-user.js");
(function(f){var e={initialValues:{primaryProfile:new a(),profileList:[]}},h={USER_QS_PARAM_NAMES:{CAMPAIGN_ADVISOR_ID:"aeid",CAMPAIGN_ID:"cid",EXT_CAMPAIGN_ID:"et_cid",EXT_MEMBER_ID:"Et_mid",SFMC_SUBSCRIBER_ID:"sfid",SFMC_LIST_ID:"l",ORIG_CAMPAIGN_LINK_ID:"u",EXT_CAMPAIGN_BATCH_ID:"jb",EXT_CAMPAIGN_CONV_ALIAS:"alias",EXT_CAMPAIGN_SRC:"src"}},g=function(j,i){this.config=f.extend(true,{},i,e);
this.init(j,this.config);
this.setItem("number",Math.random());
this.models={newProfileListItem:function(){return new a()
},newSegmentListItem:function(){return""
}};
this.Constants=f.extend(true,{},h)
};
function d(j,i){if(String.prototype.trim.call(j||"")&&f.inArray(j,this.segmentList)===-1){this.segmentList.push(j)
}if(i){this.primarySegment=j
}}function b(){var i=[];
f.extend(true,this,i);
this.noDupes=true
}b.prototype=new Array();
b.prototype.constructor=b;
function c(){this.primarySegment="";
this.segmentList=new b()
}c.prototype.pushSegmentName=d;
function a(){this.environment={day:0,browser:{family:"",userAgent:"",version:""},device:{category:"",model:"",type:"",version:""},display:{colorDepth:0,devicePixelRatio:0,nrOfColors:0,orientation:{direction:"",mode:""},pixelsPerInch:0,resolution:{height:0,width:0}},flashVersion:"",hour:0,isMobile:false,minutes:0,month:0,os:{name:"",version:""},window:{dimension:{width:0,height:0},percentageUsage:0},year:0};
this.geolocation={latitude:0,longitude:0,generatedThumbnail:""};
this.info={advisorAssistantInd:"",advisorId:"",advisorEmailId:"",advisorType:"",cgUserInitials:"",campaignEmailLink:"",campaignExtId:"",campaignSourcePlatform:"",dateOfFirstUse:(new Date()).getTime(),daysSinceFirstUse:0,daysSinceLastUse:0,daysSinceLastVisit:0,firmChannel:"",firmDesc:"",firmId:"",firmTypeCd:"",instUserId:"",investorGreeting:"",investorGreetingDisplay:"",investorId:"",marketingTier:"",planParticipantId:"",researchPortfolioCoordTerrId:"",returningStatus:"",saviLoginInd:"",sfmcBatchId:"",sfmcConversionAlias:"",sfmcId:"",sfmcListId:"",sfmcMemberId:"",siteSwitcher:"",sponsorOpId:"",stateCd:"",nadiaSubscriberId:"",userLoginType:"",visionId:"",adobeMarketingCloudVisitorId:"",wholesalerId:"",wholesalerTerrId:"",teleWholesalerContactInfo:{primary:{cgInitials:"",firstName:"",fullNameDisplay:"",lastName:"",phone:"",phoneDisplay:"",phoneDisplayNoExtension:"",phoneExtension:""},primaryImagePath:"",schedulerId:"",emailAddress:"",videoRef:"",biotext:"",linkedInProfile:""}};
this.portfolio={primaryPlan:{category:"",info:{icu:"",id:""}}};
this.segment=new c()
}ContextHub.Utils.inheritance.inherit(g,ContextHub.Store.PersistedJSONPStore);
ContextHub.Utils.storeCandidates.registerStoreCandidate(g,"contexthub.digitalData-user",0)
}(ContextHubJQ,this));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.finalize - ContextHub.store-initialization.js");
(function(d,c){var b=ContextHub;
var a=c.ContextHubKernelConfig||{};
var e=b.Shared.timers.start();
b.console.log(b.Shared.timestamp(),"[+] starting registration and initialization of the stores");
d.each(a.stores||{},function(h,j){var f=b.Utils.storeCandidates.getStoreFromCandidates(j);
if(f){try{var i=b.Shared.timers.start();
var k=b.Shared.timestamp();
b.registerStore(h,new f(h,j.config));
b.console.log(k,'[+] initializing "'+h+'" store ('+b.Shared.timers.finish(i)+"ms)")
}catch(g){b.console.error('Store "'+j.type+'" (',f,") could not be initialized:",g)
}}});
b.console.log(b.Shared.timestamp(),"[+] all stores initialized ("+b.Shared.timers.finish(e)+"ms)")
}(ContextHubJQ,window));
ContextHub.console.log(ContextHub.Shared.timestamp(),"[loading] contexthub.finalize - ContextHub.finalization.js");
ContextHub.console.timeStamp("contexthub.stop");
ContextHub.console.timeEnd("contexthub.js");