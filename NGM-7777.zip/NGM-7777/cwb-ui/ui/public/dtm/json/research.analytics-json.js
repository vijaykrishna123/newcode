{"contextHubData": {
"pageStore": {"category":{"audience":"CWB","brand":"The Capital Group","channel":"The Capital Group - CWB","country":"us","language":"en"},"info":{"breadCrumbList":["CWB","Research"],"destinationUrl":"/research","name":"CWB > Research"}}
, "eventStore": {}
, "clientSideHandlerStore": {}
}}