import configDeterminator from "../configs/configDeterminator";
import axios from "axios";

export const getAllAssignmentForUser = emailId => {
  return axios.get(
    configDeterminator.cmpApiEndpoint + "/assignments?search=" + emailId,
    {
      headers: {
        Accept: "application/json"
      }
    }
  );
};

export const getAllRegularAssignmentsAPI = username => {
  return axios.get(
    `${configDeterminator.cwbApiEndpoint}/assignments/${username}`,
    {
      headers: {
        Accept: "application/json"
      }
    }
  );
};

export const getAllUnlikedAssignment = username => {
  return axios.get(
    `${configDeterminator.cwbApiEndpoint}/assignments/unlinked/${username}`,
    {
      headers: {
        Accept: "application/json"
      }
    }
  );
};

export const linkDraftToAssignmentApi = payload => {
  return axios.put(`${configDeterminator.cwbApiEndpoint}/link`, {
    percolateId: payload.assignmentId,
    draftId: payload.draftId,
    assignmentName: payload.assignmentName
  });
};

export const deleteDraftApi = payload => {
  return axios.delete(
    `${configDeterminator.cwbApiEndpoint}/delete/${payload.id}`
  );
};

export const weneedfeedbackApi = ({ username, feedback }) => {
  const body = {
    recepient: "CE_Tech@capgroup.com",
    subject: "CWB Feedback from " + username,
    textContent: feedback
  };
  return axios.post(configDeterminator.cwbApiEndpoint + "/feedback/email", {
    ...body,
    headers: {
      Accept: "application/json"
    }
  });
};

export const getProjectsApi = userInitials => {
  return axios.get(
    configDeterminator.cwbApiEndpoint +
      "/comments?relatedInitial=" +
      userInitials
  );
};

export const shareurlAPI = data => {
  return axios.post(
    configDeterminator.cwbApiEndpoint + "/comments/share",
    data
  );
};
export const deleteProjects = commentId => {
  return axios.delete(
    configDeterminator.cwbApiEndpoint + "/comments/" + commentId
  );
};

export const fetchTemplatesAPI = () => {
  return axios.get(`${configDeterminator.cwbApiEndpoint}/templates`);
};
