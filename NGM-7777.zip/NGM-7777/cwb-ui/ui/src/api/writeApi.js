import configDeterminator from "../configs/configDeterminator";
import axios from "axios";
export const getWrite = postId => {
  let url = configDeterminator.cwbApiEndpoint + "/assignment" + postId;
  return axios.get(url);
};

export const updateUserLastLogin = user => {
  return axios.put(configDeterminator.cwbApiEndpoint + "/users", user);
};

export const edamApi = param => {
  return axios
    .post(configDeterminator.cmpApiEndpoint + "/wip-url", param)
    .catch(error => {
      console.error(error);
    });
};

export const uploadFileApi = ({
  file,
  url = "/graphics",
  assignmentId,
  userId,
  name,
  id
}) => {
  const formData = new FormData();
  formData.append("file", file);
  //const config = { headers: { "content-type": "multipart/form-data" } };
  formData.append("userId", userId);
  formData.append("postId", assignmentId);
  if (url === "/graphics") {
    formData.append("graphicId", id);
  } else {
    formData.append("backupId", id);
  }

  if (name) {
    return axios.put(configDeterminator.cwbApiEndpoint + url, formData);
  } else {
    return axios.post(configDeterminator.cwbApiEndpoint + url, formData);
  }
};
export const deleteBackups = ({ backupId }) => {
  return axios.delete(
    configDeterminator.cwbApiEndpoint + "/backups/" + backupId
  );
};

export const deleteGraphicAPI = ({ graphicId }) => {
  return axios.delete(
    configDeterminator.cwbApiEndpoint + "/graphics/" + graphicId
  );
};

export const saveWriteFormAPI = payload => {
  return axios.put(
    configDeterminator.cwbApiEndpoint +
      "/assignment/" +
      payload.assignment.percolateId,
    payload
  );
};
export const createProofApi = payload => {
  return axios.post(configDeterminator.legalApiEndpoint + "/proof?", {
    ...payload
  });
};
export const createProofVersionApi = payload => {
  return axios.post(`${configDeterminator.legalApiEndpoint}/proof-version`, {
    ...payload
  });
};

export const createPersistproofAPI = payload => {
  return axios.put(
    `${configDeterminator.cwbApiEndpoint}/persist-proof/${payload.id}`,
    {
      ...payload
    }
  );
};

export const fetchPersonalURLForProof = payload => {
  return axios.post(`${configDeterminator.legalApiEndpoint}/personalurl`, {
    ...payload
  });
};

export const addReviewerApi = payload => {
  return axios.put(`${configDeterminator.legalApiEndpoint}/add-reviewer`, {
    ...payload
  });
};

export const shareReviewerApi = data => {
  return axios.post(
    configDeterminator.cwbApiEndpoint + "/comments/add_reviewer",
    data
  );
};

export const callShareProofAPI = data => {
  return axios.post(
    configDeterminator.cwbApiEndpoint + "/comments/proof",
    data
  );
};

export const callShareProofVersionAPI = data => {
  return axios.post(
    configDeterminator.cwbApiEndpoint + "/comments/proof_version",
    data
  );
};

export const fetchReviewerApi = payload => {
  return axios.get(
    `${configDeterminator.legalApiEndpoint}/reviewers?fileId=${payload.fileId}&emailId=${payload.emailId}`,
    {
      ...payload
    }
  );
};

export const fetchAssignmentCollaboratorsApi = payload => {
  const { userInitials } = payload;
  return axios.get(
    `${configDeterminator.legalApiEndpoint}/users/${userInitials}`
  );
};

export const startLegalReviewAPI = payload => {
  const { id } = payload;
  return axios.post(
    `${configDeterminator.legalApiEndpoint}/document/upload/${id}`,
    {
      ...payload
    }
  );
};

export const sendPdfToWorkfrontAPI = payload => {
  const { id, workfrontDocId } = payload;
  return axios.put(
    `${configDeterminator.cwbApiEndpoint}/persist-workfront-details/${id}`,
    {
      workfrontDocId
    }
  );
};
