import Plugin from "@ckeditor/ckeditor5-core/src/plugin";
import SpecialCharactersEditing from "./SpecialCharactersEditing";
import SpecialCharactersUI from "./SpecialCharactersUI";

export default class SpecialCharacterPlugin extends Plugin {
  static get requires() {
    return [SpecialCharactersEditing, SpecialCharactersUI];
  }
}
