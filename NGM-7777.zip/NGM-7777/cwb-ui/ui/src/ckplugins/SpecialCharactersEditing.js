import Plugin from "@ckeditor/ckeditor5-core/src/plugin";
import SpecialCharactersCommand from "./SpecialCharactersCommand"; // ADDED
import Widget from "@ckeditor/ckeditor5-widget/src/widget";
import {
    viewToModelPositionOutsideModelElement
} from "@ckeditor/ckeditor5-widget/src/utils";

export default class SpecialCharactersEditing extends Plugin {
  static get requires() {
    return [Widget];
  }

  init() {
    this._defineSchema(); // ADDED
    this._defineConverters(); // ADDED
    this.editor.commands.add(
      "specialchars",
      new SpecialCharactersCommand(this.editor)
    );

    this.editor.editing.mapper.on(
      "viewToModelPosition",
      viewToModelPositionOutsideModelElement(this.editor.model, viewElement =>
        viewElement.hasClass("specialchars")
      )
    );
  }

  _defineSchema() {
    // ADDED
    const schema = this.editor.model.schema;

    schema.register("specialchars", {
      // Allow wherever text is allowed:
      allowWhere: "$text",

      // The placeholder will act as an inline node:
      isInline: true,

      // The inline widget is self-contained so it cannot be split by the caret and can be selected:
      isObject: true,

      // The placeholder can have many types, like date, name, surname, etc:
      allowAttributes: ["charType"]
    });
  }

  _defineConverters() {
    // ADDED
    const conversion = this.editor.conversion;

    conversion.for("upcast").elementToElement({
      view: {
        name: "span",
        classes: ["specialchars"]
      },
      model: (viewElement, modelWriter) => {
        // Extract the "name" from "{name}".
        console.log(
          "View Element",
          viewElement,
          modelWriter,
          viewElement.getChild(0)
        );
        let charType = viewElement.getChild(0) && viewElement.getChild(0).data;
        console.log("charType", charType);

        return modelWriter.createElement("specialchars", { charType });
      }
    });

    conversion.for("editingDowncast").elementToElement({
      model: "specialchars",
      view: (modelItem, viewWriter) => {
        const widgetElement = createSpecialCharacterView(modelItem, viewWriter);

        // Enable widget handling on a placeholder element inside the editing view.
        return widgetElement;
      }
    });

    conversion.for("dataDowncast").elementToElement({
      model: "specialchars",
      view: createSpecialCharacterView
    });

    // Helper method for both downcast converters.
    function createSpecialCharacterView(modelItem, viewWriter) {
      const charType = modelItem.getAttribute("charType");

      const specialCharacterView = viewWriter.createContainerElement("span", {
        class: "specialchars"
      });

      // Insert the placeholder name (as a text).
      const innerText = viewWriter.createText(charType);
      viewWriter.insert(
        viewWriter.createPositionAt(specialCharacterView, 0),
        innerText
      );

      return specialCharacterView;
    }
  }
}
