import Plugin from "@ckeditor/ckeditor5-core/src/plugin";
import controls from "./controls.json";

import {
  addListToDropdown,
  createDropdown
} from "@ckeditor/ckeditor5-ui/src/dropdown/utils";

import Collection from "@ckeditor/ckeditor5-utils/src/collection";
import Model from "@ckeditor/ckeditor5-ui/src/model";

export default class SpecialCharactersUI extends Plugin {
  init() {
    const editor = this.editor;
    const t = editor.t;
    const specialCharacters = controls;

    // The "placeholder" dropdown must be registered among the UI components of the editor
    // to be displayed in the toolbar.
    editor.ui.componentFactory.add("specialchars", locale => {
      const dropdownView = createDropdown(locale);
      dropdownView.class = "special-char-dropdown";

      // Populate the list in the dropdown with items.
      addListToDropdown(
        dropdownView,
        getDropdownItemsDefinitions(specialCharacters)
      );

      dropdownView.buttonView.set({
        // The t() function helps localize the editor. All strings enclosed in t() can be
        // translated and change when the language of the editor changes.
        label: t("Ω Symbol"),
        tooltip: false,
        withText: true
      });

      // Execute the command when the dropdown item is clicked (executed).
      this.listenTo(dropdownView, "execute", evt => {
        editor.execute("specialchars", { value: evt.source.commandParam });
        editor.editing.view.focus();
      });

      return dropdownView;
    });
  }
}

function getDropdownItemsDefinitions(specialCharacters) {
  const itemDefinitions = new Collection();

  for (const char of specialCharacters) {
    const definition = {
      type: "button",
      model: new Model({
        commandParam: char.icon,
        label: char.icon,
        withText: true
      })
    };

    // Add the item definition to the collection.
    itemDefinitions.add(definition);
  }

  return itemDefinitions;
}
