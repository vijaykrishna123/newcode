import configDeterminator from "../../configs/configDeterminator";

/**
 * Analytics Handling component for CWB
 * @param {*} pageName
 * @param {*} analyticsFileName
 */
/* global Capgroup, Analytics */

export function loadPageData(pageName, analyticsFileName) {
  if (
    configDeterminator.envName !== "alpha" &&
    configDeterminator.includeAnalytics &&
    typeof Capgroup != "undefined"
  ) {
    var userInitials = "";
    if (localStorage.getItem("userInitials") !== null) {
      userInitials = localStorage.getItem("userInitials");
    } else if (localStorage.getItem("okta-token-storage") !== null) {
      userInitials = JSON.parse(
        localStorage.getItem("okta-token-storage")
      ).idToken.claims.preferred_username.split("@")[0];
    }
    var ddPageStore = Capgroup.ContextHub.stores.page,
      ddUserStore = Capgroup.ContextHub.stores.user;
    ddPageStore.setItem("info/name", "CWB >" + pageName);
    ddPageStore.pushItem("info/breadCrumbList", ("CWB," + pageName).split(","));
    ddPageStore.setItem("info/destinationURL", null);
    ddPageStore.setItem("category/brand", "Capital Group");
    ddPageStore.setItem("category/audience", "CWB");
    ddPageStore.setItem("category/country", "us");
    ddPageStore.setItem("category/channel", "Capital Group - CWB");
    ddPageStore.setItem("category/language", "en");
    ddPageStore.setItem("category/region", "");
    ddUserStore.setItem("primaryProfile/info/cgUserInitials", userInitials);
    Capgroup.ContextHub.clientSideDefaultDataService.setContextHubData();
    let jsonFileName = "/dtm/json/" + analyticsFileName + ".analytics-json.js";
    Capgroup.ContextHub.ContextHubDataSet.nextGenSendingData = false;
    Capgroup.ContextHub.ContextHubDataSet.legacySendingData = false;
    Analytics.singlePageApp.recordStateByURI(jsonFileName);
  }
}

/**
 * Function for recording the search term analytics
 */
export function recordSearchTermAnalytics(query, results, analyticsFileName) {
  if (
    configDeterminator.envName !== "alpha" &&
    configDeterminator.includeAnalytics &&
    typeof Capgroup != "undefined"
  ) {
    var ddComponentStore = Capgroup.ContextHub.stores.component,
      ddComponentListItem = ddComponentStore.models.newComponentListItem(),
      ddEventStore = Capgroup.ContextHub.stores.event,
      ddEventListItem = ddEventStore.models.newEventListItem();

    ddComponentListItem.info.name = "Search";
    ddComponentListItem.attribute.onSiteSearchFilter = "";
    ddComponentListItem.attribute.onSiteSearchTerm = query;
    ddComponentListItem.attribute.onSiteSearchResult = results;

    ddComponentStore.pushItem("componentList", ddComponentListItem);
    console.log("ddComponentListItem" + ddComponentListItem);
    ddEventListItem.info.action =
      Capgroup.ContextHub.stores.event.Constants.EVENT_ACTIONS.RESULTS;
    ddEventListItem.info.label = ddComponentListItem.info.name;
    ddEventListItem.info.name =
      Capgroup.ContextHub.stores.event.Constants.EVENT_NAMES.ON_SITE_SEARCH;
    ddEventListItem.info.type =
      Capgroup.ContextHub.stores.event.Constants.EVENT_TYPES.SEARCH;
    ddEventListItem.info.value = results;

    ddEventStore.pushItem("eventList", ddEventListItem);
    Capgroup.ContextHub.ContextHubDataSet.nextGenSendingData = false;
    Capgroup.ContextHub.ContextHubDataSet.legacySendingData = false;

    Analytics.singlePageApp.recordStateByURI(
      "/dtm/json/" + analyticsFileName + ".analytics-json.js",
      {
        componentStore: {
          componentList: [ddComponentListItem]
        },
        eventStore: {
          eventList: [ddEventListItem]
        }
      }
    );
  }
}

/**
 * Function for recording the facet analytics
 */
export function recordSearchFacetAnalytics(
  query,
  record_count,
  args,
  analyticsFileName
) {
  if (
    configDeterminator.envName !== "alpha" &&
    configDeterminator.includeAnalytics &&
    typeof Capgroup != "undefined"
  ) {
    var ddComponentStore = Capgroup.ContextHub.stores.component,
      ddComponentListItem = ddComponentStore.models.newComponentListItem(),
      ddEventStore = Capgroup.ContextHub.stores.event,
      ddEventListItem = ddEventStore.models.newEventListItem();

    ddComponentListItem.info.name = query;
    ddComponentListItem.attribute.onSiteSearchFilter = args;
    ddComponentListItem.attribute.onSiteSearchTerm = query;
    ddComponentListItem.attribute.onSiteSearchResult = record_count;

    ddComponentStore.pushItem("componentList", ddComponentListItem);

    ddEventListItem.info.action =
      Capgroup.ContextHub.stores.event.Constants.EVENT_ACTIONS.RESULTS;
    ddEventListItem.info.label = ddComponentListItem.info.name;
    ddEventListItem.info.name = "onSiteSearchFacet";
    ddEventListItem.info.type =
      Capgroup.ContextHub.stores.event.Constants.EVENT_TYPES.SEARCH;
    ddEventListItem.info.value = record_count;

    ddEventStore.pushItem("eventList", ddEventListItem);
    Capgroup.ContextHub.ContextHubDataSet.nextGenSendingData = false;
    Capgroup.ContextHub.ContextHubDataSet.legacySendingData = false;

    Analytics.singlePageApp.recordStateByURI(
      "/dtm/json/" + analyticsFileName + ".analytics-json.js",
      {
        componentStore: {
          componentList: [ddComponentListItem]
        },
        eventStore: {
          eventList: [ddEventListItem]
        }
      }
    );
  }
}

/**
 * Function for recording the snippet click
 */
export function recordSnippetClick(title) {
  if (
    configDeterminator.envName !== "alpha" &&
    configDeterminator.includeAnalytics &&
    typeof Capgroup != "undefined"
  ) {
    var ddEventStore = Capgroup.ContextHub.stores.event,
      ddEventListItem = ddEventStore.models.newEventListItem();

    ddEventListItem.info.action = "clickThrough";
    ddEventListItem.info.label = title;
    ddEventListItem.info.name = "contentSet";
    ddEventListItem.info.type = "content";

    ddEventStore.pushItem("eventList", ddEventListItem);
    Capgroup.ContextHub.ContextHubDataSet.nextGenSendingData = false;
    Capgroup.ContextHub.ContextHubDataSet.legacySendingData = false;

    Analytics.singlePageApp.recordStateByURI(
      "/dtm/json/research.analytics-json.js",
      {
        eventStore: {
          eventList: [ddEventListItem]
        }
      }
    );

    Capgroup.ContextHub.stores.event.reset();
  }
}

export function recordState(jsPath, analyticsConfig) {
  if (
    configDeterminator.envName !== "alpha" &&
    configDeterminator.includeAnalytics &&
    typeof Capgroup != "undefined"
  ) {
    Analytics.singlePageApp.recordStateByURI(jsPath, analyticsConfig.override);
  }
}
