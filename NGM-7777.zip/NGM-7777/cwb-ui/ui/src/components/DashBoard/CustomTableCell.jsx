import { withStyles } from "@material-ui/core/styles";
import { TableCell } from "@material-ui/core";

const CustomTableCell = withStyles(theme => ({
  head: {
    color: theme.palette.common.white,
    textAlign: "left",
    padding: "0px",
    paddingLeft: "10px"
  },
  body: {
    fontSize: 14,
    textAlign: "left",
    padding: "0px",
    paddingLeft: "10px"
  },
  alignRight: {
    textAlign: "right"
  }
}))(TableCell);

export default CustomTableCell;
