import React from "react";
import {
  Button,
  Dialog,
  FormControlLabel,
  Checkbox,
  FormControl,
  InputLabel,
  Input,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  CircularProgress
} from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import ProjectLinked from "@material-ui/icons/CheckCircleOutline";
import CWBDialog from "../Dialog/CWBDialog";

export const CreatingDraft = ({ open, classes }) => (
  <Dialog open={open}>
    <DialogContent className={classes.loadingContent}>
      <div>
        <div className={classes.loadingContainer}>
          {" "}
          <CircularProgress />{" "}
        </div>
        <div> Draft is being created </div>
      </div>
    </DialogContent>
  </Dialog>
);

export const LinkConfirmation = ({ open, classes, onClose }) => (
  <Dialog open={open}>
    <DialogContent className={classes.confirmationDialog}>
      <div className={classes.confirmationContent}>
        <div>
          <strong>
            Any work currently in your project will be overwritten by this
            draft.
          </strong>
        </div>
        <div> Are you sure you want to link this project? </div>
      </div>
    </DialogContent>
    <DialogActions className={classes.confirmationActions}>
      <Button
        variant="outlined"
        className={classes.marginRight10}
        onClick={onClose}
      >
        No
      </Button>
      <Button
        onClick={() => onClose("Yes")}
        variant="contained"
        className={`${classes.button} ${classes.createDraftBtn}`}
      >
        Yes
      </Button>
    </DialogActions>
  </Dialog>
);

export const RemoveDrafts = ({ open, onClose }) => (
  <CWBDialog
    open={open}
    onClose={onClose}
    confirmation={true}
    message={`Remove this draft?<br /><br />`}
    customClass={`delete-dialog`}
  />
);

export const DraftRemoving = ({ open, classes }) => (
  <Dialog open={open}>
    <DialogContent className={classes.loadingContent}>
      <div>
        <div className={classes.loadingContainer}>
          {" "}
          <CircularProgress />{" "}
        </div>
        <div> Your draft is being linked </div>
      </div>
    </DialogContent>
  </Dialog>
);

export const CreateDraft = ({
  open,
  classes,
  onClose,
  onSubmit,
  name,
  nameHandler,
  formError,
  templates,
  type,
  typeHandler
}) => (
  <Dialog open={open} className={"dlg-create-draft"}>
    <DialogTitle className={classes.dialogTitle + " dlg-title"}>
      <strong>Create a draft project</strong>
      <IconButton
        aria-label="close"
        className={classes.closeButton + " dlg-close"}
        onClick={onClose}
      >
        <CloseIcon />
      </IconButton>
    </DialogTitle>
    <DialogContent className={classes.createDialogContent + " dlg-content"}>
      <form onSubmit={onSubmit}>
        <FormControl fullWidth>
          <InputLabel htmlFor="adornment-amount">Assignment Name</InputLabel>
          <Input id="adornment-amount" value={name} onChange={nameHandler} />
        </FormControl>
        {formError ? <div className={classes.error}>{formError}</div> : null}
        <br />
        <br />
        <div>
          <strong> Select template </strong>{" "}
        </div>
        {templates.map((template, index) => (
          <div key={index}>
            <FormControlLabel
              className={classes.checkbox + " dlg-checkbox"}
              control={
                <Checkbox
                  checked={type === template.templateName}
                  onChange={typeHandler}
                  value={template.templateName}
                  color="primary"
                />
              }
              label={template.templateName}
            />
          </div>
        ))}
        <br />
        <div className={classes.DialogActions}>
          <Button
            variant="outlined"
            className={classes.marginRight10}
            onClick={onClose}
          >
            Cancel
          </Button>{" "}
          <Button
            variant="contained"
            className={`${classes.button} ${classes.createDraftBtn}`}
            type="submit"
          >
            CREATE
          </Button>
        </div>
      </form>
    </DialogContent>
  </Dialog>
);

export const LinkedProjectSuccess = ({ open, classes, onClose, onGoTo }) => (
  <Dialog open={open}>
    <DialogContent className={classes.linkedDialogSuccess}>
      <div>
        <ProjectLinked className={classes.linkedIcon} />
      </div>
      <div> Your project is linked! </div>
      <br />
      <Button
        variant="outlined"
        className={`${classes.buttonOutlined} ${classes.marginRight10}`}
        onClick={onClose}
      >
        CLOSE
      </Button>{" "}
      <Button variant="contained" className={classes.button} onClick={onGoTo}>
        GO TO PROJECT
      </Button>
    </DialogContent>
  </Dialog>
);

export const LinkDraft = ({
  open,
  classes,
  onClose,
  draftToBeLinked,
  assignmentId,
  renderToBeLinkedProjects,
  onLink
}) => (
  <Dialog open={open} className={"dlg-link-draft"}>
    <DialogTitle className={classes.dialogTitle + " dlg-title"}>
      <strong>Select project to link "{draftToBeLinked.name}"</strong>
      <IconButton
        aria-label="close"
        className={classes.closeButton + " dlg-close"}
        onClick={onClose}
      >
        <CloseIcon />
      </IconButton>
    </DialogTitle>

    <DialogContent className={classes.DialogContent + " dlg-content"}>
      {renderToBeLinkedProjects()}
      <br />
      <br />
      <div className={classes.DialogActions}>
        <Button
          variant="outlined"
          className={`${classes.buttonOutlined} ${classes.marginRight10}`}
          onClick={onClose}
        >
          CANCEL
        </Button>{" "}
        <Button
          variant="contained"
          className={`${classes.button} ${classes.createDraftBtn} ${
            assignmentId ? "" : classes.disabled
          }`}
          onClick={onLink}
        >
          LINK
        </Button>
      </div>
    </DialogContent>
  </Dialog>
);
