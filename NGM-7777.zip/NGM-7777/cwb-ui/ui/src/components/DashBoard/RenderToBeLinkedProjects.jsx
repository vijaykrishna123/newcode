import React, { useState } from "react";
import {
  Paper,
  Table,
  TableBody,
  TableHead,
  TableRow,
  FormControlLabel,
  Checkbox
} from "@material-ui/core";
import CustomTableCell from "./CustomTableCell";
import DateDropDown from "./DateDropDown";

function RenderToBeLinkedProjects(props) {
  const {
    classes,
    assignments,
    assignmentId,
    assignmentHandler,
    renderDate,
    sortByDate
  } = props;

  const [sortOrder, setSortOrder] = useState("desc");
  let allProjects = assignments;
  if (assignments && assignments.length) {
    allProjects = sortByDate(assignments, sortOrder);
  }

  const sort = (field, sortOrder) => {
    setSortOrder(sortOrder);
  };

  return (
    <Paper className={classes.paperboxLinkTemplates + " dlg-to-be-linked"}>
      <Table className={classes.table}>
        <TableHead className={classes.contentHeading}>
          <TableRow>
            <CustomTableCell
              component="th"
              scope="row"
              className={classes.checkboxCellHeader}
            >
              NAME
            </CustomTableCell>
            <CustomTableCell>
              <DateDropDown sort={sort} />
            </CustomTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {allProjects.map((assignment, index) => {
            return (
              <TableRow className={"dashboard-table-row"} key={index}>
                <CustomTableCell component="td" scope="row">
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={assignmentId === assignment.id}
                        onChange={assignmentHandler}
                        value={assignment.id}
                        color="primary"
                      />
                    }
                    label={assignment.title}
                  />
                </CustomTableCell>

                <CustomTableCell align="right">
                  {renderDate(assignment)}
                </CustomTableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </Paper>
  );
}

export default RenderToBeLinkedProjects;
