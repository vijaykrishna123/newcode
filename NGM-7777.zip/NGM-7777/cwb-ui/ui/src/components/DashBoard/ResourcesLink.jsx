import React from "react";
import { withStyles, Grid, Typography, Paper } from "@material-ui/core";
import DisclosureFAQ from "../../assets/pdf/CWB-disclosure-faq.pdf";
import DiscoverPdf from "../../assets/pdf/CWB_keyword_vs_natural.pdf";
import Title from "../../components/Common/Title.jsx";

const styles = theme => ({
  Link: {
    fontSize: "14px",
    color: "#005f9e",
    fontWeight: "600",
    "&:hover": {
      color: "#005f9e",
      fontWeight: "600"
    }
  },
  header: {
    fontSize: "24px",
    lineHeight: "24px",
    color: "#fff"
  },
  headerContainer: {
    backgroundImage: "linear-gradient(280deg, #008eaa, #00aea9)",
    padding: "1em"
  },
  category: {
    fontSize: "17px",
    fontWeight: "bold",
    marginBottom: "4px",
    marginTop: ".5em"
  },
  resources: {
    minHeight: "660px"
  }
});
const ResourcesLink = props => {
  const { classes } = props;

  const resourcesLink = [
    {
      header: "Guidelines",
      child: [
        {
          title: "Copy Editor Sharepoint",
          link:
            "http://projects/sites/CGBrandGuidelinesAndAssets/Lists/SharedDocuments/Forms/AllItems.aspx?RootFolder=%2Fsites%2FCGBrandGuidelinesAndAssets%2FLists%2FSharedDocuments%2FCopy%20Editing&FolderCTID=0x01200019564FA27489894AA1FA4F18A37DE964&View=%7BBEB30D9B-8E32-412F-8AF8-5D4380B5DD9B%7D&InitialTabId=Ribbon%2ERead&VisibilityContext=WSSTabPersistence#InplviewHashbeb30d9b-8e32-412f-8af8-5d4380b5dd9b=FolderCTID%3D0x01200019564FA27489894AA1FA4F18A37DE964-SortField%3DLinkFilename-SortDir%3DAsc-RootFolder%3D%252Fsites%252FCGBrandGuidelinesAndAssets%252FLists%252FSharedDocuments%252FCopy%2520Editing"
        },
        {
          title: "Editorial Style Guide",
          link:
            "https://confluence.capgroup.com/pages/viewpage.action?spaceKey=MKED&title=Marketing+Editorial+Style+Guide"
        },
        {
          title: "Email Templates",
          link:
            "http://teams/sites/MarketComm/_layouts/15/WopiFrame.aspx?sourcedoc=/sites/MarketComm/Channel_Library/Email_Templates_for_Writers_Inst-Retail_Tips.pptx&action=default&DefaultItemOpen=1"
        }
      ]
    },
    {
      header: "Internal Databases",
      child: [
        {
          title: "Backup Documents Library",
          link:
            "http://teams/sites/MarketComm/BackupDocLibrary/Forms/AllItems.aspx"
        },
        {
          title: "eCatalogue",
          link:
            "https://nad.capitalgroup.com/content/internal-sites/nad/us/en/home/ecatalog.html"
        },
        {
          title: "eDAM",
          link: "https://edam.capitalgroup.com"
        },
        {
          title: "FAMIS",
          link: "http://famis/FamisWebApp/"
        },
        {
          title: "Galileo",
          link: "http://teams/sites/marketing_research/Pages/Home.aspx"
        },
        {
          title: " IP Bios",
          link: "http://apps/sites/ipbios/Pages/Home.aspx"
        },
        {
          title: "OMS Lit",
          link: "http://omslit/"
        }
      ]
    },
    {
      header: "Brand",
      child: [
        {
          title: "CG Style Guide",
          link: "https://cgweb/about/_docs/cg_short_visual_guidelines.pdf"
        },
        {
          title: "Email Signature/Logo (U.S.)",
          link: "https://cgweb/about/_docs/email_signature_guidelines_CG_R.docx"
        },
        {
          title: "Global Trademarks",
          link:
            "http://projects/sites/CGBrandGuidelinesAndAssets/Lists/SharedDocuments/Forms/AllItems.aspx?RootFolder=%2Fsites%2FCGBrandGuidelinesAndAssets%2FLists%2FSharedDocuments%2FCopy%20Editing&FolderCTID=0x01200019564FA27489894AA1FA4F18A37DE964&View=%7BBEB30D9B-8E32-412F-8AF8-5D4380B5DD9B%7D"
        },
        {
          title: "Marketing Training Materials",
          link:
            "http://teams/sites/MarketComm/MarComReferenceMaterials/MarComTrainingMaterials/Forms/Writers.aspx"
        },
        {
          title: "Design System",
          link:
            "https://www.lingoapp.com/space/94316/k/3B2A8FEF-95F6-4D10-94AC-384ECCF30B04/63DDD94B-E9B9-473C-8D96-9282C3A12E4E/?tkn=BkbFNvzp_vJ8h2VTA1AOcH8lWWC6D7AFr3szW5bcHmE"
        }
      ]
    },
    {
      header: "Creative Workbench Tipsheets",
      child: [
        {
          title: "Disclosure Tipsheet",
          link: DisclosureFAQ
        },
        {
          title: "Keyword vs. Natural Language Tipsheet",
          link: DiscoverPdf
        }
      ]
    },
    {
      header: "Data and Tools",
      child: [
        {
          title: "Capital Advantage Value Prop",
          link:
            "http://teams/sites/MarketComm/BackupDocLibrary/Forms/AllItems.aspx?RootFolder=%2fsites%2fMarketComm%2fBackupDocLibrary%2fCapital%20Advantage%20Value%20Prop%20%28back%20page%29&FolderCTID=0x0120006BB15C3B0400D940AA9D8497484E10B1"
        },
        {
          title: "MRM",
          link: "https://capitalgroup.my.workfront.com"
        },
        {
          title: " Redistribution Rights",
          link:
            "http://teams/sites/mds/visitors/redistribution/Lists/Redistribution%20Rights%20Summary/Redistribution%20Rights%20%20Standard%20View.aspx"
        },
        {
          title: "Stats Grid",
          link:
            "http://projects/sites/CGBrandGuidelinesAndAssets/Lists/SharedDocuments/Forms/AllItems.aspx?RootFolder=%2Fsites%2FCGBrandGuidelinesAndAssets%2FLists%2FSharedDocuments%2FCopy%20Editing%2FMarketing%20Stats%20Grid&FolderCTID=0x01200019564FA27489894AA1FA4F18A37DE964&View=%7BBEB30D9B-8E32-412F-8AF8-5D4380B5DD9B%7D&InitialTabId=Ribbon%2ERead&VisibilityContext=WSSTabPersistence"
        },
        {
          title: "SLOG",
          link:
            "https://confluence.capgroup.com/pages/viewpage.action?spaceKey=SLOG&title=Home"
        },
        {
          title: "Tableau Dashboard",
          link: "https://tabprod/#/site/FAMIS/projects/285/workbooks"
        }
      ]
    },

    {
      header: "External Resources",
      child: [
        {
          title: "AP Stylebook",
          link: "https://www.apstylebook.com/"
        },
        {
          title: "Disclosure Management Console(DMC)",
          link: "https://na.author.capitalgroup.com/scmc"
        }
      ]
    }
  ];

  return (
    <div>
      <Title title="Resources" icon="list" />
      <Paper className={classes.resources}>
        <Grid container spacing={0}>
          <Grid item xs={12}>
            <Typography component="h2" className={"mod-header"}>
              Resources
            </Typography>
          </Grid>
          {resourcesLink.map(data => {
            return (
              <Grid item xs={4} style={{ padding: "1em" }} key={data.header}>
                <Grid
                  container
                  spacing={8}
                  style={{ borderTop: "solid 1px #cccccc" }}
                >
                  <Typography component="h2" className={classes.category}>
                    {data.header}
                  </Typography>
                </Grid>
                <Grid container spacing={8}>
                  {data.child.map(item => {
                    return (
                      <Grid item xs={12} key={item.link}>
                        <a
                          className={classes.Link}
                          href={item.link}
                          rel="noopener noreferrer"
                          target="_blank"
                        >
                          {item.title}
                        </a>
                      </Grid>
                    );
                  })}
                </Grid>
              </Grid>
            );
          })}
        </Grid>
      </Paper>
    </div>
  );
};

export default withStyles(styles)(ResourcesLink);
