import React from "react";
import PropTypes from "prop-types";
import {
  Button,
  Dialog,
  DialogContent,
  DialogActions
} from "@material-ui/core";
import Link from "@material-ui/core/Link";
import { Link as RouterLink } from "react-router-dom";

/**
 * CWB Dialog Component
 * @param {*} props
 */
export default function CWBDialog(props) {
  const {
    open,
    onClose,
    imageIcon,
    message,
    isLinkPresent,
    linkRoute,
    confirmation,
    customClass
  } = props;

  const handleYes = event => {
    onClose("yes");
    event.stopPropagation();
  };

  const handleAlertClose = event => {
    onClose();

    event.stopPropagation();
  };
  return (
    <Dialog
      open={open}
      onClose={onClose}
      aria-labelledby="responsive-dialog-title"
    >
      <DialogContent className={customClass}>
        {imageIcon ? <img src={imageIcon} alt="link" /> : null}
        {message ? <div dangerouslySetInnerHTML={{ __html: message }} /> : null}
        {isLinkPresent ? (
          <Link component={RouterLink} to={linkRoute.to}>
            {linkRoute.message}
          </Link>
        ) : null}
        {!confirmation ? (
          <Button variant="contained" onClick={onClose}>
            Close
          </Button>
        ) : null}
      </DialogContent>
      {confirmation ? (
        <DialogActions>
          <Button onClick={handleYes}>Yes</Button>
          <Button
            className={"btn-medium btn-solid-blue"}
            variant="contained"
            onClick={handleAlertClose}
          >
            No
          </Button>
        </DialogActions>
      ) : null}
    </Dialog>
  );
}

CWBDialog.propTypes = {
  /**Dialog Open or Closed */
  open: PropTypes.bool,
  /**On Close Function */
  onClose: PropTypes.func,
  /**Image Icon to pass */
  imageIcon: PropTypes.string,
  /**Message to pass */
  message: PropTypes.string,
  /**Linked presence */
  isLinkPresent: PropTypes.bool,
  /**Link Route value */
  linkRoute: PropTypes.object,
  /**If confirmation dialog box */
  confirmation: PropTypes.bool,
  /**Custom class to pass */
  customClass: PropTypes.string
};
