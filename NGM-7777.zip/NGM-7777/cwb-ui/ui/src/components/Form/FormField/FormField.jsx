import React from "react";
import { withStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import Grid from "@material-ui/core/Grid";
import MessageIcon from "@material-ui/icons/MessageSharp";
import BackupIcon from "@material-ui/icons/BackupSharp";
import { connect } from "react-redux";
import CKEditor from "@ckeditor/ckeditor5-react";
import ClassicEditor from "../../CKEditor/ckeditor";
import config from "../../../configs/configDeterminator";
import UploadField from "./UploadField";

const styles = theme => ({
  fieldContainer: {
    position: "relative"
  },
  fieldInputWrapper: {
    width: "95%",
    display: "flex"
  },
  slateFieldWrapper: {
    width: "98%",
    marginTop: "6px",
    display: "flex"
  },
  slateFieldWrapperDiv: {
    width: "92%"
  },
  fieldInput: {
    border: "1px solid",
    borderColor: theme.palette.primary.main,
    borderRadius: "5px",
    minHeight: "30px",
    padding: "8px 12px"
  },
  fieldControlWrapper: {
    position: "absolute",
    right: "-10px",
    top: "57px"
  },
  iconButton1: {
    cursor: "pointer",
    position: "absolute",
    right: "-2px",
    top: "-23px",
    margin: "1px 0",
    color: theme.palette.primary.light
  },
  iconButton2: {
    cursor: "pointer",
    position: "absolute",
    right: "-2px",
    top: "-4px",
    margin: "4px 0",
    color: theme.palette.primary.light
  }
});

class FormField extends React.Component {
  constructor(props) {
    super(props);
    this.listenerAdded = false;
    this.unMounted = false;
    this.state = {
      openEditor: false,
      appliedContentDisclosue: false
    };
    this.timeout = setTimeout(() => {
      this.loadEditor();
    }, 1000);
    this.onEditorChange = this.onEditorChange.bind(this);
  }

  sidebarElementRef = React.createRef();
  presenceListElementRef = React.createRef();
  onChange = (id, file) => {
    if (this.props.onFileChange) {
      this.props.onFileChange(id, file);
    }
  };
  loadEditor = () => {
    this.setState({ openEditor: true });
  };

  onEditorChange = async (event, editor) => {
    const { id } = this.props;

    let newData;
    if (!this.state.appliedContentDisclosue && this.props.disclosure.Results) {
      let contentSpecificDisclosureStr = "";
      let newData = editor.getData();
      const Results = this.props.disclosure.Results || [];
      let indexDisclosureStart = newData.indexOf(
        "<strong>Disclosure:</strong>"
      );
      let indexDisclosureLast = newData.indexOf(
        "<strong>Social media posts:</strong>"
      );

      if (indexDisclosureStart !== -1 && indexDisclosureLast !== -1) {
        Results.forEach(item => {
          contentSpecificDisclosureStr =
            contentSpecificDisclosureStr + item.language + "<br/><br/>";
        });
        if (!contentSpecificDisclosureStr) {
          return;
        }
        newData =
          newData.substring(0, indexDisclosureStart) +
          '<strong>Disclosure:</strong> <br/><span>Disclosure text below is read only. Revise using the Disclosure tool, accessed through the link in the left navigation.</span> </p><table class="Headline specific_disclosure" id="specific_disclosure"><tbody><tr><td>' +
          contentSpecificDisclosureStr +
          '</td></tr></tbody></table><div class="socialMedia"><p>' +
          newData.substring(indexDisclosureLast);

        editor.data.set(newData, { suppressErrorInCollaboration: true });
        !this.unMounted && this.setState({ appliedContentDisclosue: true });
      }
    }

    //newData = editor.getData();
    if (newData !== undefined) this.props.onBlur({ id, newData });
  };

  onChangeHandler = event => {
    let value = event.target.value;
    this.setState({
      charaterCount: value.length
      // wordCount: value.split(" ").length - 1
    });
  };
  refreshDisplayMode(editor) {
    const annotations = editor.plugins.get("Annotations");
    const sidebarElement = this.sidebarElementRef.current;
    if (sidebarElement) {
      if (window.innerWidth < 1000) {
        sidebarElement.classList.remove("narrow");
        sidebarElement.classList.add("hidden");
        annotations.switchTo("inline");
      } else if (window.innerWidth < 1300) {
        sidebarElement.classList.remove("hidden");
        sidebarElement.classList.add("narrow");
        annotations.switchTo("narrowSidebar");
      } else {
        if (sidebarElement && sidebarElement.classList) {
          sidebarElement.classList.remove("hidden", "narrow");
        }
        annotations.switchTo("wideSidebar");
      }
    }
  }
  listener = () => {
    return this.props.saveForm(this.editor, this.props.id);
  };
  componentWillUnmount() {
    this.unMounted = true;
    window.removeEventListener("resize", this.boundRefreshDisplayMode);
    window.removeEventListener("save-clicked", this.listener);
    clearTimeout(this.timeout);
  }

  renderFields = () => {
    const {
      classes,
      placeholder = "Type Here",
      fieldType = "TextField",
      label = "Label",
      name,
      value,
      userId,
      assignmentId,
      saveForm,
      id
    } = this.props;
    const documentId = `${label
      .split(" ")
      .join("")
      .concat(assignmentId)}`;
    switch (fieldType) {
      case "Editor":
        return (
          <Grid className={"form-input-editor " + classes.slateFieldWrapper}>
            <div className={"form-input " + classes.slateFieldWrapperDiv}>
              <div className="ckedition-container">
                <div
                  ref={this.presenceListElementRef}
                  id={`presence-list-container-${documentId}`}
                />
                {this.state.openEditor && (
                  <CKEditor
                    onInit={editor => {
                      this.editor = editor;
                      this.boundRefreshDisplayMode = this.refreshDisplayMode.bind(
                        this,
                        editor
                      );
                      window.addEventListener(
                        "resize",
                        this.boundRefreshDisplayMode
                      );
                      if (!this.listenerAdded) {
                        window.addEventListener("save-clicked", this.listener);
                        this.listenerAdded = true;
                      }

                      this.refreshDisplayMode(editor);
                      this.onEditorChange(null, editor);
                    }}
                    data={value}
                    onChange={this.onEditorChange}
                    editor={ClassicEditor}
                    config={{
                      cloudServices: {
                        tokenUrl: `${config.cwbApiEndpoint}/token/${userId}`,
                        uploadUrl: "https://36212.cke-cs.com/easyimage/upload/",
                        webSocketUrl: "36212.cke-cs.com/ws",
                        documentId: `${documentId}`
                      },
                      sidebar: {
                        container: this.sidebarElementRef.current
                      },
                      presenceList: {
                        container: this.presenceListElementRef.current
                      },
                      autosave: {
                        save(editor) {
                          saveForm(editor, id);
                        },
                        waitingTime: 30000
                      }
                    }}
                  />
                )}
              </div>
              <div id="container">
                <div
                  ref={this.sidebarElementRef}
                  id={`sidebar-${documentId}`}
                />
              </div>
            </div>
          </Grid>
        );

      default:
        return (
          <Grid className={"form-input-item " + classes.fieldInputWrapper}>
            <TextField
              label={label}
              className={"form-input"}
              InputProps={{
                disableUnderline: true,
                classes: {
                  input: classes.fieldInput
                }
              }}
              onBlur={this.props.onBlur}
              InputLabelProps={{
                shrink: true
              }}
              placeholder={placeholder}
              fullWidth
              name={name}
              margin="normal"
              defaultValue={value}
              onChange={this.onChangeHandler}
            />
          </Grid>
        );
    }
  };
  onCommentBtnClick = () => {
    const { fieldName = "" } = this.props;
    if (this.props.onCommentBtnClick) {
      this.props.onCommentBtnClick(fieldName);
    }
  };
  render() {
    const {
      classes,
      allowComments = false,
      allowBackup = false,
      fieldType,
      label = "Label",
      value,
      name,
      id,
      imageName,
      fieldHelperText
    } = this.props;

    if (fieldType === "FileUpload") {
      return (
        <UploadField
          key={11}
          id={id}
          name={name}
          label={label}
          fileName={value}
          imageName={imageName}
          helperText={fieldHelperText}
          onFileChange={this.props.onFileChange}
        />
      );
    } else {
      return (
        <div>
          <Grid item xs={12} className={classes.fieldContainer}>
            {this.renderFields()}
            <Grid item className={classes.fieldControlWrapper}>
              {allowComments ? (
                <MessageIcon
                  className={classes.iconButton1}
                  onClick={this.onCommentBtnClick}
                />
              ) : (
                ""
              )}
              {allowBackup ? (
                <BackupIcon className={classes.iconButton2} />
              ) : (
                ""
              )}
            </Grid>
          </Grid>
        </div>
      );
    }
  }
}
const mapStateToProps = state => {
  return {
    disclosure: state.disclosures.disclosure
  };
};

export default connect(mapStateToProps)(withStyles(styles)(FormField));
