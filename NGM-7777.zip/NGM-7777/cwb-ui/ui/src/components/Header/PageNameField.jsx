import React from "react";
import { withStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import Grid from "@material-ui/core/Grid";
import ReactLoading from "react-loading";

const styles = theme => ({
  wrapper: {
    margin: theme.spacing.unit
  },
  searchField: {
    color: "#FFFFFF",
    backgroundColor: "rgba(255, 255, 255, 0.03)",
    padding: "5px 10px",
    width: "380px"
  },
  searchButton: {
    color: "#FFFFFF",
    minHeight: "42px"
  }
});

function PageNameField(props) {
  const { user } = props.assignmentDetails;
  const { classes } = props;
  if (user.error || user.dashBoardLoaded) return null;
  if (user.loading)
    return (
      <div>
        <ReactLoading
          type={"bubbles"}
          color={"#ffffff"}
          height={"5%"}
          width={"5%"}
        />
      </div>
    );

  let value = "";
  if (user.assignment && user.assignment.name) value = user.assignment.name;
  return (
    <div className={classes.wrapper}>
      <Grid container spacing={8}>
        <Grid item>
          <TextField
            value={value}
            InputProps={{
              disableUnderline: true,
              classes: {
                input: classes.bootstrapInput,
                root: classes.searchField
              }
            }}
          />
        </Grid>
      </Grid>
    </div>
  );
}

export default withStyles(styles)(PageNameField);
