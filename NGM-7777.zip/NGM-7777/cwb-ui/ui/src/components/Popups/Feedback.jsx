import React, { Fragment } from "react";
import { connect } from "react-redux";
import {
  Dialog,
  DialogContent,
  Button,
  Typography,
  TextField
} from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";

import { submitFeedback } from "../../redux/actions/dashBoardActions";
import "./../../assets/scss/modals.css";

const styles = theme => {
  return {
    dialogContent: {
      padding: "0 20px",
      backgroundColor: "#f2f2f2"
    },
    disabled: {
      backgroundColor: "#cccccc !important",
      borderColor: "#cccccc !important"
    },
    dialogContainer: {
      minWidth: 450,
      maxWidth: 800,
      width: "100%"
    },
    title: {
      fontWeight: "bold",
      fontSize: "1.125em",
      padding: "20px",
      backgroundColor: "#e5e5e5"
    },
    to: {
      fontWeight: "bold",
      fontSize: "1em",
      margin: "20px 0px"
    },
    button: {
      color: "#fff !important",
      fontWeight: 600,
      margin: theme.spacing.unit,
      backgroundColor: "#005f9e",
      padding: "10px 35px",
      border: "2px solid #005f9e"
    },
    buttonCancel: {
      color: "#005f9e !important",
      fontWeight: 600,
      backgroundColor: "#fff !important"
    },
    buttonGroup: {
      width: "100%",
      margin: "20px 0px",
      display: "flex",
      justifyContent: "flex-end"
    },
    comments: {
      width: "100%",
      backgroundColor: "#fff",
      marginTop: "10px"
    },
    thanksNote: {
      display: "flex",
      flex: 1,
      flexDirection: "column",
      alignItems: "center",
      margin: "65px 0px",
      color: "#005f9e"
    }
  };
};

class Feedback extends React.Component {
  state = {
    feedback: "",
    done: false
  };

  textHandler = event => {
    this.setState({ feedback: event.target.value });
  };
  submitRequest = () => {
    const {
      submitFeedback,
      userDetails: { fullName }
    } = this.props;
    const { feedback } = this.state;
    submitFeedback({ feedback, username: fullName });
    this.setState({ feedback: "", done: true });
    // this.props.handleClose();
  };
  render() {
    const { handleClose, classes } = this.props;
    const { feedback, done } = this.state;
    return (
      <Dialog
        open={true}
        onClose={handleClose}
        aria-labelledby="form-dialog-title"
        classes={{ paperScrollPaper: classes.dialogContainer }}
      >
        <Typography variant="title" className={classes.title}>
          <span>Feedback</span>
        </Typography>
        <DialogContent className={classes.dialogContent}>
          {!done ? (
            <Fragment>
              <div className={classes.to}>
                Your feedback along with your initials will be sent to our team.
              </div>
              <div>
                <TextField
                  id="outlined-bare"
                  className={classes.comments}
                  margin="normal"
                  multiline
                  rows="6"
                  variant="outlined"
                  inputProps={{ "aria-label": "bare" }}
                  onChange={this.textHandler}
                  value={feedback}
                />
              </div>
              <div className={classes.buttonGroup}>
                <Button
                  onClick={handleClose}
                  className={`${classes.button} ${classes.buttonCancel}`}
                >
                  Cancel
                </Button>
                <Button
                  className={`${classes.button} ${
                    !feedback ? classes.disabled : ""
                  }`}
                  onClick={this.submitRequest}
                  disabled={!feedback}
                >
                  Submit
                </Button>
              </div>
            </Fragment>
          ) : (
            <Fragment>
              <div className={classes.thanksNote}>
                <h3>Thanks!</h3>
                <p>We appreciate the feedback.</p>
              </div>
              <div className={classes.buttonGroup}>
                <Button className={`${classes.button}`} onClick={handleClose}>
                  Close
                </Button>
              </div>
            </Fragment>
          )}
        </DialogContent>
      </Dialog>
    );
  }
}

const mapStateToProps = ({ user }) => ({
  userDetails: user
});

const mapDispatchToProps = dispatch => ({
  submitFeedback: payload => dispatch(submitFeedback(payload))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(Feedback));
