import React from "react";
import { Button } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import "./../../assets/scss/modals.css";

const styles = theme => ({
  disabled: {
    backgroundColor: "#cccccc !important"
  },
  link: {
    fontSize: "1.4em",
    fontWeight: 600,
    marginTop: "34px"
  },
  linkUrl: {
    fontSize: "1em",
    fontWeight: "normal",
    marginTop: "14px"
  },
  shortcodeWrapper: {
    display: "flex",
    flexDirection: "column",
    height: "auto",
    justifyContent: "space-between",
    background: "#f2f2f2"
  },
  button: {
    color: "#fff !important",
    fontWeight: 600,
    margin: theme.spacing.unit,
    backgroundColor: "#005f9e",
    "&:hover": {
      backgroundColor: "#005f9e"
    }
  },
  buttonCancel: {
    color: "#005f9e !important",
    fontWeight: 600
  },
  buttonGroup: {
    width: "100%",
    borderTop: "1px solid #ccc",
    display: "flex",
    justifyContent: "flex-end"
  }
});

const Card = ({ classes, assignment, handleClose, email, submitRequest }) => {
  return (
    <div className="card">
      <div className={classes.shortcodeWrapper}>
        <div className={classes.link}>
          Assignment URL
          <p className={classes.linkUrl}>
            {window.location.host}/{assignment && assignment.id}
          </p>
        </div>
        <div className={classes.buttonGroup}>
          <Button onClick={handleClose} className={classes.buttonCancel}>
            Cancel
          </Button>
          <Button
            className={`${classes.button} ${!email ? classes.disabled : ""}`}
            onClick={submitRequest}
            disabled={!email}
          >
            Share
          </Button>
        </div>
      </div>
    </div>
  );
};

export default withStyles(styles)(Card);
