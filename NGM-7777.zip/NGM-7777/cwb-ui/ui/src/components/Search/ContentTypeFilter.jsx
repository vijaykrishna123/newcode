import React, { Fragment } from "react";
import { withStyles, Checkbox } from "@material-ui/core";
import { ViewLess, ViewMore } from "./FilterSearchComponent";
const styles = () => ({
  root: {
    "&$checked": {
      color: "#0089c9"
    }
  },
  checked: {},
  hrd: {
    paddingTop: "10px",
    paddingBottom: "10px",
    borderTop: "1px solid #fff"
  },
  ul: {
    listStyle: "none",
    margin: 0
  },

  reset: {
    padding: 0
  }
});
const ContentConfig = [
  {
    name: "is_on_file_type_pdf",
    value: "pdf",
    title: "Pdf"
  },
  {
    name: "is_on_file_type_image",
    value: "image",
    title: "Image"
  },
  {
    name: "is_on_file_type_chart",
    value: "chart",
    title: "Chart"
  },
  {
    name: "is_on_file_type_html",
    value: "html",
    title: "Html"
  },
  {
    name: "is_on_file_type_video",
    value: "video",
    title: "Video"
  },
  {
    name: "is_on_file_type_word",
    value: "word",
    title: "Word"
  },
  {
    name: "is_on_file_type_presentation",
    value: "presentation",
    title: "PowerPoint"
  },
  {
    name: "is_on_file_type_indd",
    value: "indd",
    title: "InDesign"
  }
];
export const ContentTypeFilter = ({
  classes,
  filterDisplayFlag,
  showMore,
  showLess,
  config,
  updateContentFilter,
  currentFilters
}) => {
  return (
    <Fragment>
      <div className={"filter-section"}>
        <div className={classes.hrd}>
          <span className="title filter-title">Content Types</span>
          {filterDisplayFlag["contentFlag"] ? (
            <ViewLess action={() => showLess("contentFlag")} />
          ) : (
            <ViewMore action={() => showMore("contentFlag")} />
          )}
        </div>
        {filterDisplayFlag["contentFlag"] ? (
          <ul className={classes.ul + " " + classes.reset}>
            <li>
              <Checkbox
                checked={config.is_on_file_type_all}
                onChange={event => updateContentFilter(event, "content")}
                value="all"
                classes={{
                  root: classes.root,
                  checked: classes.checked
                }}
              />
              <label>All Content Types</label>
              <ul
                className={classes.ul + " " + classes.reset + " content-types"}
              >
                {ContentConfig.map(content => {
                  return (
                    <li key={content.name}>
                      <Checkbox
                        checked={config[content.name]}
                        onChange={event =>
                          updateContentFilter(event, "content")
                        }
                        value={content.value}
                        classes={{
                          root: classes.root,
                          checked: classes.checked
                        }}
                      />
                      <label>{content.title}</label>
                    </li>
                  );
                })}
              </ul>
            </li>
          </ul>
        ) : (
          <div className={"filter-current-selections"}>
            {currentFilters["type"]}
          </div>
        )}
      </div>
    </Fragment>
  );
};
export default withStyles(styles)(ContentTypeFilter);
