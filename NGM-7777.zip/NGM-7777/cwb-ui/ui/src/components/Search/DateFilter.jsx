import React from "react";
import { withStyles } from "@material-ui/core";
import YearFilter from "./YearFilter";
import MonthFilter from "./MonthFilter";
import { ViewLess, ViewMore } from "./FilterSearchComponent";

const styles = theme => ({
  hrd: {
    paddingTop: "10px",
    paddingBottom: "10px",
    borderTop: "1px solid #fff"
  },
  ul: {
    listStyle: "none",
    margin: 0
  },

  reset: {
    padding: 0
  },
  reset4: {
    padding: "0 0 0 15px"
  }
});

const DateFilter = ({ classes, filterDisplayFlag, showMore, showLess, currentFilters, ...restProps }) => {
  return (
    <React.Fragment>
      <div className={"filter-section"}>
      <div className={classes.hrd}>
        <span className="title filter-title">Date</span>
        {filterDisplayFlag["dateFlag"] ? (
              <ViewLess action={() =>  showLess("dateFlag")} />
          ) : (
              <ViewMore action={() =>  showMore("dateFlag")} />
          )}
      </div>
      {filterDisplayFlag["dateFlag"] ? (         
        <ul className={classes.ul + " " + classes.reset}>
          <YearFilter {...restProps} />
          <MonthFilter {...restProps} />
        </ul>
      ):(
        <div className={"filter-current-selections"}>
           {currentFilters["timeFrame"]}
        </div>
      )}
      </div>
    </React.Fragment>
  );
};
export default withStyles(styles)(DateFilter);
