import React from "react";
import { withStyles, Paper, Button } from "@material-ui/core";
import SourceFilter from "./SourceFilter";
import DateFilter from "./DateFilter";
import ContentTypeFilter from "./ContentTypeFilter";
import { FilterHeading } from "./FilterSearchComponent";
import moment from "moment";
import {
  onSourceType,
  onFileType,
  getFileType,
  getSourceType,
  setFilter,
  resetFilters,
  getCurrentFilters
} from "./Helper";
const style = () => ({
  section: {
    background: " #e6f2f1",
    color: "#333",
    minHeight: "120vh",
    zIndex: 100,
    padding: "0 0 1em 1em"
  },
  buttonContainer: {
    marginTop: "1em",
    textAlign: "center"
  },
  filter: {
    display: "flex",
    justifyContent: "space-between"
  },
  filterChild: {
    fontSize: "1.25rem",
    fontWeight: "bold",
    paddingRight: "1.6em",
    paddingBottom: "1.25rem"
  },
  cursor: {
    cursor: "pointer"
  },
  hrd: {
    paddingTop: "10px",
    borderTop: "1px solid #fff"
  },
  ul: {
    listStyle: "none",
    margin: 0
  },
  reset: {
    padding: 0
  },
  reset4: {
    padding: "0 0 0 15px"
  },
  perfectScroll: {
    position: "relative",
    display: "block",
    width: "100%",
    height: "100%",
    maxWidth: "100%",
    maxHeight: "100%"
  },
  button: {
    width: "80%",
    cursor: "pointer",
    fontWeight: 700
  },
  button1: {
    color: "#fff",
    backgroundColor: "#b42573",
    "&:hover": { backgroundColor: "#b42573" }
  },
  button2: { color: "#b42573", border: "solid 2px #b42573" },
  divider: {
    margin: "1em"
  }
});
class Filter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      defaultObject: props.defaultSearch,
      filterDisplayFlag: {
        dateFlag: false,
        sourceFlag: false,
        contentFlag: false
      },
      config: {
        is_on_file_type_all: false,
        is_on_file_type_pdf: false,
        is_on_file_type_image: false,
        is_on_file_type_chart: false,
        is_on_file_type_html: false,
        is_on_file_type_video: false,
        is_on_file_type_word: false,
        is_on_file_type_presentation: false,
        is_on_file_type_indd: false,
        is_on_source_all: false,
        is_on_source_internal: false,
        is_on_source_external: false,
        is_on_source_edam: false,
        is_on_source_web: false,
        is_on_source_americanfunds_advisor: false,
        is_on_source_americanfunds_ria: false,
        is_on_source_americanfunds_literature: false,
        is_on_source_thecapitalideas: false,
        is_on_source_fundfire: false,
        is_on_source_ignites: false,
        is_on_source_americanfunds_individual: false,
        is_on_source_americanfunds_retirement: false,
        is_on_source_capitalgroup_us: false,
        is_on_source_galileo: false
      },
      currentFilters: {
        source: "",
        type: "",
        timeFrame: ""
      },
      filterReset: false,
      filterResetObject: null
    };
    this.dateSelection = this.dateSelection.bind(this);
    this.applyFilter = this.applyFilter.bind(this);
    this.updateSourcesFilter = this.updateSourcesFilter.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
  }
  applyFilter() {
    let { defaultObject, currentFilters } = this.state;
    let file_type = getFileType(this.state.config);
    const filter = defaultObject;
    filter["file_type"] = file_type;
    let source = getSourceType(this.state.config);
    filter["source"] = source;
    getCurrentFilters(
      currentFilters,
      defaultObject["file_type"],
      defaultObject["source"],
      defaultObject["publication_from_date"],
      defaultObject["publication_to_date"],
      defaultObject["time_filter_value"]
    );
    this.props.updateSearchQuery(filter);
  }
  showLess = status => {
    const { filterDisplayFlag } = this.state;
    filterDisplayFlag[status] = false;
    this.setState({ filterDisplayFlag });
  };
  showMore = status => {
    const { filterDisplayFlag } = this.state;
    filterDisplayFlag[status] = true;
    this.setState({ filterDisplayFlag });
  };
  dateSelection(event) {
    const { defaultObject } = this.state;
    defaultObject[event.target.name] = event.target.value;
    this.setState({ defaultObject });
    if (!Number.isNaN(Number.parseInt(event.target.value))) {
      this.applyFilter();
    }
  }
  resetFilter() {
    let { filterResetObject } = this.state;
    const filter = this.state.defaultObject;
    filter["source"] = filterResetObject["source"];
    filter["file_type"] = filterResetObject["file_type"];
    filter["time_filter_value"] = filterResetObject["time_filter_value"];
    filter["timeType"] = "Y";
    let config = resetFilters(this.state.config);
    this.setState({
      defaultObject: filter,
      filterDisplayFlag: {
        dateFlag: false,
        sourceFlag: false,
        contentFlag: false
      },
      config
    });
    this.props.updateSearchQuery(filter);
    this.setState({ filterReset: true });
  }
  updateSourcesFilter(event, type) {
    let config;
    switch (type) {
      case "source":
        config = onSourceType(event.target.value, this.state.config);
        this.setState({ config });
        break;
      case "content":
        config = onFileType(event.target.value, this.state.config);
        this.setState({ config });
        break;
      default:
        break;
    }
    this.timeout = setTimeout(() => {
      this.applyFilter();
    }, 300);
  }
  componentDidMount() {
    let {
      defaultObject,
      currentFilters,
      config,
      filterResetObject
    } = this.state;
    defaultObject["file_type"] = this.props.searchResult["file_type"];
    defaultObject["source"] = this.props.searchResult["source"];
    currentFilters = getCurrentFilters(
      currentFilters,
      this.props.searchResult["file_type"],
      this.props.searchResult["source"],
      this.props.searchResult["publication_from_date"],
      this.props.searchResult["publication_to_date"],
      defaultObject["time_filter_value"]
    );
    defaultObject["time_filter_value"] = this.getTimePassed(
      this.props.searchResult["publication_from_date"]
    );
    config = setFilter(config, defaultObject);
    this.setState({ defaultObject, currentFilters, config });
    if (!filterResetObject) {
      this.setState({
        filterResetObject: Object.assign({}, this.props.defaultSearch)
      });
    }
  }
  componentDidUpdate() {
    let {
      defaultObject,
      currentFilters,
      filterReset,
      filterResetObject,
      config
    } = this.state;
    const configArray = Object.entries(config);
    if (filterReset) {
      getCurrentFilters(
        currentFilters,
        filterResetObject["file_type"],
        filterResetObject["source"],
        filterResetObject["publication_from_date"],
        filterResetObject["publication_to_date"],
        filterResetObject["time_filter_value"]
      );
      config = setFilter(config, filterResetObject);
      this.setState({ filterReset: false });
    }
    const configType = configArray.filter(
      configItem => configItem[0].indexOf("is_on_file_type") !== -1
    );
    const configTypeFalse = configType.filter(configItem => !configItem[1]);
    const configTypeEmpty = configType.length === configTypeFalse.length;
    const configSource = configArray.filter(
      configItem => configItem[0].indexOf("is_on_source") !== -1
    );
    const configSourceFalse = configSource.filter(configItem => !configItem[1]);
    const configSourceEmpty = configSource.length === configSourceFalse.length;
    if (configTypeEmpty || configSourceEmpty) {
      const tempObj = Object.entries(defaultObject);
      if (configTypeEmpty) {
        tempObj.file_type = filterResetObject["file_type"];
      }
      if (configSourceEmpty) {
        tempObj.source = filterResetObject["source"];
      }
      config = setFilter(config, tempObj);
    }
  }
  componentWillUnmount() {
    clearTimeout(this.timeout);
  }
  getTimePassed(dateFrom) {
    const diffMonths = Math.floor(
      moment(new Date()).diff(moment(dateFrom), "months", true)
    );
    if (diffMonths > 24) {
      return 36;
    } else if (diffMonths > 12 && diffMonths <= 24) {
      return 24;
    } else if (diffMonths > 3 && diffMonths <= 12) {
      return 12;
    } else if (diffMonths === 3) {
      return 3;
    } else if (diffMonths === 2) {
      return 2;
    } else if (diffMonths === 1) {
      return 1;
    } else {
      return 36;
    }
  }
  render() {
    const {
      defaultObject,
      currentFilters,
      filterDisplayFlag,
      config
    } = this.state;
    const { classes } = this.props;
    const headingClasses = {
      filter: classes.filter,
      filterChild: classes.filterChild
    };
    return (
      <Paper>
        <section className={classes.section}>
          <FilterHeading classes={headingClasses} action={this.props.action} />
          <div>
            <div className={classes.perfectScroll}>
              <div>
                <DateFilter
                  defaultObject={defaultObject}
                  dateSelection={this.dateSelection}
                  filterDisplayFlag={filterDisplayFlag}
                  showMore={this.showMore}
                  showLess={this.showLess}
                  currentFilters={currentFilters}
                />
                <SourceFilter
                  config={config}
                  updateSourcesFilter={this.updateSourcesFilter}
                  filterDisplayFlag={filterDisplayFlag}
                  showMore={this.showMore}
                  showLess={this.showLess}
                  currentFilters={currentFilters}
                />
              </div>
              <ContentTypeFilter
                updateContentFilter={this.updateSourcesFilter}
                config={config}
                filterDisplayFlag={filterDisplayFlag}
                showMore={this.showMore}
                showLess={this.showLess}
                currentFilters={currentFilters}
              />
            </div>
          </div>
          <div className={classes.buttonContainer}>
            <Button
              variant="outlined"
              className={classes.button + " " + classes.button2}
              onClick={this.resetFilter}
            >
              Reset Filters
            </Button>
          </div>
        </section>
      </Paper>
    );
  }
}
export default withStyles(style)(Filter);
