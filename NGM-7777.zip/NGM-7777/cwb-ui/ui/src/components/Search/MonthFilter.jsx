import React, { Fragment } from "react";
import { withStyles, Radio } from "@material-ui/core";

const MonthConfig = [
  {
    value: 1,
    text: "Past 1 Month",
    flag: ""
  },
  {
    value: 2,
    text: "Past 2 Months",
    flag: ""
  },
  {
    value: 3,
    text: "Past 3 Months",
    flag: ""
  },
  {
    value: 4,
    text: "Past 4 Months",
    flag: true
  },
  {
    value: 5,
    text: "Past 5 Months",
    flag: true
  },
  {
    value: 6,
    text: "Past 6 Months",
    flag: true
  }
];
const styles = theme => ({
  hrd: {
    paddingTop: "10px",
    borderTop: "1px solid #fff"
  },
  ul: {
    listStyle: "none",
    margin: 0
  },

  reset: {
    padding: 0
  },
  reset4: {
    padding: "0 0 0 15px"
  },
  root: {
    "&$checked": {
      color: "#0089c9"
    }
  },
  checked: {}
});

const MonthFilter = ({ classes, defaultObject, dateSelection }) => {
  const default_month_value =
    defaultObject &&
    defaultObject.time_filter_value &&
    typeof defaultObject.time_filter_value != "number"
      ? parseInt(defaultObject.time_filter_value)
      : defaultObject.time_filter_value;
  return (
    <li>
      <div>
        <Radio
          value="M"
          name="timeType"
          checked={defaultObject.timeType !== "Y"}
          onChange={dateSelection}
          classes={{
            root: classes.root,
            checked: classes.checked
          }}
        />

        <label>Month(s)</label>
      </div>
      {defaultObject.timeType !== "Y" && (
        <ul className={classes.ul + " " + classes.reset4}>
          {MonthConfig.map(month => {
            return (
              <Fragment>
                {month.flag === "" && (
                  <li>
                    <div>
                      <Radio
                        name="time_filter_value"
                        value={month.value}
                        checked={default_month_value === month.value}
                        onChange={dateSelection}
                        classes={{
                          root: classes.root,
                          checked: classes.checked
                        }}
                      />

                      <label>{month.text}</label>
                    </div>
                  </li>
                )}
              </Fragment>
            );
          })}
        </ul>
      )}
    </li>
  );
};
export default withStyles(styles)(MonthFilter);
