import React from "react";
import { connect } from "react-redux";
import moment from "moment";
import { Grid, Typography, withStyles } from "@material-ui/core";
import CircularProgress from "@material-ui/core/CircularProgress";
import SearchComponent from "./SearchComponent";
import {
  searchRequest,
  feedbackRequest,
  clearStore,
  autocorrectRequest,
  autocompleteRequest,
  removeAutoCompleteList
} from "../../redux/actions/searchAction";
import SearchListComponent from "./SearchListComponent";
import FilterComponent from "./FilterComponent";
import SortBy from "./Sort";
import Pagination from "./Pagination";
import { getDefaultSearch } from "./Helper";

const styles = theme => ({
  root: {
    background: "#f2f2f2",
    minHeight: "300px",
    position: "relative"
  },
  noresults: {
    margin: "1em",
    color: "#395356",
    fontSize: "0.8rem",
    lineHeight: "19px"
  },
  searchresults: {
    overflowX: "hidden"
  },
  progress: {
    marginLeft: theme.spacing.unit * 2,
    marginRight: theme.spacing.unit * 2,
    marginTop: "225px"
  },
  loaderContainer: {
    position: "absolute",
    zIndex: 999,
    background: "#cccccc57",
    width: "100%",
    height: "100%",
    textAlign: "center",
    display: "flex",
    justifyContent: "center",
    alignItems: "top"
  }
});

class Search extends React.Component {
  constructor(props) {
    super(props);
    this.state = { search: "", filter: true, keywordValue: true };
    this.defaultSearch = getDefaultSearch();
  }
  componentDidMount() {
    this.props.clearStore();
    this.searchQuery = Object.assign({}, this.defaultSearch);
  }
  clearSearch = () => {
    this.clearAutoComplete();
    this.setState({ search: "" });
  };
  changePage = page => {
    const { search } = this.props;
    this.searchQuery["offset"] = page;
    this.searchQuery["apply_filter"] = false;
    this.searchQuery["query_id"] = search.query_id;
    this.props.searchRequest(this.searchQuery);
    document
      .getElementById("search-section")
      .scrollIntoView({ behavior: "smooth" });
  };
  updateSearchQueryAutoComplete = query => {
    this.searchQuery = Object.assign({}, this.defaultSearch);
    this.searchQuery["query"] = query;
    if (!this.searchQuery["keyword_flag"]) {
      this.searchQuery["file_type"] = [];
      this.searchQuery["source"] = [];
    }
    this.setState({ search: query });
    this.props.removeAutoCompleteList();
    query.trim() !== "No Results" && this.props.searchRequest(this.searchQuery);
  };
  clearAutoComplete = () => {
    this.props.removeAutoCompleteList();
  };
  updateSearchQuerySort = query => {
    this.searchQuery["query"] = query;
    this.props.autocorrectRequest(query);
    this.props.searchRequest(this.searchQuery);
  };
  handleSearchbutton = () => {
    if (!this.state.search) return;
    this.searchQuery = Object.assign({}, this.defaultSearch, {
      keyword_flag: this.searchQuery["keyword_flag"]
    });
    if (!this.searchQuery["keyword_flag"]) {
      this.searchQuery["file_type"] = [];
      this.searchQuery["source"] = [];
    }
    this.searchQuery.request["user_id"] = this.props.user.userId;
    this.searchQuery["query"] = this.state.search;
    this.searchQuery["apply_filter"] = false;
    this.searchQuery["offset"] = 0;
    this.searchQuery["query_id"] = "";
    this.searchQuery["publication_from_date"] = moment()
      .subtract(this.searchQuery["time_filter_value"], "months")
      .format("YYYY-MM-DD");
    this.searchQuery["publication_to_date"] = moment().format("YYYY-MM-DD");
    this.props.autocorrectRequest(this.state.search);
    this.props.removeAutoCompleteList();
    this.props.searchRequest(this.searchQuery);
  };
  sendFeedback = query => {
    const { search, user, feedbackRequest } = this.props;
    query["user"] = user.userId;
    query["query_id"] = search.query_id;
    feedbackRequest(query);
  };
  updateSearchQuery = query => {
    let keys = Object.keys(query);
    keys.forEach(objKey => (this.searchQuery[objKey] = query[objKey]));
    this.searchQuery["publication_from_date"] = moment()
      .subtract(this.searchQuery["time_filter_value"], "months")
      .format("YYYY-MM-DD");
    this.searchQuery["apply_filter"] = true;
    this.props.searchRequest(this.searchQuery);
  };
  handleSearchInput = event => {
    if (event.keyCode !== 13) {
      this.setState({ search: event.target.value });
      if (
        event.target.value.length !== 0 &&
        event.target.value.length % 3 === 0
      ) {
        this.props.autocompleteRequest({
          in_text: event.target.value,
          userid: this.props.user.userId
        });
      }
      return;
    }
    event.target.value && this.handleSearchbutton();
  };
  sortBy = event => {
    this.searchQuery[event.target.name] = event.target.value;
    this.props.searchRequest(this.searchQuery);
  };
  closeFilter = () => {
    this.setState({ filter: false });
  };
  handleSearchTypeChange = event => {
    this.setState({ keywordValue: event.target.value });
    this.searchQuery["keyword_flag"] = event.target.value;
    this.props.searchRequest(this.searchQuery);
  };
  render() {
    const { search, loading, classes } = this.props;
    return (
      <div className={classes.root} id="search-section">
        {loading && (
          <div className={classes.loaderContainer}>
            <CircularProgress className={classes.progress} color="secondary" />
          </div>
        )}
        <SearchComponent
          handleSearchInput={this.handleSearchInput}
          search={this.state.search}
          handleSearchbutton={this.handleSearchbutton}
          auto_complete={this.props.auto_complete}
          clearAutoComplete={this.clearAutoComplete}
          updateSearchQuery={this.updateSearchQueryAutoComplete}
          clearSearch={this.clearSearch}
          searchType={this.state.keywordValue}
          handleSearchTypeChange={this.handleSearchTypeChange}
        />
        {!loading ? (
          <Grid container spacing={16}>
            <Grid item xs={3}>
              {search &&
                (search.record_count > 0 || search.length !== 0) &&
                this.state.filter && (
                  <FilterComponent
                    action={this.closeFilter}
                    updateSearchQuery={this.updateSearchQuery}
                    defaultSearch={this.searchQuery || this.defaultSearch}
                    searchResult={search}
                  />
                )}
            </Grid>
            <Grid item xs={this.state.filter ? 9 : 12}>
              {search.query && (
                <SortBy
                  search={search}
                  searchQuery={this.searchQuery}
                  auto_correct={this.props.auto_correct}
                  action={this.sortBy}
                  updateSearchQuery={this.updateSearchQuerySort}
                />
              )}
              <div className={classes.searchresults}>
                {search.records && !search.records.length && (
                  <Typography className={classes.noresults}>
                    This selection has no results.
                  </Typography>
                )}
                {search &&
                  search.record_count > 0 &&
                  search.records.map(result => (
                    <SearchListComponent
                      data={result}
                      key={result.jdoc_id}
                      searchQuery={this.searchQuery}
                      sendFeedback={this.sendFeedback}
                    />
                  ))}
                {search && search.record_count > 0 && (
                  <Pagination search={search} changePage={this.changePage} />
                )}
              </div>
            </Grid>
          </Grid>
        ) : null}
      </div>
    );
  }
}
const mapStateToProps = store => {
  return {
    search: store.search.result,
    user: store.user,
    loading: store.search.loading,
    auto_correct: store.search.auto_correct,
    auto_complete: store.search.auto_complete
  };
};

export default withStyles(styles)(
  connect(mapStateToProps, {
    searchRequest,
    feedbackRequest,
    clearStore,
    autocorrectRequest,
    autocompleteRequest,
    removeAutoCompleteList
  })(Search)
);
