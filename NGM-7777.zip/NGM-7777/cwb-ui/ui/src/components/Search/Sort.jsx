import React from "react";
import { withStyles, Typography, Radio } from "@material-ui/core";
const style = theme => ({
  root: {
    display: "flex",
    padding: "1em 1em 0 1em",
    flexDirection: "column"
  },
  filter: {
    display: "flex",
    width: "100%"
  },
  suggestion: { width: "100%" },
  strong: {},
  divider: {
    marginRight: "1em",
    marginLeft: "1em"
  },
  sort: {},
  sortBy: {
    display: "inline-block"
  },
  suggetionLink: {
    textDecoration: "underline",
    cursor: "pointer"
  },
  type: {
    padding: "0px 10px",
    "&$checked": {
      color: "#0089c9"
    },
    alignItems: "flex-start",
    height: "auto"
  },
  checked: {}
});
const SortBy = ({
  classes,
  action,
  searchQuery,
  search,
  auto_correct,
  updateSearchQuery
}) => {
  if (!searchQuery || !searchQuery.sort_order) return null;
  return (
    <div className={classes.root}>
      <div className={classes.filter}>
        <strong className={classes.strong}>
          {search.record_count} result(s) for "{search.query}"
        </strong>
        <div className={classes.divider}>|</div>
        <div className={classes.sort}>
          <Typography component="span" className={classes.sortBy}>
            Sort By:
          </Typography>
          <Radio
            name="sort_order"
            value="relevance"
            checked={"relevance" === searchQuery.sort_order}
            onChange={action}
            classes={{
              root: classes.type,
              checked: classes.checked
            }}
          />
          <label>Most Relevant</label>
          <Radio
            name="sort_order"
            value="date"
            checked={"date" === searchQuery.sort_order}
            onChange={action}
            classes={{
              root: classes.type,
              checked: classes.checked
            }}
          />
          <label>Date</label>
        </div>
      </div>
      {auto_correct &&
        auto_correct.user_query.toLowerCase() !==
          auto_correct.corrected_query.toLowerCase() && (
          <div className={classes.suggestion}>
            Did you mean:&nbsp;&nbsp;
            <strong
              className={classes.suggetionLink}
              onClick={() => updateSearchQuery(auto_correct.corrected_query)}
            >
              {auto_correct.corrected_query}
            </strong>
          </div>
        )}
    </div>
  );
};
export default withStyles(style)(SortBy);
