import React from "react";
import { Link } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import { ListItemIcon, ListItemText } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import ResearchIcon from "@material-ui/icons/Visibility";
import DoneIcon from "@material-ui/icons/Done";
import InfoIcon from "@material-ui/icons/InfoOutlined";
import CreateIcon from "@material-ui/icons/CreateOutlined";
import DashboardIcon from "@material-ui/icons/Dashboard";
import MenuList from "@material-ui/core/MenuList";
import MenuItem from "@material-ui/core/MenuItem";
import ListIcon from "@material-ui/icons/Link";

const styles = theme => {
  return {
    tabLink: {
      textDecoration: "none"
    },
    tabButton: {
      display: "flex",
      flex: 1,
      flexDirection: "row",
      height: "auto",
      margin: "0 15px",
      justifyContent: "center",
      alignItems: "center"
    },
    tabLastButton: {
      minWidth: "250px",
      minHeight: "24px",
      margin: 0,
      marginRight: theme.spacing.unit,
      position: "absolute",
      right: 0
    },
    tabButtonActive: {
      borderRadius: "0.4rem",
      backgroundColor: "rgba(255, 255, 255, 0.1) !important"
    },
    button: {
      backgroundColor: "transparent",

      color: "#ccc",
      "&:hover": {
        backgroundColor: "transparent"
      }
    },

    menuItem: {
      "&:focus": {
        backgroundColor: "#aab2b5",
        lightTooltip: {
          backgroundColor: "#fff",
          color: "rgba(0, 0, 0, 0.87)",
          boxShadow: theme.shadows[1],
          fontSize: 11
        }
      }
    },
    icon: {
      color: "#ccc",
      margin: 0
    },
    dashboard: {
      color: "#ffffff"
    },
    list: {
      color: "#009cdc"
    },
    research: {
      color: "#ff6a00 !important"
    },
    create: {
      color: "#009cdc"
    },
    review: {
      color: "#ccc"
    },
    search: {
      color: "#00aea9"
    },
    info: {
      color: "#cf2a84"
    },
    activeText: {
      "& span": {
        color: "#fff"
      }
    },
    textColor: {
      "& span": {
        color: "#ccc"
      }
    },
    emptyIcon: {
      padding: "10px"
    },
    background: {
      backgroundColor: " #001a30"
    }
  };
};
let isconList = {
  dashboard: () => <DashboardIcon />,
  list: () => <ListIcon />,
  research: () => <ResearchIcon />,
  create: () => <CreateIcon />,
  review: () => <DoneIcon />,
  search: () => <SearchIcon />,
  info: () => <InfoIcon />
};

const Tab = ({
  classes,
  label,
  to,
  icon,
  activeTab,
  background,
  onTabClick,
  disable,
  tooltip,
  collapse
}) => {
  const { tabButton, tabButtonActive, button, activeText, textColor } = classes;
  let activeButton =
    activeTab === label
      ? `${tabButton} ${tabButtonActive} tabButtonIsActive tabButton`
      : tabButton + " tabButton";
  activeButton = disable
    ? `${activeButton} ${button} buttonDisable`
    : activeButton;
  return (
    <MenuList className={`${background ? classes.background : ""}`}>
      <MenuItem
        button
        component={disable ? "" : Link}
        to={disable ? "" : to}
        className={activeButton}
        onClick={onTabClick}
      >
        <ListItemIcon
          className={`${classes.icon} ${
            activeTab === label ? classes[icon] : ""
          }`}
        >
          {isconList[icon] ? (
            isconList[icon]()
          ) : (
            <div className={classes.emptyIcon}></div>
          )}
        </ListItemIcon>

        {!collapse ? (
          <ListItemText
            primary={label}
            className={activeTab === label ? activeText : textColor}
          />
        ) : null}
      </MenuItem>
    </MenuList>
  );
};

export default withStyles(styles)(Tab);
