import React, { Fragment, useState, useEffect } from "react";
import ReactLoading from "react-loading";
import Toolbar from "@material-ui/core/Toolbar";
import { withStyles } from "@material-ui/core/styles";
import SearchIcon from "@material-ui/icons/Visibility";
import configDeterminator from "../../../configs/configDeterminator";
import {
  GridList,
  GridListTile,
  Typography,
  Paper,
  Button,
  Input
} from "@material-ui/core";
import { edamApi } from "../../../api/writeApi";

const styles = theme => ({
  scrollTheSection: {
    fontSize: "16px"
  },
  progressWrapper: {
    paddingTop: "15px"
  },
  btn: {
    background: "none",
    color: "#007bff",
    border: " none",
    textTransform: "none"
  },
  heading: {
    marginTop: "3em"
  },
  projectlinks: {
    marginBottom: "20px"
  },
  subTitle: {
    fontWeight: "bold",
    fontSize: "18px"
  },
  percolateContainer: {
    padding: "1em",
    background: "#b8dce1",
    marginTop: "1em"
  },
  button: {
    margin: 0,
    marginLeft: "10px !important",
    backgroundColor: "#005f9e",
    color: "#fff",
    "&:hover": {
      backgroundColor: "#005f9e"
    }
  },
  generateBtn: {
    marginTop: "7px"
  },
  iconStyle: {
    color: theme.palette.primary.main,
    display: "inline-block",
    marginRight: "5px"
  },
  iconStyleContent: {
    marginLeft: "5px",
    display: "inline-block",
    fontWeight: 500,
    color: "#0a3039"
  },
  tableContentHeading: {
    color: " #999999",
    fontSize: "16px",
    borderTop: "solid 1px #cccccc",
    width: "80%",
    fontFamily: "AvenirNextLT-Demi",
    lineHeight: "1.29"
  },
  input: {
    width: "500px"
  },
  tableContent: {
    fontFamily: "AvenirNextLT-Regular",
    fontSize: "16px",
    fontWeight: "normal",
    fontStyle: "normal",
    fontStretch: "normal",
    lineHeight: "1.25",
    letterSpacing: "normal",
    color: "#000000"
  },
  link: {
    color: "#44959f"
  },
  assignmentButtons: {
    height: "20px",
    color: "#73c0c9",
    lineHeight: "19px",
    fontSize: "16px",
    fontFamily: "Avenir-Heavy",
    fontWeight: 900,
    margin: "25px auto",
    padding: "5px"
  },
  title: {
    marginLeft: ".3em"
  },
  header: {
    fontSize: "18px",
    lineHeight: "2.9em",
    color: "#000000",
    fontWeight: "1000",
    fontStyle: "normal"
  }
});

function AssignmentDetailsComponent(props) {
  const { assignment, writeData, loading, error } = props.assignmentDetails;
  const writeAssignment =
    writeData && writeData.write && writeData.write.assignment
      ? writeData.write.assignment
      : {};

  const { classes } = props;
  const [zeplinUrl, setZeplinUrl] = useState(
    writeAssignment.zeplinUrl ? writeAssignment.zeplinUrl : ""
  );
  const [wipUrl, setWipUrl] = useState(
    writeAssignment.wipUrl ? writeAssignment.wipUrl : ""
  );
  const [editZeplinUrl, setEditZeplinUrl] = useState(
    !writeAssignment.zeplinUrl
  );

  useEffect(() => {
    function getWipUrl() {
      if (wipUrl) {
        generateFolder();
      }
    }
    getWipUrl();
  }, [null]);

  if (loading)
    return (
      <div>
        <ReactLoading type={"bubbles"} color={"#000000"} />
      </div>
    );
  if (error) return <div>Error while fetching data </div>;
  if (!assignment) return "";

  const generateFolder = () => {
    if (!assignment.metaData.Pod) {
      return props.assignmentDetails.showErrorMsg(
        "Folder cannot be generated because of missing Pod info from Percolate"
      );
    } else if (assignment.name.toLowerCase() === "untitled content") {
      return props.assignmentDetails.showErrorMsg(
        "Folder cannot be generated because of missing Title info from Percolate"
      );
    }

    let year = "";
    if (assignment.createdAt !== null) {
      year = new Date(assignment.createdAt).getFullYear();
    }
    const params = {
      year: `${year}`,
      pod: `${assignment.metaData.Pod}`,
      assignmentName: assignment.name,
      percolateId: assignment.id.replace("post:", "")
    };
    edamApi(params)
      .then(results => {
        return results;
      })
      .then(dataValues => {
        props.assignmentDetails.showSuccessMsg(
          "Folder is successfully generated"
        );
        setWipUrl(dataValues.data);
        writeData.write.assignment.wipUrl = dataValues.data;
        props.assignmentDetails.uploadCopyFormData({
          formData: writeData.write
        });
      })
      .catch(err => {
        props.assignmentDetails.showErrorMsg(
          "Folder cannot be generated because of API Error"
        );
        console.error(err);
      });
  };

  const onChangeZeplinUrl = event => {
    const value = event.target.value;
    setZeplinUrl(value);
  };

  const saveZeplinUrl = () => {
    const write = props.assignmentDetails.writeData.write;
    write.assignment.zeplinUrl = zeplinUrl;
    props.assignmentDetails.uploadCopyFormData({ formData: write });
    setEditZeplinUrl(false);
  };

  const cancelZeplinUrl = () => {
    const value = writeAssignment.zeplinUrl ? writeAssignment.zeplinUrl : "";
    setZeplinUrl(value);
    setEditZeplinUrl(false);
  };

  const workfrontUrl =
    assignment.metaData && assignment.metaData["Workfront Job #"]
      ? `${configDeterminator.workfronturl}${assignment.metaData["Workfront Job #"]}`
      : "";

  return (
    <Fragment>
      <Toolbar className={"tab-header"}>
        <Typography variant="title">
          <SearchIcon />
          <span className={classes.title}>Overview</span>
        </Typography>
      </Toolbar>
      <div>
        <Paper className={classes.heading}>
          <Typography variant="title" className={"mod-header"}>
            <div className={"research-assignment-title"}>
              <span>Web: {assignment.name}</span>
            </div>
          </Typography>
        </Paper>
        <div
          className={
            "mod-content research-assignment-grid " + classes.contentContainer
          }
        >
          <h4>Project Details</h4>
          {assignment.metaData ? (
            <GridList cellHeight={60} className={classes.gridList} cols={8}>
              {Object.keys(assignment.metaData).map((key, index) => {
                return (
                  <GridListTile key={key} cols={2}>
                    <div>
                      <Typography
                        variant="headline"
                        component="h3"
                        className={classes.tableContentHeading}
                      >
                        {key}
                      </Typography>
                      <Typography
                        component="p"
                        className={classes.tableContent}
                      >
                        {assignment.metaData[key]}
                      </Typography>
                    </div>
                  </GridListTile>
                );
              })}
            </GridList>
          ) : null}
        </div>

        <Paper className={classes.heading}>
          <Typography variant="title" className={"mod-header"}>
            <div className={"research-assignment-title"}>
              <span> Project links </span>
            </div>
          </Typography>
        </Paper>

        <div
          className={
            "mod-content research-assignment-grid " + classes.contentContainer
          }
        >
          <div className={`${classes.progressWrapper} mod-content`}>
            <div className={classes.projectlinks}>
              <div className={classes.subTitle}> Work in progress</div>
              {wipUrl ? (
                <div>
                  <a target="_blank" href={wipUrl}>
                    {wipUrl}{" "}
                  </a>
                </div>
              ) : (
                <Button
                  className={`${classes.button} ${classes.generateBtn}`}
                  color="primary"
                  onClick={generateFolder}
                  disabled={!assignment.metaData}
                >
                  Generate
                </Button>
              )}
            </div>

            <div className={classes.projectlinks}>
              <div className={classes.subTitle}> Workfront task </div>
              {workfrontUrl ? (
                <a
                  href={workfrontUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {workfrontUrl}
                </a>
              ) : (
                <div>No link found</div>
              )}
            </div>

            <div className={classes.projectlinks}>
              <div className={classes.subTitle}> Zeplin </div>

              {!editZeplinUrl ? (
                <Fragment>
                  <a href={zeplinUrl} target="_blank" rel="noopener noreferrer">
                    {zeplinUrl}
                  </a>
                  <Button
                    className={classes.button}
                    color="primary"
                    onClick={() => setEditZeplinUrl(true)}
                  >
                    Edit
                  </Button>
                </Fragment>
              ) : (
                <form onSubmit={saveZeplinUrl}>
                  <Input
                    className={classes.input}
                    value={zeplinUrl}
                    onChange={onChangeZeplinUrl}
                    placeholder="Add zeplin url"
                  />
                  <Button
                    className={classes.button}
                    onClick={cancelZeplinUrl}
                    color="primary"
                  >
                    Cancel
                  </Button>
                  <Button
                    className={classes.button}
                    onClick={saveZeplinUrl}
                    color="primary"
                  >
                    Save
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
}

export default withStyles(styles)(AssignmentDetailsComponent);
