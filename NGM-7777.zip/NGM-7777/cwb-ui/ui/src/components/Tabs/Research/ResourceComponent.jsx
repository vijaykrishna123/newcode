import React from "react";
import orange from "@material-ui/core/colors/orange";
import { withStyles } from "@material-ui/core/styles";
import { Button, Typography } from "@material-ui/core";
import Search from "../../Search/Search";
import Discoverpdf from "../../../assets/pdf/CWB_keyword_vs_natural.pdf";

const styles = theme => ({
  root: {
    flexGrow: 1
  },

  cssRoot: {
    color: theme.palette.getContrastText(orange[500]),
    backgroundColor: orange[500],
    "&:hover": {
      backgroundColor: orange[700]
    }
  },
  margin: {
    margin: theme.spacing.unit
  },
  resource: {
    //marginTop: "1em"
  },
  resourceContent: {
    color: "#0a3039"
  },
  button: {
    width: "300px",
    textTransform: "capitalize",
    color: "#fafafa"
  },
  videotitle: {
    fontFamily: "AvenirNextLT-Demi",
    fontSize: "16px",
    fontWeight: "normal",
    fontStyle: "normal",
    fontStretch: "normal",
    lineHeight: "normal",
    letterSpacing: "normal",
    color: "#000000"
  },
  videocontainer: {
    marginBottom: 7,
    textAlign: "center",
    backgroundColor: "#d9d9d9",
    padding: ".7em"
  },
  videoAction: {
    border: "solid 2px #005f9e",
    color: "#005f9e",
    padding: "5px 20px",
    marginLeft: "18px !important"
  },
  video2: {
    marginLeft: "16px"
  }
});

function Resource(props) {
  const { classes } = props;
  return (
    <div>
      <div className={classes.videocontainer}>
        <span className={classes.videotitle}>
          <strong>
            What’s the difference between Keyword and Natural language search?
          </strong>
        </span>
        <Button
          variant="outlined"
          onClick={props.handleClickOpen}
          className={classes.videoAction}
          href={Discoverpdf}
          target="_blank"
        >
          SEE TIPSHEET
        </Button>
      </div>
      <div
        className={"discover-hdr mod-header content-block " + classes.container}
      >
        <Typography component="h2" className={"research-discover-title"}>
          DISCOVER
        </Typography>
        <div className={"research-discover-text"}>
          <Typography component="p" className={classes.resourceContent}>
            Use this tool to search CG content for articles and images related
            to your project using keyword or natural language search.
          </Typography>
        </div>
      </div>
      <div>
        <Search />
      </div>
    </div>
  );
}

export default withStyles(styles)(Resource);
