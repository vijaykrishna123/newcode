import React from "react";
import { withStyles } from "@material-ui/core/styles";
import compose from "recompose/compose";
import { connect } from "react-redux";
import Autosuggest from "react-autosuggest";
import ChipButton from "../../Common/ChipButton";
import { Button, TextField } from "@material-ui/core";
import LockIcon from "@material-ui/icons/Lock";
import {
  createProofRequest,
  addReviewer,
  shareReviewer,
  shareProof,
  shareProofVersion,
  fetchReviewer,
  removeCollaborator,
  addCollaboratorToWriteSuccess,
  showSuccessMsg,
  sendPdfToWorkfront
} from "../../../redux/actions/writeAction";
import { fetchInitialUsers } from "../../../redux/actions/userActions";

const styles = theme => ({
  title: {
    marginBottom: "20px",
    fontWeight: "bold"
  },
  container: {
    display: "flex",
    flexWrap: "wrap"
  },
  margin: {
    margin: theme.spacing.unit
  },
  cssFocused: {},
  bootstrapRoot: {
    padding: 0,
    "label + &": {
      marginTop: theme.spacing.unit * 3
    }
  },
  errorIcon: {
    color: "#b42573",
    fontWeight: "bold",
    fontSize: "18px"
  },
  error: {
    color: "#b42573",
    marginLeft: "5px",
    fontWeight: "bold"
  },
  comments: {
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important"
  },
  paper: {
    position: "absolute",
    width: theme.spacing.unit * 50,
    backgroundColor: theme.palette.background.paper,
    boxShadow: theme.shadows[5],
    padding: theme.spacing.unit * 4
  },
  bootstrapInput: {
    borderRadius: 4,
    backgroundColor: theme.palette.common.white,
    border: "1px solid #ced4da",
    fontSize: 16,
    padding: "10px 12px",
    width: "80%",
    margin: "0px 0px",
    transition: theme.transitions.create(["border-color", "box-shadow"]),
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"'
    ].join(","),
    "&:focus": {
      borderColor: "#80bdff",
      boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)"
    }
  },
  bootstrapFormLabel: {
    fontSize: 18
  },
  btnWrapper: {
    margin: "15px 0px"
  },
  genProofBtn: {
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important",
    width: "100%"
  },
  addColBtn: {
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important",
    width: "100%",
    border: "2px solid #005f9e !important",
    "&:hover": {
      border: "2px solid #005f9e",
      backgroundColor: "rgba(0,95,158,0.2)"
    }
  },
  goToProofBtn: {
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important",
    width: "100%",
    backgroundColor: "transparent !important",
    marginBottom: "0px !important"
  },
  disabled: {
    color: "#99999 !important"
  },
  enabled: {
    color: "#005f9e !important"
  },
  lockIcon: {
    marginLeft: "5px",
    marginTop: "-5px",
    fontSize: "12px"
  }
});

const escapeRegexCharacters = str => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

class EmailAutoSuggest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      emailText: "",
      tagArr: [],
      value: "",
      audienceRef: "",
      tagFilterArr: [],
      storeArray: [],
      open: false,
      suggestions: [],
      alertOpen: false,
      imageIcon: "",
      message: "",
      isLinkPresent: false,
      error: ""
    };
  }

  remove = (value, index) => {
    this.props.removeCollaborator({ index });
    this.props.showMessage(
      `${value.userInitials} removed successfully`,
      "success"
    );
  };

  getSuggestions = (value = "") => {
    this.setState({ error: "" });
    const inputValue = value.trim().toLowerCase();
    const inputLength = inputValue.length;
    const escapedValue = escapeRegexCharacters(value.trim());
    if (inputLength === 0 || escapedValue === "") {
      return [];
    }
    const output = this.props.initialUsers.filter(
      suggestion =>
        suggestion.userInitials.toLowerCase().slice(0, inputLength) ===
        inputValue
    );
    if (!output.length) {
      this.setState({ error: "Please enter valid Initials." });
    }
    return output;
  };

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: this.getSuggestions(value)
    });
  };
  onSuggestionsClearRequested = () => {};
  getSuggestionValue = suggestion => {
    return suggestion.emailId;
  };
  renderSuggestion = suggestion => {
    return suggestion.userInitials;
  };
  onSuggestionSelected = (event, { suggestion }) => {
    const {
      addCollaboratorToWriteSuccess,
      writes,
      latestProof,
      proofURL,
      assignment,
      user
    } = this.props;
    if (!proofURL) {
      addCollaboratorToWriteSuccess(suggestion);
      const obj = {
        commentValue: "@" + suggestion.userInitials.trim(),
        commentStatus: "",
        percolateId: assignment.id,
        replyToId: 0,
        userInitials: user.userId,
        optionalText: "",
        assignmentName: assignment.name
      };
      this.props.shareReviewer(obj);
    } else {
      const fileId = latestProof
        ? latestProof.fileId
        : writes.write.assignment.proofFileId;

      if (!suggestion.userInitials || !fileId) return;
      this.props.addReviewer({
        initial: suggestion.userInitials,
        emailId: suggestion.emailId,
        fileId,
        assignment,
        user
      });
    }
    this.props.showMessage(
      `${suggestion.userInitials} added successfully`,
      "success"
    );
    this.setState({ value: "" });
  };
  onChangeInput = (event, option) => {
    this.setState({ value: option.newValue });
  };

  sendProof = () => {
    const { emailText } = this.state;
    const {
      createProofRequest,
      assignment,
      writes,
      user,
      collaborators,
      showMessage,
      proofURL
    } = this.props;
    createProofRequest({
      assignmentId: assignment.id,
      assignmentName: assignment.name,
      recipients: collaborators,
      fileID: writes.write.assignment.proofFileId,
      emailID: user.emailId,
      emailText,
      user,
      proofURL,
      showMessage
    });

    this.setState({ emailText: "" });
  };

  sendPdfToWorkfront = () => {
    let assignment = null;
    if (
      this.props.writes &&
      this.props.writes.write &&
      this.props.writes.write.assignment
    ) {
      assignment = this.props.writes.write.assignment;
    }
    const payload = {
      id: assignment.percolateId,
      referenceNumber: assignment.workfrontJobId,
      newVersion: !!assignment.workfrontDocId,
      documentId: assignment.workfrontDocId,
      showMessage: this.props.showMessage
    };
    this.props.sendPdfToWorkfront(payload);
  };

  commentHandler = e => {
    const emailText = e.target.value;
    this.setState({ emailText });
  };

  componentDidMount() {
    const {
      latestProof,
      writes,
      fetchInitialUsers,
      fetchReviewer,
      user
    } = this.props;
    fetchInitialUsers();
    const fileId = latestProof
      ? latestProof.fileId
      : writes.write.assignment.proofFileId;

    if (fileId && !writes.write.assignment.reviewerLoaded) {
      fetchReviewer({ fileId, emailId: user.emailId });
    }
  }
  render() {
    const { value, suggestions, emailText, error } = this.state;
    const { collaborators, classes, proofURL, assignment } = this.props;
    const inputSuggestionProps = {
      placeholder: "add",
      value,
      onChange: this.onChangeInput,
      id: "bootstrap-input"
    };

    let reviewStarted = false;
    const writes = this.props.writes;
    if (writes && writes.write && writes.write.assignment) {
      reviewStarted = !!writes.write.assignment.workfrontDocId;
    }
    return (
      <div className="email-container">
        <h5 className={classes.title}>Reviewers </h5>
        <div className={`input-group ${error ? "error" : ""}`}>
          <ChipButton chipButtonValues={collaborators} onClose={this.remove} />
          <Autosuggest
            suggestions={suggestions}
            onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
            onSuggestionsClearRequested={this.onSuggestionsClearRequested}
            getSuggestionValue={this.getSuggestionValue}
            renderSuggestion={this.renderSuggestion}
            onSuggestionSelected={this.onSuggestionSelected}
            inputProps={inputSuggestionProps}
          />
          {error ? <span className={classes.errorIcon}>!</span> : null}
        </div>
        {error ? <div className={classes.error}>{error}</div> : null}
        <div>
          <TextField
            id="outlined-bare"
            value={emailText}
            fullWidth={true}
            className={classes.comments}
            margin="normal"
            multiline
            rows="4"
            variant="outlined"
            inputProps={{ "aria-label": "bare" }}
            onChange={this.commentHandler}
            placeholder={"Comments(optional)"}
          />
        </div>
        <div className={classes.btnWrapper}>
          <Button
            variant="contained"
            className={`${classes.genProofBtn} btn-solid-blue`}
            disabled={!collaborators.length || reviewStarted}
            onClick={this.sendProof}
          >
            GENERATE PROOF(CREATIVE)
          </Button>
        </div>
        <div className={classes.btnWrapper}>
          <Button
            href={proofURL}
            className={`${classes.goToProofBtn} ${
              !proofURL ? classes.disabled : classes.enabled
            }`}
            target="_blank"
            color="primary"
            disabled={!proofURL}
          >
            Go to proof{" "}
            {reviewStarted ? (
              <span className={classes.lockIcon}>
                <LockIcon />
              </span>
            ) : null}
          </Button>
        </div>
            {/*   {assignment.isDraft ? null : (
          <div className={classes.btnWrapper}>
            <Button
              onClick={this.sendPdfToWorkfront}
              className={`${classes.goToProofBtn} ${
                !proofURL ? classes.disabled : classes.enabled
              }`}
              target="_blank"
              color="primary"
              disabled={!proofURL}
            >
              Go To Legal Proof
            </Button>
          </div>
            )} */}
      </div>
    );
  }
}
const mapStateToProps = state => {
  const personalProof = state.write.personalUrl;
  const proofLists = Object.assign([], state.write.proofUrl);
  const latestProof = proofLists.length > 0 ? proofLists.reverse().shift() : {};
  const proofURL = personalProof ? personalProof : latestProof.proofUrl;

  return {
    latestProof,
    proofURL,
    writes: state.write,
    user: state.user,
    initialUsers: state.user.initialUsers,
    assignment: state.assignments.assignment
  };
};

export default compose(
  withStyles(styles),
  connect(mapStateToProps, {
    createProofRequest,
    addCollaboratorToWriteSuccess,
    removeCollaborator,
    fetchInitialUsers,
    addReviewer,
    shareReviewer,
    shareProof,
    shareProofVersion,
    fetchReviewer,
    showSuccessMsg,
    sendPdfToWorkfront
  })
)(EmailAutoSuggest);
