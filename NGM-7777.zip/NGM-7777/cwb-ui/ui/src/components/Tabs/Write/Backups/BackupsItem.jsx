import React, { useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { uploadFileApi } from "../../../../api/writeApi";
import * as backups_actions from "../../../../redux/actions/writeAction";
import { withStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import FormField from "../../../Form/FormField/FormField";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import ReactLoading from "react-loading";
import configDeterminator from "../../../../configs/configDeterminator";
import DeleteIcon from "@material-ui/icons/Delete";
import DownloadIcon from "@material-ui/icons/GetApp";
import CWBDialog from "../../../Dialog/CWBDialog";

const styles = theme => {
  return {
    grid: {
      display: "flex",
      flex: 1,
      alignItems: "center",
      margin: "10px"
    },
    blockquote: {
      borderLeft: "4px solid #cbd0d2",
      paddingLeft: "10px",
      color: "#17a2b8",
      fontWeight: "100"
    },
    uploadFile: {
      marginBottom: "20px"
    },
    disabled: {
      backgroundColor: "#ccccc"
    }
  };
};

const BackupsItem = React.memo(function BackupsItem(props) {
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const onClose = confirm => {
    if (confirm === "yes") {
      const { backupId } = props;
      props.deleteBackupsItemRequest({ backupId });
    } else {
      console.log("Ok, We will not delete");
    }
    setOpen(false);
  };

  const uploadFile = (backupId, name, file) => {
    const { assignmentId, userId } = props;
    setLoading(true);
    uploadFileApi({
      file,
      url: "/backups",
      assignmentId,
      userId,
      name,
      id: backupId
    })
      .then(({ data }) => {
        setLoading(false);
        props.showSuccessMsg("Successfully Uploaded");
        props.uploadBackupSuccess({ data, backupId });
      })
      .catch(error => {
        setLoading(false);
        props.showErrorMsg("File Upload Fail");
      });
  };

  const onFileChange = (backupId, fieldName, file) => {
    const { name } = props;
    if (name === file.name) {
      const isConfirm = window.confirm(
        "File with the same name already exists.  Do you want to replace existing file with this new one?"
      );
      if (isConfirm) {
        uploadFile(backupId, props.name, file);
      }
    } else if (name) {
      const isConfirm = window.confirm("Are you sure you want to override ?");
      if (isConfirm) {
        uploadFile(backupId, props.name, file);
      }
    } else {
      uploadFile(backupId, props.name, file);
    }
  };

  const handleDeleteBackupItem = () => {
    setOpen(true);
  };

  const renderBackupItem = () => {
    const { classes, name, backupId } = props;
    return (
      <Card className={"write-backup-card"}>
        <CardHeader
          className={"write-backup-card-hdr"}
          title="Backup File"
          action={
            <div className={"backup_card_buttons"}>
              <Button
                onClick={handleDeleteBackupItem}
                color="primary"
                disabled={!name}
                title="Delete"
              >
                <DeleteIcon color={name ? "primary" : "disabled"} />
              </Button>
              <Button
                color="primary"
                target="_blank"
                href={`${configDeterminator.cwbApiEndpoint}/backups/${backupId}`}
                disabled={!name}
                title="Download"
              >
                <DownloadIcon color={name ? "primary" : "disabled"} />
              </Button>
            </div>
          }
        />
        <CardContent className={"write-backup-card-file"}>
          <div className={classes.uploadFile}>
            {loading ? (
              <ReactLoading type={"bubbles"} color={"#000000"} />
            ) : (
              <FormField
                id={backupId}
                label={"Browse"}
                onFileChange={onFileChange}
                allowComments={false}
                fieldType="FileUpload"
                value={name}
              />
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const { classes, isList } = props;
  return (
    <Grid
      item
      className={isList ? "backups-flat-list" : `backup-card ${classes.grid}`}
    >
      <CWBDialog
        open={open}
        onClose={onClose}
        confirmation={true}
        message={`Are you sure you want to delete?<br /><br />`}
        customClass={`delete-dialog`}
      />
      {renderBackupItem()}
    </Grid>
  );
});

const mapStateToProps = ({ assignments, user }) => {
  return {
    assignmentId: assignments.assignment && assignments.assignment.id,
    userId: user.userId
  };
};

const mapDispatchToProps = dispatch => {
  return {
    ...bindActionCreators(backups_actions, dispatch)
  };
};

const ConnectedComponent = connect(
  mapStateToProps,
  mapDispatchToProps
)(BackupsItem);

export default withStyles(styles)(ConnectedComponent);
