import React from "react";
import { List, ViewComfy } from "@material-ui/icons";

function DisplayButtons(props) {
  const { backups, displayList, setDisplay, sectionType } = props;
  const backupsLength = backups
    ? backups.filter(backup => {
        const sectionTypeId =
          sectionType === "backups" ? backup.backupId : backup.graphicsId;
        return sectionTypeId !== "";
      }).length
    : 0;
  return (
    <div className={"format-buttons " + (backupsLength === 0 ? "hide" : "")}>
      <button
        className={displayList ? "active-state" : ""}
        onClick={() => setDisplay(true)}
        title="List View"
      >
        <List />
      </button>
      <span>|</span>
      <button
        className={displayList ? "" : "active-state"}
        onClick={() => setDisplay(false)}
        title="Card View"
      >
        <ViewComfy />
      </button>
    </div>
  );
}

export default DisplayButtons;
