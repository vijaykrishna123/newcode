import React, { useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Grid from "@material-ui/core/Grid";
import ResponsiveImageItem from "./ResponsiveImageItem";
import SectionHeader from "../SectionHeader";
import { uploadFileApi } from "../../../../api/writeApi";
import FormField from "../../../Form/FormField/FormField";
import * as backups_actions from "../../../../redux/actions/writeAction";
import {
  ExpansionPanel,
  ExpansionPanelDetails,
  ExpansionPanelSummary
} from "@material-ui/core";
import { ExpandMore} from "@material-ui/icons";
import DisplayButtons from "./DisplayButtons";

function Backups(props) {
  const [expanded, setExpanded] = useState(false);
  const [displayList, setDisplay] = useState(true);
  const handleChange = panel => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
  const { backups } = props;
  const backupsLength = backups
    ? backups.filter(backup => backup.graphicsId !== "").length
    : 0;
  const renderItems = () => {
    const { backups } = props;
    if (!backups) {
      return;
    }
    return backups
      .filter(backup => backup.graphicsId !== "")
      .map(backupItem => {
        return (
          <ResponsiveImageItem
            key={backupItem.graphicsId}
            graphicId={backupItem.graphicsId}
            name={backupItem.name}
            isList={displayList}
          />
        );
      });
  };
  const uploadFile = (name, graphicsId, file, cb) => {
    const { assignmentId, userId } = props;

    uploadFileApi({
      file,
      assignmentId,
      userId,
      name,
      id: graphicsId
    })
      .then(({ data }) => {
        props.showSuccessMsg("Successfully Uploaded");
        if (name) {
          return cb(null);
        }
        cb({
          graphicsId: data.graphicId,
          name: data.graphicName
        });
      })
      .catch(error => {
        props.showErrorMsg(`File name - ${file.name} Upload Fail`);
        cb(null);
      });
  };

  const onFileChange = (id, fieldName, files) => {
    if (!files || !files.length) {
      return;
    }
    const allUploadedBackups = [];
    const uploadFiles = (files, cb) => {
      let count = 0;
      let fileLength = files.length;

      const uploadFileSuccess = backup => {
        if (backup) {
          allUploadedBackups.push(backup);
        }
        count++;
        if (count === fileLength) {
          cb();
        }
      };

      for (let i = 0; i < fileLength; i++) {
        const file = files.item(i);

        var filePath = file.name;
        var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
        if (!allowedExtensions.exec(filePath)) {
          alert(
            "Please upload file having extensions .jpeg/.jpg/.png/.gif only."
          );
          count++;
          if (count === fileLength) {
            cb();
          }
        } else {
          const existingBackup = props.backups.filter(
            backup => backup.name === file.name
          )[0];

          if (existingBackup) {
            const isConfirm = window.confirm(
              `File with the ${file.name} name already exists. Do you want to replace existing file with this new one?`
            );
            if (isConfirm) {
              uploadFile(
                file.name,
                existingBackup.graphicsId,
                file,
                uploadFileSuccess
              );
            }
          } else {
            const graphicsId = Math.floor(Math.random() * 20);
            uploadFile("", graphicsId, file, uploadFileSuccess);
          }
        }
      }
    };
    uploadFiles(files, () => {
      props.uploadGraphicSuccess(allUploadedBackups);
    });
  };

  return (
    <Grid
      container
      direction="row"
      justify="center"
      alignItems="center"
      spacing={16}
    >
      <Grid item xs={12}>
        <ExpansionPanel
          expanded={expanded === "panel1"}
          onChange={handleChange("panel1")}
          className={"expansion-panel"}
        >
          <ExpansionPanelSummary
            expandIcon={<ExpandMore />}
            aria-controls="panel1bh-content"
            id="panel1bh-header"
            className={"mod-header"}
          >
            <SectionHeader
              title={"Creative assets (" + backupsLength + ")"}
              id="backup"
              noIcon={true}
            />
          </ExpansionPanelSummary>
          <ExpansionPanelDetails className={"expansion-details"}>
            <div className={"write-backups-items write-backups-block"}>
              <DisplayButtons
                backups={backups}
                displayList={displayList}
                setDisplay={setDisplay}
                sectionType="responsive"
              />
              {renderItems()}
              <Grid item xs={12} className={"add-button-container"}>
                <FormField
                  id={"multiple_file_upload"}
                  label={"+ ADD NEW IMAGE"}
                  onFileChange={onFileChange}
                  allowComments={false}
                  fieldType="FileUpload"
                  value={""}
                />
              </Grid>
            </div>
          </ExpansionPanelDetails>
        </ExpansionPanel>
      </Grid>
    </Grid>
  );
}

const mapStateToProps = state => {
  return {
    backups: state.write.write && state.write.write.graphics,
    assignmentId:
      state.assignments.assignment && state.assignments.assignment.id,
    userId: state.user.userId
  };
};
const mapDispatchToProps = dispatch => {
  return {
    ...bindActionCreators(backups_actions, dispatch)
  };
};
const ConnectedComponent = connect(
  mapStateToProps,
  mapDispatchToProps
)(Backups);
export default ConnectedComponent;
