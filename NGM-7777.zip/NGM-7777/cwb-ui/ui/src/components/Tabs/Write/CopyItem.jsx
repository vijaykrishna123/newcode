import React from "react";
import FormField from "../../Form/FormField/FormField";
import { getEMailTemplate } from "../../Template/Email";
import { getWebTemplate } from "../../Template/webarticle";

function CopyItem(props) {
  const handleCommentModal = () => {
    const { onCommentBtnClick } = props;
    if (onCommentBtnClick) {
      onCommentBtnClick({ open: true });
    }
  };
  const saveInStore = payload => {
    props.saveInStore({ [payload.id]: payload.newData });
  };

  const renderForm = () => {
    const { type, saveForm } = props;
    const { fields = [] } = props.fieldProps;
    const data = fields[0];
    const ckvalue =
      (data.fieldValue === "") | (data.fieldValue === "<p></p>") &&
      type === "Email"
        ? getEMailTemplate()
        : (data.fieldValue === "") | (data.fieldValue === "<p></p>") &&
          (type === "Web") | (type === "Web Article")
        ? getWebTemplate()
        : data.fieldValue;

    return fields.map((field, index) => {
      const { fieldName } = field;
      const { allowComments, ...restProps } = {
        minLength: "0",
        fieldType: "Editor",
        maxLength: "50",
        fieldHelperText: null
      };
      return (
        <FormField
          key={index}
          label={fieldName}
          name={data.fieldId + ""}
          allowComments={allowComments}
          onCommentBtnClick={handleCommentModal}
          onBlur={saveInStore}
          value={ckvalue}
          id={data.fieldId}
          userId={props.userId}
          assignmentId={props.assignmentId}
          saveForm={saveForm}
          {...restProps}
        />
      );
    });
  };

  return <div className={"form-item"}>{renderForm()}</div>;
}

export default CopyItem;
