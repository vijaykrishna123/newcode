import React from "react";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import Copy from "./Copy";
import WriteHeader from "./WriteHeader";
import WriteProofModal from "./WriteProofModal";
import {
  fetchAssignmentDetails,
  createAssignment
} from "../../../redux/actions/assignmentActions";
import { fetchDraftDetail } from "../../../redux/actions/draftsAction";
import { addDisclosureDetails } from "../../../redux/actions/disclosureActions";
import Backups from "./Backups/Backups";
import ResponsiveImage from "./Backups/ResponsiveImage";
import {
  fetchAllFieldsRequest,
  addCollaborator,
  fetchPersonalUrl,
  updatedisclosureTags,
  receivePostSaveResponse
} from "../../../redux/actions/writeAction";
import { shareUrlToOther } from "../../../redux/actions/commentAction";
import * as R from "ramda";
import ReactLoading from "react-loading";
import ShareWithOthers from "components/Popups/ShareWithOthers";
import { loadPageData } from "../../Analytics/Analytics";
import { unHideTabs } from "../../../redux/actions/dashBoardActions";
import queryString from "query-string";
import { getDisclosureDetails } from "../../../api/disclosureApi";
import { applyTags } from "../../../utils/cwbUtils";
import {
  STANDARD_TAGS,
  STAND_ALONE_TAGS
} from "../../../redux/constants/standardDisclosuresConstants";
import { receiveStdDisclosuresDetails } from "../../../redux/actions/standardDisclosuresAction";

class Write extends React.Component {
  state = {
    popup: false,
    showProofModal: false,
    personalUrlLoaded: false,
    disclosureApiCalled: false
  };

  async componentDidMount() {
    loadPageData("Write", "write");
    const values = queryString.parse(this.props.location.search);
    if (!R.test(/write/, this.props.location.pathname)) {
      const path = "/" + this.props.match.params.postId;
      if (values.unlinked) {
        this.props.fetchDraftDetail(path);
      } else {
        this.props.fetchAssignmentDetails(path);
      }
      this.props.fetchAllFieldsRequest(path);
      this.props.unHideTabs();
    } else {
      if (this.props.write && R.isEmpty(this.props.write.write))
        this.props.history.push("/");
    }

    if (this.props.proofModal) {
      this.setState({ showProofModal: true });
      this.loadPersonalUrl();
    }
    this.fetchDisclosure();
  }

  loadPersonalUrl = () => {
    const { write, email, fetchPersonalUrl } = this.props;
    if (
      email &&
      write.write &&
      write.write.assignment &&
      !this.state.personalUrlLoaded
    ) {
      const payload = {
        fileID: write.write.assignment.proofFileId,
        emailID: `${email}`
      };

      fetchPersonalUrl(payload);
      this.setState({ personalUrlLoaded: true });
    }
  };
  componentDidUpdate() {
    const assignment = this.props.assignment;
    if (
      assignment !== null &&
      !R.isEmpty(assignment) &&
      this.props.userName &&
      this.props.write.error
    ) {
      this.createAssignmentDetails(this.props);
      this.props.fetchAllFieldsRequest(this.props.location.pathname);
    }

    this.loadPersonalUrl();
    this.fetchDisclosure();

    const write = this.props.write.write;
    if (
      assignment &&
      assignment.id &&
      write &&
      write.assignment &&
      write.assignment.percolateId === assignment.id
    ) {
      let updated = false;
      if (assignment.name !== write.assignment.assignmentName) {
        updated = true;
        write.assignment.assignmentName = assignment.name;
      }
      if (
        assignment.metaData &&
        assignment.metaData["Workfront Job #"] !==
          write.assignment.workfrontJobId
      ) {
        updated = true;
        write.assignment.workfrontJobId =
          assignment.metaData["Workfront Job #"];
      }
      if (updated) {
        this.props.receivePostSaveResponse(write);
      }
    }
  }
  fetchDisclosure = () => {
    if (
      this.state.disclosureApiCalled ||
      !this.props.assignment ||
      this.props.assignment.template !== "Web Article"
    ) {
      return;
    }
    if (
      !this.props.write ||
      !this.props.write.write ||
      (this.props.write && R.isEmpty(this.props.write.write))
    ) {
      return;
    }
    this.setState({ disclosureApiCalled: true });

    const writeData = this.props.write.write;
    let tags = JSON.parse(STAND_ALONE_TAGS);
    if (!this.props.assignment || R.isEmpty(this.props.assignment.taxonomy)) {
      tags = JSON.parse(STANDARD_TAGS);
    }
    if (
      writeData &&
      writeData.assignment &&
      writeData.assignment.disclosureTags &&
      writeData.assignment.disclosureTags.length
    ) {
      tags = writeData.assignment.disclosureTags;
    }
    const param = applyTags(tags, this.props.assignment);
    this.props.updatedisclosureTags(tags);
    getDisclosureDetails(param)
      .then(results => {
        return results;
      })
      .then(dataValues => {
        this.props.addDisclosureDetails(dataValues.data);
      })
      .catch(err => console.error(err));
  };
  createAssignmentDetails({ assignment, userName }) {
    let assignmentData = {
      percolateId: assignment.id,
      assignmentName: assignment.name,
      templateName: assignment.template,
      userInitials: userName,
      workfrontJobId: assignment.metaData["Workfront Job #"]
    };
    this.props.createAssignment(assignmentData);
  }

  shareUrl = () => {
    this.setState({ popup: !this.state.popup });
  };
  onProofModalClose = () => {
    this.setState({ showProofModal: false });
  };

  render() {
    const { classes, write, assignment, loading, userName } = this.props;
    if (typeof userName === "undefined" || R.isEmpty(write) || loading)
      return (
        <div>
          <ReactLoading type={"bubbles"} color={"#000000"} />
        </div>
      );
    if (write.error) return null;

    const personalProof = write.personalUrl;
    const proofLists = Object.assign([], write.proofUrl);
    const latestProof =
      proofLists.Length > 0 ? proofLists.reverse().shift() : {};
    const proofURL = personalProof ? personalProof : latestProof.proofUrl;

    return (
      <div className={"write-block"}>
        <WriteHeader classes={classes} shareUrl={this.shareUrl} />
        <WriteProofModal
          open={!!(proofURL && this.state.showProofModal)}
          onProofModalClose={this.onProofModalClose}
          assignment={assignment}
          proofURL={proofURL}
        />
        <div>
          <Copy
            ref={section => {
              this.Copy = section;
            }}
          />
          <Backups
            makeApiCall={this.makeApiCall}
            ref={section => {
              this.Backups = section;
            }}
          />
          <ResponsiveImage />
          {this.state.popup && (
            <ShareWithOthers
              handleClose={this.shareUrl}
              name={this.props.userName}
              assignment={assignment}
              shareUrlToOther={this.props.shareUrlToOther}
              addCollaborator={this.props.addCollaborator}
              userEmail={this.props.email}
            />
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ write, assignments, comment, user }) => {
  return {
    write: write,
    assignment: assignments.assignment,
    comment,
    userName: user.userId,
    email: user.emailId
  };
};

const ConnectedComponent = connect(mapStateToProps, {
  fetchAllFieldsRequest,
  shareUrlToOther,
  fetchAssignmentDetails,
  fetchDraftDetail,
  updatedisclosureTags,
  receivePostSaveResponse,
  addDisclosureDetails,
  createAssignment,
  addCollaborator,
  fetchPersonalUrl,
  unHideTabs
})(Write);

const style = theme => ({
  container: {
    display: "flex",
    justifyContent: "space-between"
  },
  button: {
    margin: theme.spacing.unit,
    color: "#fff",
    fontWeight: "bold",
    backgroundColor: "transparent",
    "&:hover": {
      backgroundColor: "transparent"
    }
  }
});
const mapDispatchToProps = dispatch => ({
  receiveStdDisclosuresDetails: param =>
    dispatch(receiveStdDisclosuresDetails(param))
});
export default connect(
  null,
  mapDispatchToProps
)(withStyles(style)(ConnectedComponent));
