import React from "react";
import { Toolbar, Typography, Button } from "@material-ui/core";
import WriteIcon from "@material-ui/icons/Create";
import ShareIcon from "@material-ui/icons/Share";

const WriteHeader = props => {
  const { classes, shareUrl } = props;
  return (
    <Toolbar className={"tab-header " + classes.container}>
      <Typography variant="title">
        <WriteIcon />
        Write
      </Typography>
      <Button variant="contained" className={classes.button} onClick={shareUrl}>
        <ShareIcon /> SHARE
      </Button>
    </Toolbar>
  );
};

export default WriteHeader;
