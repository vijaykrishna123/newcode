export const getEMailTemplate = () => {
  return ` 
  <p>
  <table class='Headline Subj'>
     <tbody>
        <tr>
           <p><span><strong>Subject</strong></span><br />The subject line of the email seen in the recipient's inbox, the first opportunity to engage. Max 40-60 char.</p>
           <td>&nbsp;</td>
        </tr>
     </tbody>
  </table><p/>
  <table class='Headline Prehead'>
     <tbody>
        <tr>
           <p>
              <span><strong>Pre-header</strong></span><br />The text that follows the subject line when viewing an email from the inbox. This is the second opportunity to engage. Max 40-80 char.
           </p>
           <td>&nbsp;</td>
        </tr>
     </tbody>
  </table><p/>
  <div>
     <span><strong>Logo</strong></span><br />
     <img id='logo' src='https://36212.cdn.cke-cs.com/Vj4iKRDUw4D5PUjTGq03/images/ce2e456567c2bb867015a49c490a9c409a94ce57837b359c.png'/>
  </div><p/>
  <div>
     <span><strong>Hero image</strong></span><br />Hero Image width = 1100px width. Display width = 550px. Before uploading or dragging the images to upload, please delete the below image.
     <img class='heroimage' src='https://36212.cdn.cke-cs.com/A85jVP04lPR7VEeANbt1/images/abde8993ea4527ecb54234575fc44960dcb9d379ac1ede16.png'/>
  </div><p/>
  <table class='Headline headstyle'>
     <tbody>
        <tr>
           <p>
              <span><strong>Header</strong></span><br />The heading of the email message (discuss placement with designer). Less than 65 char.
           </p>
           <td>&nbsp;</td>
        </tr>
     </tbody>
  </table><p/>
  <table class='Headline Content'>
     <tbody>
        <tr>
           <p>
              <span><strong>Email body</strong></span><br />Additional text and images. 
           </p>
           <td><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p></td>
        </tr>
     </tbody>
  </table><p/>
  <table class='Headline btext'>
     <tbody>
        <tr>
           <p>
              <span><strong>Button text</strong></span><br />Call to action.
           </p>
           <td>&nbsp;</td>
        </tr>
     </tbody>
  </table><p/>
  <table class='Headline blink'>
     <tbody>
        <tr>
           <p>
              <span><strong>Button link</strong></span><br />Link to the website or PDF lit code from the CTA.
           </p>
           <td>&nbsp;</td>
        </tr>
     </tbody>
  </table><p/>
  <table class="Standard Disclosure">
     <tbody>
        <tr>
           <p><span><strong>Standard disclosure</strong></span>
           </p>
           <td>
              <p><strong>Investments are not FDIC-insured, nor are they deposits of or guaranteed by a bank or any other entity, so they may lose value.</strong></p>
                    
        <p><strong>Investors should carefully consider investment objectives, risks, charges and expenses. This and other important information is contained in the fund prospectuses and summary prospectuses, which can be obtained from a financial professional and should be read carefully before investing.</strong></p>
                    
        <p> Statements attributed to an individual represent the opinions of that individual as of the date published and do not necessarily reflect the opinions of Capital Group or its affiliates. This information is intended to highlight issues and should not be considered advice, an endorsement or a recommendation.</p>
                    
        <p> This content, developed by Capital Group, home of American Funds, should not be used as a primary basis for investment decisions and is not intended to serve as impartial investment or fiduciary advice. </p>
                    
        <p> American Funds Distributors, Inc., member FINRA. </p>
           </td>
        </tr>
     </tbody>
  </table><p/>
  <table class='maxwidth foot'>
     <tbody>
        <tr>
           <p>
              <span><strong>Footer</strong></span><br />This is boilerplate footer language, do not edit unless needed
           </p>
           <td>
              <p>If you no longer wish to receive promotional communications from Capital Group, you may <span href='https://click.comm.capgroup.com/expired.html'  target='_blank'>unsubscribe</span> at any time.</p>
              <p> All Capital Group trademarks referenced are registered trademarks owned by The Capital Group Companies, Inc. or an affiliated company. All other company and product names mentioned are the trademarks or registered trademarks of their respective companies.</p>
              <p> Copyright © 2019 Capital Group. All rights reserved.</p>
                 333 S. Hope Street, Los Angeles, CA 90071 USA  |  <span href='https://www.capitalgroup.com/us/privacy-policy.html' target='_blank'>
                 PRIVACY
                 </span>
              </p>
           </td>
        </tr>
     </tbody>
  </table><p/>
  </p>`;
};
