import configLocal from "./alpha.config";
import configStaging from "./staging.config";
import configProduction from "./prod.config";
import configDev from "./dev.config";

let config = configLocal;

let envValue = process.env.REACT_APP_ENV;
if (/stg/.test(window.location.hostname)) config = configStaging;
else if (/localhost/.test(window.location.hostname)) config = configLocal;
else if (envValue === "DEVELOPMENT" && /dev/.test(window.location.hostname))
  config = configDev;
else config = configProduction;
export default {
  ...config
};
