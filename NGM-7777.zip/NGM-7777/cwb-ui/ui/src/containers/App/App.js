import React from "react";
import "../../shared/scss/App.css";
import { Route, Switch, Link } from "react-router-dom";
import CWBHeader from "../../components/Header/CWBHeader";
import Research from "../Research/ResearchContainer";
import Disclosure from "../../components/Tabs/Disclosure/Disclosure";
import ReviewSubmit from "../../components/Tabs/Review&Submit/ReviewSubmit";
import Resources from "../../components/DashBoard/ResourcesLink";
import Write from "../../components/Tabs/Write/Write";
import { SecureRoute, ImplicitCallback } from "@okta/okta-react";
import DashBoard from "../DashBoard/DashBoardContainer";
import { withStyles } from "@material-ui/core/styles";
import CWBSnackBar from "../../components/Popups/CWBSnackBar";
const FourOhFour = () => (
  <div className="container">
    <h1>404: Not Found</h1>
    <h3>
      <Link to="/">Go Home</Link>
    </h3>
  </div>
);
const styles = theme => ({
  root: {
    flexGrow: 1,
    height: "auto",
    zIndex: 1,
    overflow: "hidden",
    position: "relative",
    display: "flex"
  },
  content: {
    flexGrow: 1
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: "0 8px",
    ...theme.mixins.toolbar
  }
});
const App = ({ router, classes }) => {
  return (
    <div className={"app-container " + classes.root}>
      <CWBHeader />
      <main className={"tab-container"}>
        <div className={classes.toolbar} />
        <CWBSnackBar />
        <Switch>
          <SecureRoute exact={true} path="/" component={DashBoard} />
          <SecureRoute exact path="/research" component={Research} />
          <SecureRoute exact path="/overview" component={Research} />
          <SecureRoute exact path="/write" component={Write} />
          <SecureRoute exact path="/disclosures" component={Disclosure} />
          <SecureRoute path="/review" component={ReviewSubmit} />
          <SecureRoute path="/resources" component={Resources} />
          <SecureRoute exact path="/:postId" component={Write} />
          <SecureRoute
            exact
            path="/:postId/proof-modal"
            render={props => <Write {...props} proofModal={true} />}
          />
          <SecureRoute path="*" component={FourOhFour} />
        </Switch>
        <Route path="/implicit/callback" component={ImplicitCallback} />
      </main>
    </div>
  );
};

export default withStyles(styles)(App);
