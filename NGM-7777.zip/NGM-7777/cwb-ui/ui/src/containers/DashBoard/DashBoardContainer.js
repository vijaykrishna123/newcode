import React, { Component } from "react";
import DashBoard from "../../components/DashBoard/DashBoardComponent";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import {
  fetchAllAssignments,
  fetchTemplates
} from "../../redux/actions/dashBoardActions";
import { saveUserDetailsToStore } from "../../redux/actions/userActions";
import { withAuth } from "@okta/okta-react";
import { hideTabs, submitFeedback } from "../../redux/actions/dashBoardActions";
import {
  updateUserLoginStatus,
  clearWriteStore
} from "../../redux/actions/writeAction";
import {
  addDraft,
  deleteDraft,
  fetchAllDrafts,
  linkDraftToAssignment,
  setLinkingStatus
} from "../../redux/actions/draftsAction";
import { clearDisclosureStore } from "../../redux/actions/disclosureActions";
import { updateAssignmentStatusRequest } from "../../redux/actions/assignmentActions";
import { loadPageData } from "../../components/Analytics/Analytics";

class DashBoardContainer extends Component {
  async componentDidMount() {
    const {
      clearWriteStore,
      clearDisclosureStore,
      fetchTemplates
    } = this.props;
    loadPageData("Dashboard", "dashboard");
    fetchTemplates();
    await this.getCurrentUser();
    await clearWriteStore();
    await clearDisclosureStore();
  }

  getCurrentUser = async () => {
    const { auth, updateUserLoginStatus, fetchAllDrafts } = this.props;

    const user = await auth.getUser();
    let { email, given_name, family_name, preferred_username } = user;
    const username = preferred_username.split("@")[0];
    await this.fetchAllAssignments(email, username);
    await fetchAllDrafts(username);
    updateUserLoginStatus({
      email: email,
      firstName: given_name,
      lastName: family_name,
      userInitials: username
    });

    this.setSession(username);
  };

  setSession = userInitials => {
    let timeStamp = Date.now().toString();
    let sessionId = btoa(timeStamp.concat(userInitials));
    localStorage.setItem("sessionId", sessionId);
    localStorage.setItem("userInitials", userInitials);
  };

  fetchAllAssignments = (email, username) => {
    if (null != email) {
      const { fetchAllAssignments, hideTabs } = this.props;
      fetchAllAssignments({ email, username });
      hideTabs();
    }
  };

  render() {
    return (
      <div>
        <DashBoard assignments={this.props} />
      </div>
    );
  }
}

const mapStateToProps = ({ userAssignments, user, drafts }) => {
  const { allAssignments, loading, error, templates } = userAssignments;
  return {
    templates,
    loading: loading,
    allAssignments: allAssignments,
    error: error,
    userDetails: user,
    drafts: drafts.drafts,
    draftCreating: drafts.draftCreating,
    linkingStatus: drafts.linkingStatus
  };
};

const mapDispatchToProps = dispatch => ({
  saveUserDetailsToStore: emailId => dispatch(saveUserDetailsToStore(emailId)),
  fetchAllAssignments: user => dispatch(fetchAllAssignments(user)),
  hideTabs: () => dispatch(hideTabs()),
  updateUserLoginStatus: user => dispatch(updateUserLoginStatus(user)),
  clearWriteStore: () => dispatch(clearWriteStore()),
  clearDisclosureStore: () => dispatch(clearDisclosureStore()),
  updateAssignmentStatusRequest: payload =>
    dispatch(updateAssignmentStatusRequest(payload)),
  submitFeedback: payload => dispatch(submitFeedback(payload)),
  fetchTemplates: () => dispatch(fetchTemplates()),
  fetchAllDrafts: username => dispatch(fetchAllDrafts(username)),
  addDraft: payload => dispatch(addDraft(payload)),
  deleteDraft: payload => dispatch(deleteDraft(payload)),
  linkDraftToAssignment: payload => dispatch(linkDraftToAssignment(payload)),
  setLinkingStatus: payload => dispatch(setLinkingStatus(payload))
});

DashBoardContainer.propTypes = {
  saveUserDetailsToStore: PropTypes.func.isRequired,
  fetchAllAssignments: PropTypes.func.isRequired
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withAuth(DashBoardContainer));
