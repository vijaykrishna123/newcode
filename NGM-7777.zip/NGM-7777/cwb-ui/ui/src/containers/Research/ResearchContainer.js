import React, { Component } from "react";
import AssignmentDetailsContainer from "../Assignment/AssignmentDetailsContainer";
import Resource from "../../components/Tabs/Research/ResourceComponent";
import configDeterminator from "../../configs/configDeterminator";
import { connect } from "react-redux";
import { loadPageData } from "../../components/Analytics/Analytics";
import Title from "../../components/Common/Title";
import * as R from "ramda";

class Research extends Component {
  componentDidMount() {
    loadPageData("Research", "research");
  }

  render() {
    let renderAssignment = null;
    if (!R.test(/standalone/, this.props.location.search)) {
      renderAssignment = (
        <AssignmentDetailsContainer postId={this.props.location.pathname} />
      );
    } else {
      renderAssignment = (
        <div>
          <Title icon="search" title="Discover" />
          <Resource
            daaUrl={configDeterminator.daaUrl}
            handleClose={this.handleClose}
          />
        </div>
      );
    }
    return <div>{renderAssignment}</div>;
  }
}

export default connect()(Research);
