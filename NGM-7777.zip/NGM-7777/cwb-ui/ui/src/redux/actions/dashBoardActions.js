import {
  FETCH_ALL_ASSIGNMENT,
  FETCH_ALL_ASSIGNMENT_SUCCEEDED,
  FETCH_ALL_ASSIGNMENT_FAILED,
  ASSIGNMENT_DASHBOARD_LOADED,
  ASSIGNMENT_DASHBOARD_UNLOADED,
  FEEDBACK_SUBMIT_REQUEST,
  FETCH_TEMPLATES,
  FETCH_TEMPLATES_SUCCESS,
  FETCH_TEMPLATES_FAILED
} from "../constants/dashBoardConstants";

/**
 * Method for fetching the assignment details from percolate
 */
export const fetchAllAssignments = user => ({
  type: FETCH_ALL_ASSIGNMENT,
  payload: user
});

/**
 * Function in case we get error while getting all assignment
 */
export const fetchErrorAllAssignments = error => ({
  type: FETCH_ALL_ASSIGNMENT_FAILED,
  payload: error
});

/**
 * Function for dispatching once the all assignment are received
 */
export const receiveAllAssignments = assignmentDetails => ({
  type: FETCH_ALL_ASSIGNMENT_SUCCEEDED,
  payload: assignmentDetails
});

export const hideTabs = () => ({
  type: ASSIGNMENT_DASHBOARD_LOADED
});

export const unHideTabs = () => ({
  type: ASSIGNMENT_DASHBOARD_UNLOADED
});

export const submitFeedback = payload => ({
  type: FEEDBACK_SUBMIT_REQUEST,
  payload
});

export const fetchTemplates = payload => ({
  type: FETCH_TEMPLATES,
  payload
});

export const fetchTemplatesSuccess = payload => ({
  type: FETCH_TEMPLATES_SUCCESS,
  payload
});

export const fetchTemplatesError = payload => ({
  type: FETCH_TEMPLATES_FAILED,
  payload
});
