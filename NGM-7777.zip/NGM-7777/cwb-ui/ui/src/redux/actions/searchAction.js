import {
  SEARCH_REQUEST,
  SEARCH_FAIL,
  SEARCH_SUCCESS,
  FEEDBACK_REQUEST,
  FEEDBACK_FAIL,
  FEEDBACK_SUCCESS,
  FILTER_REQUEST,
  FILTER_FAIL,
  FILTER_SUCCESS,
  AUTOCOMPLETE_REQUEST,
  AUTOCOMPLETE_FAIL,
  AUTOCOMPLETE_SUCCESS,
  AUTOCORRECT_REQUEST,
  AUTOCORRECT_FAIL,
  AUTOCORRECT_SUCCESS,
  CLEAR_STATE,
  CLEAR_AUTOCOMPLETE_STATE
} from "../constants/searchConstant";

export const clearStore = () => ({
  type: CLEAR_STATE
});
export const searchRequest = payload => ({
  type: SEARCH_REQUEST,
  payload
});
export const searchRequestFail = error => ({
  type: SEARCH_FAIL,
  error
});
export const searchSuccess = payload => ({
  type: SEARCH_SUCCESS,
  payload
});

export const feedbackRequest = payload => ({
  type: FEEDBACK_REQUEST,
  payload
});
export const feedbackRequestFail = error => ({
  type: FEEDBACK_FAIL,
  error
});
export const feedbackSuccess = payload => ({
  type: FEEDBACK_SUCCESS,
  payload
});
export const filterRequest = payload => ({
  type: FILTER_REQUEST,
  payload
});
export const filterRequestFail = error => ({
  type: FILTER_FAIL,
  error
});
export const filterSuccess = payload => ({
  type: FILTER_SUCCESS,
  payload
});

export const autocompleteRequest = payload => ({
  type: AUTOCOMPLETE_REQUEST,
  payload
});
export const autocompleteRequestFail = error => ({
  type: AUTOCOMPLETE_FAIL,
  error
});
export const autocompleteSuccess = payload => ({
  type: AUTOCOMPLETE_SUCCESS,
  payload
});

export const autocorrectRequest = payload => ({
  type: AUTOCORRECT_REQUEST,
  payload
});
export const autocorrectRequestFail = error => ({
  type: AUTOCORRECT_FAIL,
  error
});
export const autocorrectSuccess = payload => ({
  type: AUTOCORRECT_SUCCESS,
  payload
});
export const removeAutoCompleteList = () => ({
  type: CLEAR_AUTOCOMPLETE_STATE
});
