import {
  FETCH_ALL_FIELDS_REQUEST,
  FETCH_ALL_FIELDS_SUCCESS,
  FETCH_ALL_FIELDS_FAILURE,
  FETCH_COPY_REQUEST,
  FETCH_COPY_SUCCESS,
  FETCH_COPY_FAILURE,
  ADD_COPY_REQUEST,
  ADD_COPY_SUCCESS,
  FETCH_BACKUPS_REQUEST,
  FETCH_BACKUPS_SUCCESS,
  FETCH_BACKUPS_FAILURE,
  UPLOAD_COPY_FORM_DATA_SUCCESS,
  ADD_BACKUPS_ITEM_REQUEST,
  DELETE_BACKUPS_ITEM_REQUEST,
  DELETE_GRAPHIC_ITEM_REQUEST,
  UPDATE_COPY_REQUEST,
  UPDATE_BACKUPS_ITEM_SUCCESS,
  UPDATE_GRAPHICS_ITEM_SUCCESS,
  UPLOAD_COPY_FORM_DATA,
  DELETE_BACKUPS_ITEM_SUCCESS,
  DELETE_GRAPHIC_ITEM_SUCCESS,
  USER_LAST_LOGIN,
  UPDATE_DISCLOSURE_TAGS_SUCCESS,
  CREATE_PROOF_REQUEST,
  CREATE_PROOF_SUCCESS,
  CREATE_PROOF_FAILURE,
  PROOF_ACTION,
  SAVE_ASSIGNMENT_SUCCEEDED,
  CLEAR_WRITE_STORE,
  UPDATE_WRITE_FOR_DISCLOSURE,
  SAVE_WRITE_FOR_DISCLOSURE,
  ADD_COLLABORATOR_TO_WRITE,
  REMOVE_COLLABORATOR_FROM_WRITE,
  ADD_COLLABORATOR_TO_WRITE_SUCCESS,
  ADD_COLLABORATOR_TO_WRITE_FAILURE,
  FETCH_PERSONAL_URL,
  CREATE_PROOF_PERSONAL_URL_SUCCESS,
  ADD_REVIEWER,
  SHARE_REVIEWER,
  SHARE_PROOF,
  SHARE_PROOF_VERSION,
  FETCH_REVIEWER,
  FETCH_REVIEWER_SUCCESS,
  FETCH_REVIEWER_FAILED,
  START_LEGAL_REVIEW_SUCCESS,
  SEND_PDF_TO_WORKFRONT,
} from "../constants/writeConstants";
import { openSnackbar } from "../../components/Popups/CWBSnackBar";
// write action
export const fetchAllFieldsRequest = postId => {
  return {
    type: FETCH_ALL_FIELDS_REQUEST,
    payload: postId
  };
};
export const showSuccessMsg = message => {
  openSnackbar({ message: message, variant: "success" });
  return {
    type: "SUCCESS"
  };
};
export const showErrorMsg = message => {
  openSnackbar({ message: message, variant: "error" });
  return {
    type: "ERROR"
  };
};

export const fetchAllFieldsSuccess = payload => {
  return {
    type: FETCH_ALL_FIELDS_SUCCESS,
    payload
  };
};

export const fetchAllFieldsFailure = payload => {
  return {
    type: FETCH_ALL_FIELDS_FAILURE,
    payload
  };
};

/*Function for assignment collaborators API*/

export const addCollaboratorToWriteSuccess = payload => {
  return {
    type: ADD_COLLABORATOR_TO_WRITE_SUCCESS,
    payload
  };
};

export const addCollaboratorToWriteFailure = payload => {
  return {
    type: ADD_COLLABORATOR_TO_WRITE_FAILURE,
    payload
  };
};

//   end write action
// copy action
export const fetchCopyRequest = () => {
  return {
    type: FETCH_COPY_REQUEST
  };
};

export const fetchCopySuccess = payload => {
  return {
    type: FETCH_COPY_SUCCESS,
    payload
  };
};

export const fetchCopyFailure = error => {
  return {
    type: FETCH_COPY_FAILURE,
    error
  };
};

export const addCopyRequest = () => {
  return {
    type: ADD_COPY_REQUEST
  };
};

export const addCopySuccess = () => {
  return {
    type: ADD_COPY_SUCCESS
  };
};

export const addCopyFailure = error => {
  return {
    type: ADD_COPY_SUCCESS,
    error
  };
};
export const updateCopyRequest = payload => {
  return {
    type: UPDATE_COPY_REQUEST,
    payload
  };
};

// back up action
export const fetchBackupsRequest = () => {
  return {
    type: FETCH_BACKUPS_REQUEST
  };
};

export const fetchBackupsSuccess = backupFields => {
  return {
    type: FETCH_BACKUPS_SUCCESS,
    backupFields
  };
};

export const fetchBackupsFailure = error => {
  return {
    type: FETCH_BACKUPS_FAILURE,
    error
  };
};
export const addBackupsItemRequest = payload => {
  return {
    type: ADD_BACKUPS_ITEM_REQUEST,
    payload
  };
};
export const deleteBackupsItemSuccess = payload => {
  return {
    type: DELETE_BACKUPS_ITEM_SUCCESS,
    payload
  };
};

export const deleteGraphicItemSuccess = payload => {
  return {
    type: DELETE_GRAPHIC_ITEM_SUCCESS,
    payload
  };
};

export const deleteBackupsItemRequest = payload => {
  return {
    type: DELETE_BACKUPS_ITEM_REQUEST,
    payload
  };
};

export const deleteGraphicRequest = payload => {
  return {
    type: DELETE_GRAPHIC_ITEM_REQUEST,
    payload
  };
};

export const uploadBackupSuccess = payload => {
  return {
    type: UPDATE_BACKUPS_ITEM_SUCCESS,
    payload
  };
};

export const uploadGraphicSuccess = payload => {
  return {
    type: UPDATE_GRAPHICS_ITEM_SUCCESS,
    payload
  };
};

export const uploadCopyFormData = payload => {
  return {
    type: UPLOAD_COPY_FORM_DATA,
    payload
  };
};
export const saveFormSuccess = () => ({ type: UPLOAD_COPY_FORM_DATA_SUCCESS });
export const updateUserLoginStatus = payload => ({
  type: USER_LAST_LOGIN,
  payload
});
// Update disclosureTags for saving into database

export const updatedisclosureTags = tags => ({
  type: UPDATE_DISCLOSURE_TAGS_SUCCESS,
  payload: tags
});

//create proof action
export const createProofRequest = payload => ({
  type: CREATE_PROOF_REQUEST,
  payload
});
export const createProofSuccess = payload => ({
  type: CREATE_PROOF_SUCCESS,
  payload
});
export const createProofFailure = () => ({
  type: CREATE_PROOF_FAILURE
});
export const updateProofAction = payload => ({
  type: PROOF_ACTION,
  payload
});
export const createProofPersonalUrlSuccess = payload => ({
  type: CREATE_PROOF_PERSONAL_URL_SUCCESS,
  payload
});

//Add and Remove the collaborators
export const addCollaborator = payload => ({
  type: ADD_COLLABORATOR_TO_WRITE,
  payload
});

export const removeCollaborator = payload => ({
  type: REMOVE_COLLABORATOR_FROM_WRITE,
  payload
});

export const addReviewer = payload => ({
  type: ADD_REVIEWER,
  payload
});

export const shareReviewer = payload => ({
  type: SHARE_REVIEWER,
  payload
});

export const shareProof = payload => ({
  type: SHARE_PROOF,
  payload
});

export const shareProofVersion = payload => ({
  type: SHARE_PROOF_VERSION,
  payload
});

export const fetchReviewer = payload => ({
  type: FETCH_REVIEWER,
  payload
});

export const fetchReviewerSuccess = payload => ({
  type: FETCH_REVIEWER_SUCCESS,
  payload
});

export const fetchReviewerFailed = payload => ({
  type: FETCH_REVIEWER_FAILED,
  payload
});
export const fetchPersonalUrl = payload => ({
  type: FETCH_PERSONAL_URL,
  payload
});

//twitter

export const receivePostSaveResponse = postDetails => ({
  type: SAVE_ASSIGNMENT_SUCCEEDED,
  payload: postDetails
});

export const clearWriteStore = () => ({
  type: CLEAR_WRITE_STORE
});
export const saveDisclosure = payload => ({
  type: SAVE_WRITE_FOR_DISCLOSURE,
  payload
});
export const updateDisclosureForWrite = payload => ({
  type: UPDATE_WRITE_FOR_DISCLOSURE,
  payload
});

export const startLegalReviewSuccess = payload => ({
  type: START_LEGAL_REVIEW_SUCCESS,
  payload
});

export const sendPdfToWorkfront = payload => ({
  type: SEND_PDF_TO_WORKFRONT,
  payload
});

