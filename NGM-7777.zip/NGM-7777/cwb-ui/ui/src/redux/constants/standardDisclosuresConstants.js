export const FETCH_STD_DISCLOSURES = "FETCH_STD_DISCLOSURES";

export const FETCH_STD_DISCLOSURES_SUCCEEDED =
  "FETCH_STD_DISCLOSURES_SUCCEEDED";

export const FETCH_STD_DISCLOSURES_FAILED = "FETCH_STD_DISCLOSURES_FAILED";

export const STANDARD_TAGS = JSON.stringify([
  {
    parent: "sc:audience",
    title: "Audience*",
    child: [{ text: "Adviser", tagName: "adviser", isPercolate: true }]
  },
  {
    parent: "sc:channel",
    title: "Channel*",
    child: [{ text: "Web", tagName: "web", isPercolate: true }]
  },
  {
    parent: "sc:product",
    title: "Product",
    child: [{ text: "No product", tagName: "noProduct", isPercolate: false }]
  },
  {
    parent: "sc:feeStructure",
    title: "Fee Structure",
    child: [
      {
        text: "No fee structure",
        tagName: "noFeeStructure",
        isPercolate: false
      }
    ]
  },
  { parent: "sc:statistic", title: "Statistic", child: [] },
  {
    parent: "sc:feeStructureCharacteristic",
    title: "Fee Structure Characteristic",
    child: []
  },
  {
    parent: "sc:materialCharacteristic",
    title: "Material Characteristic",
    child: []
  },
  {
    parent: "sc:productCharacteristic",
    title: "Product Characteristic",
    child: []
  },
  { parent: "sc:general", title: "General", child: [] }
]);

export const STAND_ALONE_TAGS = JSON.stringify([
  { parent: "sc:audience", title: "Audience*", child: [] },
  { parent: "sc:channel", title: "Channel*", child: [] },
  { parent: "sc:product", title: "Product", child: [] },
  { parent: "sc:feeStructure", title: "Fee Structure", child: [] },
  { parent: "sc:statistic", title: "Statistic", child: [] },
  {
    parent: "sc:feeStructureCharacteristic",
    title: "Fee Structure Characteristic",
    child: []
  },
  {
    parent: "sc:materialCharacteristic",
    title: "Material Characteristic",
    child: []
  },
  {
    parent: "sc:productCharacteristic",
    title: "Product Characteristic",
    child: []
  },
  { parent: "sc:general", title: "General", child: [] }
]);
