import {
  RELATED_PROJECTS_SUCCESS,
  RELATED_PROJECTS_ERROR,
  DELETE_PROJECT_SUCCESS
} from "../constants/commentConstant";

let initialState = {
  isFetching: true,
  relatedProject: []
};
const commentReducer = (state = initialState, action) => {
  switch (action.type) {
    case RELATED_PROJECTS_SUCCESS:
      return { ...state, relatedProject: action.payload, isFetching: false };
    case RELATED_PROJECTS_ERROR:
      return { ...state, isFetching: false };
    case DELETE_PROJECT_SUCCESS:
      const commentID = action.payload;
      const relatedProject = state.relatedProject.filter(
        project => project.commentId !== commentID
      );
      return { ...state, relatedProject };
    default:
      return state;
  }
};

export default commentReducer;
