import {
  SEARCH_SUCCESS,
  SEARCH_REQUEST,
  CLEAR_STATE,
  SEARCH_FAIL,
  AUTOCORRECT_SUCCESS,
  AUTOCOMPLETE_SUCCESS,
  CLEAR_AUTOCOMPLETE_STATE,
  AUTOCOMPLETE_REQUEST
} from "../constants/searchConstant";

let initialState = {
  error: null,
  result: [],
  loading: false,
  auto_correct: null
};

export const searchReducer = (state = initialState, action) => {
  switch (action.type) {
    case SEARCH_FAIL:
      return { ...state, loading: false };
    case CLEAR_STATE:
      return initialState;
    case SEARCH_REQUEST:
      return { ...state, error: null, loading: true };
    case SEARCH_SUCCESS:
      return {
        ...state,
        error: null,
        result: action.payload,
        loading: false,
        auto_complete: null
      };
    case AUTOCORRECT_SUCCESS:
      return { ...state, auto_correct: action.payload };
    case AUTOCOMPLETE_SUCCESS:
      return { ...state, auto_complete: action.payload };
    case CLEAR_AUTOCOMPLETE_STATE:
      return { ...state, auto_complete: null };
    case AUTOCOMPLETE_REQUEST:
      return { ...state, auto_complete: ["Loading....."] };
    default:
      return state;
  }
};
