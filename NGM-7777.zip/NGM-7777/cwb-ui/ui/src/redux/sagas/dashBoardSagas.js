import { put, takeLatest, call } from "redux-saga/effects";
import {
  FETCH_ALL_ASSIGNMENT,
  FEEDBACK_SUBMIT_REQUEST,
  FETCH_TEMPLATES
} from "../constants/dashBoardConstants";

import {
  receiveAllAssignments,
  fetchErrorAllAssignments,
  fetchTemplatesSuccess,
  fetchTemplatesError
} from "../actions/dashBoardActions";
import {
  getAllAssignmentForUser,
  getAllRegularAssignmentsAPI,
  weneedfeedbackApi,
  fetchTemplatesAPI
} from "../../api/dashBoardApi";

function* fetchAllAssignment(action) {
  try {
    const response = yield call(getAllAssignmentForUser, action.payload.email);
    const regularResponse = yield call(
      getAllRegularAssignmentsAPI,
      action.payload.username
    );
    let allAssignments = response.data ? response.data.assignments : [];

    if (
      allAssignments &&
      allAssignments.length &&
      regularResponse &&
      regularResponse.data &&
      regularResponse.data.length
    ) {
      allAssignments = allAssignments.map(assignment => {
        assignment.updatedAt = assignment.liveAt;
        for (let i = 0; i < regularResponse.data.length; i++) {
          if (
            regularResponse.data[i].percolateId === assignment.id &&
            regularResponse.data[i].updatedAt
          ) {
            assignment.updatedAt = regularResponse.data[i].updatedAt;
            break;
          }
        }
        return assignment;
      });
    }
    yield put(receiveAllAssignments({ assignments: allAssignments }));
  } catch (error) {
    yield put(fetchErrorAllAssignments(error));
  }
}

function* fetchTemplates() {
  try {
    const response = yield call(fetchTemplatesAPI);
    const filteredData = response.data.filter(
      template => ["Email", "Web Article"].indexOf(template.templateName) > -1
    );
    yield put(fetchTemplatesSuccess(filteredData));
  } catch (error) {
    yield put(fetchTemplatesError(error));
  }
}

function* submitUserFeedback({ payload }) {
  try {
    yield call(weneedfeedbackApi, payload);
    //yield put(showSuccessMsg("Thanks "));
  } catch (e) {
    //  yield put(showErrorMsg("API ERROR"));
  }
}

function* dashBoardSagas() {
  yield takeLatest(FETCH_ALL_ASSIGNMENT, fetchAllAssignment);
  yield takeLatest(FEEDBACK_SUBMIT_REQUEST, submitUserFeedback);
  yield takeLatest(FETCH_TEMPLATES, fetchTemplates);
}

export default dashBoardSagas;
