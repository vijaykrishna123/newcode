import { put, takeLatest, call } from "redux-saga/effects";
import {
  ADD_DRAFT_ASSIGNMENT,
  FETCH_ALL_DRAFTS,
  FETCH_DRAFT,
  LINK_DRAFT,
  DELETE_DRAFT_ASSIGNMENT
} from "../constants/draftsConstants";
import {
  createAssignmentDetails,
  getDraftDetailsApi
} from "../../api/assignmentApi";
import {
  getAllUnlikedAssignment,
  linkDraftToAssignmentApi,
  deleteDraftApi
} from "../../api/dashBoardApi";

import {
  receiveDraftAssignmentSuccess,
  receiveDraftAssignmentError,
  fetchAllDraftsSuccess,
  fetchAllDraftsError,
  fetchDraftError,
  fetchDraftSuccess,
  linkDraftToAssignmentError,
  linkDraftToAssignmentSuccess,
  showSuccessMsg,
  showErrorMsg,
  deleteDraftSuccess,
  deleteDraftFailed,
  setDraftCreating,
  setLinkingStatus
} from "../actions/draftsAction";

function* fetchAllUnlinkedAssignment(action) {
  try {
    const response = yield call(getAllUnlikedAssignment, action.payload);
    yield put(fetchAllDraftsSuccess(response.data));
  } catch (error) {
    yield put(fetchAllDraftsError(error));
  }
}

function* fetchDraft(action) {
  try {
    const response = yield call(getDraftDetailsApi, action.payload);
    yield put(fetchDraftSuccess({ ...response.data, isDraft: true }));
  } catch (error) {
    yield put(fetchDraftError(error));
  }
}

function* deleteDraft(action) {
  try {
    yield call(deleteDraftApi, action.payload);
    showSuccessMsg("Draft deleted Successfully");
    yield put(deleteDraftSuccess(action.payload));
  } catch (error) {
    showErrorMsg("Error occured in deleting draft");
    yield put(deleteDraftFailed(error));
  }
}

const delay = ms => new Promise(res => setTimeout(res, ms));

function* linkDraft(action) {
  try {
    yield put(setLinkingStatus({ status: "creating" }));
    const response = yield call(linkDraftToAssignmentApi, action.payload);
    yield put(linkDraftToAssignmentSuccess(response.data));
    yield delay(3000);
    yield put(setLinkingStatus({ status: "created" }));
    const response2 = yield call(
      getAllUnlikedAssignment,
      action.payload.userInitials
    );
    yield put(receiveDraftAssignmentSuccess(response2.data));
  } catch (error) {
    showErrorMsg("Error occured in draft linking");
    yield put(linkDraftToAssignmentError(error));
  }
}

function* createDraftAssignment(action) {
  try {
    yield put(setDraftCreating({ status: true }));
    yield call(createAssignmentDetails, action.payload);
    const response = yield call(
      getAllUnlikedAssignment,
      action.payload.userInitials
    );
    yield put(setDraftCreating({ status: false }));
    showSuccessMsg("Draft created successfully");
    yield put(receiveDraftAssignmentSuccess(response.data));
  } catch (error) {
    showErrorMsg("Error occured in draft creation");
    yield put(receiveDraftAssignmentError(error));
  }
}

function* draftsSaga() {
  yield takeLatest(FETCH_ALL_DRAFTS, fetchAllUnlinkedAssignment);
  yield takeLatest(ADD_DRAFT_ASSIGNMENT, createDraftAssignment);
  yield takeLatest(FETCH_DRAFT, fetchDraft);
  yield takeLatest(LINK_DRAFT, linkDraft);
  yield takeLatest(DELETE_DRAFT_ASSIGNMENT, deleteDraft);
}

export default draftsSaga;
