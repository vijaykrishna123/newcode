import { all, fork } from "redux-saga/effects";
import * as assignmentSagas from "./assignmentSagas";
import * as userSagas from "./userSagas";
import * as writeSagas from "./writeSagas";
import * as commentSagas from "./commentSaga";
import * as dashBoardSagas from "./dashBoardSagas";
import * as searchsaga from "./searchSaga";
import * as draftsSaga from "./draftsSaga";
import * as standardDisclosuresSagas from "./standardDisclosuresSagas";
// notice how we now only export the rootSaga
// single entry point to start all Sagas at once
export default function* rootSaga() {
  yield all(
    [
      ...Object.values(assignmentSagas),
      ...Object.values(userSagas),
      ...Object.values(commentSagas),
      ...Object.values(writeSagas),
      ...Object.values(dashBoardSagas),
      ...Object.values(searchsaga),
      ...Object.values(draftsSaga),
      ...Object.values(standardDisclosuresSagas)
    ].map(fork)
  );
}
