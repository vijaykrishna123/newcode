import { put, takeLatest, call } from "redux-saga/effects";

import { FETCH_INITIAL_USERS } from "../constants/userConstants";
import { fetchInitialUsersSuccess } from "../actions/userActions";
import { fetchInitialUsersAPI } from "../../api/userApi";

function* fetchInitialUsers({ payload }) {
  try {
    const response = yield call(fetchInitialUsersAPI, payload);
    yield put(fetchInitialUsersSuccess(response.data));
  } catch (e) {
    console.error("update error", e);
  }
}

function* userSagas() {
  yield takeLatest(FETCH_INITIAL_USERS, fetchInitialUsers);
}

export default userSagas;
