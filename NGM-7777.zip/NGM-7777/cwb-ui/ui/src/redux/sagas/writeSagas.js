// import saga helper function
import { put, takeLatest, call, select, takeEvery } from "redux-saga/effects";

// import action constant
import {
  FETCH_ALL_FIELDS_REQUEST,
  DELETE_BACKUPS_ITEM_REQUEST,
  DELETE_GRAPHIC_ITEM_REQUEST,
  UPLOAD_COPY_FORM_DATA,
  USER_LAST_LOGIN,
  CREATE_PROOF_REQUEST,
  SAVE_WRITE_FOR_DISCLOSURE,
  FETCH_PERSONAL_URL,
  ADD_REVIEWER,
  SHARE_REVIEWER,
  SHARE_PROOF,
  SHARE_PROOF_VERSION,
  FETCH_REVIEWER,
  ADD_COLLABORATOR_TO_WRITE,
  SEND_PDF_TO_WORKFRONT
} from "../constants/writeConstants";

// import action
import {
  fetchAllFieldsSuccess,
  fetchAllFieldsFailure,
  deleteBackupsItemSuccess,
  deleteGraphicItemSuccess,
  showErrorMsg,
  showSuccessMsg,
  saveFormSuccess,
  createProofSuccess,
  addCollaborator,
  addCollaboratorToWriteSuccess,
  addCollaboratorToWriteFailure,
  updateDisclosureForWrite,
  createProofPersonalUrlSuccess,
  fetchReviewerSuccess,
  startLegalReviewSuccess
} from "../actions/writeAction";

// import api
import {
  getWrite,
  deleteBackups,
  deleteGraphicAPI,
  saveWriteFormAPI,
  updateUserLastLogin,
  createProofApi,
  createProofVersionApi,
  createPersistproofAPI,
  fetchPersonalURLForProof,
  addReviewerApi,
  shareReviewerApi,
  callShareProofAPI,
  callShareProofVersionAPI,
  fetchReviewerApi,
  fetchAssignmentCollaboratorsApi,
  startLegalReviewAPI,
  sendPdfToWorkfrontAPI
} from "../../api/writeApi";

function* fetchWrite(action) {
  try {
    const response = yield call(getWrite, action.payload);
    yield put(fetchAllFieldsSuccess(response.data));
  } catch (error) {
    yield put(fetchAllFieldsFailure(error));
  }
}

function* deletebackup({ payload }) {
  try {
    if (payload.backupId) yield call(deleteBackups, payload);
    yield put(deleteBackupsItemSuccess(payload));
    yield put(showSuccessMsg("Deleted Successfully"));
  } catch (error) {
    yield put(showErrorMsg("Error for deleting backup"));
  }
}

function* deleteGraphic({ payload }) {
  try {
    if (payload.graphicId) yield call(deleteGraphicAPI, payload);
    yield put(deleteGraphicItemSuccess(payload));
    yield put(showSuccessMsg("Deleted Successfully"));
  } catch (error) {
    yield put(showErrorMsg("Error for deleting responsive image"));
  }
}

function* uploadCopyFormData({ payload }) {
  try {
    yield call(saveWriteFormAPI, payload.formData);
    yield put(showSuccessMsg("Saved Successfully"));
    yield put(saveFormSuccess());
  } catch (error) {
    console.error(error);
    yield put(showErrorMsg("Failed to Save the Content"));
  }
}
function* updateUserLoginStatus({ payload }) {
  try {
    yield call(updateUserLastLogin, payload);
  } catch (e) {
    console.error("update error", e);
  }
}

function* createProof({ payload }) {
  try {
    if (payload.showMessage) {
      payload.showMessage("Proof is being generated", "success");
    } else {
      yield put(showSuccessMsg("Proof is being generated"));
    }
    let res;
    const state = yield select();
    let proofList = state.write.proofUrl;

    let recipients = [];
    if (payload.recipients && payload.recipients.length) {
      recipients = payload.recipients
        .filter(recipient => recipient)
        .map(recipient => recipient.emailId)
        .join();
    }

    if (proofList.length < 1) {
      res = yield call(createProofApi, {
        assignmentId: payload.assignmentId,
        recipients: recipients,
        emailText: payload.emailText
      });
    } else {
      let parentFileID = proofList[proofList.length - 1].fileId;
      res = yield call(createProofVersionApi, {
        assignmentId: payload.assignmentId,
        recipients: recipients,
        parentFileID,
        emailText: payload.emailText
      });
    }

    let proofUrl =
      proofList.length > 0 ? proofList.map(proof => proof.proofUrl) : [];
    let fileId = res.data.fileId;
    proofUrl.push(res.data.proofUrl);
    proofUrl = proofUrl.join("|");

    yield call(createPersistproofAPI, {
      proofUrl,
      fileId,
      id: payload.assignmentId
    });

    if (fileId !== null) {
      const personalURlResponse = yield call(fetchPersonalURLForProof, {
        fileID: fileId,
        emailID: payload.emailID
      });
      yield put(createProofPersonalUrlSuccess(personalURlResponse.data));
    }

    // Call Api to send Email
    if (res && (res.status === 200 || res.status === 201)) {
      let commentValue = "";
      payload.recipients.forEach(col => {
        if (col && col.userInitials) {
          commentValue += "@" + col.userInitials.trim() + ",";
        }
      });
      if (commentValue) {
        const obj = {
          commentValue: commentValue.slice(0, commentValue.length - 1),
          commentStatus: "",
          percolateId: payload.assignmentId,
          replyToId: 0,
          userInitials: payload.user.userId,
          optionalText: payload.emailText,
          assignmentName: payload.assignmentName
        };
        try {
          if (!payload.proofURL) {
            yield call(callShareProofAPI, obj);
          } else {
            yield call(callShareProofVersionAPI, obj);
          }
        } catch (error) {
          yield put(
            showErrorMsg("Error occurred in sending proof to Reviewer")
          );
        }
      }
    }
    yield put(createProofSuccess(res.data));
  } catch (e) {
    console.error(e);
    if (payload.showMessage) {
      payload.showMessage("Error To Send proof", "error");
    } else {
      yield put(showErrorMsg("Error To Send proof"));
    }
  }
}

function* callAddReviewer({ payload }) {
  if (payload.fileId) {
    try {
      const res = yield call(addReviewerApi, {
        emailId: payload.emailId,
        fileId: payload.fileId
      });
      if (res && res.status === 200) {
        const obj = {
          commentValue: "@" + payload.initial.trim(),
          commentStatus: "",
          percolateId: payload.assignment.id,
          replyToId: 0,
          userInitials: payload.user.userId,
          optionalText: "",
          assignmentName: payload.assignment.name
        };
        try {
          yield call(shareReviewerApi, obj);
        } catch (error) {
          yield put(
            showErrorMsg("Error occurred while sending email to Reviewer")
          );
        }
      }
      yield put(
        addCollaborator({
          userInitials: payload.initial,
          emailId: payload.emailId
        })
      );
    } catch (error) {
      yield put(showErrorMsg("Error occurred in adding Reviewer"));
    }
  }
}

function* callShareReviewer({ payload }) {
  try {
    yield call(shareReviewerApi, payload);
  } catch (error) {
    yield put(showErrorMsg("Error occurred while sending email to Reviewer"));
  }
}
function* callShareProof({ payload }) {
  try {
    yield call(callShareProofAPI, payload);
  } catch (error) {
    yield put(showErrorMsg("Error occurred in sending proof to Reviewer"));
  }
}
function* callShareProofVersion({ payload }) {
  try {
    yield call(callShareProofVersionAPI, payload);
  } catch (error) {
    yield put(
      showErrorMsg("Error occurred in sending proof-version to Reviewer")
    );
  }
}

function* callFetchReviewer({ payload }) {
  if (payload.fileId) {
    try {
      const response = yield call(fetchReviewerApi, payload);
      yield put(fetchReviewerSuccess(response.data));
    } catch (error) {
      yield put(showErrorMsg("Error occured in fetching Reviewer"));
    }
  }
}
function* fetchProofPersonalUrl({ payload }) {
  if (payload.fileID !== null) {
    try {
      const personalURlResponse = yield call(fetchPersonalURLForProof, {
        fileID: payload.fileID,
        emailID: payload.emailID
      });
      yield put(createProofPersonalUrlSuccess(personalURlResponse.data));
    } catch (error) {
      yield put(showErrorMsg("Error in fetching url"));
    }
  }
}

function* fetchAssignmentCollaborators(action) {
  try {
    const response = yield call(
      fetchAssignmentCollaboratorsApi,
      action.payload
    );
    yield put(addCollaboratorToWriteSuccess(response.data));
  } catch (error) {
    yield put(addCollaboratorToWriteFailure(error));
  }
}

function* updateCopyForDisclosure({ payload: { Results, id, write } }) {
  try {
    let div = document.createElement("div");
    div.innerHTML = write.copy.fields[0].fieldValue;
    const type = write.assignment.templateName;
    const body = div.querySelector("#Legal").firstElementChild;
    let data =
      type === "Email"
        ? `<tr><td><a href='Legal'><strong>Legal Disclosure</strong></a><br>`
        : `<tr><td><a href='Legal Disclosure'><strong>Legal Disclosure</strong></a>
    <p><a href='#Content Specific Disclosure'><strong>Content Specific Disclosure:</strong></a></p>
    <p><a href='#Standard Disclosure'><strong>Standard Disclosure:</strong></a></p><br`;
    Results.forEach(res => {
      data += `<p>${res.language}</p>`;
    });
    data += "</td></tr>";
    body.innerHTML = data;
    yield put(updateDisclosureForWrite(div.innerHTML));
    const obj = {
      write: { write },
      user: { assignment: { id } }
    };
    yield call(saveWriteFormAPI, obj);
  } catch (error) {
    //console.error(error);
    if (!Results) {
      yield put(showErrorMsg("Unable to load the disclosure language"));
    }
  }
}

function* callSendPdfToWorkfrontApi({ payload }) {
  const { showMessage, ...rest } = payload;
  try {
    let workfrontDocId = payload.documentId;
    const response = yield call(startLegalReviewAPI, rest);
    if (!payload.documentId) {
      yield put(startLegalReviewSuccess(response.data));
      //response.data.ID is the workfrontDocId that we get in First API call
      workfrontDocId = response.data.ID;
      yield call(sendPdfToWorkfrontAPI, {
        id: payload.id, // payload.id is the percolate id of the assignment
        workfrontDocId
      });
    }
    showMessage("Uploaded successfully to Workfront", "success");
    window.open(response.data.workfrontUrl, "_blank");
  } catch (error) {
    showMessage("Error in uploading to Workfront", "error");
  }
}

function* writeSagas() {
  yield takeLatest(FETCH_ALL_FIELDS_REQUEST, fetchWrite);
  yield takeLatest(DELETE_BACKUPS_ITEM_REQUEST, deletebackup);
  yield takeLatest(DELETE_GRAPHIC_ITEM_REQUEST, deleteGraphic);
  yield takeLatest(UPLOAD_COPY_FORM_DATA, uploadCopyFormData);
  yield takeLatest(USER_LAST_LOGIN, updateUserLoginStatus);
  yield takeLatest(CREATE_PROOF_REQUEST, createProof);
  yield takeLatest(FETCH_PERSONAL_URL, fetchProofPersonalUrl);
  yield takeLatest(ADD_REVIEWER, callAddReviewer);
  yield takeLatest(SHARE_REVIEWER, callShareReviewer);
  yield takeLatest(SHARE_PROOF, callShareProof);
  yield takeLatest(SHARE_PROOF_VERSION, callShareProofVersion);
  yield takeLatest(FETCH_REVIEWER, callFetchReviewer);
  yield takeLatest(SAVE_WRITE_FOR_DISCLOSURE, updateCopyForDisclosure);
  yield takeLatest(SEND_PDF_TO_WORKFRONT, callSendPdfToWorkfrontApi);
  yield takeEvery(ADD_COLLABORATOR_TO_WRITE, fetchAssignmentCollaborators);
}

export default writeSagas;
