import _ from "lodash";
import configDeterminator from "../configs/configDeterminator";
import { APPLICATION_JSON } from "./cwbconstants";
import { STANDARD_TAGS } from "../redux/constants/standardDisclosuresConstants";

const { OcpApimSubscriptionKey } = configDeterminator;

export default function getHeader() {
  const { accessToken } = JSON.parse(
    localStorage.getItem("okta-token-storage")
  );

  const header = {
    "Content-Type": APPLICATION_JSON,
    "Ocp-Apim-Subscription-Key": OcpApimSubscriptionKey,
    client: "daa",
    Authorization: `${accessToken.tokenType} ${accessToken.accessToken}`
  };

  return header;
}

export const applyTags = (tags, assignment) => {
  if (assignment && assignment.taxonomy) {
    const percolateTagArr = assignment.taxonomy;
    tags.forEach(a => {
      Object.keys(assignment.taxonomy).forEach(items => {
        if (items.includes(a.parent.replace("sc:", ""))) {
          percolateTagArr[items].forEach((tag, index) => {
            let arrayIndex = a.child.findIndex(
              i => i.tagName.toUpperCase() === tag.toUpperCase()
            );
            if (arrayIndex === -1) {
              let tempArr = { text: tag, isPercolate: true, tagName: tag };
              a.child = a.child.concat(tempArr);
            }
          });
        }
      });
    });
  }

  const standardTags = JSON.parse(STANDARD_TAGS);
  tags.forEach(arrTag => {
    if (arrTag.child && arrTag.child.length) {
      return;
    }
    standardTags.forEach(tag => {
      if (arrTag.parent === tag.parent) {
        arrTag.child = _.cloneDeep(tag.child);
      }
    });
  });

  let param = "";
  Object.keys(tags).forEach((item, index) => {
    if (index === 0) {
      param = tags[item].parent.replace("sc:", "") + "=";
    } else {
      param = param + "&" + tags[item].parent.replace("sc:", "") + "=";
    }
    tags[item].child.forEach((items, index) => {
      if (index === 0) {
        param = param + items.tagName;
      } else {
        param = param + "," + items.tagName;
      }
    });
  });
  return param;
};
