const path = require("path");
const { version } = require("./package");

module.exports = {
  components: "src/components/**/[A-Z]*.{js,jsx}",
  defaultExample: true,
  moduleAliases: {
    "rsg-example": path.resolve(__dirname, "src")
  },
  ribbon: {
    url: "https://github.com/styleguidist/react-styleguidist"
  },
  version,
  webpackConfig: require("./config/webpack.config.js")
};
