import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { Alert, AlertType } from '../../_models/alert';
import { AlertService } from '../../_services/alert.service';

@Component({
  moduleId: module.id,
  selector: 'alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})

export class AlertComponent implements OnInit {
  // alerts: Alert[] = [];
  alertObj: Alert = null;
  
  constructor(private alertService: AlertService) { }

  ngOnInit() {
    this.alertService.getAlert().subscribe((alert: Alert) => {
      if (!alert) {
        // clear alerts when an empty alert is received
        // this.alerts = [];
        this.alertObj = null;
        return;
      }

      // add alert to array
      // this.alerts.push(alert);
      this.alertObj = alert;
        
      // remove alert after 5 seconds
      if(alert.time !== -1)
        setTimeout(() => this.removeAlert(alert), alert.time);
    });
  }

  removeAlert(alert: Alert) {
    // this.alerts = this.alerts.filter(x => x !== alert);
    this.alertObj = null;
  }

  cssClass(alert: Alert) {
    if(!alert) {
      return;
    }

    // return css class based on alert type
    switch(alert.type) {
      case AlertType.Success:
        return 'alert alert-success align-center';
      case AlertType.Error:
        return 'alert alert-danger align-center';
      case AlertType.Info:
        return 'alert alert-info align-center';
      case AlertType.Warning:
        return 'alert alert-warning align-center';
    }
  }

}
