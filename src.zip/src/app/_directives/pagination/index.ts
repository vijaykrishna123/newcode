export { PaginationModule } from './pagination.module';
export { PaginationComponent } from './pagination.component';