import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ResultService } from '../../_services/result.service';
import { FilterService } from '../../_services/filter.service';
import { HttpService } from '../../_services/http.service';

@Component({
  selector: 'daa-pagination',
  templateUrl: './pagination.component.html'
})
export class PaginationComponent {

  results: any;
  page: number; // the current page
  count: number; // how many total items there are in all pages
  perPage: number; // how many items we want to show per page
  pagesToShow = 3; // how many pages between next/prev

  resultSubscription: Subscription;

  constructor( 
    private _resultService: ResultService, 
    private _filterService: FilterService,
    private httpService: HttpService ) { 
      
  }

   ngOnInit() {

      this.resultSubscription = this._resultService.onChangeResults().subscribe(res => {
        if (res) {
           this.results = res;
           this.count = this.results.record_count;
           this.perPage = this.results.page_size;
           this.page = this.results.offset;
        }
      });
   }

   save() {

      this._filterService.saveFilters({
        offset: this.results.offset,
        apply_filter: false
      });

    this.httpService.getDocuments().subscribe(
      results => {
      }, error => {
      });
   }
  

  onPage(n: number): void {
    this.page = n;
    this.results.offset = n;
    this.save();
  }

  onNext(): void {
    this.results.offset = this.page + 1;
    this.save();
  }

  onPrev(): void {
    this.results.offset = this.page - 1;
    this.save();
  }

  getMin(): number {
    return ((this.perPage * this.page) - this.perPage) + 1;
  }

  getMax(): number {
    let max = this.perPage * this.page;
    if(max > this.count) {
      max = this.count;
    }
    return max;
  }

  totalPages(): number {
    return Math.ceil(this.count / this.perPage) || 0;
  }

  lastPage(): boolean {
    // return this.perPage * this.page === this.count;
    return this.page === this.totalPages();
  }

  getPages(): number[] {
    const c = Math.ceil(this.count / this.perPage);
    const p = this.page || 1;
    const pagesToShow = this.pagesToShow || 9;
    const times = pagesToShow - 1;
    const pages: number[] = [];

    pages.push(p);
    for(let i = 0; i < times; i++) {
      if(pages.length < pagesToShow) {
        if(Math.min.apply(null, pages) > 1) {
          pages.push(Math.min.apply(null, pages) - 1);
        }
      }
      if(pages.length < pagesToShow) {
        if(Math.max.apply(null, pages) < c) {
          pages.push(Math.max.apply(null, pages) + 1);
        }
      }
    }
    pages.sort((a, b) => a - b);
    return pages;
  }

   ngOnDestroy() {
    this.resultSubscription.unsubscribe();
  }

}
