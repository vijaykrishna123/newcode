export { SidePanelModule } from './side-panel.module';
export { SidePanelComponent } from './side-panel.component';