import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

import { Content } from '../../_models/content';

@Component({
  selector: 'app-side-panel',
  templateUrl: './side-panel.component.html',
  styleUrls: ['./side-panel.component.scss']
})
export class SidePanelComponent implements OnInit {
  @Input() content: Content;
  @Output() onClosed = new EventEmitter<boolean>();

  constructor(private sanitizer: DomSanitizer) { }

  inlineHeight = 0;

  ngOnInit() {
    console.log(this.content);   
  }
  
  print () {
    var win = window.open();
    win.document.open();
    win.document.write(this.content.text);
    win.document.close();
    win.print();
    win.close();
  }

  innerHtml() {
    if(this.content.user_selection === 'text') {
      return '<div id="textSummary">' + this.content.text + '</div>';
    } else {
      return this.sanitizer.bypassSecurityTrustHtml(
        '<object data="' + this.content.url + 
        '" type="' + this.content.mime_type + 
        '" width="100%"' +
        '" height="100%"' +
        '" class="embed-responsive-item"' +
        '>' + 
        '<embed src="' + this.content.url + 
        '" type="' + this.content.mime_type + 
        '" />' + 
        '</object>'
      );
    }
  }

  closePanel() {
    this.onClosed.emit(false);
  }
    
}
