import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { SidePanelComponent } from './side-panel.component';
import { ClipboardModule } from 'ngx-clipboard';


@NgModule ({
  imports: [
    CommonModule,
    FormsModule,
    ClipboardModule
  ],
  declarations: [SidePanelComponent],
  exports: [SidePanelComponent]
})

export class SidePanelModule {
}