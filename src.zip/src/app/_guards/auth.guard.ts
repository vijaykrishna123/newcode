import { Injectable } from "@angular/core";
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router
} from "@angular/router";
import { OktaAuthService } from "@okta/okta-angular";
import { SecurityService } from "./../_services/security.service";

@Injectable()
export class AuthGuard implements CanActivate {
  isAuthenticated: any;
  constructor(
    private oktaAuth: OktaAuthService,
    private securityService: SecurityService
  ) {}

  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    this.oktaAuth
      .isAuthenticated()
      .then(isAuthenticated => {
        !isAuthenticated && this.securityService.setCallBack(false);
        return this.securityService.setAuthorizationData(isAuthenticated);
      })
      .catch(error => console.log(error));

    if (
      JSON.parse(this.securityService.authorized()) ||
      JSON.parse(this.securityService.getCallBack())
    ) {
      return true;
    } else {
      this.securityService.setCallBack(true);
      const path = state.url.split(/[?#]/)[0];
      this.oktaAuth.setFromUri(path, route.queryParams);
      this.oktaAuth.loginRedirect();
    }
  }
}
