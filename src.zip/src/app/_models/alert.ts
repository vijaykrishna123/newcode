export class Alert {
  type: AlertType;
  message: string;
  time: number;
}

export enum AlertType {
  Success,
  Error,
  Info,
  Warning
}