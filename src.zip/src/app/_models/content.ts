export class Content {
  url: string;
  mime_type: string;
  user_selection: string;
  text: string;
}