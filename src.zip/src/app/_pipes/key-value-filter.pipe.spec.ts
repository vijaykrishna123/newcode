import { KeyValueFilterPipe } from './key-value-filter.pipe';

describe('KeyValueFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new KeyValueFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
