import { ResponseTimePipe } from './response-time.pipe';

describe('ResponseTimePipe', () => {
  it('create an instance', () => {
    const pipe = new ResponseTimePipe();
    expect(pipe).toBeTruthy();
  });
});
