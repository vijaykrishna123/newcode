import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'responseTimeFilter'
})
export class ResponseTimePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    return (value / 1000).toFixed(2);
  }

}
