import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../environments/environment";
declare var Capgroup: any;
declare var _satellite: any;
declare var jQuery: any;
declare var Analytics: any;

@Injectable()
export class AnalyticsService {
  /**
	 * Function for recording the page load events
	 */
  rootProxypath = "/content/sites/the-capital-group/daa/us/en/home";
  loadPageData(pageName, analyticsFileName) {
    if (
      environment.envName !== "alpha" &&
      environment.includeAnalytics &&
      typeof Capgroup != "undefined"
    ) {
      var ddPageStore = Capgroup.ContextHub.stores.page,
        ddUserStore = Capgroup.ContextHub.stores.user;

      ddPageStore.setItem("info/name", "DAA &gt;" + pageName);
      ddPageStore.pushItem(
        "info/breadCrumbList",
        ("DAA," + pageName).split(",")
      );
      ddPageStore.setItem("info/destinationURL", null);
      ddPageStore.setItem("category/brand", "Capital Group");
      ddPageStore.setItem("category/audience", "DAA");
      ddPageStore.setItem("category/country", "us");
      ddPageStore.setItem("category/channel", "Capital Group - DAA");
      ddPageStore.setItem("category/language", "en");
      ddPageStore.setItem("category/region", "");
      if (localStorage.getItem("userInitials") != null)
        ddUserStore.setItem(
          "primaryProfile/info/cgUserInitials",
          localStorage.getItem("userInitials")
        );
      Capgroup.ContextHub.clientSideDefaultDataService.setContextHubData();

      let jsonFileName =
        "../../assets/dtm/json/" + analyticsFileName + ".analytics-json.js";
      Capgroup.ContextHub.ContextHubDataSet.nextGenSendingData = false;
      Capgroup.ContextHub.ContextHubDataSet.legacySendingData = false;
      Analytics.singlePageApp.recordStateByURI(jsonFileName);
    }
  }

  /**
	 * Function for recording the search term analytics
	 */
  recordSearchTermAnalytics(query, results) {
    if (
      environment.envName !== "alpha" &&
      environment.includeAnalytics &&
      typeof Capgroup != "undefined"
    ) {
      console.log(
        "*********************recordSearchTermAnalytics**************************"
      );
      var ddComponentStore = Capgroup.ContextHub.stores.component,
        ddComponentListItem = ddComponentStore.models.newComponentListItem(),
        ddEventStore = Capgroup.ContextHub.stores.event,
        ddEventListItem = ddEventStore.models.newEventListItem();

      ddComponentListItem.info.name = "Search";
      ddComponentListItem.attribute.onSiteSearchFilter = "";
      ddComponentListItem.attribute.onSiteSearchTerm = query;
      ddComponentListItem.attribute.onSiteSearchResult = results;

      ddComponentStore.pushItem("componentList", ddComponentListItem);
      console.log("ddComponentListItem" + ddComponentListItem);
      ddEventListItem.info.action =
        Capgroup.ContextHub.stores.event.Constants.EVENT_ACTIONS.RESULTS;
      ddEventListItem.info.label = ddComponentListItem.info.name;
      ddEventListItem.info.name =
        Capgroup.ContextHub.stores.event.Constants.EVENT_NAMES.ON_SITE_SEARCH;
      ddEventListItem.info.type =
        Capgroup.ContextHub.stores.event.Constants.EVENT_TYPES.SEARCH;
      ddEventListItem.info.value = results;

      ddEventStore.pushItem("eventList", ddEventListItem);
      Capgroup.ContextHub.ContextHubDataSet.nextGenSendingData = false;
      Capgroup.ContextHub.ContextHubDataSet.legacySendingData = false;

      Analytics.singlePageApp.recordStateByURI(
        "../../assets/dtm/json/search-result.analytics-json.js",
        {
          componentStore: {
            componentList: [ddComponentListItem]
          },
          eventStore: {
            eventList: [ddEventListItem]
          }
        }
      );
      Capgroup.ContextHub.stores.component.reset();
      Capgroup.ContextHub.stores.event.reset();
    }
  }

  /**
	 * Function for recording the facet analytics
	 */
  recordSearchFacetAnalytics(query, record_count, args) {
    if (
      environment.envName !== "alpha" &&
      environment.includeAnalytics &&
      typeof Capgroup != "undefined"
    ) {
      var ddComponentStore = Capgroup.ContextHub.stores.component,
        ddComponentListItem = ddComponentStore.models.newComponentListItem(),
        ddEventStore = Capgroup.ContextHub.stores.event,
        ddEventListItem = ddEventStore.models.newEventListItem();

      ddComponentListItem.info.name = query;
      ddComponentListItem.attribute.onSiteSearchFilter = args;
      ddComponentListItem.attribute.onSiteSearchTerm = query;
      console.log("Results" + record_count);
      ddComponentListItem.attribute.onSiteSearchResult = record_count;

      ddComponentStore.pushItem("componentList", ddComponentListItem);

      ddEventListItem.info.action =
        Capgroup.ContextHub.stores.event.Constants.EVENT_ACTIONS.RESULTS;
      ddEventListItem.info.label = ddComponentListItem.info.name;
      ddEventListItem.info.name = "onSiteSearchFacet";
      ddEventListItem.info.type =
        Capgroup.ContextHub.stores.event.Constants.EVENT_TYPES.SEARCH;
      ddEventListItem.info.value = record_count;

      ddEventStore.pushItem("eventList", ddEventListItem);
      Capgroup.ContextHub.ContextHubDataSet.nextGenSendingData = false;
      Capgroup.ContextHub.ContextHubDataSet.legacySendingData = false;

      Analytics.singlePageApp.recordStateByURI(
        "../../assets/dtm/json/search-result.analytics-json.js",
        {
          componentStore: {
            componentList: [ddComponentListItem]
          },
          eventStore: {
            eventList: [ddEventListItem]
          }
        }
      );
      Capgroup.ContextHub.stores.component.reset();
      Capgroup.ContextHub.stores.event.reset();
    }
  }

  /**
	 * Function for recording the snippet click
	 */
  recordSnippetClick(title: string) {
    if (
      environment.envName !== "alpha" &&
      environment.includeAnalytics &&
      typeof Capgroup != "undefined"
    ) {
      console.log("Article Clicked");
      var ddEventStore = Capgroup.ContextHub.stores.event,
        ddEventListItem = ddEventStore.models.newEventListItem();

      ddEventListItem.info.action = "clickThrough";
      ddEventListItem.info.label = title;
      ddEventListItem.info.name = "contentSet";
      ddEventListItem.info.type = "content";

      ddEventStore.pushItem("eventList", ddEventListItem);
      Capgroup.ContextHub.ContextHubDataSet.nextGenSendingData = false;
      Capgroup.ContextHub.ContextHubDataSet.legacySendingData = false;

      Analytics.singlePageApp.recordStateByURI(
        "../../assets/dtm/json/search-result.analytics-json.js",
        {
          eventStore: {
            eventList: [ddEventListItem]
          }
        }
      );

      Capgroup.ContextHub.stores.event.reset();
    }
  }

  recordState(jsPath, analyticsConfig) {
    if (
      environment.envName !== "alpha" &&
      environment.includeAnalytics &&
      typeof Capgroup != "undefined"
    ) {
      Analytics.singlePageApp.recordStateByURI(
        jsPath,
        analyticsConfig.override
      );
    }
  }
}
