import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';

import 'rxjs/add/operator/map';

import { HeaderService } from './header.service';
import { UserManager, UserManagerSettings, User } from 'oidc-client';
import { Router, ActivatedRoute } from '@angular/router';
import { SecurityService } from './security.service';
import { AppConfig } from '../app.config';


@Injectable()
export class AuthService {
private user: User = null;
userManager;
returnUrl: string = '/search';
configData:any;

    constructor(private config:AppConfig,private http: Http, private headerService: HeaderService, private router: Router,private securityService:SecurityService) {

    }

    	onUserInit(environmentConfigData:any) {
	        this.userManager = new UserManager(getClientSettings(environmentConfigData));
	            this.userManager.getUser().then(user => {
	            this.user = user;
	    	});
   
            this.userManager.events.addAccessTokenExpiring(function () {
                console.log("token expiring");
            });

            this.userManager.events.addAccessTokenExpired(function () {
                console.log("token expired");
            });

            this.userManager.events.addSilentRenewError(function (e) {
                console.log("silent renew error", e.message);
            });

            this.userManager.events.addUserLoaded((user) => {
                console.log("user loaded", user);
                this.securityService.setAuthorizationData(user.access_token);
                this.userManager.getUser().then(function () {
                    console.log("getUser loaded user after userLoaded event fired");
                });
            });

            this.userManager.events.addUserUnloaded(function (e) {
                console.log("user unloaded");
            });
        }

    isLoggedIn(): boolean {
        return this.user != null && !this.user.expired;// || this.securityService.authorized() != null;
    }

    getClaims(): any {
        return this.user.profile;
    }

    getAuthorizationHeaderValue(): string {
        return `${this.user.token_type} ${this.user.access_token}`;
    }

    startAuthentication(): Promise<void> {
        return this.userManager.signinRedirect();
    }

    completeAuthentication():Promise<void> {
        return this.userManager.signinRedirectCallback().then(user => {

        this.user = user;
        this.securityService.setUserName(this.user.profile.preferred_username);
        this.securityService.setSessionIdForUser(this.user.profile.preferred_username);
        this.router.navigate([this.returnUrl]);
        }, error => {
            
            this.router.navigate(['/not-auth']);
        });
    }

    logout() {
        // remove user from local storage to log user out
        this.configData = (!this.config.getConfigData())? JSON.parse(localStorage.getItem("configData")) : this.config.getConfigData();
        if(!this.userManager) {
            this.onUserInit(this.configData);
            this.userManager.removeUser();
        } else {
            this.userManager.removeUser();
        }  
        localStorage.removeItem('userInitials');
        this.securityService.resetAuthorizationData();
        this.headerService.saveStore(null);
        this.user=null;
    }

}

export function getClientSettings(environment): UserManagerSettings {
    return {
        authority: environment.authority,
        client_id: environment.client_id,
        redirect_uri: environment.redirect_uri,
        post_logout_redirect_uri:environment.post_logout_redirect_uri,
        response_type:environment.response_type,
        scope:environment.scope,
        filterProtocolClaims:environment.filterProtocolClaims,
        loadUserInfo:environment.loadUserInfo,
        automaticSilentRenew:environment.automaticSilentRenew,
    };
}