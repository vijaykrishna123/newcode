import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import * as moment from 'moment';

@Injectable()
export class FilterService {
  allowedKeys = [
    'query',
    'offset',
    'source',
    'file_type',
    'time_filter_value',
    'sort_order',
    'publication_from_date',
    'publication_to_date',
    'query_id',
    'apply_filter',
    'keyword_flag'
  ];
  storageName = 'daa_filters';
  private subject = new BehaviorSubject<any>(false);

  constructor() {}

  public resetFilters() {
    let defaultValues = {
      query: '',
      offset: 0,
      source: [],
      file_type: [],
      time_filter_value: 36,
      publication_from_date: moment()
        .subtract(36, 'months')
        .format('YYYY-MM-DD'),
      publication_to_date: moment().format('YYYY-MM-DD'),
      sort_order: 'relevance',
      query_id: 0,
      apply_filter: false,
      keyword_flag: true
    };

    if (localStorage.getItem(this.storageName)) {
      let f = this.getFilters();
      defaultValues.query = f.query;
    }

    localStorage.setItem(this.storageName, JSON.stringify(defaultValues));
    this.subject.next(this.getFilters());
  }

  public resetFilterJSON() {
    const defaultValues = {
      query: '',
      offset: 0,
      source: [],
      file_type: [],
      time_filter_value: 36,
      publication_from_date: moment()
        .subtract(36, 'months')
        .format('YYYY-MM-DD'),
      publication_to_date: moment().format('YYYY-MM-DD'),
      sort_order: 'relevance',
      query_id: 0,
      apply_filter: false,
      keyword_flag: true
    };
    localStorage.setItem(this.storageName, JSON.stringify(defaultValues));
  }

  public getFilters() {
    // console.log(
    //   "get filter",
    //   JSON.parse(localStorage.getItem(this.storageName))
    // );
    return JSON.parse(localStorage.getItem(this.storageName));
  }

  public saveFilters(params) {
    const filtered = Object.keys(params)
      .filter(key => this.allowedKeys.includes(key))
      .reduce((obj, key) => {
        obj[key] = params[key];
        return obj;
      }, {});

    const merged = Object.assign({}, this.getFilters(), filtered);

    localStorage.setItem(this.storageName, JSON.stringify(merged));
    this.subject.next(this.getFilters());
  }

  public areDefault() {
    let filters = this.getFilters();
    return !filters['file_type'].length &&
      !filters['source'].length &&
      filters.time_filter_value === 36 &&
      filters.sort_order === 'relevance' &&
      filters.keyword_flag === true
      ? true
      : false;
  }

  public onChangeFilters(): Observable<any> {
    const sub = this.subject.asObservable();

    // The app has been refreshed
    if (!sub._isScalar) {
      this.subject.next(this.getFilters());
    }

    return this.subject.asObservable();
  }
}
