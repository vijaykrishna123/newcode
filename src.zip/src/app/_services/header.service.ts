import { Injectable } from '@angular/core';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs';

@Injectable()
export class HeaderService {
  private subject = new Subject<any>();

  constructor() { }

  saveStore(user: any) {
    this.subject.next(JSON.parse(user));
  }

  getStorageData(): Observable<any> {
    return this.subject.asObservable();
  }  

}
