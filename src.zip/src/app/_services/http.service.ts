import { Injectable } from '@angular/core';
import { Http, Headers, Response, ResponseContentType } from '@angular/http';
import { AnalyticsService } from '../_services/analytics.service';
import { FilterService } from '../_services/filter.service';
import { ResultService } from '../_services/result.service';
import { AppConfig } from '../app.config';
import 'rxjs/add/operator/map';

@Injectable()
export class HttpService {
  configData: any;
  APPID: any;
  APPWD: any;
  TOKENCODE: any;
  encodedString: any;

  headers: any;

  HOST: any;
  PORT: any;
  userInitials: any;
  sessionId: any;

  COLLECTIONSAPPID: any;
  COLLECTIONSAPPWD: any;
  collectionApiHost: any;
  collectionApiHeaders: any;

  AUTHCODE: any;
  collectionApiEncodedString: any;
  tokenStorage: any;

  constructor(
    private config: AppConfig,
    private http: Http,
    private _analyticsService: AnalyticsService,
    private _filterService: FilterService,
    private _resultService: ResultService
  ) {
    this.configData = !this.config.getConfigData()
      ? JSON.parse(localStorage.getItem('configData'))
      : this.config.getConfigData();
    this.HOST = this.configData.host;
    this.PORT = this.configData.port;
  }

  getAuth(): object {
    return {
      session_id: localStorage.getItem('sessionId'),
      user_id: localStorage.getItem('userInitials')
    };
  }

  getHeaders(): Headers {
    this.tokenStorage = localStorage.getItem('okta-token-storage');
    this.tokenStorage = JSON.parse(this.tokenStorage).accessToken.accessToken;
    const headers = new Headers({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.tokenStorage,
      'Ocp-Apim-Subscription-Key': this.configData.ocimSubscriptionKey,
      client: 'daa'
    });

    return headers;
  }

  getDocuments() {
    const data = this._filterService.getFilters();

    let req = this.getAuth();
    req['search_type'] = 1;
    req['query_type'] = 'as';

    data.request = req;
    data.is_nlp = true;

    // Analytics
    if (true) {
      const time_filter_value = data.time_filter_value;
      const source = data.source.toString();
      const file_type = data.file_type.toString();
      const query = data.query;
      const record_count = data.record_count;
      const str = source + ';' + file_type + ';' + time_filter_value;
      const keyword_flag = data.keyword_flag;
      this._analyticsService.recordSearchFacetAnalytics(
        query,
        record_count,
        str
      );
    }

    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/advanced-search/v1/list',
        JSON.stringify(data),
        { headers: this.getHeaders() }
      )
      .map((response: Response) => {
        const res = response.json();

        // Response is a source of truth
        this._filterService.saveFilters({
          file_type: res.file_type,
          source: res.source,
          time_filter_value: res.time_filter_value,
          publication_from_date: res.publication_from_date,
          publication_to_date: res.publication_to_date,
          query_id: res.query_id,
          keyword_flag: res.keyword_flag
        });

        this._resultService.saveResults(res);
        return res;
      });
  }

  /**
   * Function for displaying the file
   * @param docId
   * @param extn
   */
  displayFile(docId: string, extn: string): any {
    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/advanced-search/v1/display',
        JSON.stringify({ doc_id: docId }),
        { headers: this.getHeaders(), responseType: ResponseContentType.Blob }
      )
      .map(res => {
        if (extn === 'pdf') {
          return new Blob([res.blob()], { type: 'application/pdf' });
        } else {
          return new Blob([res.blob()], { type: 'text/html' });
        }
      });
  }

  /**
   * Function for sending the feedback for the result item
   * @param queryId
   * @param docId
   * @param snippetId
   * @param level
   * @param feedback
   * @param auth
   */
  sendFeedback(
    queryId: number,
    docId: number,
    snippetId: String,
    level: string,
    feedback: string
  ) {
    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/advanced-search/v1/feedback',
        JSON.stringify({
          feedback: feedback,
          feedback_type: 'as',
          feedback_level: level,
          query_id: queryId,
          doc_id: docId,
          section_id: snippetId,
          request: this.getAuth()
        }),
        { headers: this.getHeaders() }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  /**
   * Function for getting the recent search results
   * @param maxResultNo
   * @param req
   */
  getRecentSearch(maxResultNo: number) {
    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/advanced-search/v1/recent-searches',
        JSON.stringify({ max_result_no: maxResultNo, request: this.getAuth() }),
        { headers: this.getHeaders() }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  /**
   * Function to upload the file for summarization
   * @param formData
   * @param auth
   */
  fileUpload(formData: any, auth: any) {
    const headers = new Headers({
      // 'Content-Type': 'multipart/form-data',
      TokenType: auth.token_type,
      SessionId: auth.session_id,
      UserId: auth.user_id,
      SearchType: auth.search_type,
      RecordCount: auth.record_count
    });
    // console.log(this.headers);
    return (
      this.http
        // post the form data to the url defined above and map the response. Then subscribe //to initiate the post. if you don't subscribe, angular wont post.
        .post(
          'https://' +
            this.HOST +
            ':' +
            this.PORT +
            '/api/mss/content-operation/v1/upload',
          formData,
          { headers: headers }
        )
        .map((res: Response) => {
          return res.json();
        })
    );
  }

  /**
   * Function for sending link or content for summarization
   * @param url
   * @param content
   * @param type
   * @param auth
   */
  sendLinkOrContent(url: string, content: string, type: string, auth: any) {
    // console.log(this.headers);
    // console.log(JSON.stringify({url: url, long_content: content, content_type: type, summary_extraction: 'true', request: req}));
    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/content-operation/v1/content',
        JSON.stringify({
          url: url,
          long_content: content,
          content_type: type,
          summary_extraction: true,
          request: auth
        }),
        { headers: this.getHeaders() }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  /**
   * Function for sending summary feedback
   * @param reqId
   * @param summary
   * @param auth
   */
  sendSummaryFeedback(reqId: string, summary: any, auth: any) {
    const req = {
      request_id: reqId,
      feedback: summary.feedback,
      summary_id: summary.summary_id,
      user_id: auth.user_id,
      system_id: null,
      updated_keywords: [],
      updated_metadata: null,
      request: auth
    };
    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/content-operation/v1/feedback',
        JSON.stringify(req),
        { headers: this.getHeaders() }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  /**
   * Function for editting the summary snippet
   * @param reqId
   * @param summary
   * @param auth
   */
  editSummarySnippet(reqId: string, summary: any, auth: any) {
    const reqAuth = { session_id: auth.session_id, user_id: auth.user_id };
    const req = {
      request_id: reqId,
      summary_id: summary.summary_id,
      user_text: summary.user_text,
      request: reqAuth
    };
    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/content-operation/v1/editSummary',
        JSON.stringify(req),
        { headers: this.getHeaders() }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  addSummarySnippet(
    reqId: string,
    userText: string,
    reqType: string,
    auth: any
  ) {
    const reqAuth = { session_id: auth.session_id, user_id: auth.user_id };
    const req = {
      request_id: reqId,
      summary_id: null,
      user_text: userText,
      requestType: reqType,
      request: reqAuth
    };
    console.log(req);
    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/content-operation/v1/reviseSummary',
        JSON.stringify(req),
        { headers: this.getHeaders() }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  /**
   * Function to display summary document
   * @param docId
   * @param extn
   * @param auth
   */
  displaySummaryDoc(docId: string, extn: string, auth: any): any {
    // console.log(extn);
    console.log(JSON.stringify({ doc_id: docId, token_type: auth.token_type }));
    this.headers = new Headers({
      'Content-Type': 'application/json'
    });
    return this.http
      .post(
        'https://' +
          this.HOST +
          ':' +
          this.PORT +
          '/api/mss/content-operation/v1/docDisplay',
        JSON.stringify({ doc_id: docId, token_type: auth.token_type }),
        { headers: this.headers, responseType: ResponseContentType.Blob }
      )
      .map(res => {
        if (extn === 'pdf') {
          return new Blob([res.blob()], { type: 'application/pdf' });
        } else if (extn === 'txt') {
          return new Blob([res.blob()], { type: 'text/plain' });
        } else {
          return new Blob([res.blob()], { type: 'text/html' });
        }
      });
  }

  /**
 * Function for collections

 */
  createCollection() {
    const collectionRequest = {
      description: 'Collection',
      name: 'Collection',
      status: 'public',
      userInitials: localStorage.getItem('userInitials')
    };
    return this.http
      .post(
        this.collectionApiHost + 'collections',
        JSON.stringify(collectionRequest),
        { headers: this.collectionApiHeaders }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  addCollectionRecord(record: any) {
    const collectionId = localStorage.getItem('collectionId');
    return this.http
      .post(
        this.collectionApiHost + 'collections/' + collectionId + '/add',
        JSON.stringify(record),
        { headers: this.collectionApiHeaders }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  deleteCollectionRecord(recordId: string) {
    const collectionId = localStorage.getItem('collectionId');
    return this.http
      .delete(
        this.collectionApiHost +
          'collections/' +
          collectionId +
          '/record/' +
          recordId +
          '/delete',
        { headers: this.collectionApiHeaders }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  getCollectionbyUser(page: number) {
    const collectionRequest = { page: page, size: '10' };
    return this.http
      .get(
        this.collectionApiHost +
          'collections/' +
          localStorage.getItem('userInitials'),
        { headers: this.collectionApiHeaders, params: collectionRequest }
      )
      .map((response: Response) => {
        return response.json();
      });
  }

  getAutocorrectTerm() {
    const data = this._filterService.getFilters();
    const url =
      'https://' +
      this.HOST +
      ':' +
      this.PORT +
      '/api/mss/autocorrect/autocorrect';
    const autocorrectRequest = { user_query: data.query };
    return this.http
      .post(url, JSON.stringify(autocorrectRequest), {
        headers: this.getHeaders()
      })
      .map(res => {
        const json = res.json();
        return json;
      });
  }
}
