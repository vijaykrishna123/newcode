import { Injectable } from '@angular/core';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs';

@Injectable()
export class LoadingService {
    private subject = new Subject<any>();
 
    setLoading(flag: boolean) {
        this.subject.next(flag);
    }
 
    getState(): Observable<any> {
        return this.subject.asObservable();
    }
}