import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from "rxjs";

@Injectable()
export class ResultService {

    private subject = new BehaviorSubject<any>(false);
  
    constructor() {
    }

    public saveResults(res) {
        this.subject.next(res);
    }

    public onChangeResults(): Observable<any> {
        const sub = this.subject.asObservable();

        // //The app has been refreshed
        // if (sub._isScalar) {
        //     this.subject.next(res);
            return sub;
       // }
    }
}



 


