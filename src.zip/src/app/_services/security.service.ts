import { Injectable } from "@angular/core";

@Injectable()
export class SecurityService {
  resetAuthorizationData() {
    sessionStorage.removeItem("isLoggedIn");
    localStorage.removeItem("daa_filters");
    localStorage.removeItem("sessionId");
    localStorage.removeItem("configData");
  }

  setAuthorizationData(boolValue) {
    sessionStorage.setItem("isLoggedIn", boolValue);
    //TODO: Parse out the groups from token to determine role.
  }

  setUserName(userInitials) {
    if (userInitials.toString().indexOf("@") != -1)
      userInitials = userInitials.substring(0, userInitials.indexOf("@"));

    localStorage.setItem("userInitials", userInitials);
  }

  setSessionIdForUser(userInitials) {
    let timeStamp = Date.now().toString();
    let sessionId = btoa(timeStamp.concat(userInitials));
    localStorage.setItem("sessionId", sessionId);
  }

  setCallBack(boolValue) {
    sessionStorage.setItem("callbackExecuted", boolValue);
  }

  getCallBack() {
    return sessionStorage.getItem("callbackExecuted");
  }

  //return the token if it exists. Calling code can also use this to do something with the token, if authorized.
  authorized = function() {
    return sessionStorage.getItem("isLoggedIn");
  };
}
