import {
  Component,
  Renderer2,
  AfterContentInit,
  AfterContentChecked
} from "@angular/core";
import { Router, NavigationStart } from "@angular/router";
import { AnalyticsService } from "./_services/analytics.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html"
})
export class AppComponent {
  previousUrl: string;

  flag = false;

  constructor(
    private renderer: Renderer2,
    private router: Router,
    private _analyticsService: AnalyticsService
  ) {
    //this._analyticsService.loadPageData();

    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        if (event.url === "/") {
          this.router.navigate(["/search"]);
        }

        if (this.previousUrl) {
          this.renderer.removeClass(document.body, this.previousUrl);
        }
        let currentUrlSlug = event.url.slice(1).match(/[^?]*/i)[0]; // get route name
        if (currentUrlSlug) {
          this.renderer.addClass(document.body, currentUrlSlug);
        }
        this.previousUrl = currentUrlSlug;
      }
    });
  }

  ngAfterContentChecked() {
    if (!this.flag) {
      this._analyticsService.loadPageData("Search", "search");
      this.flag = true;
    }
  }
}
