import { Inject, Injectable } from "@angular/core";
import { Http, Response } from "@angular/http";
import { Observable } from "rxjs/Rx";
import "rxjs/add/operator/toPromise";
import { environment } from "../environments/environment";

@Injectable()
export class AppConfig {
  private _environmentsURL = "./environments/environments.json";
  private _alphaenvironmentsURL = "./environments/environments_alp.json";
  envFile = this._environmentsURL;
  configData: any;

  constructor(private http: Http) {}

  getEnvironmentValues(): Observable<any> {
    if (environment.envName === "alpha") {
      this.envFile = this._alphaenvironmentsURL;
    }

    return this.http
      .get(this.envFile)
      .map((response: Response) => {
        const res = response.json();
        if (!localStorage.getItem("configData"))
          localStorage.setItem("configData", JSON.stringify(response.json()));
        this.configData = res;
        return res;
      })
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

  public getConfigData() {
    return this.configData;
  }
}
