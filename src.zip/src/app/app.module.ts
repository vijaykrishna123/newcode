import { NgModule, APP_INITIALIZER } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

import { FormsModule } from "@angular/forms";
import { HttpModule } from "@angular/http";

import { SharedModule } from "./shared/shared.module";
import { CoreModule } from "./core/core.module";

import { LoadingModule } from "ngx-loading";

import { AppComponent } from "./app.component";
import { routing } from "./app.routing";

import { MasterModule } from "./master/master.module";
import { AlertModule } from "./_directives/alert/index";
import { SidePanelModule } from "./_directives/side-panel/index";

import { NotFoundComponent } from "./public/not-found/not-found.component";
import { SecurityService } from "./_services/security.service";
import { AnalyticsService } from "./_services/analytics.service";
import { AppConfig } from "./app.config";
import {
  OktaAuthModule,
  OktaAuthService,
  OKTA_CONFIG
} from "@okta/okta-angular";
import { OktaCallbackComponent } from "./callback/callback.component";

import { MatIconModule } from "@angular/material/icon";

@NgModule({
  declarations: [AppComponent, NotFoundComponent, OktaCallbackComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    SharedModule,
    CoreModule,
    routing,
    MasterModule,
    AlertModule,
    LoadingModule,
    SidePanelModule,
    MatIconModule,
    OktaAuthModule
  ],
  providers: [
    AppConfig,
    SecurityService,
    AnalyticsService,
    {
      provide: APP_INITIALIZER,
      useFactory: initConfig,
      deps: [AppConfig],
      multi: true
    },
    {
      provide: OKTA_CONFIG,
      useFactory: (configService: AppConfig) => {
        const config = configService.getConfigData();
        const oktaConfig = {
          issuer: `${config.baseUrl}/oauth2/${config.authServer}`,
          redirectUri: config.redirect_uri,
          clientId: config.client_id,
          responseType: config.response_type,
          scope: config.scope
        };
        return oktaConfig;
      },
      deps: [AppConfig]
    },
    OktaAuthService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

export function initConfig(configService: AppConfig) {
  return () => {
    return configService.getEnvironmentValues().toPromise();
  };
}
