import { Routes, RouterModule } from "@angular/router";
import { NotFoundComponent } from "./public/not-found/not-found.component";
import { SearchComponent } from "./master/search/search.component";
import { AuthGuard } from "./_guards/auth.guard";
import { OktaCallbackComponent } from "./callback/callback.component";

const appRoutes: Routes = [
  {
    path: "404",
    component: NotFoundComponent
  },
  {
    path: "auth-callback",
    component: OktaCallbackComponent
  },
  {
    path: "**",
    redirectTo: "/404"
  }
];

export const routing = RouterModule.forRoot(appRoutes);
