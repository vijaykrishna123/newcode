import { OktaAuthService } from "@okta/okta-angular";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { SecurityService } from "./../_services/security.service";

@Component({
  selector: "callback",
  templateUrl: "./callback.component.html"
})
export class OktaCallbackComponent implements OnInit {
  constructor(
    private okta: OktaAuthService,
    private router: Router,
    private securityService: SecurityService
  ) {
    this.okta
      .handleAuthentication()
      .then(oktaDetails => {})
      .catch(error => {
        console.log("Error while authneticating", error);
        this.securityService.setCallBack(false);
        this.router.navigate(["/not-auth"]);
      });
  }

  ngOnInit() {}
}
