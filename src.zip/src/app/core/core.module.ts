import { APP_INITIALIZER } from '@angular/core';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { throwIfAlreadyLoaded } from './helpers/module-import-guard';
import { ToastModule } from './toast/toast.module';



@NgModule({
  imports: [
    CommonModule, ToastModule
  ],
  exports: [
    CommonModule, ToastModule
  ],
  declarations: [],
  providers: [
  ]
})
export class CoreModule {
  constructor( @Optional() @SkipSelf() parentModule: CoreModule) {
    throwIfAlreadyLoaded(parentModule, 'CoreModule');
  }
}
