export class RequestJson {
    session_id:string;
    user_id:string;
    
    constructor() { 
         this.session_id= localStorage.getItem('sessionId');
         this.user_id=localStorage.getItem('userInitials');
    }

    /**
     * Json for recent Search request
     */
    public getRequestJson() {
        
        let recentSearchRequest = {
            session_id: this.session_id,
            user_id: this.user_id,
        }
        return recentSearchRequest;
        
    }

    /**
     * Json for list request
     */
    public getRequestJsonForList() {

        let listRequest = {
            query_type:"as",
            session_id: this.session_id,
            user_id: this.user_id,
            search_type:1
        }
        return listRequest;
    }

    /**
     * Json for summarization
     */
    public getRequestJsonForSummarization() {
        
        let summarizationRequest = {
            record_count:5,
            session_id: this.session_id,
            user_id: this.user_id,
            search_type:1
        }
        return summarizationRequest;

    }

}    