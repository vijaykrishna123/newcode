import * as moment from "moment";

export class SearchFilter {
  allowedKeys = [
    "offset",
    "page_size",
    "result_type",
    "query",
    "query_id",
    "source",
    "file_type",
    "time_filter_value",
    "sort_order",
    "publication_from_date",
    "publication_to_date",
    "apply_filter",
    "keyword"
  ];
  storageName = "daa_filters";

  public resetFilters() {
    let defaultValues = {
      query: "",
      query_id: 0,
      result_type: null,
      page_size: 0,
      offset: false,
      source: [],
      file_type: [],
      time_filter_value: 36,
      publication_from_date: moment()
        .subtract(36, "months")
        .format("YYYY-MM-DD"),
      publication_to_date: moment().format("YYYY-MM-DD"),
      sort_order: "relevance",
      apply_filter: false,
      keyword: true
    };

    localStorage.setItem(this.storageName, JSON.stringify(defaultValues));
  }

  public setInitValues() {
    let vals = {
      source: [],
      file_type: [],
      time_filter_value: 36,
      publication_from_date: moment()
        .subtract(36, "months")
        .format("YYYY-MM-DD"),
      publication_to_date: moment().format("YYYY-MM-DD"),
      sort_order: "relevance",
      query_id: 0,
      apply_filter: false,
      keyword: true
    };

    localStorage.setItem(this.storageName, JSON.stringify(vals));
  }

  public getFilters(results?) {
    if (results) {
      const filtered = Object.keys(results)
        .filter(key => this.allowedKeys.includes(key))
        .reduce((obj, key) => {
          obj[key] = results[key];
          return obj;
        }, {});

      if (!filtered["sort_order"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = s["sort_order"];
        filtered["sort_order"] = val;
      }

      if (!filtered["source"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = s["source"];
        filtered["source"] = val;
      }

      if (!filtered["file_type"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = s["file_type"];
        filtered["file_type"] = val;
      }

      if (!filtered["time_filter_value"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = s["time_filter_value"];
        filtered["time_filter_value"] = val;
      }

      if (!filtered["publication_from_date"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = moment()
          .subtract(Number.parseInt(s["time_filter_value"]), "months")
          .format("YYYY-MM-DD");
        filtered["publication_from_date"] = val;
      }

      if (!filtered["publication_to_date"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = s["publication_to_date"];
        filtered["publication_to_date"] = val;
      }
      if (!filtered["query_id"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = s["query_id"];
        filtered["query_id"] = val;
      }
      if (!filtered["apply_filter"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = s["apply_filter"];
        filtered["apply_filter"] = val;
      }
      if (!filtered["keyword"]) {
        let s = JSON.parse(localStorage.getItem(this.storageName));
        let val = s["keyword"];
        filtered["keyword"] = val;
      }
      localStorage.setItem(this.storageName, JSON.stringify(filtered));
    }

    if (!localStorage.getItem(this.storageName)) {
      this.setInitValues();
    }

    return JSON.parse(localStorage.getItem(this.storageName));
  }
}
