import { Component, OnInit } from '@angular/core';
import { AboutDialogService } from '../../../shared/dialogs/about-dialog/about-dialog.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html'
})
export class FooterComponent implements OnInit {

  constructor( public _aboutDialogService: AboutDialogService, private router: Router ) {
  }

  ngOnInit() {
  }

  // showDialog(){
  //   this._aboutDialogService.open();
  // }

  signOut(){
     this.router.navigate(['/sign-out']);
  }

}
