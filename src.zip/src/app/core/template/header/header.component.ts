import { Component, OnInit, OnChanges } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { AnalyticsService } from '../../../_services/analytics.service';
import { HeaderService } from '../../../_services/header.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  private subscription: Subscription;
  currentUser: any;
  currentRouteName: string;

  constructor( private headerService: HeaderService,  private router: Router,private _analyticsService:AnalyticsService ) {

    this.subscription = headerService.getStorageData()
      .subscribe(user => {
        this.currentUser = user;
      });


      router.events.subscribe((val) => {
         this.currentRouteName = this.router.url;
      });
  }

  onTopNavLinkClick(name: string,fileName: string):void {
        this._analyticsService.loadPageData(name,fileName);
  }

  ngOnInit() {
    this.headerService.saveStore(localStorage.getItem('currentUser'));
  }

}
