import { Component, OnInit } from '@angular/core';
import { ToasterConfig } from 'angular2-toaster/angular2-toaster';

@Component({
  selector: 'daa-toaster',
  template: `
    <toaster-container [toasterconfig]="toasterconfig" ></toaster-container>
  `,
  styles: []
})
export class ToastComponent implements OnInit {

  toasterconfig: ToasterConfig =
  new ToasterConfig({
    showCloseButton: { 'success': false, 'error': true },
    tapToDismiss: true,
    mouseoverTimerStop: true,
    timeout: 10000,
    newestOnTop: false,
    positionClass: 'toast-top-right'
  });


  constructor() { }

  ngOnInit() {
  }

}
