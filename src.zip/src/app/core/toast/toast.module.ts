import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToasterModule } from 'angular2-toaster';
import { ToastComponent } from './toast.component';
import { ToastService } from './toast.service';
import { throwIfAlreadyLoaded } from '../helpers/module-import-guard';

@NgModule({
  imports: [
    CommonModule,
    ToasterModule
  ],
  exports: [ToasterModule, ToastComponent],
  declarations: [ToastComponent],
  providers: [ToastService]
})
export class ToastModule {
  constructor( @Optional() @SkipSelf() parentModule: ToastModule) {
    throwIfAlreadyLoaded(parentModule, 'ToastModule');
  }
}
