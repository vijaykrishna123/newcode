import { Injectable } from '@angular/core';
import { ToasterService, Toast } from 'angular2-toaster/angular2-toaster';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

export interface ToastMessage {
  message: string;
}

@Injectable()
export class ToastService {
  private toastSubject = new Subject<ToastMessage>();
  toastState = this.toastSubject.asObservable();

  constructor(private toasterService: ToasterService) {

  }

  activate(message?: string) {
    this.toastSubject.next(<ToastMessage>{ message: message });
  }

  success(message) {
    this.toasterService.pop('success', '', message);
  }

  error(message) {
    this.toasterService.pop('error', '', message);
  }

  pop(type, title?, body?): Toast {
    return this.toasterService.pop(type, title, body);
  }

  popAsync(type, title?, body?): Observable<Toast> {
    return this.toasterService.popAsync(type, title, body);
  }
}
