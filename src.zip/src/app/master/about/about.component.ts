import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html'
})
export class AboutComponent implements OnInit {

  oneAtATime: boolean = true;
  isShowAllOn:boolean = false;
  group:Array<any> = [];

  constructor() {

    const len = 9;
    for (var i = 0; i < len; i++) {
      this.group.push(false);
    } 
  }

  ngOnInit() {
  }

  displayAll(state):void  {

   this.oneAtATime = (state) ? false : true;

   for (var i = 0; i < this.group.length; i++) {
      this.group[i] = state;
      console.log(this.group[i]);
    }

  }


  onPanelChange(isOpened: boolean, index: number):void {

    // console.log('---isOpened ', isOpened , ' index', index);
   

    // if (!this.isShowAllOn) {

    //     this.isShowAllOn = false;
    //       this.oneAtATime = true;
        
    //     for (var i = 0; i < this.group.length; i++) {
    //         this.group[i] = (index === i) ? true : false;
    //     }
    // }
  }

}
