import { Component, OnInit, ElementRef, Input } from '@angular/core';
import {  FileUploader } from 'ng2-file-upload/ng2-file-upload';

import { HttpService } from '../../_services/http.service';
import { ToastService } from '../../core/toast/toast.service';

import { Content } from '../../_models/content';
import { RequestJson } from  '../../core/requestjson';

@Component({
  selector: 'app-assistive-authoring',
  templateUrl: './assistive-authoring.component.html'
})

export class AssistiveAuthoringComponent implements OnInit {
  loading = false;
  myType = 'file';
  urlLink = '';
  longContent = '';
  inputText = '';
  results: any;
  authO: any;
  showInput = false;
  hasError = false;
  responseTime: number = 0;
  showContentPanel = false;
  requestJson:any;
  showAddButton = true;
  userText = '';

  content: Content = new Content();
  
  // declare a property called fileuploader and assign it to an instance of a new fileUploader.
  // pass in the Url to be uploaded to, and pass the itemAlais, which would be the name of the //file input when sending the post request.
  /* public uploader: FileUploader = new FileUploader({url: "https://localhost:8443/api/upload", itemAlias: 'fileName'}); */

  constructor(private httpService: HttpService, private el: ElementRef, private _toastService: ToastService) { }

  ngOnInit() {
    // override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
    /* this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; }; */
    // overide the onCompleteItem property of the uploader so we are
    // able to deal with the server response.
    /* this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
      console.log("ImageUpload:uploaded:", item, status, response);
    }; */
    this.requestJson = new RequestJson();

  }

  // the function which handles the file upload without using a plugin.
  uploadLink() {
    if(this.myType === 'file') {
      // locate the file element meant for the file upload.
      let inputEl: HTMLInputElement = this.el.nativeElement.querySelector('#fileName');
      // get the total amount of files attached to the file input.
      let fileCount: number = inputEl.files.length;
      let formData = new FormData();

      let extn = inputEl.value.substr(inputEl.value.lastIndexOf('.') + 1).toLowerCase();
      
      // check if the filecount is greater than zero, to be sure a file was selected.
      if (fileCount > 0 && (extn === 'pdf' || extn === 'html' || extn === 'txt')) {
        this.loading = true;
        this.hasError = false;
        // a file was selected
        // append the key name 'fileName' with the first file in the element
        formData.append('file', inputEl.files.item(0));
        let timeStart: number = performance.now();
        this.httpService.fileUpload(formData, this.requestJson.getRequestJsonForSummarization()).subscribe(
          response => {
            this.loading = false;
            let timeEnd: number = performance.now();
            let ping: number = timeEnd - timeStart;
            this.responseTime = ping;
            console.log(response);
            this.results = response; 
          }, error => {
            this.loading = false;
            this.results = '';
            var json = JSON.parse(error._body);
            this._toastService.error(`Error: ${(json.message)? json.message : json.code}`);
          }
        );
      } else {
        this.hasError = true;
      }
    }
    else {
      if(this.urlLink !== '' || this.longContent !== '') {
        this.loading = true;
        this.hasError = false;
        let timeStart: number = performance.now();
        this.httpService.sendLinkOrContent(this.urlLink, this.longContent, this.myType, this.requestJson.getRequestJsonForSummarization()).subscribe(
          response => {
            this.loading = false;
            let timeEnd: number = performance.now();
            let ping: number = timeEnd - timeStart;
            this.responseTime = ping;
            console.log(response); 
            this.results = response; 
          }, error => {
            this.loading = false;
            this.results = '';
            var json = JSON.parse(error._body);
            if(this.myType === 'text') {
              this._toastService.error(`Error: A minimum of about 50 characters of content is needed to provide a summary. Please provide more content.`);
            } else {
              this._toastService.error(`Error: ${(json.message)? json.message : json.code}`);
            }
             
          }
        );
        console.log(this.results);
      } else {
        this.hasError = true;
      }
    }
  }

  setDefault(fileType) {
    this.hasError = false;
    this.showContentPanel = false;
    this.myType = fileType;
    this.longContent = null;
    this.inputText = null;
    this.urlLink = null;
    this.results = null;
    if (fileType == 'text'){
    	setTimeout(function(){ document.getElementById('longContent').focus()}, 500);
    }
  }

  private ifArray(data) {
		return Array.isArray(data);
  };

  private sendSummaryFeedback(event: any, reqId: string, summary: any) {

    var x = event.toElement.parentNode.parentNode.getElementsByClassName("feedback-icon");
    for (var i = 0; i < x.length; i++) {
        x[i].classList.remove('active');
    }
    event.toElement.classList.add('active');
    summary.feedback = event.toElement.getAttribute("data-feedback");
    this.httpService.sendSummaryFeedback(reqId, summary, this.requestJson.getRequestJson()).subscribe(
      response => { 
         this._toastService.success(response.message);
      },
      error => {
        var json = JSON.parse(error._body);
                this._toastService.error(`Error: ${(json.message)? json.message : json.code}`);
      }
    );
  }

    saveUserInput(reqId: string) {
    this.authO = JSON.parse(localStorage.getItem('currentUser'));
    this.showAddButton = !this.showAddButton;
    this.httpService.addSummarySnippet(reqId, this.userText, 'a', this.requestJson.getRequestJson()).subscribe(
      response => {
        // alert(response.message);
        let summary = { feedback: null, is_input: false, score: 0.0, score_flag: 'N', summary_id: response.summaryId, summary_text: this.userText, user_text: '' };
        this.results.summaries.push(summary);
        this._toastService.success(response.message);
        this.userText = '';
      },
      error => {
        var json = JSON.parse(error._body);
                this._toastService.error(`Error: ${(json.message)? json.message : json.code}`);
        this.userText = '';
      }
    );
  }

  closeUserInput(){
    this.userText = null;
  }

  displayContent(docId: string) {
    console.log(this);
    if(this.myType === 'file' || this.myType === 'text') {
    	this.showContentPanel = !this.showContentPanel;
   	}
    this.authO = JSON.parse(localStorage.getItem('currentUser'));
    let path = null;
    
    this.content.user_selection = this.myType;
    if(this.myType === 'file') {
      path = this.el.nativeElement.querySelector('#fileName').value;
      // let fileName = path.split('/').pop().split('\\').pop();
      let extn = path.substr(path.lastIndexOf('.') + 1).toLowerCase();
      // calling service to get the upload file object and also set the content object
      this.httpService.displaySummaryDoc(docId, extn, this.authO.response).subscribe((res) => { 
        this.content.url = URL.createObjectURL(res);
      });
      this.content.mime_type = this.getMimeType(path);
    } else if(this.myType === 'url') {
      window.open(this.results.url, "_blank");
      return false;
      //this.content.url = this.results.url;
      //this.content.mime_type = this.getMimeType(this.results.url);
    } else {
      // set textarea text to the side panel
      this.content.url = null;
      this.content.mime_type = null;
      this.content.text = this.longContent.replace(/(?:\r\n|\r|\n)/g, '<br/>');
    }
  }
  getMimeType(url: string) {
    let extn = url.substr(url.lastIndexOf('.') + 1).toLowerCase();
    if(extn === 'pdf')
      return 'application/pdf';
    else if(extn === 'txt')
      return 'text/plain';
    else
      return 'text/html';
  }

  onClosed(flag: boolean) {
    this.showContentPanel = flag;
  }
}
