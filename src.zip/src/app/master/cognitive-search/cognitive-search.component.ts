import {
  Component,
  OnInit,
  OnDestroy,
  AfterViewInit,
  ViewChild
} from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { HttpService } from '../../_services/http.service';
import { ResultService } from '../../_services/result.service';
import { LoadingService } from '../../_services/loading.service';
import { SearchFilterComponent } from '../../shared/search-filter/search-filter.component';
import { SearchFieldComponent } from '../../shared/search-field/search-field.component';
import { ToastService } from '../../core/toast/toast.service';

@Component({
  selector: 'app-cognitive-search',
  templateUrl: './cognitive-search.component.html'
})
export class CognitiveSearchComponent implements OnInit, OnDestroy {
  isCollapsed: boolean = true;
  loading: boolean;
  results: any;
  isAutocompleted: any;
  autocorrected: any;

  loadingSubscription: Subscription;
  resultSubscription: Subscription;
  autocorrectSubscription: Subscription;
  @ViewChild(SearchFilterComponent) searchFilter: SearchFilterComponent;

  constructor(
    private httpService: HttpService,
    private _resultService: ResultService,
    private _loadingService: LoadingService,
    private _toastService: ToastService
  ) {
    this.loadingSubscription = this._loadingService
      .getState()
      .subscribe(res => {
        this.loading = res;
      });
  }

  ngOnInit() {
    this.resultSubscription = this._resultService
      .onChangeResults()
      .subscribe(res => {
        if (res) {
          this.results = res;
          window.scroll(0, 0);
          this.isAutocompleted = this.setAutcompleteStatus();
          this.autocorrectSubscription = this.httpService
            .getAutocorrectTerm()
            .subscribe(res => {
              // console.log(res);
              if (res) {
                if (
                  res.corrected_query.toLowerCase() !=
                  res.user_query.toLowerCase()
                ) {
                  this.autocorrected = res;
                }
              }
            });
        } else {
          this.onPageRefresh();
        }
      });

    let collectId = localStorage.getItem('collectionId');

    if (collectId == null) {
      /*
			this.httpService.createCollection().subscribe(
			      	response => {
			          console.log(response.collectionId);
			          localStorage.setItem("collectionId",response.collectionId)
			      	},
			      	error => {
			      		this._toastService.error(error);
			      	}
			  );
			 */
    }
    this.setCollapsed(false);
  }

  onPageRefresh() {
    this._loadingService.setLoading(true);

    this.httpService.getDocuments().subscribe(
      res => {
        this.results = res;
        this._loadingService.setLoading(false);
      },
      error => {
        this._loadingService.setLoading(false);
        const json = JSON.parse(error._body);
        this._toastService.error(
          `Error: ${json.message ? json.message : json.code}`
        );
      }
    );
  }

  ngOnDestroy() {
    this.resultSubscription.unsubscribe();
    this.loadingSubscription.unsubscribe();
    this.autocorrectSubscription.unsubscribe();
  }

  searchFilterClosed() {
    this.setCollapsed(true);
  }

  setCollapsed(flag: boolean): void {
    if (flag) {
      this.isCollapsed = true;
    } else {
      this.isCollapsed = false;
      //  this.searchFilter.reset();
    }
  }

  setAutcompleteStatus() {
    const autocompleteStatus = localStorage.getItem('autocompleted');
    // console.log(autocompleteStatus);
    if (autocompleteStatus == 'true') {
      return true;
    }
    return false;
  }

  @ViewChild(SearchFieldComponent) searchField: SearchFieldComponent;
  searchSuggestionLink(searchValue: any) {
    // console.log(searchValue);
    localStorage.setItem('autocompleted', 'true');
    this.searchField.searchQuery(searchValue);
  }
}
