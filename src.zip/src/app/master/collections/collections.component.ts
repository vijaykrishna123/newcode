import { Component, Output, OnInit } from '@angular/core';
import { HttpService } from '../../_services/http.service';
import { RequestJson } from '../../core/requestjson';
import { ToastService } from '../../core/toast/toast.service';

@Component({
  selector: 'app-collections',
  templateUrl: './collections.component.html'
})
export class CollectionsComponent implements OnInit {
  results: any;
  sortedBy: string;
  tags: any;
  requestJson: any;

  //for pagination
  page: number; // the current page
  count: number; // how many total items there are in all pages
  perPage: number; // how many items we want to show per page
  pagesToShow = 3; // how many pages between next/prev
  offset: number;

  ratings = [];

  constructor(
    private httpService: HttpService,
    private _toastService: ToastService
  ) {}

  ngOnInit() {
    this.initRatings();
    this.requestJson = new RequestJson();
    let collectId = localStorage.getItem('collectionId');
    if (collectId == null) {
      this.httpService.createCollection().subscribe(
        response => {
          console.log(response.collectionId);
          localStorage.setItem('collectionId', response.collectionId);
        },
        error => {
          this._toastService.error(error);
        }
      );
    }
    this.httpService.getCollectionbyUser(0).subscribe(
      response => {
        this.results = response.content;
        this.count = response.totalElements;
        console.log(this.count);
        this.perPage = response.size;
        this.page = response.page + 1;
        this.offset = response.page;
      },
      error => {
        this._toastService.error(error);
      }
    );
  }

  private initRatings() {
    this.ratings = [
      {
        name: 'Not Helpful',
        type: 'dislike',
        icon: 'daa-icn-notuseful'
      },
      {
        name: 'Not Sure',
        type: 'neutral',
        icon: 'daa-icn-notsure'
      },
      {
        name: 'Good',
        type: 'like',
        icon: 'daa-icn-notuseful'
      },
      {
        name: 'Great',
        type: 'vlike',
        icon: 'daa-icn-great'
      }
    ];
  }

  private getDoc(doc: string) {
    doc = doc.substr(doc.lastIndexOf('/') + 1);
    var docName = doc.split('.');
    // return '['+ docName.pop().toUpperCase() +'] ' + docName.join('.');
    return docName.pop() + ' ' + docName.join('.');
  }

  deleteFromCollection(recordId: any) {
    this.httpService.deleteCollectionRecord(recordId).subscribe(
      response => {
        this.httpService.getCollectionbyUser(0).subscribe(response => {
          this.results = response.content;
        });
        this._toastService.success(response.messages);
      },
      error => {
        this._toastService.error(error);
      }
    );
  }

  sortResultsByDate(asc) {
    let myResults = '';
    myResults = this.results.sort(function(a, b) {
      if (asc == 'oldest') {
        return a['edam_date'] > b['edam_date']
          ? 1
          : a['edam_date'] < b['edam_date']
          ? -1
          : 0;
      } else if (asc == 'newest') {
        return b['edam_date'] > a['edam_date']
          ? 1
          : b['edam_date'] < a['edam_date']
          ? -1
          : 0;
      } else {
        return b['dateAdded'] > a['dateAdded']
          ? 1
          : b['dateAdded'] < a['dateAdded']
          ? -1
          : 0;
      }
    });
    this.sortedBy =
      asc == 'oldest'
        ? 'Date - Oldest'
        : asc == 'newest'
        ? 'Date - Newest'
        : 'Date - Added';
    return false;
  }

  getCollectionRecordsForUser() {
    this.httpService.getCollectionbyUser(0).subscribe(
      response => {},
      error => {
        this._toastService.error(error);
      }
    );
  }

  //pagination

  save(offset: number) {
    this.httpService.getCollectionbyUser(offset).subscribe(
      response => {
        this.results = response.content;
        this.page = response.page + 1;
      },
      error => {
        this._toastService.error(error);
      }
    );
  }

  onPage(n: number): void {
    this.page = n;
    this.offset = n;
    this.save(this.offset - 1);
  }

  onNext(): void {
    console.log('next:' + this.offset);
    this.offset = this.offset + 1;
    this.save(this.offset);
  }

  onPrev(): void {
    console.log('prev:' + this.offset);
    this.offset = this.offset - 1;
    this.save(this.offset);
  }

  getMin(): number {
    return this.perPage * this.page - this.perPage + 1;
  }

  getMax(): number {
    let max = this.perPage * this.page;
    if (max > this.count) {
      max = this.count;
    }
    return max;
  }

  totalPages(): number {
    return Math.ceil(this.count / this.perPage) || 0;
  }

  lastPage(): boolean {
    // return this.perPage * this.page === this.count;
    return this.page === this.totalPages();
  }

  getPages(): number[] {
    const c = Math.ceil(this.count / this.perPage);
    const p = this.page || 1;
    const pagesToShow = this.pagesToShow || 9;
    const times = pagesToShow - 1;
    const pages: number[] = [];

    pages.push(p);
    for (let i = 0; i < times; i++) {
      if (pages.length < pagesToShow) {
        if (Math.min.apply(null, pages) > 1) {
          pages.push(Math.min.apply(null, pages) - 1);
        }
      }
      if (pages.length < pagesToShow) {
        if (Math.max.apply(null, pages) < c) {
          pages.push(Math.max.apply(null, pages) + 1);
        }
      }
    }
    pages.sort((a, b) => a - b);
    return pages;
  }
}
