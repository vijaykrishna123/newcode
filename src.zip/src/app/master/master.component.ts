import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './master.component.html'
})
export class MasterComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
