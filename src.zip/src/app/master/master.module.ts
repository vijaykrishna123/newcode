import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

import { NgxBootstrapModule } from "../shared/ngxBootstrap.module";
import { SharedModule } from "../shared/shared.module";

import { TruncateModule } from "ng2-truncate";

import { MasterComponent } from "./master.component";
import { masterRouting } from "./master.routing";
import { AlertModule } from "../_directives/alert/index";

import { LoadingModule } from "ngx-loading";

import { HttpService } from "../_services/http.service";

import { HeaderComponent } from "../core/template/header/header.component";
import { HeaderService } from "../_services/header.service";

// import { FooterComponent } from '../core/template/footer/footer.component';

import { KeyValueFilterPipe } from "../_pipes/key-value-filter.pipe";

import { SearchComponent } from "./search/search.component";
import { CognitiveSearchComponent } from "./cognitive-search/cognitive-search.component";
import { AssistiveAuthoringComponent } from "./assistive-authoring/assistive-authoring.component";
import { CollectionsComponent } from "./collections/collections.component";
import { SignOutComponent } from "../public/sign-out/sign-out.component";

import { SidePanelModule } from "../_directives/side-panel/index";
import { PaginationModule } from "../_directives/pagination/index";
import { FooterModule } from "../core/template/footer/footer.module";
import { AboutComponent } from "./about/about.component";
import { NotAuthComponent } from "./not-auth/not-auth.component";
import { AuthGuard } from "./../_guards/auth.guard";
import { AuthService } from "./../_services/auth.service";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgxBootstrapModule,
    SharedModule,
    masterRouting,
    AlertModule,
    TruncateModule,
    LoadingModule,
    SidePanelModule,
    PaginationModule,
    FooterModule
  ],
  declarations: [
    MasterComponent,
    SearchComponent,
    CognitiveSearchComponent,
    AssistiveAuthoringComponent,
    SignOutComponent,
    KeyValueFilterPipe,
    HeaderComponent,
    AboutComponent,
    NotAuthComponent,
    CollectionsComponent
  ],
  providers: [AuthGuard, HttpService, HeaderService, AuthService]
})
export class MasterModule {}
