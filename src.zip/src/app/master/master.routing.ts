import { Routes, RouterModule } from "@angular/router";

import { MasterComponent } from "./master.component";
import { SearchComponent } from "./search/search.component";
import { CognitiveSearchComponent } from "./cognitive-search/cognitive-search.component";
import { AssistiveAuthoringComponent } from "./assistive-authoring/assistive-authoring.component";
import { CollectionsComponent } from "./collections/collections.component";
import { SignOutComponent } from "../public/sign-out/sign-out.component";
import { AboutComponent } from "./about/about.component";
import { NotAuthComponent } from "./not-auth/not-auth.component";
import { AuthGuard } from "./../_guards/auth.guard";

const masterRoutes: Routes = [
  {
    path: "",
    component: MasterComponent,

    children: [
      {
        path: "search",
        component: SearchComponent,
        canActivate: [AuthGuard]
      },
      {
        path: "search-results",
        component: CognitiveSearchComponent,
        canActivate: [AuthGuard]
      },
      {
        path: "summarization",
        component: AssistiveAuthoringComponent,
        canActivate: [AuthGuard]
      },
      /*
      {
        path: 'collections',
        component: CollectionsComponent,
        canActivate: [AuthGuard],
      },
      */
      {
        path: "about",
        component: AboutComponent,
        canActivate: [AuthGuard]
      },
      {
        path: "sign-out",
        component: SignOutComponent,
        canActivate: [AuthGuard]
      },
      {
        path: "not-auth",
        component: NotAuthComponent
      }
    ]
  }
];

export const masterRouting = RouterModule.forRoot(masterRoutes, {
  enableTracing: true
});
