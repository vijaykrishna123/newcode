import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-auth',
  templateUrl: './not-auth.component.html'
})
export class NotAuthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
