import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  Renderer2
} from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs/Subscription";

import { LoadingService } from "../../_services/loading.service";
import { FilterService } from "../../_services/filter.service";
import { SearchFieldComponent } from "../../shared/search-field/search-field.component";
import { OktaAuthService } from "@okta/okta-angular";
import { SecurityService } from "app/_services/security.service";
@Component({
  selector: "search",
  templateUrl: "./search.component.html"
})
export class SearchComponent implements OnInit, OnDestroy {
  initialBodyClassName = "search";
  loading: boolean;
  recentSearches: any;
  userInitials: string;

  loadingSubscription: Subscription;

  @ViewChild(SearchFieldComponent) search: SearchFieldComponent;

  constructor(
    private router: Router,
    private securityService: SecurityService,
    private _loadingService: LoadingService,
    private _filterService: FilterService,
    private renderer: Renderer2,
    private oktaAuthService: OktaAuthService
  ) {
    this.renderer.addClass(document.body, this.initialBodyClassName);

    this.loadingSubscription = this._loadingService
      .getState()
      .subscribe(res => {
        this.loading = res;
      });
  }

  ngOnInit() {
    this._filterService.saveFilters({
      query: ""
    });

    this._filterService.resetFilters();
    let userInitials = this.oktaAuthService.getUser().then(
      userPromise => {
        {
          let userInitials = userPromise.preferred_username;
          this.securityService.setUserName(userInitials);
          this.securityService.setSessionIdForUser(userInitials);
        }
      },
      error => console.log("error", error)
    );
    //this.httpService.getRecentSearch(5).subscribe(response => { this.recentSearches = response.recent_search_terms });
  }

  propagateSearch(topic: string) {
    this.search.searchQuery(topic);
  }

  ngOnDestroy() {
    this.loadingSubscription.unsubscribe();
    this.renderer.removeClass(document.body, this.initialBodyClassName);
  }
}
