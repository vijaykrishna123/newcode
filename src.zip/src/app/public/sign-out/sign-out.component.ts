import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../_services/auth.service';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common'
import { AnalyticsService } from '../../_services/analytics.service';

@Component({
  selector: 'app-sign-out',
  templateUrl: './sign-out.component.html'
})
export class SignOutComponent implements OnInit {
  show = true;
  constructor(
    private router: Router, 
    private authService: AuthService,
    private analyticsService:AnalyticsService,
    private location: PlatformLocation ) {

      location.onPopState(() => {
        this.backToLogIn();
      });
     }

  ngOnInit() {
     this.authService.logout();
	
  }

   backToLogIn(){
	 this.show = false;   
     this.router.navigate(['/search']);
	 
  }

}
