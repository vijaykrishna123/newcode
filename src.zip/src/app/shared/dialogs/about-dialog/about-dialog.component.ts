﻿import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

@Component({
    selector: 'daa-about-dialog',
    templateUrl: './about-dialog.component.html'
})

export class AboutDialogComponent implements OnInit {
   
  constructor(public bsModalRef: BsModalRef) {}
 
  ngOnInit() {
  }

}
