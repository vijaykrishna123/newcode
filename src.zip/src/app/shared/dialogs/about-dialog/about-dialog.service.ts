import { Injectable } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';


import { AboutDialogComponent } from './about-dialog.component';

@Injectable()
export class AboutDialogService {
  
  bsModalRef: BsModalRef;
  constructor(private modalService: BsModalService) {}
 
  open() {
    this.bsModalRef = this.modalService.show(AboutDialogComponent, {});
  }
  
}