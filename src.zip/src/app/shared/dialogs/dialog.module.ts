﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutDialogService } from './about-dialog/about-dialog.service';
import { AboutDialogComponent } from './about-dialog/about-dialog.component';


@NgModule({
    imports: [
        CommonModule
    ],
    exports: [
        AboutDialogComponent
    ],
    declarations: [
        AboutDialogComponent
    ],
    providers: [
        AboutDialogService
    ],
    entryComponents: [
        AboutDialogComponent
    ]
})
export class DialogModule { }
