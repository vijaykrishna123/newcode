import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'daa-panel-toggle',
  templateUrl: './panel-toggle.component.html'
})
export class PanelToggleComponent implements OnInit {

  isCollapsed: boolean = true;
  @Input() showMore: boolean = false;

  constructor () {
  }

  ngOnInit() {
  }

  reset(): void {
     this.isCollapsed = true;
  }
}
