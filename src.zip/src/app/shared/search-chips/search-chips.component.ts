import { Component, OnInit, OnDestroy, RendererType2 } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { HttpService } from '../../_services/http.service';
import { FilterService } from '../../_services/filter.service';
import { ToastService } from '../../core/toast/toast.service';

@Component({
  selector: 'daa-search-chips',
  templateUrl: './search-chips.component.html'
})
export class SearchChipsComponent {

  arr = [];
  loading = false;
  selectedIndex = -1;
  filterSubscription: Subscription;
  source: string[] = [];
  file_type: string[] = [];
  filters;
  isTimeFilterOn;

  constructor( private httpService: HttpService,
               private _toastService: ToastService,
               private _filterService: FilterService ) {
  }

   ngOnInit() {

      this.filterSubscription = this._filterService.onChangeFilters().subscribe(res => {
        this.setFilter();
      });
   }

   setFilter() {

    this.arr = [];
    this.source = [];
    this.file_type = [];
    this.filters = this._filterService.getFilters();

      //Time
      this.isTimeFilterOn = (this.filters.time_filter_value > 0 && this.filters.time_filter_value < 36)? true : false;
      if (this.isTimeFilterOn) {
        let text;
        switch (this.filters.time_filter_value) {
          case 1:
          text = 'Last 1 Month';
          break;
          case 2:
            text = 'Last 2 Month';
          break;
          case 3:
            text = 'Last 3 Month';
          break;
          case 4:
            text = 'Last 4 Month';
          break;
          case 5:
            text = 'Last 6 Month';
          break;
          case 6:
            text = 'Last 6 Month';
          break;
          case 12:
            text = 'Last 1 Year';
          break;
          case 24:
            text = 'Last 2 Year';
          break;
          case 36:
            text = 'Last 3 Years';
          break;
        }

        this.arr.push({
          text,
          type: 'time'
        });
      }


      if (this.filters.file_type.length >= 1) {

        let flag = false;
        this.filters.file_type.forEach(item => {
   
          // if (item === 'all') {
          //    this.file_type = ['all'];
          //    flag = true;
          // }

          if (!flag) {
             this.file_type.push(item);
          }
        });
      }

       this.file_type.forEach(item => {

          switch(item) {
            case "all":
              this.arr.push({ text: 'All Content Types', type: 'allFiles', group: 'file_type'});
              break;
          case "pdf":
              this.arr.push({ text: 'Pdf', type: 'pdf', group: 'file_type'});
              break;
          case "image":
              this.arr.push({ text: 'Image', type: 'image', group: 'file_type'});
              break;
          case "video":
              this.arr.push({ text: 'Video', type: 'video', group: 'file_type'});
              break;
          case "html":
              this.arr.push({ text: 'Html', type: 'html', group: 'file_type'});
              break;
          case "chart":
              this.arr.push({ text: 'Chart', type: 'chart', group: 'file_type'});
              break;
           case "word":
              this.arr.push({ text: 'Word', type: 'word', group: 'file_type'});
              break;
          case "presentation":
              this.arr.push({ text: 'PowerPoint', type: 'presentation', group: 'file_type'});
              break;
          case "indd":
              this.arr.push({ text: 'InDesign', type: 'indd', group: 'file_type'});
              break;
          }
      });

      //Source
      this.filters.source.forEach(item => {
        this.source.push(item);
      });
      

      // (filters.source[0] !== 'internal')
      if (true) {
        this.source.forEach(item => {

           switch(item) {
             case "all":
                this.arr.push({ text: 'All sources', type: 'allSources', group: 'source'});
                break;
            case "external":
                this.arr.push({ text: 'External', type: 'external', group: 'source'});
                break;
            case "internal":
                this.arr.push({ text: 'Internal', type: 'internal', group: 'source'});
                break;
            case "web":
                this.arr.push({ text: 'Web', type: 'web', group: 'source'});
                break;
            case "edam":
               this.arr.push({ text: 'eDAM', type: 'edam', group: 'source'});
                break;
            case "americanfunds_advisor":
                this.arr.push({ text: 'AF Advisor', type: 'americanfunds_advisor', group: 'source'});
                break;
            case "americanfunds_ria":
                this.arr.push({ text: 'AF Ria', type: 'americanfunds_ria', group: 'source'});
                break;
            case "americanfunds_literature":
                this.arr.push({ text: 'AF Literature', type: 'americanfunds_literature', group: 'source'});
                break;
             case "americanfunds_individual":
                this.arr.push({ text: 'AF Individual', type: 'americanfunds_individual', group: 'source'});
                break;
            case "americanfunds_retirement":
                this.arr.push({ text: 'AF Retirement', type: 'americanfunds_retirement', group: 'source'});
                break;
             case "capitalgroup_us":
                this.arr.push({ text: 'AF Institutional', type: 'capitalgroup_us', group: 'source'});
                break;
                case "thecapitalideas":
                this.arr.push({ text: 'The Capital Ideas', type: 'thecapitalideas', group: 'source'});
                break;
            case "fundfire":
                this.arr.push({ text: 'Fundfire', type: 'fundfire', group: 'source'});
                break;
            case "ignites":
                this.arr.push({ text: 'Ignites', type: 'ignites', group: 'source'});
                break;
            case "galileo":
                this.arr.push({ text: 'Galileo', type: 'galileo', group: 'source'});
                break;
            case "dowjones_economist":
                this.arr.push({ text: 'Dow Jones Economist', type: 'dowjones_economist', group: 'source'});
                break;
            case "dowjones_wsj":
                this.arr.push({ text: 'Dow Jones WSJ', type: 'dowjones_wsj', group: 'source'});
                break;
            }
        });
      }
   }

   remove(type, index):void {
    switch (type) {
      
      case "allFiles":
      case "allSources":
      case "internal":
      case "external":
      case "web":
      case "edam":
      case "americanfunds_advisor":
      case "americanfunds_ria":
      case "americanfunds_literature":
      case "americanfunds_individual":
      case "americanfunds_retirement":
      case "capitalgroup_us":
      case "thecapitalideas":
      case "fundfire":
      case "ignites":
      case "galileo":
      case "dowjones_economist":
      case "dowjones_wsj":
      case "pdf":
      case "indd":
      case "html":
      case "image":
      case "video":
      case "chart":
      case "word":
      case "presentation":
      case "indd":

        this.source.forEach((item, index) => {
      
          if (item === type) {
            this.source.splice(index, 1);
            this.filters.source = this.source;
          }
        });

        if (type === 'allSources') {
          this.filters.source = [];
        }

        this.file_type.forEach((item, index) => {
      
          if (item === type) {
            this.file_type.splice(index, 1);
            this.filters.file_type = this.file_type;
          }
        });

        if (type === 'allFiles') {
          this.filters.file_type = [];
        }

        
      break;

      case 'time':
        this.filters.time_filter_value = 36;
      break;
    }

    this.loading = true;
    this.selectedIndex = index;

    this._filterService.saveFilters(this.filters);

      this.httpService.getDocuments().subscribe(
      results => {

         this.loading = false;
      }, error => {

        this.loading = false;
        const json = JSON.parse(error._body);
        this._toastService.error(`Error: ${(json.message)? json.message : json.code}`);
      }
    );
   }

   ngOnDestroy() {
    this.filterSubscription.unsubscribe();
  }
}
