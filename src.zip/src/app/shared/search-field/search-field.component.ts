import { LoadingModule } from 'ngx-loading';
import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { HttpService } from '../../_services/http.service';
import { LoadingService } from '../../_services/loading.service';
import { AnalyticsService } from '../../_services/analytics.service';
import { ToastService } from '../../core/toast/toast.service';
import { FilterService } from '../../_services/filter.service';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

@Component({
  selector: 'daa-search-field',
  templateUrl: './search-field.component.html'
})
export class SearchFieldComponent implements OnInit {
  loading = false;
  query = '';
  filterSubscription: Subscription;
  showMe = false;
  sourceData = null;
  hideSuggestions = false;
  searchType = [
    {
      name: 'Keyword',
      placeholder: 'Search by keyword relevant to your topic.',
      value: true
    },
    {
      name: 'Natural Language',
      placeholder: 'Search by subject or related terms.',
      value: false
    }
  ];
  selectedSearchType = this.searchType[0].value;

  @Input() placeholder = '';

  public searchFldEventEmitter = new EventEmitter<boolean>();

  constructor(
    private httpService: HttpService,
    private _loadingService: LoadingService,
    private _analyticsService: AnalyticsService,
    private _toastService: ToastService,
    private _filterService: FilterService,
    private router: Router,
    public http: Http
  ) {}

  ngOnInit() {
    this.filterSubscription = this._filterService
      .onChangeFilters()
      .subscribe(res => {
        //this.query = res.query;
      });
  }

  searchQuery(query?): void {
    if (query) {
      this.query = query;
    }

    // Dont make call if the query is an empty string and min 2 chars
    if (this.query !== '' && this.query.length >= 2) {
      this.hideSuggestions = true;
      this._loadingService.setLoading(true);
      this.loadDocuments();
      if (this.router.url === '/search-results') {
        this.query = '';
      }
    }
  }

  resetQuery(): void {
    this.hideSuggestions = false;
    this.searchFldEventEmitter.emit(true);
    this.query = '';
  }

  onSearchChange(searchValue: string) {
    // if (searchValue.length > 1 ){
    return true;
    // }
  }

  private loadDocuments() {
    this._filterService.resetFilterJSON();
    this._filterService.saveFilters({
      query: this.query,
      offset: 0,
      keyword_flag: this.selectedSearchType
    });

    this.httpService.getDocuments().subscribe(
      results => {
        this._loadingService.setLoading(false);
        this._analyticsService.recordSearchTermAnalytics(
          results.query,
          results.record_count
        );

        if (this.router.url === '/search') {
          this.router.navigate(['/search-results']);
        }
      },
      error => {
        this._loadingService.setLoading(false);
        const json = JSON.parse(error._body);
        this._toastService.error(
          `Error: ${json.message ? json.message : json.code}`
        );
      }
    );
  }

  myTypeCallback(eventValue: boolean) {
    this.selectedSearchType = eventValue;
    this.placeholder = eventValue
      ? this.searchType[0].placeholder
      : this.searchType[1].placeholder;
    localStorage.setItem(
      'selectedSearchType',
      this.selectedSearchType.toString()
    );
  }

  myCallback(eventValue: string) {
    //console.log("myCallBack:"+this.query +":"+ eventValue);
    //console.log(localStorage.getItem("autocompleted"));
    this.hideSuggestions = false;
    if (this.query == eventValue) {
      localStorage.setItem('autocompleted', 'false');
    } else {
      this.query = eventValue;
      localStorage.setItem('autocompleted', 'true');
      this.searchQuery();
    }
  }

  completionSource = (keyword: any): Observable<any[]> => {
    let url: string =
      'https://' +
      this.httpService.HOST +
      ':' +
      this.httpService.PORT +
      '/api/mss/autocomplete/autocomplete?userid=' +
      localStorage.getItem('userInitials') +
      '&in_text=' +
      keyword;
    //console.log(url);
    if (keyword && keyword.length > 1) {
      if (keyword) {
        return this.http
          .get(url, { headers: this.httpService.getHeaders() })
          .map(res => {
            let json = res.json();
            return json;
          });
      } else {
        return Observable.of([]);
      }
    }
  };

  ngOnDestroy() {
    this.filterSubscription.unsubscribe();
  }
}
