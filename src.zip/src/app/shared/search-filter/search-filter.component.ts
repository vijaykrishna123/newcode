import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  Output,
  EventEmitter
} from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { HttpService } from '../../_services/http.service';
import { FilterService } from '../../_services/filter.service';
import { ToastService } from '../../core/toast/toast.service';
import { PanelToggleComponent } from '../panel-toggle/panel-toggle.component';
import * as moment from 'moment';

@Component({
  selector: 'daa-search-filter',
  templateUrl: './search-filter.component.html'
})
export class SearchFilterComponent {
  loading: boolean;
  timeType = 'Y';
  filters;
  collection;

  sections = [];
  dateSection = [];
  sourceSection = [];
  contentTypeSection = [];
  currentDateFilter;
  currentSourceFilter;
  currentContentTypeFilter;

  is_on_file_type_all = false;
  is_on_file_type_pdf = false;
  is_on_file_type_image = false;
  is_on_file_type_chart = false;
  is_on_file_type_html = false;
  is_on_file_type_video = false;
  is_on_file_type_word = false;
  is_on_file_type_presentation = false;
  is_on_file_type_indd = false;

  is_on_source_all = false;
  is_on_source_internal = false;
  is_on_source_external = false;
  is_on_source_edam = false;
  is_on_source_web = false;
  is_on_source_americanfunds_advisor = false;
  is_on_source_americanfunds_ria = false;
  is_on_source_americanfunds_literature = false;
  is_on_source_thecapitalideas = false;
  is_on_source_fundfire = false;
  is_on_source_ignites = false;
  is_on_source_americanfunds_individual = false;
  is_on_source_americanfunds_retirement = false;
  is_on_source_capitalgroup_us = false;
  is_on_source_galileo = false;

  @ViewChild(PanelToggleComponent) panel: PanelToggleComponent;
  @Output() closed = new EventEmitter();

  filterSubscription: Subscription;

  constructor(
    private httpService: HttpService,
    private _toastService: ToastService,
    private _filterService: FilterService
  ) {}

  ngOnInit(): void {
    this.populateSections();
    this.filterSubscription = this._filterService
      .onChangeFilters()
      .subscribe(res => {
        this.filters = res;
        this.setFilter();
      });
  }

  populateSections(): void {
    // DATE SECTION
    this.sections = [
      {
        title: 'Date',
        isCollapsed: true
      },
      {
        title: 'Source',
        isCollapsed: true
      },
      {
        title: 'Content Types',
        isCollapsed: true
      }
    ];

    const dataYear = [
      {
        label: 'Past 1 Year',
        value: 12,
        id: 'y1'
      },
      {
        label: 'Past 2 Years',
        value: 24,
        id: 'y2'
      },
      {
        label: 'Past 3 Years',
        value: 36,
        id: 'y3'
      }
    ];

    const dataMonth = [
      {
        label: 'Past 1 Month',
        value: 1,
        id: 'm1'
      },
      {
        label: 'Past 2 Months',
        value: 2,
        id: 'm2'
      },
      {
        label: 'Past 3 Months',
        value: 3,
        id: 'm3'
      }
    ];

    this.dateSection = [
      {
        label: 'Year(s)',
        value: 'Y',
        name: 'timeType',
        id: 'type2',
        data: dataYear
      },
      {
        label: 'Month(s)',
        value: 'M',
        name: 'timeType',
        id: 'type1',
        data: dataMonth
      }
    ];

    // SOURCE SECTION
    this.sourceSection = [
      {
        label: 'All Sources',
        value: 'all',
        name: 'source_all',
        id: 'type1',
        className: 'mb-2'
      },
      {
        label: 'Internal Only',
        value: 'internal',
        name: 'source_internal',
        id: 'type2',
        className: 'mb-2'
      },
      {
        label: 'eDAM',
        value: 'edam',
        name: 'source_edam',
        id: 'type2.1',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'Galileo',
        value: 'galileo',
        name: 'source_galileo',
        id: 'type2.2',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'Web',
        value: 'web',
        name: 'source_web',
        id: 'type2.3',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'The Capital Ideas',
        value: 'thecapitalideas',
        name: 'source_thecapitalideas',
        id: 'type2.3.1',
        className: 'mb-2 ml-8 w-max'
      },
      {
        label: 'AF Advisor',
        value: 'americanfunds_advisor',
        name: 'source_americanfunds_advisor',
        id: 'type2.3.2',
        className: 'mb-2 ml-8 w-max'
      },
      {
        label: 'AF RIA',
        value: 'americanfunds_ria',
        name: 'source_americanfunds_ria',
        id: 'type2.3.3',
        className: 'mb-2 ml-8 w-max'
      },
      {
        label: 'AF Literature',
        value: 'americanfunds_literature',
        name: 'source_americanfunds_literature',
        id: 'type2.3.3',
        className: 'mb-2 ml-8 w-max'
      },
      {
        label: 'AF Investor',
        value: 'americanfunds_individual',
        name: 'source_americanfunds_individual',
        id: 'type2.3.4',
        className: 'mb-2 ml-8 w-max'
      },
      {
        label: 'AF Retirement',
        value: 'americanfunds_retirement',
        name: 'source_americanfunds_retirement',
        id: 'type2.3.5',
        className: 'mb-2 ml-8 w-max'
      },
      {
        label: 'AF Institutional',
        value: 'capitalgroup_us',
        name: 'source_capitalgroup_us',
        id: 'type2.3.6',
        className: 'mb-2 ml-8 w-max'
      },
      {
        label: 'All External',
        value: 'external',
        name: 'source_external',
        id: 'type3',
        className: 'mb-2'
      },
      {
        label: 'Fundfire',
        value: 'fundfire',
        name: 'source_fundfire',
        id: 'type3.1',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'Ignites',
        value: 'ignites',
        name: 'source_ignites',
        id: 'type3.2',
        className: 'mb-2 ml-4 w-max'
      }
    ];

    // CONTENT TYPE SECTION
    this.contentTypeSection = [
      {
        label: 'All Content Types',
        value: 'all',
        name: 'file_type_all',
        id: 'type1',
        className: 'mb-2'
      },
      {
        label: 'Pdf',
        value: 'pdf',
        name: 'file_type_pdf',
        id: 'type2',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'Image',
        value: 'image',
        name: 'file_type_image',
        id: 'type3',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'Chart',
        value: 'chart',
        name: 'file_type_chart',
        id: 'type4',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'Html',
        value: 'html',
        name: 'file_type_html',
        id: 'type5',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'Video',
        value: 'video',
        name: 'file_type_video',
        id: 'type6',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'Word',
        value: 'word',
        name: 'file_type_word',
        id: 'type7',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'PowerPoint',
        value: 'presentation',
        name: 'file_type_presentation',
        id: 'type8',
        className: 'mb-2 ml-4 w-max'
      },
      {
        label: 'InDesign',
        value: 'indd',
        name: 'file_type_indd',
        id: 'type9',
        className: 'mb-2 ml-4 w-max'
      }
    ];
  }

  outputDateSelection(): string {
    let selectedChoice = 'None selected';

    if (this.timeType && this.filters.time_filter_value) {
      selectedChoice = this.dateSection
        .filter(dateType => {
          if (this.timeType === dateType.value) {
            return dateType;
          }
        })
        .map(dateType => {
          for (let choice of dateType.data) {
            if (choice.value === this.filters.time_filter_value) {
              return choice;
            }
          }
        })[0].label;
    }

    return selectedChoice;
  }

  outputSourceSelection(): string {
    let selected = [];
    let selection = {
      internalIsSelected: false,
      internalId: null,
      externalIsSelected: false,
      externalId: null,
      webIsSelected: false,
      webId: null
    };

    for (let choice of this.sourceSection) {
      if (this.getIsChecked(choice.name)) {
        if (choice.value === 'all') {
          return choice.label;
        } else if (choice.value === 'internal') {
          selection.internalIsSelected = true;
          selection.internalId = choice.id;
          selected.push(choice.label);
          continue;
        } else if (choice.value === 'external') {
          selection.externalIsSelected = true;
          selection.externalId = choice.id;
          selected.push(choice.label);
          continue;
        } else if (choice.value === 'web' && !selection.internalIsSelected) {
          selection.webIsSelected = true;
          selection.webId = choice.id;
          selected.push(choice.label);
          continue;
        }
        if (
          (selection.internalIsSelected &&
            choice.id.startsWith(selection.internalId)) ||
          (selection.externalIsSelected &&
            choice.id.startsWith(selection.externalId)) ||
          (selection.webIsSelected && choice.id.startsWith(selection.webId))
        ) {
          continue;
        }
        selected.push(choice.label);
      }
    }

    if (!!selected.length) {
      return selected.join(', ');
    }

    return 'None selected';
  }

  getIsChecked(type: string): boolean {
    switch (type) {
      case 'source_all':
        return this.is_on_source_all;
      case 'source_internal':
        return this.is_on_source_internal;
      case 'source_external':
        return this.is_on_source_external;
      case 'source_edam':
        return this.is_on_source_edam;
      case 'source_web':
        return this.is_on_source_web;
      case 'source_americanfunds_advisor':
        return this.is_on_source_americanfunds_advisor;
      case 'source_americanfunds_ria':
        return this.is_on_source_americanfunds_ria;
      case 'source_americanfunds_literature':
        return this.is_on_source_americanfunds_literature;
      case 'source_thecapitalideas':
        return this.is_on_source_thecapitalideas;
      case 'source_fundfire':
        return this.is_on_source_fundfire;
      case 'source_ignites':
        return this.is_on_source_ignites;
      case 'source_americanfunds_individual':
        return this.is_on_source_americanfunds_individual;
      case 'source_americanfunds_retirement':
        return this.is_on_source_americanfunds_retirement;
      case 'source_capitalgroup_us':
        return this.is_on_source_capitalgroup_us;
      case 'source_galileo':
        return this.is_on_source_galileo;
      case 'file_type_all':
        return this.is_on_file_type_all;
      case 'file_type_pdf':
        return this.is_on_file_type_pdf;
      case 'file_type_image':
        return this.is_on_file_type_image;
      case 'file_type_chart':
        return this.is_on_file_type_chart;
      case 'file_type_html':
        return this.is_on_file_type_html;
      case 'file_type_video':
        return this.is_on_file_type_video;
      case 'file_type_word':
        return this.is_on_file_type_word;
      case 'file_type_presentation':
        return this.is_on_file_type_presentation;
      case 'file_type_indd':
        return this.is_on_file_type_indd;
      default:
        return false;
    }
  }

  outputContentTypeSelection(): string {
    let selected = [];

    for (let choice of this.contentTypeSection) {
      if (this.getIsChecked(choice.name)) {
        if (choice.value === 'all') {
          return choice.label;
        }
        selected.push(choice.label);
      }
    }

    if (!!selected.length) {
      return selected.join(', ');
    }
    return 'None selected';
  }

  hideFilter() {
    this.closed.emit();
  }

  apply() {
    this.loading = true;

    this.filters.file_type = this.getFileType();
    this.filters.source = this.getSourceType();
    this.filters.publication_from_date = moment()
      .subtract(Number.parseInt(this.filters.time_filter_value), 'months')
      .format('YYYY-MM-DD');
    this.filters.publication_to_date = moment().format('YYYY-MM-DD');
    const numMonths = moment(this.filters.publication_to_date).diff(
      this.filters.publication_from_date,
      'months'
    );
    this.filters.time_filter_value = numMonths;
    this.filters.apply_filter = true;

    this._filterService.saveFilters(this.filters);

    this.httpService.getDocuments().subscribe(
      results => {
        this.currentDateFilter = this.outputDateSelection();
        this.currentSourceFilter = this.outputSourceSelection();
        this.currentContentTypeFilter = this.outputContentTypeSelection();
        this.loading = false;
      },
      error => {
        this.loading = false;
        const json = JSON.parse(error._body);
        this._toastService.error(
          `Error: ${json.message ? json.message : json.code}`
        );
      }
    );

    setTimeout(() => {
      this.loading = false;
    }, 4000);
  }

  resetFilters(): void {
    this._filterService.resetFilters();
    this.filters = this._filterService.getFilters();

    this.is_on_file_type_all = false;
    this.is_on_file_type_pdf = false;
    this.is_on_file_type_image = false;
    this.is_on_file_type_chart = false;
    this.is_on_file_type_html = false;
    this.is_on_file_type_video = false;
    this.is_on_file_type_word = false;
    this.is_on_file_type_presentation = false;
    this.is_on_file_type_indd = false;

    this.is_on_source_all = false;
    this.is_on_source_internal = false;
    this.is_on_source_external = false;
    this.is_on_source_edam = false;
    this.is_on_source_web = false;
    this.is_on_source_americanfunds_advisor = false;
    this.is_on_source_americanfunds_ria = false;
    this.is_on_source_americanfunds_literature = false;
    this.is_on_source_thecapitalideas = false;
    this.is_on_source_fundfire = false;
    this.is_on_source_ignites = false;
    this.is_on_source_americanfunds_individual = false;
    this.is_on_source_americanfunds_retirement = false;
    this.is_on_source_capitalgroup_us = false;
    this.is_on_source_galileo = false;

    this.apply();
  }

  onFileType(type: string) {
    switch (type) {
      case 'all':
        this.is_on_file_type_all = !this.is_on_file_type_all;
        if (this.is_on_file_type_all) {
          this.is_on_file_type_pdf = true;
          this.is_on_file_type_image = true;
          this.is_on_file_type_chart = true;
          this.is_on_file_type_html = true;
          this.is_on_file_type_video = true;
          this.is_on_file_type_word = true;
          this.is_on_file_type_presentation = true;
          this.is_on_file_type_indd = true;
        } else {
          this.is_on_file_type_pdf = false;
          this.is_on_file_type_image = false;
          this.is_on_file_type_chart = false;
          this.is_on_file_type_html = false;
          this.is_on_file_type_video = false;
          this.is_on_file_type_word = false;
          this.is_on_file_type_presentation = false;
          this.is_on_file_type_indd = false;
        }
        break;
      case 'pdf':
        this.is_on_file_type_pdf = !this.is_on_file_type_pdf;
        break;
      case 'image':
        this.is_on_file_type_image = !this.is_on_file_type_image;
        break;
      case 'chart':
        this.is_on_file_type_chart = !this.is_on_file_type_chart;
        break;
      case 'html':
        this.is_on_file_type_html = !this.is_on_file_type_html;
        break;
      case 'video':
        this.is_on_file_type_video = !this.is_on_file_type_video;
        break;
      case 'word':
        this.is_on_file_type_word = !this.is_on_file_type_word;
        break;
      case 'presentation':
        this.is_on_file_type_presentation = !this.is_on_file_type_presentation;
        break;
      case 'indd':
        this.is_on_file_type_indd = !this.is_on_file_type_indd;
        break;
    }

    if (
      this.is_on_file_type_pdf === true &&
      this.is_on_file_type_image === true &&
      this.is_on_file_type_chart === true &&
      this.is_on_file_type_html === true &&
      this.is_on_file_type_video === true &&
      this.is_on_file_type_word === true &&
      this.is_on_file_type_presentation === true &&
      this.is_on_file_type_indd === true
    ) {
      this.is_on_file_type_all = true;
    }

    if (
      this.is_on_file_type_pdf === false ||
      this.is_on_file_type_image === false ||
      this.is_on_file_type_chart === false ||
      this.is_on_file_type_html === false ||
      (this.is_on_file_type_video === false &&
        this.is_on_file_type_word === false) ||
      this.is_on_file_type_presentation === false ||
      this.is_on_file_type_indd === false
    ) {
      this.is_on_file_type_all = false;
    }
  }

  onSourceType(source: string) {
    switch (source) {
      case 'all':
        this.is_on_source_all = !this.is_on_source_all;
        if (this.is_on_source_all) {
          this.is_on_source_internal = true;
          this.is_on_source_external = true;
          this.is_on_source_web = true;
          this.is_on_source_edam = true;
          this.is_on_source_americanfunds_advisor = true;
          this.is_on_source_americanfunds_ria = true;
          this.is_on_source_americanfunds_literature = true;
          this.is_on_source_thecapitalideas = true;
          this.is_on_source_external = true;
          this.is_on_source_fundfire = true;
          this.is_on_source_ignites = true;
          this.is_on_source_americanfunds_individual = true;
          this.is_on_source_americanfunds_retirement = true;
          this.is_on_source_capitalgroup_us = true;
          this.is_on_source_galileo = true;
        } else {
          this.is_on_source_internal = false;
          this.is_on_source_external = false;
          this.is_on_source_web = false;
          this.is_on_source_edam = false;
          this.is_on_source_americanfunds_advisor = false;
          this.is_on_source_americanfunds_ria = false;
          this.is_on_source_americanfunds_literature = false;
          this.is_on_source_thecapitalideas = false;
          this.is_on_source_external = false;
          this.is_on_source_fundfire = false;
          this.is_on_source_ignites = false;
          this.is_on_source_americanfunds_individual = false;
          this.is_on_source_americanfunds_retirement = false;
          this.is_on_source_capitalgroup_us = false;
          this.is_on_source_galileo = false;
        }
        break;
      case 'internal':
        this.is_on_source_internal = !this.is_on_source_internal;
        if (this.is_on_source_internal) {
          this.is_on_source_web = true;
          this.is_on_source_edam = true;
          this.is_on_source_americanfunds_advisor = true;
          this.is_on_source_americanfunds_ria = true;
          this.is_on_source_americanfunds_literature = true;
          this.is_on_source_thecapitalideas = true;
          this.is_on_source_americanfunds_individual = true;
          this.is_on_source_americanfunds_retirement = true;
          this.is_on_source_capitalgroup_us = true;
          this.is_on_source_galileo = true;
        } else {
          this.is_on_source_web = false;
          this.is_on_source_edam = false;
          this.is_on_source_americanfunds_advisor = false;
          this.is_on_source_americanfunds_ria = false;
          this.is_on_source_americanfunds_literature = false;
          this.is_on_source_thecapitalideas = false;
          this.is_on_source_americanfunds_individual = false;
          this.is_on_source_americanfunds_retirement = false;
          this.is_on_source_capitalgroup_us = false;
          this.is_on_source_galileo = false;
        }
        break;
      case 'external':
        this.is_on_source_external = !this.is_on_source_external;
        if (this.is_on_source_external) {
          this.is_on_source_fundfire = true;
          this.is_on_source_ignites = true;
        } else {
          this.is_on_source_fundfire = false;
          this.is_on_source_ignites = false;
        }
        break;
      case 'web':
        this.is_on_source_web = !this.is_on_source_web;
        if (this.is_on_source_web) {
          this.is_on_source_americanfunds_advisor = true;
          this.is_on_source_americanfunds_ria = true;
          this.is_on_source_americanfunds_literature = true;
          this.is_on_source_thecapitalideas = true;
          this.is_on_source_americanfunds_individual = true;
          this.is_on_source_americanfunds_retirement = true;
          this.is_on_source_capitalgroup_us = true;
        } else {
          this.is_on_source_americanfunds_advisor = false;
          this.is_on_source_americanfunds_ria = false;
          this.is_on_source_americanfunds_literature = false;
          this.is_on_source_thecapitalideas = false;
          this.is_on_source_americanfunds_individual = false;
          this.is_on_source_americanfunds_retirement = false;
          this.is_on_source_capitalgroup_us = false;
        }
        break;
      case 'edam':
        this.is_on_source_edam = !this.is_on_source_edam;
        break;
      case 'galileo':
        this.is_on_source_galileo = !this.is_on_source_galileo;
        break;
      case 'americanfunds_advisor':
        this.is_on_source_americanfunds_advisor = !this
          .is_on_source_americanfunds_advisor;
        break;
      case 'americanfunds_ria':
        this.is_on_source_americanfunds_ria = !this
          .is_on_source_americanfunds_ria;
        break;
      case 'americanfunds_literature':
        this.is_on_source_americanfunds_literature = !this
          .is_on_source_americanfunds_literature;
        break;
      case 'thecapitalideas':
        this.is_on_source_thecapitalideas = !this.is_on_source_thecapitalideas;
        break;
      case 'americanfunds_individual':
        this.is_on_source_americanfunds_individual = !this
          .is_on_source_americanfunds_individual;
        break;
      case 'americanfunds_retirement':
        this.is_on_source_americanfunds_retirement = !this
          .is_on_source_americanfunds_retirement;
        break;
      case 'capitalgroup_us':
        this.is_on_source_capitalgroup_us = !this.is_on_source_capitalgroup_us;
        break;
      case 'fundfire':
        this.is_on_source_fundfire = !this.is_on_source_fundfire;
        break;
      case 'ignites':
        this.is_on_source_ignites = !this.is_on_source_ignites;
        break;
    }

    if (!this.is_on_source_internal || !this.is_on_source_external) {
      this.is_on_source_all = false;
    }

    if (
      !this.is_on_source_edam ||
      !this.is_on_source_web ||
      !this.is_on_source_galileo
    ) {
      this.is_on_source_internal = false;
      this.is_on_source_all = false;
    }

    if (
      !this.is_on_source_americanfunds_advisor ||
      !this.is_on_source_americanfunds_ria ||
      !this.is_on_source_americanfunds_literature ||
      !this.is_on_source_thecapitalideas ||
      !this.is_on_source_americanfunds_individual ||
      !this.is_on_source_americanfunds_retirement ||
      !this.is_on_source_capitalgroup_us
    ) {
      this.is_on_source_web = false;
      this.is_on_source_internal = false;
      this.is_on_source_all = false;
    }

    if (
      this.is_on_source_americanfunds_advisor &&
      this.is_on_source_americanfunds_ria &&
      this.is_on_source_americanfunds_literature &&
      this.is_on_source_thecapitalideas &&
      this.is_on_source_americanfunds_individual &&
      this.is_on_source_americanfunds_retirement &&
      this.is_on_source_capitalgroup_us
    ) {
      this.is_on_source_web = true;
    }

    if (!this.is_on_source_fundfire || !this.is_on_source_ignites) {
      this.is_on_source_external = false;
      this.is_on_source_all = false;
    }
    if (this.is_on_source_fundfire && this.is_on_source_ignites) {
      this.is_on_source_external = true;
    }

    if (
      this.is_on_source_edam &&
      this.is_on_source_web &&
      this.is_on_source_galileo
    ) {
      this.is_on_source_internal = true;
    }

    if (this.is_on_source_internal && this.is_on_source_external) {
      this.is_on_source_all = true;
    }
  }

  getFileType() {
    let arr = [];

    if (this.is_on_file_type_all) {
      arr.push('all');
      return arr;
    }
    if (this.is_on_file_type_pdf) {
      arr.push('pdf');
    }
    if (this.is_on_file_type_image) {
      arr.push('image');
    }
    if (this.is_on_file_type_chart) {
      arr.push('chart');
    }
    if (this.is_on_file_type_html) {
      arr.push('html');
    }
    if (this.is_on_file_type_video) {
      arr.push('video');
    }
    if (this.is_on_file_type_word) {
      arr.push('word');
    }
    if (this.is_on_file_type_presentation) {
      arr.push('presentation');
    }
    if (this.is_on_file_type_indd) {
      arr.push('indd');
    }

    return arr;
  }

  getSourceType() {
    let arr = [];

    if (this.is_on_source_all) {
      arr.push('all');
      return arr;
    }

    if (!this.is_on_source_internal && this.is_on_source_edam) {
      arr.push('edam');
    }
    if (!this.is_on_source_internal && this.is_on_source_web) {
      arr.push('web');
    }
    if (!this.is_on_source_internal && this.is_on_source_galileo) {
      arr.push('galileo');
    }
    if (
      !this.is_on_source_internal &&
      !this.is_on_source_web &&
      this.is_on_source_americanfunds_advisor
    ) {
      arr.push('americanfunds_advisor');
    }
    if (
      !this.is_on_source_internal &&
      !this.is_on_source_web &&
      this.is_on_source_americanfunds_ria
    ) {
      arr.push('americanfunds_ria');
    }
    if (
      !this.is_on_source_internal &&
      !this.is_on_source_web &&
      this.is_on_source_americanfunds_literature
    ) {
      arr.push('americanfunds_literature');
    }
    if (
      !this.is_on_source_internal &&
      !this.is_on_source_web &&
      this.is_on_source_americanfunds_individual
    ) {
      arr.push('americanfunds_individual');
    }
    if (
      !this.is_on_source_internal &&
      !this.is_on_source_web &&
      this.is_on_source_americanfunds_retirement
    ) {
      arr.push('americanfunds_retirement');
    }
    if (
      !this.is_on_source_internal &&
      !this.is_on_source_web &&
      this.is_on_source_capitalgroup_us
    ) {
      arr.push('capitalgroup_us');
    }
    if (
      !this.is_on_source_internal &&
      !this.is_on_source_web &&
      this.is_on_source_thecapitalideas
    ) {
      arr.push('thecapitalideas');
    }

    if (this.is_on_source_external) {
      arr.push('external');
    }

    if (!this.is_on_source_external && this.is_on_source_fundfire) {
      arr.push('fundfire');
    }
    if (!this.is_on_source_external && this.is_on_source_ignites) {
      arr.push('ignites');
    }

    if (this.is_on_source_internal) {
      arr.push('internal');
    }
    return arr;
  }

  isChildAllSelected(itemValue) {
    return itemValue;
  }

  setFilter(): void {
    this.filters.time_filter_value = moment(
      this.filters.publication_to_date
    ).diff(this.filters.publication_from_date, 'months');
    if (this.filters.time_filter_value > 6) {
      this.timeType = 'Y';
    } else {
      this.timeType = 'M';
    }

    if (this.filters && this.filters.file_type) {
      this.is_on_file_type_all = false;
      this.is_on_file_type_pdf = false;
      this.is_on_file_type_image = false;
      this.is_on_file_type_chart = false;
      this.is_on_file_type_html = false;
      this.is_on_file_type_video = false;
      this.is_on_file_type_word = false;
      this.is_on_file_type_presentation = false;
      this.is_on_file_type_indd = false;

      this.filters.file_type.forEach(type => {
        switch (type) {
          case 'all':
            this.is_on_file_type_all = false;
            this.onFileType('all');
            break;
          case 'pdf':
            this.is_on_file_type_pdf = true;
            break;
          case 'image':
            this.is_on_file_type_image = true;
            break;
          case 'chart':
            this.is_on_file_type_chart = true;
            break;
          case 'html':
            this.is_on_file_type_html = true;
            break;
          case 'video':
            this.is_on_file_type_video = true;
            break;
          case 'word':
            this.is_on_file_type_word = true;
            break;
          case 'presentation':
            this.is_on_file_type_presentation = true;
            break;
          case 'indd':
            this.is_on_file_type_indd = true;
            break;
        }
      });

      let files_all = [
        this.is_on_file_type_pdf,
        this.is_on_file_type_image,
        this.is_on_file_type_chart,
        this.is_on_file_type_html,
        this.is_on_file_type_video,
        this.is_on_file_type_word,
        this.is_on_file_type_presentation,
        this.is_on_file_type_indd
      ];

      this.is_on_file_type_all = files_all.every(this.isChildAllSelected);
    }

    if (this.filters && this.filters.source) {
      this.is_on_source_all = false;
      this.is_on_source_internal = false;
      this.is_on_source_external = false;
      this.is_on_source_edam = false;
      this.is_on_source_web = false;
      this.is_on_source_americanfunds_advisor = false;
      this.is_on_source_americanfunds_ria = false;
      this.is_on_source_americanfunds_literature = false;
      this.is_on_source_thecapitalideas = false;
      this.is_on_source_fundfire = false;
      this.is_on_source_ignites = false;
      this.is_on_source_americanfunds_individual = false;
      this.is_on_source_americanfunds_retirement = false;
      this.is_on_source_capitalgroup_us = false;
      this.is_on_source_galileo = false;

      this.filters.source.forEach(source => {
        switch (source) {
          case 'all':
            this.is_on_source_all = true;
            this.is_on_source_internal = true;
            this.is_on_source_external = true;
            this.is_on_source_web = true;
            this.is_on_source_edam = true;
            this.is_on_source_americanfunds_advisor = true;
            this.is_on_source_americanfunds_ria = true;
            this.is_on_source_americanfunds_literature = true;
            this.is_on_source_thecapitalideas = true;
            this.is_on_source_external = true;
            this.is_on_source_fundfire = true;
            this.is_on_source_ignites = true;
            this.is_on_source_americanfunds_individual = true;
            this.is_on_source_americanfunds_retirement = true;
            this.is_on_source_capitalgroup_us = true;
            this.is_on_source_galileo = true;
            break;
          case 'internal':
            this.is_on_source_internal = true;
            this.is_on_source_web = true;
            this.is_on_source_edam = true;
            this.is_on_source_americanfunds_advisor = true;
            this.is_on_source_americanfunds_ria = true;
            this.is_on_source_americanfunds_literature = true;
            this.is_on_source_thecapitalideas = true;
            this.is_on_source_americanfunds_individual = true;
            this.is_on_source_americanfunds_retirement = true;
            this.is_on_source_capitalgroup_us = true;
            break;
          case 'external':
            this.is_on_source_external = true;
            this.is_on_source_fundfire = true;
            this.is_on_source_ignites = true;
            break;
          case 'web':
            this.is_on_source_web = true;
            this.is_on_source_americanfunds_advisor = true;
            this.is_on_source_americanfunds_ria = true;
            this.is_on_source_americanfunds_literature = true;
            this.is_on_source_thecapitalideas = true;
            this.is_on_source_americanfunds_individual = true;
            this.is_on_source_americanfunds_retirement = true;
            this.is_on_source_capitalgroup_us = true;
            break;
          case 'edam':
            this.is_on_source_edam = true;
            break;
          case 'galileo':
            this.is_on_source_galileo = true;
            break;
          case 'americanfunds_advisor':
            this.is_on_source_americanfunds_advisor = true;
            break;
          case 'americanfunds_ria':
            this.is_on_source_americanfunds_ria = true;
            break;
          case 'americanfunds_literature':
            this.is_on_source_americanfunds_literature = true;
            break;
          case 'americanfunds_advisor':
            this.is_on_source_americanfunds_advisor = true;
            break;
          case 'americanfunds_individual':
            this.is_on_source_americanfunds_individual = true;
            break;
          case 'americanfunds_retirement':
            this.is_on_source_americanfunds_retirement = true;
            break;
          case 'capitalgroup_us':
            this.is_on_source_capitalgroup_us = true;
            break;
          case 'thecapitalideas':
            this.is_on_source_thecapitalideas = true;
            break;
          case 'fundfire':
            this.is_on_source_fundfire = true;
            break;
          case 'ignites':
            this.is_on_source_ignites = true;
            break;
        }
      });
    }

    let web_all = [
      this.is_on_source_americanfunds_advisor,
      this.is_on_source_americanfunds_ria,
      this.is_on_source_americanfunds_literature,
      this.is_on_source_thecapitalideas,
      this.is_on_source_americanfunds_individual,
      this.is_on_source_americanfunds_retirement,
      this.is_on_source_capitalgroup_us
    ];

    let external_all = [this.is_on_source_fundfire, this.is_on_source_ignites];

    this.is_on_source_external = external_all.every(this.isChildAllSelected);
    this.is_on_source_web = web_all.every(this.isChildAllSelected);

    //this needs to come after web
    let internal_all = [
      this.is_on_source_web,
      this.is_on_source_edam,
      this.is_on_source_galileo
    ];

    this.is_on_source_internal = internal_all.every(this.isChildAllSelected);

    let sources_all = [this.is_on_source_internal, this.is_on_source_external];

    this.is_on_source_all = sources_all.every(this.isChildAllSelected);

    this.currentDateFilter = this.outputDateSelection();
    this.currentSourceFilter = this.outputSourceSelection();
    this.currentContentTypeFilter = this.outputContentTypeSelection();
  }

  reset(): void {
    this.panel.reset();
  }

  ngOnDestroy(): void {
    this.filterSubscription.unsubscribe();
  }
}
