import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { HttpService } from '../../_services/http.service';
import { ResultService } from '../../_services/result.service';
import { AnalyticsService } from '../../_services/analytics.service';
import { ToastService } from '../../core/toast/toast.service';
import { AppConfig } from 'app/app.config';

@Component({
  selector: 'daa-search-result-item',
  templateUrl: './search-result-item.component.html'
})
export class SearchResultItemComponent {
  results: any;
  resultSubscription: Subscription;
  sub: any;
  workfrontUrl: any;
  ratings = [];

  constructor(
    private httpService: HttpService,
    private _resultService: ResultService,
    private _analyticsService: AnalyticsService,
    private _toastService: ToastService,
    private configService: AppConfig
  ) {}

  ngOnInit() {
    this.initRating();
    this.resultSubscription = this._resultService
      .onChangeResults()
      .subscribe(res => {
        if (res) {
          this.loadDocuments(res);
        }
      });
    const config = this.configService.getConfigData();
    this.workfrontUrl = config.workfront_url;
  }

  getPath(path): string {
    let activePath = '';
    if (path) {
      if (path.startsWith('https')) {
        activePath = path.replace('https://', '');
      } else {
        activePath = path.replace('http://', '');
      }

      if (activePath.length > 60) {
        const startPos = activePath.indexOf('/');
        const endPos = activePath.lastIndexOf('/') + 1;
        const replaceStr = activePath.substring(startPos, endPos);
        activePath = activePath.replace(replaceStr, '/.../');
      }
    }

    return activePath;
  }

  private initRating(): void {
    this.ratings = [
      {
        name: 'Not Helpful',
        type: 'dislike',
        icon: 'daa-icn-notuseful'
      },
      {
        name: 'Not Sure',
        type: 'neutral',
        icon: 'daa-icn-notsure'
      },
      {
        name: 'Good',
        type: 'like',
        icon: 'daa-icn-good'
      },
      {
        name: 'Great',
        type: 'vlike',
        icon: 'daa-icn-great'
      }
    ];
  }

  private getDoc(doc: string) {
    doc = doc.substr(doc.lastIndexOf('/') + 1);
    let docName = doc.split('.');
    // return '['+ docName.pop().toUpperCase() +'] ' + docName.join('.');
    return docName.pop() + ' ' + docName.join('.');
  }

  checkNumWord(txt: string, num: number) {
    return txt.split(' ').length > num ? true : false;
  }

  reduceText(txt: string, num: number) {
    return txt
      .split(/\s+/)
      .slice(0, num)
      .join(' ');
  }

  getExtension(txt: string) {
    return txt.slice(txt.lastIndexOf('.') + 1);
  }

  private ifArray(data) {
    return Array.isArray(data);
  }

  private loadDocuments(res) {
    this.results = this.addTruncatedText(res);
  }

  addTruncatedText(res) {
    for (let record of res.records) {
      for (let snippet of record.snippets) {
        snippet.preview = this.checkNumWord(snippet.text, 60)
          ? this.reduceText(snippet.text, 60)
          : false;
      }
    }

    return res;
  }

  private sendSnippetFeedback(
    event: any,
    queryId: number,
    doc: any,
    snippet: any,
    feedback: string
  ) {
    // this.hideFeedbackOptions(event);
    snippet.feedback = feedback;

    this.httpService
      .sendFeedback(
        queryId,
        doc.jdoc_id,
        snippet.section_id,
        'snippet',
        snippet.feedback
      )
      .subscribe(
        response => {
          this._toastService.success(response.message);
        },
        error => {
          let json = JSON.parse(error._body);
          this._toastService.error(
            `Error: ${json.message ? json.message : json.code}`
          );
        }
      );
  }

  displayFile(docId: string) {
    const extn = docId.substr(docId.lastIndexOf('.') + 1).toLowerCase();
    this.httpService.displayFile(docId, extn).subscribe(res => {
      const fileURL = URL.createObjectURL(res);
      window.open(fileURL); // if you want to open it in new tab
    });
  }

  checkType(type: string) {
    type = type.toLowerCase();
    if (type === 'edam' || type === 'literature center') return 'pdf';
    else return 'html';
  }

  openFile(path: string) {
    window.open(path);
  }

  ngOnDestroy() {
    this.resultSubscription.unsubscribe();
  }

  recordAnalytics(title: string) {
    this._analyticsService.recordSnippetClick(title);
  }

  showFeedbackOptions(el) {
    let feedbackOptions = el.target.closest('.feedback').children;
    // console.log(feedbackOptions);
    for (let i = 0; i < feedbackOptions.length; i++) {
      feedbackOptions[i].classList.remove('feedback-rating-hide');
    }
  }

  hideFeedbackOptions(el) {
    let feedbackOptions = el.target.closest('.feedback').children;
    // console.log(feedbackOptions);
    for (let i = 0; i < feedbackOptions.length; i++) {
      if (
        !feedbackOptions[i].classList.contains('feedback-rating-show') &&
        !feedbackOptions[i].classList.contains('rate-text')
      ) {
        feedbackOptions[i].classList.add('feedback-rating-hide');
      }
    }
  }

  /*addToCollection(jdoc_id :string, btn: any) {
    btn.path[1].disabled = true;
    for(let record of this.results.records) {
    	if (jdoc_id == record.jdoc_id) {
	      this.httpService.addCollectionRecord(record).subscribe(
	      	response => {
	          this._toastService.success(response.messages);
	      	},
	      	error => {
	          this._toastService.error(error);
	      	}
	    );
    }
  }
}*/
}
