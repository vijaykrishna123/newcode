import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { FilterService } from '../../_services/filter.service';
import { HttpService } from '../../_services/http.service';

@Component({
  selector: 'daa-search-sort-dropdown',
  templateUrl: './search-sort-dropdown.component.html'
})
export class SearchSortDropdownComponent  {

  filterSubscription: Subscription;

  radios = [ 
    {
        value: "relevance",
        label: "Most Relevant",
        checked: false
    },
    {
        value: "date",
        label: 'Date',
        checked: false
    }];

   
  constructor( private _filterService: FilterService,
               private httpService: HttpService ) {
  }

   ngOnInit() {

      this.filterSubscription = this._filterService.onChangeFilters().subscribe(res => {

        this.radios[0]['checked'] = false;
        this.radios[1]['checked'] = false;
        (res['sort_order'] === 'relevance')? this.radios[0]['checked'] = true :  this.radios[1]['checked'] = true;
      });
   }


   change(o){

    this._filterService.saveFilters({
      sort_order: o
    });

    this.httpService.getDocuments().subscribe(
      results => {
      }, error => {
      });
   }


   ngOnDestroy() {
    this.filterSubscription.unsubscribe();
  }
}
