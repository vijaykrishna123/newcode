import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpService } from '../_services/http.service';
import { ResultService } from '../_services/result.service';
import { FilterService } from '../_services/filter.service';
import { LoadingService } from '../_services/loading.service';
import { LoadingModule } from 'ngx-loading';

import { AngularMaterialModule } from './angular-material.module';
import { NgxBootstrapModule } from './ngxBootstrap.module';
import { DialogModule } from './dialogs/dialog.module';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

import { ResponseTimePipe } from '../_pipes/response-time.pipe';
import { FocusDirective } from '../_directives/focus.directive';


import { SearchFilterComponent } from './search-filter/search-filter.component';
import { SearchFieldComponent } from './search-field/search-field.component';
import { SearchChipsComponent } from './search-chips/search-chips.component';
import { SearchSortDropdownComponent } from './search-sort-dropdown/search-sort-dropdown.component';
import { PanelToggleComponent } from './panel-toggle/panel-toggle.component';
import { SearchResultItemComponent } from './search-result-item/search-result-item.component';

import { NguiAutoCompleteModule } from '@ngui/auto-complete';

@NgModule({
  imports: [
    CommonModule,
    AngularMaterialModule,
    NgxBootstrapModule,
    FormsModule,
    PerfectScrollbarModule,
    LoadingModule,
    DialogModule,
    NguiAutoCompleteModule
  ],
  exports: [ AngularMaterialModule, DialogModule, SearchFilterComponent, SearchFieldComponent, SearchChipsComponent, SearchSortDropdownComponent, ResponseTimePipe, PanelToggleComponent, SearchResultItemComponent ],
  declarations: [ SearchFilterComponent, SearchFieldComponent, SearchChipsComponent, SearchSortDropdownComponent, ResponseTimePipe, PanelToggleComponent, FocusDirective, SearchResultItemComponent ],
  providers: [
    HttpService,
    ResultService,
    FilterService,
    LoadingService
  ]
})
export class SharedModule {}
