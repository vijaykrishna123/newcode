{"contextHubData": {
"pageStore": {"category":{"audience":"DAA","brand":"The Capital Group","channel":"The Capital Group - DAA","country":"us","language":"en"},"info":{"breadCrumbList":["daa","FAQs"],"destinationUrl":"/about","name":"daa &gt; FAQs"}}
, "eventStore": {}
, "clientSideHandlerStore": {}
}}