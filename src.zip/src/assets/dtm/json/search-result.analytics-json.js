{"contextHubData": {
"pageStore": {"category":{"audience":"DAA","brand":"The Capital Group","channel":"The Capital Group - DAA","country":"us","language":"en"},"info":{"breadCrumbList":["daa","search"],"destinationUrl":"/search-results","name":"daa &gt; search-results"}}
, "eventStore": {}
, "clientSideHandlerStore": {}
}}