{"contextHubData": {
"pageStore": {"category":{"audience":"DAA","brand":"The Capital Group","channel":"The Capital Group - DAA","country":"us","language":"en"},"info":{"breadCrumbList":["daa","Search"],"destinationUrl":"/content/sites/the-capital-group/daa/us/en/home/search.html","name":"daa &gt; Search"}}
, "eventStore": {}
, "clientSideHandlerStore": {}
}}