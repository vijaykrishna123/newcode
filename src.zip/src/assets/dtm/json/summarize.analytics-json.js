{"contextHubData": {
"pageStore": {"category":{"audience":"DAA","brand":"The Capital Group","channel":"The Capital Group - DAA","country":"us","language":"en"},"info":{"breadCrumbList":["daa","Summarize"],"destinationUrl":"/summarization","name":"daa &gt; Summarize"}}
, "eventStore": {}
, "clientSideHandlerStore": {}
}}