export const environment = {
  production: true,
  envName: 'prod',
  host: 'a2imds4v2-2.eastus.cloudapp.azure.com',
  port: '443',
  appId:'daaApp',
  appPassword:'We can do IT.',
  authority:'https://capgroup-dev.oktapreview.com/',
  client_id:'0oaduxfkfkjLxswnW0h7',
  redirect_uri:'https://daa.dev.capgroup.com/auth-callback',
  post_logout_redirect_uri:'https://daa.dev.capgroup.com/',
  response_type:'id_token token',
  scope:'openid profile',
  filterProtocolClaims:true,
  loadUserInfo:true,
  automaticSilentRenew:true,
  includeAnalytics:true

};
